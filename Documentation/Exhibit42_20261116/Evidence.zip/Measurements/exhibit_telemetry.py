import argparse
import ctypes as c
import json
from pathlib import Path
import shutil
import subprocess
import time


ROOT=Path(__file__).resolve().parent
PM=Path("C:/Program Files/Epic Games/UE_5.8/Engine/Binaries/ThirdParty/PresentMon/Win64/PresentMon-1.8.0-x64.exe")


def hidden(args,stdout,stderr):
    with stdout.open("wb") as out,stderr.open("wb") as err:
        return subprocess.Popen(args,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)


def clock_snapshot():
    q=c.c_longlong(); f=c.c_longlong()
    c.windll.kernel32.QueryPerformanceFrequency(c.byref(f))
    a=time.time_ns()
    c.windll.kernel32.QueryPerformanceCounter(c.byref(q))
    b=time.time_ns()
    return {"qpc":q.value,"frequency":f.value,"utc_epoch_ns":(a+b)//2,"window_ns":b-a}


def start(folder):
    folder.mkdir(exist_ok=True)
    config=folder/"telemetry.json"
    if config.exists():raise ValueError("Output already exists")
    session="KDExhibit42_"+str(int(time.time()))
    output=folder/"presents_native.csv"
    # PresentMon's process-name filter attaches to later starts as well.
    pm=hidden([str(PM),"-session_name",session,"-process_name","myProject-Win64-Shipping.exe","-qpc_time","-output_file",str(output),"-no_top"],folder/"pm.stdout",folder/"pm.stderr")
    smi=hidden([shutil.which("nvidia-smi.exe"),"--query-gpu=timestamp,name,pstate,clocks.gr,clocks.mem,memory.used,memory.total,utilization.gpu,temperature.gpu,power.draw","--format=csv","-lms","1000"],folder/"gpu_native.csv",folder/"gpu.stderr")
    rec={"presentmon_pid":pm.pid,"smi_pid":smi.pid,"session":session,"csv":str(output),"start":clock_snapshot()}
    config.write_text(json.dumps(rec,indent=2),encoding="utf8")
    time.sleep(.45)
    if pm.poll() is not None:raise RuntimeError("PresentMon failed")
    print(json.dumps(rec),flush=True)


def stop(folder):
    config=folder/"telemetry.json"
    rec=json.loads(config.read_text("utf8"))
    subprocess.run([str(PM),"-terminate_existing","-session_name",rec["session"]],creationflags=subprocess.CREATE_NO_WINDOW)
    subprocess.run(["powershell.exe","-NoProfile","-NonInteractive","-Command",
                    "$p=Get-Process -Id "+str(int(rec["smi_pid"]))+" -ErrorAction SilentlyContinue; if ($p -and $p.ProcessName -eq 'nvidia-smi') {Stop-Process -Id $p.Id}"],
                   creationflags=subprocess.CREATE_NO_WINDOW)
    rec["end"]=clock_snapshot()
    config.write_text(json.dumps(rec,indent=2),encoding="utf8")
    print("Stopped "+rec["session"])


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("mode",choices=("start","stop"))
    parser.add_argument("folder",type=Path)
    args=parser.parse_args()
    (start if args.mode=="start" else stop)(ROOT/args.folder)
