import argparse
import collections
import csv
import json
import math
from pathlib import Path
import statistics as st

ROOT=Path(__file__).resolve().parent
FRAME=1000/60


def stats(items):
    items=sorted(items)
    at=lambda q: round(items[math.ceil(q*len(items))-1],4)
    if not items:
        return {"n":0}
    return {"n":len(items),"fps":round(1000/st.mean(items),3),"mean_ms":round(st.mean(items),4),
            "p95_ms":at(.95),"p99_ms":at(.99),"max_ms":round(max(items),4),
            "over16p67":sum(v>FRAME for v in items),"over17p2":sum(v>17.2 for v in items),
            "over20":sum(v>20 for v in items),"over25":sum(v>25 for v in items),
            "over33p33":sum(v>FRAME*2 for v in items)}


def inspect(folder):
    events=[json.loads(line) for line in (folder/"events.jsonl").read_text("utf8").splitlines()]
    freq=next(x["qpc_frequency"] for x in events if x["event"]=="session")
    frames_by_pid=collections.defaultdict(list)
    for fil in sorted(folder.glob("presents_*.csv")):
        with fil.open(encoding="utf-8-sig",newline="") as f:
            for row in csv.DictReader(f):
                if not row.get("QPCTime"):
                    continue
                frames_by_pid[int(row["ProcessID"])].append(row)
    results=[]
    regions=[]
    for begin in [e for e in events if e["event"]=="run_begin"]:
        lab=begin["lap"]
        end=next((e for e in events if e["event"]=="run_end" and e["lap"]==lab and e["qpc"]>begin["qpc"]),None)
        if not end:continue
        stop=end["qpc"]
        verified=next((e for e in events if e["event"]=="run_verified" and e["lap"]==lab and e["qpc"]>=stop),None)
        stages=[e for e in events if e["event"]=="leg" and not e["reverse"] and begin["qpc"]<=e["qpc"]<stop]
        allrows=frames_by_pid[begin["pid"]]
        samples=[r for r in allrows if begin["qpc"]<=int(r["QPCTime"])<=stop]
        if not samples:continue
        chains=collections.Counter(r["SwapChainAddress"] for r in samples)
        dxgi=collections.Counter(r["SwapChainAddress"] for r in samples if r["Runtime"]=="DXGI" and int(r["SwapChainAddress"],16)!=0)
        main=max(dxgi,key=dxgi.get) if dxgi else max(chains,key=chains.get)
        samples=[r for r in samples if r["SwapChainAddress"]==main]
        info={"lap":lab,"pid":begin["pid"],"route_s":round((stop-begin["qpc"])/freq,3),
              "route_verified":bool(verified),"swapchains":dict(chains),"swapchain":main,
              "present_modes":dict(collections.Counter(r["PresentMode"] for r in samples)),
              "dropped":sum(r["Dropped"]=="1" for r in samples)}
        for part,start,finish in [("all",begin["qpc"],stop)]+[(s["source"]+"-"+s["destination"],s["qpc"],(stages[i+1]["qpc"] if i+1<len(stages) else stop)) for i,s in enumerate(stages)]:
            seen=set()
            presented=[]
            shown=[]
            completed=[]
            unit=freq/1000
            completed_times=[]
            for r in allrows:
                if r["SwapChainAddress"]!=main:continue
                q=int(r["QPCTime"])
                if q<start-freq or q>finish or q in seen:continue
                seen.add(q)
                interval=float(r["msBetweenPresents"])
                if q<=finish and q-interval*unit>=start and interval>0:
                    presented.append(interval)
                d=float(r.get("msUntilDisplayed") or 0)
                displayed=q+d*unit
                interval=float(r.get("msBetweenDisplayChange") or 0)
                if r["Dropped"]=="0" and d>0 and interval>0 and start<=displayed-interval*unit and displayed<=finish:
                    shown.append(interval)
                j=float(r.get("msUntilRenderComplete") or 0)
                if j>0:
                    completed_times.append(q+j*unit)
            completed_times.sort()
            completed=[(b-a)/unit for a,b in zip(completed_times,completed_times[1:]) if start<=a and b<=finish and b>a]
            met={k:stats(v) for k,v in [("present",presented),("display",shown),("render_complete",completed)]}
            if part=="all":
                info.update(met)
            else:
                regions.append(dict(lap=lab,region=part,**met))
        results.append(info)
    (folder/"measured.json").write_text(json.dumps({"walks":results,"regions":regions},indent=2),encoding="utf8")
    for filename,rows in (("walks.csv",results),("segments.csv",regions)):
        flat=[]
        for v in rows:
            out={}
            for k,a in v.items():
                if k in ("present","display","render_complete"):
                    out.update({k+"_"+x:y for x,y in a.items()})
                else:out[k]=a
            flat.append(out)
        if flat:
            with (folder/filename).open("w",newline="",encoding="utf-8-sig") as f:
                writer=csv.DictWriter(f,fieldnames=list(dict.fromkeys(k for row in flat for k in row)))
                writer.writeheader()
                writer.writerows(flat)
    return results


if __name__=="__main__":
    args=argparse.ArgumentParser()
    args.add_argument("directory")
    for r in inspect(ROOT/args.parse_args().directory):
        print(r["lap"],r["route_verified"],r["present"],r["display"],flush=True)
