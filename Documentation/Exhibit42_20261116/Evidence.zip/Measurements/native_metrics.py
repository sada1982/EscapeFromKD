import argparse
import collections
import csv
import datetime
import json
import math
from pathlib import Path
import re
from statistics import mean

from exhibit_metrics import inspect, stats
from exhibit_telemetry import ROOT


def read_csv(path):
    return list(csv.DictReader(path.open(encoding="utf-8-sig",newline="")))


def write_csv(path,rows):
    if not rows:return
    with path.open("w",encoding="utf-8-sig",newline="") as output:
        w=csv.DictWriter(output,fieldnames=list(dict.fromkeys(k for r in rows for k in r)))
        w.writeheader()
        w.writerows(rows)


def xyz(r):return [float(r[k]) for k in ("x","y","z")]


def process(directory):
    root=ROOT/directory
    obs=root/"route"
    ev=read_csv(obs/"events.csv")
    raw=read_csv(obs/"frames.csv")
    mon=json.loads((root/"telemetry.json").read_text("utf8"))
    launch=json.loads((root/"launch_native.json").read_text("utf8"))
    isolated=json.loads((obs/"isolation.json").read_text("utf8"))
    freq=mon["start"]["frequency"]
    pid=int(isolated["pid"])
    laps={}
    bridge=[dict(event="session",pid=pid,qpc_frequency=freq)]
    waypoints=[(402,-890),(-117,-890),(-117,109),(-876,109),(-876,308),(-1635,308),(-1635,189),(-2154,189)]
    names=["classroom_aisle","classroom_exit","gallery","connector","lobby_turn","stair_approach","stair_turn","downstairs"]
    all_intervals={"First":[],"Warm pooled":[]}
    output_frames=[]
    for no in sorted(set(int(r["lap"]) for r in ev if r["event"]=="lap_start")):
        events=[r for r in ev if int(r["lap"])==no]
        a=next(r for r in events if r["event"]=="lap_start")
        ends=[r for r in events if r["event"]=="lap_end"]
        if not ends:continue
        end=ends[-1]
        start_q=int(a["qpc"]);end_q=int(end["qpc"])
        label="First" if no==1 else f"Warm{no-1:02d}"
        reached=[r for r in events if r["event"]=="waypoint"]
        pathok=len(reached)==8 and [int(r["leg"]) for r in reached]==list(range(8))
        errors=[math.dist(xyz(r)[:2],waypoints[int(r["leg"])]) for r in reached]
        valid=pathok and max(errors)<46 and float(end["z"])<-58 and abs(float(a["z"])-98.15)<4
        bridge.append(dict(event="run_begin",lap=label,pid=pid,qpc=start_q))
        for leg in range(8):
            previous=[r for r in reached if int(r["leg"])==leg-1]
            if leg and not previous:continue
            bridge.append(dict(event="leg",lap=label,source=names[leg],destination=str(leg+1),reverse=False,
                               qpc=int(previous[-1]["qpc"]) if leg else start_q))
        bridge.append(dict(event="run_end",lap=label,pid=pid,qpc=end_q))
        if valid:bridge.append(dict(event="run_verified",lap=label,pid=pid,qpc=end_q))
        rows=[r for r in raw if int(r["lap"])==no and start_q<=int(r["qpc"])<=end_q]
        intervals=[(int(b["qpc"])-int(a0["qpc"]))*1000/freq for a0,b in zip(rows,rows[1:])]
        all_intervals["First" if no==1 else "Warm pooled"]+=intervals
        for r0,ms in zip(rows[1:],intervals):
            output_frames.append(dict(lap=label,region=names[int(r0["leg"])],tick_interval_ms=round(ms,4),**{k:v for k,v in r0.items() if k!="lap"}))
        laps[label]={"lap":label,"route_verified":valid,"n_waypoints":len(reached),"start_cm":xyz(a),"end_cm":xyz(end),
                     "max_waypoint_xy_error_cm":round(max(errors),2) if errors else None,
                     "walk_s":round((end_q-start_q)/freq,4),"qpc_start":start_q,"qpc_end":end_q,"engine_tick":stats(intervals)}
    (root/"events.jsonl").write_text("\n".join(json.dumps(r) for r in bridge)+"\n",encoding="utf8")
    write_csv(root/"engine_ticks.csv",output_frames)
    result=inspect(root)
    for r in result:
        laps[r["lap"]].update({k:r[k] for k in ("present","display","render_complete","dropped","present_modes")})
    raw_presents=read_csv(root/"presents_native.csv")
    pooled={"First":[],"Warm pooled":[]}
    for row in result:
        record=laps[row["lap"]]
        for r in raw_presents:
            if r["Runtime"]!="DXGI" or r["SwapChainAddress"]!=row["swapchain"] or int(r["ProcessID"])!=pid:
                continue
            interval=float(r["msBetweenPresents"])
            q=int(r["QPCTime"])
            if interval>0 and q-interval*freq/1000>=record["qpc_start"] and q<=record["qpc_end"]:
                pooled["First" if row["lap"]=="First" else "Warm pooled"].append(interval)
    condition=[]
    for kind,intervals in pooled.items():
        metric=stats(intervals)
        condition.append({"condition":kind,**{"present_"+k:v for k,v in metric.items()},
                          **{"engine_"+k:v for k,v in stats(all_intervals[kind]).items()}})
    write_csv(root/"condition_summary.csv",condition)
    gpu=read_csv(root/"gpu_native.csv")
    wall=lambda q: mon["start"]["utc_epoch_ns"]/1e9+(q-mon["start"]["qpc"])/freq
    for lap in laps.values():
        samples=[]
        for row in gpu:
            row={k.strip():v.strip() for k,v in row.items() if k and v}
            try:
                t=datetime.datetime.strptime(row["timestamp"],"%Y/%m/%d %H:%M:%S.%f").timestamp()
            except (KeyError,ValueError):continue
            if wall(lap["qpc_start"])<=t<=wall(lap["qpc_end"]):
                samples.append(row)
        if samples:
            def get(column):
                return [float(next(v for k,v in row.items() if k.startswith(column)).split()[0]) for row in samples]
            lap["whole_gpu"]={"samples":len(samples),"memory_mib_range":[min(get("memory.used")),max(get("memory.used"))],
                              "gpu_percent_range":[min(get("utilization.gpu")),max(get("utilization.gpu"))],
                              "gpu_percent_mean":round(mean(get("utilization.gpu")),1)}
    output={"laps":list(laps.values()),"engine_tick_pooled":{k:stats(v) for k,v in all_intervals.items()},
            "present_pooled":{k:stats(v) for k,v in pooled.items()},
            "private_desktop":isolated["desktop"],"input_desktop_start":isolated["input_desktop_start"],
            "input_desktop_end":isolated.get("input_desktop_end"),"game_pid":pid,
            "engine_result":(obs/"result.txt").read_text("utf-8-sig").strip()}
    (root/"route_summary.json").write_text(json.dumps(output,ensure_ascii=False,indent=2),encoding="utf8")
    print(json.dumps({"lap_summary":[[r["lap"],r["route_verified"],r["engine_tick"].get("fps"),r.get("present",{}).get("fps"),r.get("display",{}).get("n"),r["end_cm"]] for r in laps.values()],"result":output["engine_result"]},ensure_ascii=True))
    return output


if __name__=="__main__":
    p=argparse.ArgumentParser()
    p.add_argument("directory")
    process(p.parse_args().directory)
