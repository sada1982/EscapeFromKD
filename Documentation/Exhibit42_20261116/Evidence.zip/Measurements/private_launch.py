"""Launch the packaged UE process on a private Win32 desktop and leave the input desktop untouched."""
import argparse
import ctypes as c
from ctypes import wintypes as w
import datetime,json,os
from pathlib import Path
import subprocess
import time
import uuid

u=c.WinDLL('user32',use_last_error=True)
k=c.WinDLL('kernel32',use_last_error=True)
class Startup(c.Structure):
    _fields_=[('cb',w.DWORD),('reserved',w.LPWSTR),('desktop',w.LPWSTR),('title',w.LPWSTR),
              ('x',w.DWORD),('y',w.DWORD),('xs',w.DWORD),('ys',w.DWORD),
              ('xc',w.DWORD),('yc',w.DWORD),('fill',w.DWORD),('flags',w.DWORD),
              ('show',w.WORD),('bytes',w.WORD),('reserved2',c.c_void_p),
              ('stdin',w.HANDLE),('stdout',w.HANDLE),('stderr',w.HANDLE)]
class Info(c.Structure):
    _fields_=[('process',w.HANDLE),('thread',w.HANDLE),('pid',w.DWORD),('tid',w.DWORD)]
u.CreateDesktopW.argtypes=[w.LPCWSTR,w.LPCWSTR,c.c_void_p,w.DWORD,w.DWORD,c.c_void_p]
u.CreateDesktopW.restype=w.HANDLE
u.OpenInputDesktop.argtypes=[w.DWORD,w.BOOL,w.DWORD];u.OpenInputDesktop.restype=w.HANDLE
u.GetUserObjectInformationW.argtypes=[w.HANDLE,c.c_int,c.c_void_p,w.DWORD,c.POINTER(w.DWORD)]
u.CloseDesktop.argtypes=[w.HANDLE]
k.CreateProcessW.argtypes=[w.LPCWSTR,w.LPWSTR,c.c_void_p,c.c_void_p,w.BOOL,w.DWORD,c.c_void_p,w.LPCWSTR,c.POINTER(Startup),c.POINTER(Info)]
k.WaitForSingleObject.argtypes=[w.HANDLE,w.DWORD];k.WaitForSingleObject.restype=w.DWORD
k.GetExitCodeProcess.argtypes=[w.HANDLE,c.POINTER(w.DWORD)]
k.CloseHandle.argtypes=[w.HANDLE]
u.GetWindowThreadProcessId.argtypes=[w.HWND,c.POINTER(w.DWORD)]
u.IsWindowVisible.argtypes=[w.HWND]
u.GetClientRect.argtypes=[w.HWND,c.POINTER(w.RECT)]
enumproc=c.WINFUNCTYPE(w.BOOL,w.HWND,w.LPARAM)
u.EnumDesktopWindows.argtypes=[w.HANDLE,enumproc,w.LPARAM]
def check(cond):
    if not cond:raise c.WinError(c.get_last_error())
def name_of(h):
    buf=c.create_unicode_buffer(512);n=w.DWORD()
    check(u.GetUserObjectInformationW(h,2,buf,c.sizeof(buf),c.byref(n)))
    return buf.value
def input_desktop():
    d=u.OpenInputDesktop(0,False,1)
    if not d:return 'unavailable'
    try:return name_of(d)
    finally:u.CloseDesktop(d)
def windows(h,pid):
    result=[]
    @enumproc
    def record(hwnd,_):
        n=w.DWORD()
        u.GetWindowThreadProcessId(hwnd,c.byref(n))
        if n.value==pid and u.IsWindowVisible(hwnd):
            rect=w.RECT();u.GetClientRect(hwnd,c.byref(rect))
            result.append([int(hwnd),rect.right,rect.bottom])
        return True
    u.EnumDesktopWindows(h,record,0)
    return result
def main():
    p=argparse.ArgumentParser()
    p.add_argument('executable',type=Path);p.add_argument('out',type=Path)
    p.add_argument('args',nargs=argparse.REMAINDER)
    a=p.parse_args()
    exe=a.executable.resolve(strict=True)
    out=a.out.resolve()
    out.mkdir(parents=True,exist_ok=True)
    label='KDExhibit_'+uuid.uuid4().hex[:10]
    desktop=u.CreateDesktopW(label,None,None,0,0x0001|0x0002|0x0004|0x0040|0x0080,None)
    check(desktop)
    # DESKTOP_SWITCHDESKTOP access is intentionally omitted from the desktop handle.
    s=Startup();s.cb=c.sizeof(s);s.desktop='WinSta0\\'+label
    info=Info()
    argv=[str(exe)]+a.args
    state={'desktop':name_of(desktop),'input_desktop_start':input_desktop(),'utc_start':datetime.datetime.now(datetime.timezone.utc).isoformat(),'args':argv}
    assert state['desktop']!=state['input_desktop_start']
    try:
        check(k.CreateProcessW(str(exe),c.create_unicode_buffer(subprocess.list2cmdline(argv)),None,None,False,0x08000000,None,str(exe.parent),c.byref(s),c.byref(info)))
        k.CloseHandle(info.thread)
        state['pid']=info.pid
        (out/'isolation.json').write_text(json.dumps(state,indent=2,ensure_ascii=False),encoding='utf8')
        hist=[];last=None
        while k.WaitForSingleObject(info.process,1000)==258:
            entry=[input_desktop(),windows(desktop,info.pid)]
            if entry!=last:
                hist.append([time.time(),*entry]);last=entry
                (out/'desktop_windows.json').write_text(json.dumps(hist,indent=1),encoding='utf8')
        rc=w.DWORD();k.GetExitCodeProcess(info.process,c.byref(rc));k.CloseHandle(info.process)
        state.update(exit_code=rc.value,input_desktop_end=input_desktop(),utc_end=datetime.datetime.now(datetime.timezone.utc).isoformat())
        (out/'isolation.json').write_text(json.dumps(state,indent=2,ensure_ascii=False),encoding='utf8')
        return rc.value
    finally:u.CloseDesktop(desktop)
if __name__=='__main__':raise SystemExit(main())
