from pathlib import Path
import numpy as np,json,sys
from PIL import Image,ImageDraw,ImageFont
r=Path(__file__).resolve().parent
# Coordinates on quarter-resolution view. All crops include the foot and neighboring carpet.
rois={'feet':{'desk_left':(84,134,140,167),'chair_front':(150,224,216,265),'chair_mid':(167,149,218,181)},'wheels':{'desk_left':(66,95,122,122),'desk_front':(145,240,228,267),'chair_left':(15,124,55,161)}}
def arr(tag,view):
 return np.asarray(Image.open(r/(tag+'_'+view+'.png')).convert('RGB'),dtype=np.float32)
def calc(tag):
 fields={}
 for view,boxes in rois.items():
  d=arr(tag,view)-arr('old',view)
  sub={}
  for name,(x,y,X,Y) in boxes.items():
   a=d[4*y:4*Y,4*x:4*X]
   h,w=a.shape[:2];q=a[:h//8*8,:w//8*8].reshape(h//8,8,w//8,8,3).mean(axis=(1,3))
   patch=np.abs(q).mean(axis=2)
   sub[name]={'mae':round(float(patch.mean()),2),'p95':round(float(np.percentile(patch,95)),2),'signed':round(float(q.mean(axis=(0,1))@[.2126,.7152,.0722]),2)}
  fields[view]=sub
 vals=[f for s in fields.values() for f in s.values()]
 return {'mean':round(float(np.mean([f['mae'] for f in vals])),2),'p95mean':round(float(np.mean([f['p95'] for f in vals])),2),'rois':fields}
data={}
for p in r.glob('*_wheels.png'):
 tag=p.name[:-11]
 try:data[tag]=calc(tag)
 except (OSError,FileNotFoundError):pass
(r/'roi.json').write_text(json.dumps(data,indent=1),encoding='utf-8')
print([(k,d['mean'],d['p95mean'],[(n,f['signed']) for n,f in d['rois']['feet'].items()]) for k,d in data.items()])
