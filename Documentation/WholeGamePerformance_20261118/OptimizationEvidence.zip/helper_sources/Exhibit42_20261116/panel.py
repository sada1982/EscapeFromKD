import json
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
root=Path(__file__).resolve().parent
dest=root.parents[2]/'Documentation'/'Exhibit42_20261116'
dest.mkdir(exist_ok=True)
scales=[('old','従来の照明'),('raw','42灯・影補正前'),('final','採用版・実習室12灯を補正')]
rows=[('feet',(0,250,900,1050),'机列と椅子の足元'),('feet',(526,850,889,1075),'手前のキャスター'),('wheels',(496,865,945,1075),'机脚と床の境目')]
font=lambda n:ImageFont.truetype('C:/Windows/Fonts/YuGothM.ttc',n)
bold=lambda n:ImageFont.truetype('C:/Windows/Fonts/YuGothB.ttc',n)
out=Image.new('RGB',(1194,922),'#f4f4f1');d=ImageDraw.Draw(out)
d.text((22,12),'3F 実習室　机・椅子の接地影',font=bold(29),fill='#202a30')
d.text((23,57),'同じカメラ・1080p出力・内部解像度54%　｜　明るさと光源寸法は全列共通',font=font(18),fill='#41525d')
for i,(t,txt) in enumerate(scales):
 x=22+i*393
 d.text((x,98),txt,font=bold(21),fill='#21394a')
for j,(v,box,title) in enumerate(rows):
 y=[139,418,695][j];height=[239,238,158][j]
 for i,(t,txt) in enumerate(scales):
  x=22+i*393
  im=Image.open(root/(t+'_'+v+'.png')).convert('RGB').crop(box)
  w,h=im.size
  # Center-fit all columns to the same pixel grid and crop window.
  nw,nh=375,height
  s=max(nw/w,nh/h);im=im.resize((round(w*s),round(h*s)),Image.Resampling.LANCZOS)
  ox=(im.width-nw)//2;oy=(im.height-nh)//2
  out.paste(im.crop((ox,oy,ox+nw,oy+nh)),(x,y))
 d.text((22,y+height+3),title,font=font(16),fill='#304650')
d.text((22,887),'キャスターと机脚の6領域を8px単位で比較。従来との差（0〜255）は補正前6.79、採用版0.94。',font=font(17),fill='#1e393e')
out.save(dest/'ContactShadows.jpg',quality=95,subsampling=0)

