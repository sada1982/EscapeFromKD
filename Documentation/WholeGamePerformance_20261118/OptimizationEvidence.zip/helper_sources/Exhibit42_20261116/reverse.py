import json, time, traceback
from pathlib import Path
import unreal
root=Path(unreal.Paths.convert_relative_path_to_full(unreal.Paths.project_saved_dir()))/'Automation/Exhibit42_20261116'
world=None
jobs=[]
wait=0
state='boot'
current={}
views={'aisle':(402,-73,98.15,-90,0),'desk':(402,-580,98.15,-142,-6),'feet':(402,-440,98.15,-176,-34),'wheels':(402,-724,98.15,-5,-34),'gallery':(-117,-465,98.15,3,0),'landing':(-2133,189,-71.85,180,-12)}
def ev(kind,**data):
 with (root/'visual.jsonl').open('a',encoding='utf8') as fp: fp.write(json.dumps(dict(t=time.time(),event=kind,**data))+'\n')
def cmd(s): unreal.SystemLibrary.execute_console_command(world,s,pc)
def read(obj,k):return obj.get_editor_property(k)
def init():
 global world,pc,pawn,move,lights,room,defaults,method
 world=unreal.find_object(None,'/Game/Main/Stage/KDStage.KDStage')
 if not world:return False
 pawn=unreal.GameplayStatics.get_player_pawn(world,0)
 if not pawn:return False
 pc=unreal.GameplayStatics.get_player_controller(world,0)
 move=pawn.get_component_by_class(unreal.CharacterMovementComponent)
 for v in 'ViewDistance AntiAliasing Shadow GlobalIllumination Reflection PostProcess Texture Effects Foliage Shading Landscape'.split():cmd('sg.'+v+'Quality 3')
 for k,v in {'r.ScreenPercentage':54,'r.DynamicRes.OperationMode':0,'r.VSync':0,'t.MaxFPS':0,'t.IdleWhenNotForeground':0,'r.TSR.History.ScreenPercentage':100,'r.Shadow.Virtual.MaxPhysicalPages':2048,'r.LumenScene.SurfaceCache.AtlasSize':3072,'r.Lumen.ScreenProbeGather.RadianceCache.ProbeResolution':16,'r.Shadow.Virtual.SMRT.RayCountLocal':4,'r.Nanite.Streaming.StreamingPoolSize':128}.items():cmd(k+' '+str(v))
 lights={}
 for a in unreal.GameplayStatics.get_all_actors_of_class(world,unreal.Light):
  c=a.get_component_by_class(unreal.LightComponent)
  if c:
   lights[a.get_actor_label()]=c
   assert read(c,'allow_mega_lights')==read(c,'cast_shadows'),a.get_actor_label()
 room={k:c for k,c in lights.items() if k.startswith('F03_GameLab_')}
 assert len(lights)==61 and len(room)==12,(len(lights),len(room))
 c=next(iter(room.values()))
 method=type(read(c,'mega_lights_shadow_method'))
 defaults={k:read(c,k) for k in ['source_width','source_height','mega_lights_shadow_method','intensity']}
 ev('init',lights=len(lights),room=list(room),values=str(defaults),enums=str(dir(method)))
 return True
def configure(j):
 if j.get('authored'):
  assert sum(str(read(c,'mega_lights_shadow_method')).find('VIRTUAL_SHADOW_MAP')>=0 for c in room.values())==12
  ev('authored',lights=len(lights),shadowed=sum(read(c,'cast_shadows') for c in lights.values()),room_vsm=len(room),allowed=unreal.SystemLibrary.get_console_variable_int_value('r.MegaLights.Allowed'),project_default=unreal.SystemLibrary.get_console_variable_int_value('r.MegaLights.EnableForProject'))
  return
 cmd('r.MegaLights.EnableForProject 1')
 cmd('r.MegaLights.Allowed '+str(int(not j.get('legacy',False))))
 for k,c in room.items():
  idx=int(k[-2:])
  c.set_editor_property('mega_lights_shadow_method',getattr(method,'VIRTUAL_SHADOW_MAP') if idx in j.get('vsm',[]) else defaults['mega_lights_shadow_method'])
  c.set_source_width(defaults['source_width']*j.get('width',1))
  c.set_source_height(defaults['source_height']*j.get('height',1))
  c.set_intensity(defaults['intensity']*j.get('intensity',1))
  c.set_visibility(False,False);c.set_visibility(True,False)
 ev('condition',job=j)
def process(dt):
 global state, wait, jobs, current, remaining, view
 if time.monotonic()<wait:return
 if state=='boot':
  if not init():return
  state='next';wait=time.monotonic()+3;return
 if state=='next':
  if not jobs:
   p=root/'visual_queue.json'
   if not p.exists():return
   jobs=json.loads(p.read_text('utf-8-sig'));p.unlink()
  current=jobs.pop(0)
  if current.get('stop'):
   ev('stop');cmd('quit');unreal.unregister_slate_post_tick_callback(handle);return
  configure(current);remaining=list(current.get('views',['feet','wheels','aisle','desk']));state='move'
 if state=='move':
  view=remaining.pop(0);x,y,z,yaw,pitch=views[view]
  move.stop_movement_immediately();pawn.set_actor_location(unreal.Vector(x,y,z),False,True)
  pc.set_control_rotation(unreal.Rotator(pitch=pitch,yaw=yaw,roll=0))
  state='shot';wait=time.monotonic()+2.8;return
 if state=='shot':
  cmd('Shot -nosuffix filename="'+(root/(current['tag']+'_'+view+'.png')).as_posix()+'"')
  ev('shot',tag=current['tag'],view=view,xyz=str(pawn.get_actor_location()))
  state='move' if remaining else 'next';wait=time.monotonic()+0.65
def tick(dt):
 try:process(dt)
 except Exception:
  ev('error',error=traceback.format_exc());unreal.unregister_slate_post_tick_callback(handle);cmd('quit')
import math,os
views.update({'landing_back':(-2133,189,-71.85,0,12),'landing_side':(-2133,189,-71.85,90,0),'exit':(-117,-890,98.15,90,0),'lobbyin':(-876,109,98.15,90,0),'top':(-1635,189,98.15,180,0),'corner1':(402,-890,98.15,180,0),'corner3':(-117,109,98.15,180,0),'corner5':(-876,308,98.15,180,0),'corner6':(-1635,308,98.15,-90,0)})
for k in list(views):
 x,y,z,ya,pi=views[k];ra=math.radians(ya)
 views[k+'_stereo']=(x-20*math.sin(ra),y+20*math.cos(ra),z,ya,pi)
jobs=[{'tag':'final','authored':True,'views':['landing_back','landing_back_stereo','landing_side','landing_side_stereo']},{'stop':True}]
handle=unreal.register_slate_post_tick_callback(tick)
