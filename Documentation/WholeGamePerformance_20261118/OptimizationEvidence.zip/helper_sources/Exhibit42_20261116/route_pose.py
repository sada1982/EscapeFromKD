import math
from pathlib import Path

from PIL import Image
from win_route_io import cv2, np, picture


BASE=Path(__file__).resolve().parent
POSES={"aisle":(402,-73,98.15,-90,0), "corner1":(402,-890,98.15,180,0),
       "exit":(-117,-890,98.15,90,0), "corner3":(-117,109,98.15,180,0),
       "lobbyin":(-876,109,98.15,90,0), "corner5":(-876,308,98.15,180,0),
       "corner6":(-1635,308,98.15,-90,0), "top":(-1635,189,98.15,180,0),
       "landing":(-2133,189,-71.85,180,-12), "landing_back":(-2133,189,-71.85,0,12)}


def pairs(a,b):
    if a is None or b is None:
        return {}
    return {m.queryIdx:m.trainIdx for m,n in cv2.BFMatcher().knnMatch(a,b,k=2) if m.distance<0.75*n.distance}


class Anchor:
    def __init__(self, name, focal=480):
        self.name=name
        self.f=float(focal)
        self.k,self.d=picture(Image.open(BASE/f"final_{name}.png"))
        ks,ds=picture(Image.open(BASE/f"final_{name}_stereo.png"))
        self.coords={}
        for i,j in pairs(self.d,ds).items():
            u,v=self.k[i].pt
            us,vs=ks[j].pt
            disp=u-us
            if 1.5<disp<250 and abs(v-vs)<2.5:
                z=self.f*20/disp
                self.coords[i]=[(u-480)*z/self.f,(v-270)*z/self.f,z]
        x,y,z,yaw,pitch=POSES[name]
        self.origin=np.float64((x,y,z))
        yaw,pitch=map(math.radians,(yaw,pitch))
        self.basis=np.column_stack(([-math.sin(yaw),math.cos(yaw),0],
                                    [math.sin(pitch)*math.cos(yaw),math.sin(pitch)*math.sin(yaw),-math.cos(pitch)],
                                    [math.cos(pitch)*math.cos(yaw),math.cos(pitch)*math.sin(yaw),math.sin(pitch)]))
        self.K=np.float64([[self.f,0,480],[0,self.f,270],[0,0,1]])

    def locate(self, image):
        kk,dd=picture(image)
        matches=[(self.coords[i],kk[j].pt) for i,j in pairs(self.d,dd).items() if i in self.coords]
        if len(matches)<8:
            return {"anchor":self.name,"valid":False,"matches":len(matches)}
        a,b=map(lambda q: np.asarray(q,dtype=np.float64), zip(*matches))
        ok,r,t,inliers=cv2.solvePnPRansac(a,b,self.K,None,iterationsCount=200,reprojectionError=3.2,confidence=0.999,flags=cv2.SOLVEPNP_EPNP)
        if not ok or inliers is None or len(inliers)<8:
            return {"anchor":self.name,"valid":False,"matches":len(matches)}
        idx=inliers.ravel()
        r,t=cv2.solvePnPRefineLM(a[idx],b[idx],self.K,None,r,t)
        R=cv2.Rodrigues(r)[0]
        shift=(-R.T@t).ravel()
        pos=self.origin+self.basis@shift
        front=self.basis@R.T@np.array([0,0,1.])
        yaw=math.degrees(math.atan2(front[1],front[0]))
        pitch=math.degrees(math.asin(np.clip(front[2],-1.,1.)))
        reproj=cv2.projectPoints(a[idx],r,t,self.K,None)[0].reshape(-1,2)
        error=float(np.median(np.linalg.norm(reproj-b[idx],axis=1)))
        return {"anchor":self.name,"valid":bool(error<2.5 and len(idx)>=10),
                "inliers":len(idx),"matches":len(matches),"reproj_px960":round(error,3),
                "pawn_equivalent_cm":[round(float(v),2) for v in pos],"yaw":round(yaw,3),"pitch":round(pitch,3)}


if __name__=="__main__":
    for n in POSES:
        if not (BASE/f"final_{n}_stereo.png").exists():
            continue
        a=Anchor(n)
        im=Image.open(BASE/f"final_{n}_stereo.png")
        print(n,len(a.coords),a.locate(im),flush=True)
