import argparse
import ctypes as c
from ctypes import wintypes as w
from pathlib import Path
import sys
import tempfile

import numpy as np
from PIL import Image
sys.path.insert(0, str(Path(tempfile.gettempdir())/"kd_stage_opencv_410"))
sys.path.insert(0, str(Path(tempfile.gettempdir())/"kd_wgc_20261116"))
from windows_capture import WindowsCapture
from win_route_io import windows


def shipping_path(pid):
    kernel=c.windll.kernel32
    kernel.OpenProcess.restype=w.HANDLE
    h=kernel.OpenProcess(0x1000,False,pid)
    if not h:raise c.WinError()
    size=w.DWORD(32768)
    path=c.create_unicode_buffer(size.value)
    try:
        if not kernel.QueryFullProcessImageNameW(w.HANDLE(h),0,path,c.byref(size)):raise c.WinError()
    finally:
        kernel.CloseHandle(w.HANDLE(h))
    if Path(path.value).name.lower()!="myproject-win64-shipping.exe":
        raise ValueError("Only the packaged game can be captured")
    return path.value


def capture(pid, output):
    shipping_path(pid)
    items=windows(pid)
    if len(items)!=1:
        raise RuntimeError(f"Expected one visible game window, found {len(items)}")
    h=items[0]
    cap=WindowsCapture(window_hwnd=h,cursor_capture=False,draw_border=False)
    frames=[]
    @cap.event
    def on_frame_arrived(frame,control):
        frames.append(frame.frame_buffer.copy())
        control.stop()
    @cap.event
    def on_closed():
        pass
    cap.start()
    if not frames:raise RuntimeError("The game capture stream had no frame")
    pixels=frames[0][:,:,:3][:,:,::-1]
    image=Image.fromarray(np.ascontiguousarray(pixels),"RGB")
    image.save(output)
    print(f"game={pid} hwnd={h} size={image.size} mean={pixels.mean():.2f}")


if __name__=="__main__":
    p=argparse.ArgumentParser()
    p.add_argument("pid",type=int)
    p.add_argument("image",type=Path)
    a=p.parse_args()
    capture(a.pid,a.image)
