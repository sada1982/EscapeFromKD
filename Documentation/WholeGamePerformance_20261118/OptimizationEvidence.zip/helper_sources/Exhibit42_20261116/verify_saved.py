import json
from pathlib import Path
import unreal

folder = Path(unreal.Paths.convert_relative_path_to_full(unreal.Paths.project_saved_dir())) / 'Automation' / 'Exhibit42_20261116'
saved = json.loads((folder / 'after.json').read_text(encoding='utf-8'))
world = unreal.EditorLoadingAndSavingUtils.load_map('/Game/Main/Stage/KDStage')
assert world and world.get_path_name() == '/Game/Main/Stage/KDStage.KDStage'
light_actors = unreal.GameplayStatics.get_all_actors_of_class(world, unreal.Light)
assert len(light_actors) == len(saved['lights']) == 61
expected = {item['refPath']: item['values'] for item in saved['lights']}
records = []
for actor in light_actors:
    component = actor.get_component_by_class(unreal.LightComponent)
    path = component.get_path_name()
    values = json.loads(unreal.ToolsetLibrary.get_object_properties(component, list(expected[path])))
    assert values == expected[path], (path, values, expected[path])
    if actor.get_actor_label().startswith('F03_GameLab_'):
        room = json.loads(unreal.ToolsetLibrary.get_object_properties(component, ['SourceWidth', 'SourceHeight', 'MegaLightsShadowMethod', 'Intensity']))
    else:
        room = None
    records.append({'actor': actor.get_actor_label(), 'component': path, 'values': values, 'roomSettings': room})
volumes = unreal.GameplayStatics.get_all_actors_of_class(world, unreal.PostProcessVolume)
assert len(volumes) == 1
pp = json.loads(unreal.ToolsetLibrary.get_object_properties(volumes[0], list(saved['postProcess'])))
assert pp == saved['postProcess'], 'PostProcessVolume differs from audited editor'
summary = {'map': world.get_path_name(), 'mega': sum(x['values']['bAllowMegaLights'] for x in records), 'conventional': sum(not x['values']['bAllowMegaLights'] for x in records), 'lights': records, 'postProcessMatches': True, 'override': pp['Settings']['bOverride_bMegaLights'], 'enabled': pp['Settings']['bMegaLights']}
assert (summary['mega'], summary['conventional'], summary['override'], summary['enabled']) == (42,19,True,True)
(folder / 'disk_verified.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
unreal.log('EXHIBIT42_DISK_VERIFIED')
