import ctypes as c
from ctypes import wintypes as w
from pathlib import Path
import sys
import tempfile
import time

import numpy as np
from PIL import ImageGrab
from scipy.optimize import least_squares

sys.path.insert(0, str(Path(tempfile.gettempdir()) / "kd_stage_opencv_410"))
import cv2

cv2.setNumThreads(1)
user = c.windll.user32
user.SetProcessDPIAware()
user.GetForegroundWindow.restype = w.HWND
user.GetWindowThreadProcessId.argtypes = [w.HWND, c.POINTER(w.DWORD)]
user.SetWindowPos.argtypes = [w.HWND, w.HWND, c.c_int, c.c_int, c.c_int, c.c_int, w.UINT]
user.GetClientRect.argtypes = [w.HWND, c.POINTER(w.RECT)]
user.ClientToScreen.argtypes = [w.HWND, c.POINTER(w.POINT)]
user.SetForegroundWindow.argtypes = [w.HWND]
user.GetWindowRect.argtypes = [w.HWND, c.POINTER(w.RECT)]


class Mouse(c.Structure):
    _fields_ = [("dx", w.LONG), ("dy", w.LONG), ("mouseData", w.DWORD),
                ("dwFlags", w.DWORD), ("time", w.DWORD), ("dwExtraInfo", c.c_size_t)]


class Key(c.Structure):
    _fields_ = [("wVk", w.WORD), ("wScan", w.WORD), ("dwFlags", w.DWORD),
                ("time", w.DWORD), ("dwExtraInfo", c.c_size_t)]


class InputData(c.Union):
    _fields_ = [("mi", Mouse), ("ki", Key)]


class Input(c.Structure):
    _anonymous_ = ("data",)
    _fields_ = [("type", w.DWORD), ("data", InputData)]


user.SendInput.argtypes = [w.UINT, c.POINTER(Input), c.c_int]
keys = {"w": 0x11, "a": 0x1E, "s": 0x1F, "d": 0x20, "alt": 0x38}


def send(event):
    if user.SendInput(1, c.byref(event), c.sizeof(Input)) != 1:
        raise c.WinError()


def key(name, down):
    event = Input(type=1)
    event.ki = Key(0, keys[name], 0x8 | (0 if down else 0x2), 0, 0)
    send(event)


def mouse(dx, dy):
    event = Input(type=0)
    event.mi = Mouse(int(dx), int(dy), 0, 1 | 0x2000, 0, 0)
    send(event)


def windows(pid):
    found = []
    callback_type = c.WINFUNCTYPE(w.BOOL, w.HWND, w.LPARAM)
    @callback_type
    def callback(hwnd, unused):
        process = w.DWORD()
        user.GetWindowThreadProcessId(hwnd, c.byref(process))
        if process.value == pid and user.IsWindowVisible(hwnd):
            box = w.RECT()
            user.GetClientRect(hwnd, c.byref(box))
            if box.right >= 1000 and box.bottom >= 650:
                found.append(hwnd)
        return True
    user.EnumWindows(callback, 0)
    return found


def foreground(hwnd):
    if user.GetForegroundWindow() != hwnd:
        key("alt", True)
        key("alt", False)
        user.SetForegroundWindow(hwnd)
        time.sleep(0.12)
    if user.GetForegroundWindow() != hwnd:
        raise RuntimeError("Game foreground unavailable")


def client(hwnd):
    o, r = w.POINT(), w.RECT()
    user.ClientToScreen(hwnd, c.byref(o))
    user.GetClientRect(hwnd, c.byref(r))
    return o.x, o.y, o.x + r.right, o.y + r.bottom


def place(hwnd):
    foreground(hwnd)
    x, y, x1, y1 = client(hwnd)
    width, height = x1-x, y1-y
    if (width, height) != (1920, 1080):
        raise RuntimeError(f"Unexpected game client size: {width}x{height}")
    if (x, y) != (0, 0):
        box = w.RECT()
        user.GetWindowRect(hwnd, c.byref(box))
        user.SetWindowPos(hwnd, 0, box.left-x, box.top-y, 0, 0, 0x15)
        time.sleep(0.15)
    if client(hwnd) != (0, 0, width, height):
        raise RuntimeError(f"Could not align game client: {client(hwnd)}")


def snapshot(hwnd):
    if user.GetForegroundWindow() != hwnd:
        raise RuntimeError("Foreground changed during the run")
    return ImageGrab.grab(bbox=client(hwnd), all_screens=True).convert("RGB")


def picture(image):
    g = cv2.cvtColor(np.asarray(image.convert("RGB")), cv2.COLOR_RGB2GRAY)
    g = cv2.resize(g, (960, 540), interpolation=cv2.INTER_AREA)
    mask = np.full_like(g, 255)
    g = cv2.createCLAHE(clipLimit=1.5, tileGridSize=(8,8)).apply(g)
    mask[int(g.shape[0]*0.54):,int(g.shape[1]*0.51):] = 0
    mask[0:30, :] = 0
    mask[-30:, :] = 0
    return cv2.SIFT_create(nfeatures=2600,contrastThreshold=.012,edgeThreshold=16).detectAndCompute(g, mask)


def correspond(a, b):
    ka, da = a
    kb, db = b
    if da is None or db is None:
        raise RuntimeError("No static scene features")
    matches = cv2.BFMatcher().knnMatch(da, db, k=2)
    pairs = [i for i, j in matches if i.distance < 0.70*j.distance]
    if len(pairs) < 8:
        raise RuntimeError(f"Only {len(pairs)} feature pairs")
    return np.float64([ka[i.queryIdx].pt for i in pairs]), np.float64([kb[i.trainIdx].pt for i in pairs])


def turn_angle(reference, image, focal=None):
    a, b = correspond(reference, picture(image))
    h, keep = cv2.findHomography(a, b, cv2.RANSAC, 2.8)
    if h is None or keep.sum() < 12:
        raise RuntimeError("No coherent pure camera turn")
    a, b = a[keep.ravel()!=0] - (480, 270), b[keep.ravel()!=0] - (480, 270)
    def residual(p):
        yaw = np.deg2rad(p[0])
        f = p[1] if focal is None else focal
        xx, yy = a[:,0]/f, a[:,1]/f
        zz = xx*np.sin(yaw) + np.cos(yaw)
        pred = np.column_stack(((xx*np.cos(yaw)-np.sin(yaw))*f/zz, yy*f/zz))
        return (pred-b).ravel()
    seed = -np.degrees(np.arctan(np.median((b-a)[:,0]) / 480.0))
    fit = least_squares(residual, [seed, 480] if focal is None else [seed],
                        bounds=([-85,220],[85,1000]) if focal is None else ([-85],[85]), loss="soft_l1")
    return {"degrees":float(fit.x[0]), "focal_960":float(fit.x[1] if focal is None else focal),
            "inliers":len(a),"residual_px":float(np.median(np.abs(fit.fun)))}


def score(reference, image):
    try:
        a,b = correspond(reference,picture(image))
        h,k = cv2.findHomography(a,b,cv2.RANSAC,3.2)
        if h is None:
            return {"count":0}
        d = np.linalg.norm((a-b)[k.ravel()!=0],axis=1)
        return {"count":int(k.sum()),"median_shift_px960":round(float(np.median(d)),2)}
    except RuntimeError:
        return {"count":0}


def qpc():
    result = c.c_longlong()
    c.windll.kernel32.QueryPerformanceCounter(c.byref(result))
    return result.value
