from pathlib import Path
import json

import numpy as np
from PIL import Image, ImageDraw, ImageFont

folder = Path(__file__).resolve().parent
samples = {
    'desk': ((317, 620, 415, 687), (344, 660, 376, 664), (344, 672, 376, 676)),
    'caster': ((805, 924, 886, 991), (847, 965, 858, 969), (847, 979, 858, 983)),
}
tags = ('old', 'raw', 'final', 'oldrepeat', 'vsm12')
images = {tag: Image.open(folder / (tag + '_feet.png')).convert('RGB') for tag in tags}
records = {}
for label, (crop, near, nearby) in samples.items():
    values = {}
    for tag, img in images.items():
        def luma(box):
            pixels = np.asarray(img.crop(box), dtype=np.float64)
            return (pixels @ [0.2126, 0.7152, 0.0722]).mean()
        dark = luma(near)
        light = luma(nearby)
        values[tag] = {'contact':float(dark), 'carpet':float(light), 'contrast':float(light-dark)}
    records[label] = {'crop': crop, 'contact_xyxy': near, 'carpet_xyxy': nearby, 'tags': values}
data = {'view':'feet','pixels':'1920x1080. Origin top left, end-exclusive rectangles. Same carpet pixels in each saved frame. Boxes selected on original image. Rec.709 coefficients on 8-bit display RGB, not scene-linear.', 'samples':records}
(folder / 'carpet_contacts.json').write_text(json.dumps(data, indent=2), encoding='utf-8')

canvas = Image.new('RGB', (1020, 636), '#f5f5f2')
draw = ImageDraw.Draw(canvas)
font_path = 'C:/Windows/Fonts/YuGothM.ttc'
font = ImageFont.truetype(font_path,18)
small = ImageFont.truetype(font_path,15)
title_font = ImageFont.truetype('C:/Windows/Fonts/YuGothB.ttc',26)
ink = '#283541'
colors = ('#16e5e1','#febf43')
draw.text((18,10),'机脚とキャスターの接地点に隣接する床',font=title_font,fill=ink)
draw.text((18,50),'青緑は接点直下の床、黄は近傍の床。写真下の数値は2領域の平均明度差（0–255）。',font=small,fill=ink)
for i, title in enumerate(('従来の照明','42灯でMegaLightsを有効化','確定版・実習室12灯にVSM')):
    draw.text((140+290*i,82),title,font=font,fill=ink)
for row, (case,(crop, near, nearby)) in enumerate(samples.items()):
    y = 115 + 246*row
    draw.text((12,y+89),'机脚' if row==0 else 'キャスター',font=font,fill=ink)
    for col,tag in enumerate(tags[:3]):
        left = 135 + 290*col
        x0,y0,x1,y1=crop
        factor=2.72
        cut=images[tag].crop(crop).resize((round((x1-x0)*factor), round((y1-y0)*factor)),Image.Resampling.NEAREST)
        d=ImageDraw.Draw(cut)
        for box,color in zip((near,nearby),colors):
            a,b,c,e=box
            d.rectangle((round((a-x0)*factor)-2,round((b-y0)*factor)-2,round((c-x0)*factor)+1,round((e-y0)*factor)+1),outline=color,width=2)
        canvas.paste(cut,(left,y))
        f=records[case]['tags'][tag]
        draw.text((left,y+191),f"{f['carpet']:.1f} − {f['contact']:.1f} = {f['contrast']:.2f}",font=font,fill=ink)
draw.text((18,602),'同一視点のPNGから切り出した2例。接地影の強さを、接点直下と近くのカーペットの差で比較。',font=small,fill=ink)
canvas.save(folder/'carpet_contacts.png')
