import argparse
import ctypes as c
import json
import math
import os
from pathlib import Path
import subprocess
import time

from PIL import Image

import win_route_io as io
from route_pose import Anchor, BASE, POSES


PM=Path("C:/Program Files/Epic Games/UE_5.8/Engine/Binaries/ThirdParty/PresentMon/Win64/PresentMon-1.8.0-x64.exe")
STOPS=["aisle","corner1","exit","corner3","lobbyin","corner5","corner6","top","landing"]


def event(kind, **fields):
    row=dict(event=kind,qpc=io.qpc(),epoch=time.time(),**fields)
    with (data/"events.jsonl").open("a",encoding="utf8") as out:
        out.write(json.dumps(row)+"\n")
    print(kind,fields,flush=True)


def orientation(dx,dy,duration):
    steps=max(1,math.ceil(duration/0.012))
    now=time.monotonic()
    for i in range(steps):
        tx=round(dx*(i+1)/steps)-round(dx*i/steps)
        ty=round(dy*(i+1)/steps)-round(dy*i/steps)
        if tx or ty:
            io.mouse(tx,ty)
        time.sleep(max(0,now+(i+1)*duration/steps-time.monotonic()))


def face(yaw,pitch):
    global facing, elevation
    a=(yaw-facing+180)%360-180
    b=pitch-elevation
    dx=round(a/gain)
    dy=round(-b/vertical_gain)
    if dx or dy:
        orientation(dx,dy,max(abs(a)/360,abs(b)/240,0.035))
    facing=(facing+dx*gain+180)%360-180
    elevation-=dy*vertical_gain


def held(k,seconds):
    if io.user.GetForegroundWindow()!=hwnd:
        raise RuntimeError("Game lost focus")
    io.key(k,True)
    try:
        time.sleep(seconds)
    finally:
        io.key(k,False)


def motion(cm,axis="w"):
    if cm<=1:
        return
    v=600
    accel=2048
    accel_dist=v*v/(2*accel)
    brake_dist=25
    t=(cm+accel_dist-brake_dist)/v
    if cm<accel_dist+brake_dist:
        lo,hi=0.,v/accel
        for _ in range(20):
            mid=(lo+hi)*.5
            peak=accel*mid
            braking=peak/16-(accel/(16*16))*math.log1p(16*peak/accel)
            if accel*mid*mid*.5+braking<cm:lo=mid
            else:hi=mid
        t=(lo+hi)*.5
    held(axis,t)
    time.sleep(.19)


def photograph(label,name):
    io.foreground(hwnd)
    time.sleep(.06)
    im=io.snapshot(hwnd)
    im.save(data/f"{label}_{name}.jpg",quality=91)
    return im


def pose(anchor, label):
    if anchor not in anchors:
        anchors[anchor]=Anchor(anchor,focal)
    im=photograph(label,anchor)
    p=anchors[anchor].locate(im)
    event("pose",label=label,**p)
    return p


def correct_at(name,label,tolerance=9):
    global facing,elevation
    target=POSES[name]
    face(*target[3:])
    time.sleep(.28)
    for attempt in range(4):
        p=pose(name,label+"_"+str(attempt))
        if not p["valid"]:
            return p
        facing,elevation=p["yaw"],p["pitch"]
        pos=p["pawn_equivalent_cm"]
        dx,dy=target[0]-pos[0],target[1]-pos[1]
        if math.hypot(dx,dy)<tolerance and abs((facing-target[3]+180)%360-180)<.8 and abs(elevation-target[4])<1:
            return p
        if math.hypot(dx,dy)>180 or abs(pos[2]-target[2])>60:
            return p
        face(*target[3:])
        if math.hypot(dx,dy)>tolerance:
            a=math.radians(target[3])
            forward=dx*math.cos(a)+dy*math.sin(a)
            right=-dx*math.sin(a)+dy*math.cos(a)
            if abs(forward)>4: motion(abs(forward),"w" if forward>0 else "s")
            if abs(right)>4: motion(abs(right),"d" if right>0 else "a")
        time.sleep(.25)
    return pose(name,label+"_final")


def calibrate():
    global facing,elevation,focal,gain,vertical_gain
    frame=photograph("static","origin")
    focal=480.
    initial=Anchor("aisle",focal)
    before=initial.locate(frame)
    if not before["valid"]:
        raise RuntimeError("No recognized start view "+str(before))
    io.foreground(hwnd)
    orientation(50,0,.16)
    time.sleep(.28)
    after=initial.locate(photograph("static","turn"))
    if not after["valid"]:
        raise RuntimeError("Camera-turn pose unavailable "+str(after))
    yaw=(after["yaw"]-before["yaw"]+180)%360-180
    if abs(yaw)<.6:
        raise RuntimeError("Mouse gain unavailable "+str(after))
    io.foreground(hwnd)
    orientation(-50,0,.16)
    time.sleep(.28)
    gain=yaw/50
    vertical_gain=abs(gain)
    facing,elevation=-90.,0.
    event("mouse_calibration",gain=gain,focal=focal,before=before,after=after)
    p=pose("aisle","spawn")
    if not p["valid"] or math.dist(p["pawn_equivalent_cm"],POSES["aisle"][:3])>42:
        raise RuntimeError("Spawn image mismatch "+str(p))
    facing,elevation=p["yaw"],p["pitch"]
    orientation(0,35,.12)
    time.sleep(.25)
    pd=pose("aisle","pitch")
    orientation(0,-35,.12)
    time.sleep(.25)
    if pd["valid"] and abs(pd["pitch"]-elevation)>.4:
        vertical_gain=(elevation-pd["pitch"])/35
    face(-90,0)
    event("calibrated",horizontal_gain=gain,vertical_gain=vertical_gain,focal=focal)


def walk(lap, backwards=False):
    stops=list(reversed(STOPS)) if backwards else STOPS
    if not backwards:
        start=correct_at("aisle",lap+"_start",14)
        if not start["valid"] or math.dist(start["pawn_equivalent_cm"],POSES["aisle"][:3])>32:
            raise RuntimeError("Unverified walk start "+str(start))
        time.sleep(.35)
        event("run_begin",lap=lap,pid=pid)
    for j,(a,b) in enumerate(zip(stops,stops[1:])):
        x,y=POSES[a][:2]
        nx,ny=POSES[b][:2]
        yaw=math.degrees(math.atan2(ny-y,nx-x))
        pitch=-12 if not backwards and b=="landing" else 0
        event("leg",lap=lap,source=a,destination=b,reverse=backwards)
        face(yaw,pitch)
        motion(math.hypot(nx-x,ny-y))
        if args.inspect:
            photograph(lap,f"{'R' if backwards else 'F'}{j+1}")
    if backwards:
        face(-90,0)
    else:
        event("run_end",lap=lap,pid=pid)
        photograph(lap,"forward_end")
        face(0,12)
        time.sleep(.30)
        end=pose("landing_back",lap+"_end")
        if not end["valid"] or abs(end["pawn_equivalent_cm"][2]+71.85)>38 or math.dist(end["pawn_equivalent_cm"][:2],POSES["landing"][:2])>140:
            raise RuntimeError("Unverified landing "+str(end))
        correct_at("landing_back",lap+"_realign",17)
        event("run_verified",lap=lap,pid=pid)


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("folder")
    parser.add_argument("pid",type=int)
    parser.add_argument("--laps",type=int,default=11)
    parser.add_argument("--inspect",action="store_true")
    parser.add_argument("--attach",action="store_true")
    parser.add_argument("--from-lap",type=int,default=0)
    args=parser.parse_args()
    data=BASE/args.folder
    data.mkdir(exist_ok=True)
    pid=args.pid
    hwnd=next(iter(io.windows(pid)),None)
    if not hwnd:raise RuntimeError("No visible 1080p game window for pid "+str(pid))
    io.place(hwnd)
    anchors={}
    session="KDEx42_"+str(pid)+"_"+str(int(time.time()))
    raw=data/("presents_"+str(int(time.time()))+".csv")
    with (data/"presentmon.log").open("a") as log:
        pm=subprocess.Popen([str(PM),"-session_name",session,"-process_id",str(pid),"-qpc_time","-output_file",str(raw),"-no_top"],stdout=log,stderr=log,creationflags=subprocess.CREATE_NO_WINDOW)
    try:
        counter=c.c_longlong()
        c.windll.kernel32.QueryPerformanceFrequency(c.byref(counter))
        event("session",pid=pid,hwnd=hwnd,qpc_frequency=counter.value,client=io.client(hwnd),raw=raw.name)
        calibrate()
        for i in range(args.from_lap,args.from_lap+args.laps):
            label="First" if i==0 else f"Warm{i:02d}"
            if pm.poll() is not None: raise RuntimeError("PresentMon stopped")
            walk(label)
            if i+1<args.from_lap+args.laps:
                walk(label,True)
    finally:
        for key in "wasd":io.key(key,False)
        subprocess.run([str(PM),"-terminate_existing","-session_name",session],creationflags=subprocess.CREATE_NO_WINDOW)
        try:pm.wait(timeout=12)
        except subprocess.TimeoutExpired:pm.terminate()
