import json, os, subprocess, sys
from pathlib import Path
base=Path(__file__).resolve().parent
args=json.loads((base.parent/'ClassroomAB_20261116/launch_cold.json').read_text('utf-8'))['args']
args=['-abslog='+str(base/'visual.log') if a.startswith('-abslog=') else '-ExecCmds=py '+(base/'visual.py').as_posix() if a.startswith('-ExecCmds=') else a for a in args if a!='-csvGpuStats']
print(subprocess.Popen(args,cwd=base.parents[2]).pid)
