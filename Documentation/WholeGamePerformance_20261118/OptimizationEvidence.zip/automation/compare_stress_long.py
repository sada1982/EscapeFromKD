import json
from pathlib import Path


here = Path(__file__).resolve().parent
results = []
lines = ["Shipping long firing stress / 2026-11-18", "",
         "Independent fresh deployment paths, same LoadingCapProbe executable/pak, Editor open/maximized, Slate sleep1, no trace, no OS input/activation. Existing1 enemy compared with10 total enemies (one existing plus nine transient) at the same atrium camera. One main enemy receives sustained real firing; the others execute existing bounded walk/run movement. This is a density stress case, not ten simultaneous attackers or a full-game guarantee.",
         "120 seconds per case, workers15, loading MaxFPS0. Fresh executable path and UserDir; global driver/OS caches not cleared. Each case has a separate read-only250ms window watcher and thread CPU sampler.", "",
         "Enemies | Mean ms | FPS | P99 ms | Max ms | >16.67 count/intervals | Shots/hit updates | First15 mean/P99 | Last15 mean/P99"]
for name in ("StressLong1A", "StressLong10A"):
    run = here / name
    meta = json.loads((run / "metadata.json").read_text(encoding="utf8"))
    growth = json.loads((run / "stress_growth_audit.json").read_text(encoding="utf8"))
    telemetry = json.loads((run / "stress_telemetry.json").read_text(encoding="utf8"))
    window = json.loads((here / (name + "Window") / "sample_window_audit.json").read_text(encoding="utf8"))
    execution = json.loads((here / (name + "Control") / "execution.json").read_text(encoding="utf8"))
    checks = json.loads((here / (name + "Control") / "gate_checks.json").read_text(encoding="utf8"))
    assert meta["returncode"] == meta["monitor_returncode"] == execution["runner_returncode"] == execution["watcher_returncode"] == execution["sampler_returncode"] == 0
    assert window["all_rounds_observed_stable"] and growth["completion"]["success"] == "1"
    overall, first, last = growth["all_raw"], growth["first_last_15_seconds"]["first"]["present"], growth["first_last_15_seconds"]["last"]["present"]
    completion = growth["completion"]
    lines.append(f'{completion["enemies"]} | {overall["mean_ms"]:.5f} | {1000/overall["mean_ms"]:.3f} | {overall["p99_ms"]:.4f} | {overall["max_ms"]:.4f} | {overall["over_16_67"]}/{overall["n"]} | {completion["shots"]}/{completion["hit_updates"]} | {first["mean_ms"]:.5f}/{first["p99_ms"]:.4f} | {last["mean_ms"]:.5f}/{last["p99_ms"]:.4f}')
    results.append(dict(name=name, growth=growth, telemetry=telemetry, window=window, execution=execution, checks=checks))
lines += ["", "Checks: all normal process/monitor/watcher/sampler exit0, startup settled/input restored, all priorities included in active precache gating, actual shots and hit updates observed, Editor remained maximized and nonforeground throughout sampled startup and stress windows.", ""]
for result in results:
    growth, telemetry = result["growth"], result["telemetry"]
    all_window = telemetry["windows"]["all"]
    pso = [row for row in all_window["threads"] if "PSOPrecompilePool" in row["name"]]
    durations = [row["duration_ms"] for row in growth["inventory_brackets"]]
    lines.append(result["name"])
    lines.append(f'Observed visible enemy minimum={growth["minimum_visible_sampled"]}; inventory PSO pending maximum={growth["maximum_inventory_pending"]}. Inventory duration {min(durations):.4f}..{max(durations):.4f}ms; all raw frames retained, proximity-filtered reference available in JSON.')
    lines.append(f'Actual observed thread CPU {all_window["observed_thread_cpu_equivalent_cores"]:.3f} core-equivalents, PSOPrecompilePool {len(pso)} observed threads, {sum(row["cpu_seconds"] for row in pso):.6f} CPU seconds in120s. Parallel CPU work is not critical-path frame time.')
    lines.append(f'GPU mean {all_window["gpu"]["clocks.current.graphics [MHz]"]["mean"]:.2f}MHz / {all_window["gpu"]["temperature.gpu"]["mean"]:.2f}C; GPU-wide memory {all_window["gpu"]["memory.used [MiB]"]["mean"]:.2f}MiB; game local memory {all_window["process"]["game"]["local_usage_B"]["mean"]/1048576:.2f}MiB; game eviction max {all_window["process"]["game"]["evicted_process_B"]["max"]:.0f}B.')
    lines.append("GPU software power cap Active throughout sampled gameplay; software/hardware thermal slowdown Not Active. Observed game evicted-process counter increased from0 to about20MiB during each case; its cause is unresolved, and this alone does not prove VRAM-budget stalls.")
    for label in ("first", "last"):
        counters = growth["first_last_15_seconds"][label]["engine"]
        lines.append(label + "15 engine mean ms: " + ", ".join(f'{key}={counters[key]["mean_ms"]:.5f}' for key in ("gt_ms", "rt_ms", "rhi_ms", "gpu_ms")))
    lines.append("elapsed seconds / total decals / registered decals / total Niagara / active Niagara:")
    lines.extend(f'{row["elapsed"]} / {row["decals"]} / {row["registered_decals"]} / {row["niagara"]} / {row["active_niagara"]}' for row in growth["inventory_snapshots"])
    lines.append("")
lines += ["Interpretation: registered decals stop growing around60seconds in these runs; total object counts also show decreases. This observation does not prove the exact configured lifespan or pool reuse. Niagara total/active counts describe observed states only.",
          "No monotonic performance degradation established over the120-second runs. Individual over-budget frames remain, so continuous60FPS on every frame is not established.",
          "Inventory visibility is sampled, not a guarantee every enemy is continuously visible. Inventory itself has measured CPU cost; raw results remain primary. Thread sampler is present equally in both cases, and its overhead has not been subtracted.",
          "CPU totals use cumulative per-thread user/kernel deltas with both endpoints inside each window. Edge portions and unsampled threads are omitted; see stress_telemetry.json limits. Shipping results must not be numerically mixed with instrumented Development trace timing.",
          "This pair is one ordered sample per enemy count. It does not justify new production decal/FX changes by itself. Assets/settings and Editor UI were not changed.",
          "Evidence: per-run summary.json, stress_growth_audit.json, stress_telemetry.json, monitor CSVs, Window/sample_window_audit.json, Threads/thread_cpu.csv and Control/execution.json/gate_checks.json. Raw runtime files live at metadata.route."]
text = "\n".join(lines) + "\n"
(here / "stress_long_comparison.txt").write_text(text, encoding="utf8")
(here / "stress_long_comparison.json").write_text(json.dumps(dict(runs=results, interpretation=lines), indent=2), encoding="utf8")
print(text)
