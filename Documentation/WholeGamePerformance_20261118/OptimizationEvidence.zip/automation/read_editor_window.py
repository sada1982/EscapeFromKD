import ctypes
from ctypes import wintypes
import json
import sys

u = ctypes.WinDLL('user32', use_last_error=True)
class Placement(ctypes.Structure):
    _fields_ = [('length', wintypes.UINT), ('flags', wintypes.UINT), ('showCmd', wintypes.UINT), ('ptMinPosition', wintypes.POINT), ('ptMaxPosition', wintypes.POINT), ('rcNormalPosition', wintypes.RECT)]

u.GetForegroundWindow.restype = wintypes.HWND
u.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
u.GetWindowPlacement.argtypes = [wintypes.HWND, ctypes.POINTER(Placement)]
u.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
u.IsWindowVisible.argtypes = [wintypes.HWND]
u.IsIconic.argtypes = [wintypes.HWND]
u.IsZoomed.argtypes = [wintypes.HWND]
callback = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
u.EnumWindows.argtypes = [callback, wintypes.LPARAM]
foreground = u.GetForegroundWindow()
foreground_pid = wintypes.DWORD()
u.GetWindowThreadProcessId(foreground, ctypes.byref(foreground_pid))
result = {'foreground': int(foreground or 0), 'foreground_pid': foreground_pid.value, 'windows': []}
target_pid = int(sys.argv[1])

@callback
def collect(hwnd, ignored):
    pid = wintypes.DWORD()
    u.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
    if pid.value != target_pid:
        return True
    text = ctypes.create_unicode_buffer(1024)
    u.GetWindowTextW(hwnd, text, len(text))
    placement = Placement(length=ctypes.sizeof(Placement))
    ok = bool(u.GetWindowPlacement(hwnd, ctypes.byref(placement)))
    rect = placement.rcNormalPosition
    result['windows'].append({'hwnd': int(hwnd), 'title': text.value, 'visible': bool(u.IsWindowVisible(hwnd)), 'iconic': bool(u.IsIconic(hwnd)), 'zoomed': bool(u.IsZoomed(hwnd)), 'placement_ok': ok, 'flags': placement.flags, 'showCmd': placement.showCmd, 'normal_rect': [rect.left, rect.top, rect.right, rect.bottom], 'min_position': [placement.ptMinPosition.x, placement.ptMinPosition.y], 'max_position': [placement.ptMaxPosition.x, placement.ptMaxPosition.y]})
    return True

if not u.EnumWindows(collect, 0):
    raise ctypes.WinError(ctypes.get_last_error())
print(json.dumps(result, ensure_ascii=False, indent=2))
