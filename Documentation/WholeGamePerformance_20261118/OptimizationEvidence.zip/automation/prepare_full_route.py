import shutil

def full_insert(old, new):
    global cpp
    assert cpp.count(old) == 1, old
    cpp = cpp.replace(old, new)

shutil.copyfile(here / "FullRoute.h", module / "FullRoute.h")
full_insert('#include "Engine/World.h"', '#include "Engine/World.h"\n#include "FullRoute.h"')
full_insert('    bool bRoute = false, bBypassGate = false;', '    bool bRoute = false, bBypassGate = false;\n    bool bFullRoute = false;')
full_insert('    static FVector2D Target(int32 Index)\n    {', '''    FVector2D Target(int32 Index) const
    {
        if (bFullRoute)
        {
            const FVector P=FKDFullRoute::At(Index).Position;
            return FVector2D(P.X,P.Y);
        }''')
full_insert('            if (Leg==7)', '''            if (bFullRoute && FMath::Abs(Pos.Z-FKDFullRoute::At(Leg).Position.Z)>45.0)
            {
                Mark(TEXT("waypoint_height_mismatch"),Now,Pos,Player->GetControlRotation().Yaw);
                WriteSettings(World,Player,Char,TEXT("height_mismatch"));
                Finish(false,TEXT("waypoint_height_mismatch")); return;
            }
            if (Leg==(bFullRoute?FKDFullRoute::Count()-1:7))''')
full_insert('                if (Pos.Z>=-58)', '                if (bFullRoute?FMath::Abs(Pos.Z-FKDFullRoute::At(Leg).Position.Z)>45.0:Pos.Z>=-58)')
full_insert('Finish(true,TEXT("landing"))', 'Finish(true,bFullRoute?TEXT("exit_1f"):TEXT("landing"))')
full_insert('Seconds(Now,StartQpc)>45.0', 'Seconds(Now,StartQpc)>(bFullRoute?180.0:45.0)')
full_insert('Player->SetControlRotation(FRotator(Leg==7?-12.0:0.0,Yaw,0));', 'Player->SetControlRotation(FRotator(bFullRoute?(Leg>=7 && Leg<=22?-12.0:0.0):(Leg==7?-12.0:0.0),Yaw,0));')
full_insert('        bRoute=FParse::Param(Cmd,TEXT("KDExhibitRoute"));', '        bRoute=FParse::Param(Cmd,TEXT("KDExhibitRoute"));\n        bFullRoute=FParse::Param(Cmd,TEXT("KDFullRoute"));')
full_insert('        Frames.Reserve(Laps*1800);', '        Frames.Reserve(Laps*(bFullRoute?12000:1800));')
