import shutil


def ownership_insert(old, new):
    global cpp
    assert cpp.count(old) == 1, old
    cpp = cpp.replace(old, new)


gate_source = (module / "ExhibitStartupGate.cpp").read_text(encoding="utf8")
assert "ResourceReadyQpc" in gate_source and "LoadingFpsLimit" in gate_source
shutil.copyfile(here / "LoadingCapOwnershipTest.h", module / "LoadingCapOwnershipTest.h")
ownership_insert('#include "Engine/World.h"', '#include "Engine/World.h"\n#include "LoadingCapOwnershipTest.h"')
ownership_insert('    FExhibitStartupGate Startup;', '    FExhibitStartupGate Startup;\n    FLoadingCapOwnershipTest CapOwnership;')
ownership_insert('            Startup.Begin(*Viewport,*Player,Now,bBypassGate,bRoute || !Dir.IsEmpty());',
                 '            CapOwnership.BeforeGate(Dir,Now);\n            Startup.Begin(*Viewport,*Player,Now,bBypassGate,bRoute || !Dir.IsEmpty());')
ownership_insert('        Startup.Tick(Now);', '        Startup.Tick(Now);\n        CapOwnership.Tick(Dir,Now,Startup.IsOpen());')
ownership_insert('        Startup.End();', '        Startup.End();\n        if (!Dir.IsEmpty() && FParse::Param(FCommandLine::Get(),TEXT("KDLoadingCapCloseProof"))) Startup.WriteReport(Dir);')
