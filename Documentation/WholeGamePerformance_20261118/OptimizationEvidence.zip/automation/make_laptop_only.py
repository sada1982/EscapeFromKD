import hashlib
import json
import os
from pathlib import Path
import unreal

out = Path(os.environ['KD_MODEL_EVIDENCE'])
project = Path(unreal.Paths.convert_relative_path_to_full(unreal.Paths.project_dir())).resolve()
assert project == Path(os.environ['LOCALAPPDATA']) / 'KDModelLaptopOnly_20261118', project
isolation = json.loads((out / 'LaptopOnly_isolation.json').read_text(encoding='utf8'))
world = unreal.EditorLoadingAndSavingUtils.load_map('/Game/Main/Stage/KDStage')
assert world
bp = unreal.load_asset('/Game/Main/Stage/BP_Floor03')
sub = unreal.get_engine_subsystem(unreal.SubobjectDataSubsystem)
lib = unreal.SubobjectDataBlueprintFunctionLibrary
mesh = unreal.load_asset('/Game/Main/Stage/Floor03/OptimizedV03/SM_F03V03_Laptops')
assert mesh and mesh.get_num_nanite_triangles() == 31500
source_path = '/Game/Main/Stage/Floor03/SurveyV02/SM_F03V02_Laptops.SM_F03V02_Laptops'
props = ['cast_shadow', 'cast_dynamic_shadow', 'cast_hidden_shadow', 'hidden_in_game', 'visible',
         'render_in_main_pass', 'render_in_depth_pass', 'receives_decals', 'render_custom_depth',
         'affect_distance_field_lighting', 'affect_dynamic_indirect_lighting',
         'affect_indirect_lighting_while_hidden', 'visible_in_ray_tracing',
         'visible_in_reflection_captures', 'visible_in_real_time_sky_captures']

def templates():
    result = {}
    for handle in sub.k2_gather_subobject_data_for_blueprint(bp):
        data = lib.get_data(handle)
        result[str(lib.get_variable_name(data))] = (handle, lib.get_object_for_blueprint(data, bp))
    return result

def floor_actor():
    return next(actor for actor in unreal.GameplayStatics.get_all_actors_of_class(world, unreal.Actor) if actor.get_actor_label() == 'BP_Floor03')

def material_paths(component):
    return [component.get_material(i).get_path_name() if component.get_material(i) else None for i in range(component.get_num_materials())]

def collision_only(component):
    component.set_visibility(False, False)
    component.set_hidden_in_game(True, False)
    for prop in ('cast_shadow', 'cast_dynamic_shadow', 'cast_hidden_shadow', 'visible_in_ray_tracing',
                 'affect_distance_field_lighting', 'affect_dynamic_indirect_lighting',
                 'affect_indirect_lighting_while_hidden', 'visible_in_reflection_captures', 'visible_in_real_time_sky_captures'):
        component.set_editor_property(prop, False)

floor = floor_actor()
position = floor.get_actor_location()
rotation = floor.get_actor_rotation()
scale = floor.get_actor_scale3d()
assert all(abs(value) < 0.0001 for value in (position.x, position.y, position.z, rotation.pitch, rotation.yaw, rotation.roll))
assert all(abs(value - 1) < 0.0001 for value in (scale.x, scale.y, scale.z))
records = []
for actor in unreal.GameplayStatics.get_all_actors_of_class(world, unreal.Actor):
    for component in actor.get_components_by_class(unreal.StaticMeshComponent):
        original = component.get_editor_property('static_mesh')
        if not original or original.get_path_name() != source_path:
            continue
        name = 'Laptops_OptimizedV03' if actor == floor else actor.get_actor_label() + '_OptimizedV03'
        records.append(dict(name=name, actor=actor.get_actor_label(), source_component=component.get_name(),
            properties={prop: component.get_editor_property(prop) for prop in props},
            mobility=component.get_editor_property('mobility'), materials=[component.get_material(i) for i in range(component.get_num_materials())],
            expected_materials=material_paths(component), position=component.get_world_location(),
            rotation=component.get_world_rotation(), scale=component.get_world_scale()))
assert len(records) == 2, records
for record in records:
    tree = templates()
    assert record['name'] not in tree
    params = unreal.AddNewSubobjectParams(parent_handle=tree['DefaultSceneRoot'][0], new_class=unreal.StaticMeshComponent, blueprint_context=bp)
    handle, reason = sub.add_new_subobject(params)
    assert not str(reason), reason
    assert sub.rename_subobject(handle, unreal.Text(record['name']))
    target = templates()[record['name']][1]
    target.set_static_mesh(mesh)
    target.set_mobility(record['mobility'])
    for prop, value in record['properties'].items():
        if prop == 'visible':
            target.set_visibility(value, False)
        elif prop == 'hidden_in_game':
            target.set_hidden_in_game(value, False)
        else:
            target.set_editor_property(prop, value)
    target.set_editor_property('relative_location', record['position'])
    target.set_editor_property('relative_rotation', record['rotation'])
    target.set_editor_property('relative_scale3d', record['scale'])
    for index, material in enumerate(record['materials']):
        target.set_material(index, material)
    target.set_collision_profile_name('NoCollision')
    target.set_collision_enabled(unreal.CollisionEnabled.NO_COLLISION)
    target.set_editor_property('can_ever_affect_navigation', False)
    target.set_editor_property('use_attach_parent_bound', False)
    assert material_paths(target) == record['expected_materials']
collision_only(templates()['Laptops'][1])
unreal.BlueprintEditorLibrary.compile_blueprint(bp)
assert unreal.EditorLoadingAndSavingUtils.save_packages([bp.get_outermost()], False)
for actor in unreal.GameplayStatics.get_all_actors_of_class(world, unreal.Actor):
    for component in actor.get_components_by_class(unreal.StaticMeshComponent):
        original = component.get_editor_property('static_mesh')
        if original and original.get_path_name() == source_path:
            collision_only(component)
placed = {component.get_name(): component for component in floor_actor().get_components_by_class(unreal.StaticMeshComponent)}
for record in records:
    assert material_paths(templates()[record['name']][1]) == record['expected_materials']
    assert material_paths(placed[record['name']]) == record['expected_materials']
assert unreal.EditorLoadingAndSavingUtils.save_map(world, '/Game/Main/Stage/KDStage')
unreal.SystemLibrary.execute_console_command(world, 'Editor.AsyncAssetCompilationFinishAll')
os.environ['KD_CENTRAL_RUN'] = str(out)
os.environ['KD_CENTRAL_VARIANT'] = 'laptop_only'
check = out.parent / 'CentralHitch_20261117/verify_world.py'
exec(compile(check.read_text(encoding='utf8'), str(check), 'exec'), {'__name__': '__main__'})
before = json.loads((out / 'world_furniture_before.json').read_text(encoding='utf8'))
after = json.loads((out / 'world_laptop_only.json').read_text(encoding='utf8'))
assert before['tested'] == after['tested'] and before['sha256_trace'] == after['sha256_trace']
for name, component in before['components'].items():
    if name != 'Laptops':
        assert after['components'][name] == component, name
for entry in isolation['files']:
    if 'Chairs' in entry['path'] or '/ShadowCasters/' in entry['path']:
        assert hashlib.sha256((project / entry['path']).read_bytes()).hexdigest() == entry['sha256'], entry['path']
proof = dict(project=str(project), mesh=mesh.get_path_name(), triangles=31500,
    components=[dict(name=record['name'], actor=record['actor'], materials=record['expected_materials']) for record in records],
    chairs_and_shadow_files_unchanged=True, collision_sha256=after['sha256_trace'], collision_rays=after['tested'])
(out / 'laptop_only_proof.json').write_text(json.dumps(proof, indent=2), encoding='utf8')
unreal.log('KDLaptopOnly candidate complete; all chairs and shadow files unchanged')
