import argparse
from collections import defaultdict
import csv
import json
from pathlib import Path
import statistics

here = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument("--run", type=Path, default=here / "AllWaitCPU2")
parser.add_argument("--threads", type=Path, default=here / "AllWaitCPU2Threads")
parser.add_argument("--thread-map", type=Path)
args = parser.parse_args()

def read(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))

meta = json.loads((args.run / "metadata.json").read_text())
route = Path(meta["route"])
events = read(route / "survey_events.csv")
begins = [row for row in events if row["event"] == "sample_begin"]
ends = [row for row in events if row["event"] == "sample_end"]
assert len(begins) == len(ends) == 1
begin, end = int(begins[0]["qpc"]), int(ends[0]["qpc"])
frequency = meta["start"]["frequency"]
duration = (end - begin) / frequency
assert 60 <= duration < 61, duration
frames = read(route / "survey_frames.csv")
assert [int(row["frame"]) for row in frames] == list(range(1, len(frames) + 1))
pending = [row for row in read(route / "survey_pending.csv") if begin <= int(row["qpc"]) <= end]
assert pending and all(int(row["pso_pending"]) == int(row["active_precache"]) == 0 for row in pending)
state = json.loads((args.threads / "thread_cpu_state.json").read_text())
assert state["identity_verified"] and state["pid"] == meta["game_pid"]
threads = read(args.threads / "thread_cpu.csv")
processes = read(args.threads / "thread_process_cpu.csv")
assert threads and max(int(row["observed_threads"]) for row in processes) > 0
names = {int(row["tid"]): row["description"] for row in threads if row["description"]}
mapping_evidence = None
if args.thread_map:
    if args.thread_map.suffix.lower() == ".json":
        mapping_evidence = json.loads(args.thread_map.read_text())
        observed_ids = {int(row["tid"]) for row in threads}
        for row in mapping_evidence["records"]:
            assert int(row["os_tid"]) in observed_ids
            names[int(row["os_tid"])] = row["name"]
    else:
        for row in read(args.thread_map):
            if "SystemThreadId" not in row or "ThreadName" not in row:
                raise ValueError("Map requires SystemThreadId and ThreadName; standard Insights Id/ThreadId is not an OS TID")
            names[int(row["SystemThreadId"])] = row["ThreadName"]

def fraction(row, a, b):
    if not row["elapsed_s"]:
        return 0
    dt = float(row["elapsed_s"])
    stop = (int(row["qpc"]) - begin) / frequency
    return max(0, min(b, stop) - max(a, stop - dt)) / dt

windows = []
for a, b in [(0, 10), (10, 30), (30, 60), (0, 60)]:
    per_thread = defaultdict(lambda: [0.0, 0.0])
    for row in threads:
        weight = fraction(row, a, b)
        if weight:
            item = per_thread[int(row["tid"])]
            item[0] += float(row["delta_user_s"]) * weight
            item[1] += float(row["delta_kernel_s"]) * weight
    process_user = process_kernel = 0.0
    for row in processes:
        weight = fraction(row, a, b)
        if weight:
            process_user += float(row["delta_user_s"]) * weight
            process_kernel += float(row["delta_kernel_s"]) * weight
    process_cpu = process_user + process_kernel
    thread_cpu = sum(sum(item) for item in per_thread.values())
    rows = [dict(tid=tid, name=names.get(tid, ""), user_cpu_s=values[0], kernel_cpu_s=values[1],
                 cpu_s=sum(values), cpu_pct_one_core=sum(values) / (b-a) * 100,
                 process_cpu_share_pct=sum(values) / process_cpu * 100)
            for tid, values in per_thread.items()]
    rows.sort(key=lambda row: -row["cpu_s"])
    selected = [row for row in processes if a <= (int(row["qpc"])-begin)/frequency <= b]
    windows.append(dict(start_s=a, end_s=b, process_user_cpu_s=process_user, process_kernel_cpu_s=process_kernel,
                        process_cpu_s=process_cpu, process_cpu_pct_one_core=process_cpu/(b-a)*100,
                        thread_cpu_s=thread_cpu, thread_cpu_pct_one_core=thread_cpu/(b-a)*100,
                        process_minus_thread_cpu_s=process_cpu-thread_cpu,
                        observed_threads_min=min(int(row["observed_threads"]) for row in selected),
                        observed_threads_max=max(int(row["observed_threads"]) for row in selected),
                        read_window_ms_median=statistics.median(float(row["read_window_ms"]) for row in selected),
                        read_window_ms_max=max(float(row["read_window_ms"]) for row in selected), threads=rows))
gate = dict(line.split("=", 1) for line in (route / "startup_result.txt").read_text().splitlines() if "=" in line)
report = dict(run=str(args.run), thread_source=str(args.threads), game_pid=state["pid"],
              diagnostic_exit_code=meta["returncode"], survey_result=(route/"survey_result.txt").read_text(),
              startup_s=(int(gate["open_qpc"])-int(gate["start_qpc"]))/frequency,
              open_to_sample_s=(begin-int(gate["open_qpc"]))/frequency,
              sample_begin_qpc=begin, sample_end_qpc=end, sample_duration_s=duration,
              frames=len(frames), sequence_complete=True, pending_observations=len(pending),
              pending_zero_at_every_observation=True, named_threads=len(names), mapping_evidence=mapping_evidence, windows=windows,
              limitations=["Diagnostic Development + trace/named-event overhead; not Shipping performance certification.",
                           "Exit 777003 is not normal exit 0; route result and data completeness are checked separately.",
                           "Original AllWaitCPU2/thread_cpu.csv excluded because its snapshot flag returned no threads.",
                           "AllWaitCPU2Threads names were omitted by the original HRESULT==0 check. Standard Insights thread export has internal IDs, not OS TIDs; only supplementary verified SystemThreadId mappings may be joined, and unmapped threads remain unknown.",
                           "Window edges proportionally weight 1-second CPU deltas; subsecond distribution is unknown.",
                           "Thread and process timestamps differ across the read window; use longer windows and report residual."])
(args.run / "actual_cpu_audit.json").write_text(json.dumps(report, indent=2), encoding="utf8")
print(json.dumps({key: report[key] for key in ("sample_duration_s", "frames", "pending_observations", "named_threads")}))
for window in windows:
    print(window["start_s"], window["end_s"], "processCPU%", round(window["process_cpu_pct_one_core"], 3),
          "threadCPU%", round(window["thread_cpu_pct_one_core"], 3), "residualCPU_s", round(window["process_minus_thread_cpu_s"], 4))
