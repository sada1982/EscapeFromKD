import json
import os
from pathlib import Path
import shutil
import unreal

out = Path(os.environ['KD_MODEL_EVIDENCE'])
project = Path(unreal.Paths.convert_relative_path_to_full(unreal.Paths.project_dir())).resolve()
assert project == Path(os.environ['LOCALAPPDATA']) / 'KDModelFurniture_20261118', project
source = out.parents[2]
lib = unreal.EditorAssetLibrary
api = unreal.GeometryScript_AssetUtils
assets = unreal.AssetToolsHelpers.get_asset_tools()
sub = unreal.get_engine_subsystem(unreal.SubobjectDataSubsystem)
sub_lib = unreal.SubobjectDataBlueprintFunctionLibrary
bp = unreal.load_asset('/Game/Main/Stage/BP_Floor03')
world = unreal.EditorLoadingAndSavingUtils.load_map('/Game/Main/Stage/KDStage')
assert world
directory = '/Game/Main/Stage/Floor03/OptimizedV03'
props = ['cast_shadow', 'cast_dynamic_shadow', 'cast_hidden_shadow', 'hidden_in_game', 'visible',
         'render_in_main_pass', 'render_in_depth_pass', 'receives_decals', 'render_custom_depth',
         'affect_distance_field_lighting', 'affect_dynamic_indirect_lighting',
         'affect_indirect_lighting_while_hidden', 'visible_in_ray_tracing',
         'visible_in_reflection_captures', 'visible_in_real_time_sky_captures',
         'relative_location', 'relative_rotation', 'relative_scale3d', 'override_materials']

def components():
    result = {}
    for handle in sub.k2_gather_subobject_data_for_blueprint(bp):
        data = sub_lib.get_data(handle)
        result[str(sub_lib.get_variable_name(data))] = (handle, sub_lib.get_object_for_blueprint(data, bp))
    return result

def read_source(mesh):
    dynamic = unreal.DynamicMesh()
    options = unreal.GeometryScriptCopyMeshFromAssetOptions()
    options.request_tangents = True
    options.apply_build_settings = False
    lod = unreal.GeometryScriptMeshReadLOD()
    lod.lod_type = unreal.GeometryScriptLODType.SOURCE_MODEL
    _, result = api.copy_mesh_from_static_mesh(mesh, dynamic, options, lod)
    assert result == unreal.GeometryScriptOutcomePins.SUCCESS
    return dynamic

def replace_geometry(dynamic, mesh):
    options = unreal.GeometryScriptCopyMeshToAssetOptions()
    options.clean_assigned_materials = False
    options.enable_recompute_normals = False
    options.enable_recompute_tangents = False
    options.enable_remove_degenerates = False
    _, result = api.copy_mesh_to_static_mesh(dynamic, mesh, options, unreal.GeometryScriptMeshWriteLOD(), True)
    assert result == unreal.GeometryScriptOutcomePins.SUCCESS
    unreal.SystemLibrary.execute_console_command(world, 'Editor.AsyncAssetCompilationFinishAll')
    assert mesh.get_num_nanite_triangles() == dynamic.get_triangle_count()

def configure(target, original):
    target.set_mobility(original.get_editor_property('mobility'))
    for prop in props:
        if prop == 'visible':
            target.set_visibility(original.get_editor_property(prop), False)
        elif prop == 'hidden_in_game':
            target.set_hidden_in_game(original.get_editor_property(prop), False)
        else:
            target.set_editor_property(prop, original.get_editor_property(prop))
    target.set_collision_profile_name('NoCollision')
    target.set_collision_enabled(unreal.CollisionEnabled.NO_COLLISION)
    target.set_editor_property('can_ever_affect_navigation', False)
    target.set_editor_property('use_attach_parent_bound', False)

def collision_only(component):
    component.set_visibility(False, False)
    component.set_hidden_in_game(True, False)
    for prop in ('cast_shadow', 'cast_dynamic_shadow', 'cast_hidden_shadow', 'visible_in_ray_tracing',
                 'affect_distance_field_lighting', 'affect_dynamic_indirect_lighting',
                 'affect_indirect_lighting_while_hidden', 'visible_in_reflection_captures', 'visible_in_real_time_sky_captures'):
        component.set_editor_property(prop, False)

def verify_world(label):
    os.environ['KD_CENTRAL_RUN'] = str(out)
    os.environ['KD_CENTRAL_VARIANT'] = label
    check = out.parent / 'CentralHitch_20261117/verify_world.py'
    exec(compile(check.read_text(encoding='utf8'), str(check), 'exec'), {'__name__': '__main__'})

unreal.SystemLibrary.execute_console_command(world, 'Editor.AsyncAssetCompilationFinishAll')
verify_world('furniture_before')
world = unreal.get_editor_subsystem(unreal.UnrealEditorSubsystem).get_editor_world()
unreal.SystemLibrary.execute_console_command(world, 'Interchange.FeatureFlags.Import.FBX 0')
packages = []
proof = dict(project=str(project), groups={}, world_copies=[])
replacement_assets = {}
for category, expected in [('Chairs', 333618), ('Laptops', 31500)]:
    tree = components()
    original = tree[category][1].get_editor_property('static_mesh')
    name = 'SM_F03V03_' + category
    original_fbx = source / 'SourceAssets/Stages/Floor03/OptimizedV03/Export' / (name + '.fbx')
    fbx = project / 'Saved/ModelImport' / (name + '.fbx')
    fbx.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(original_fbx, fbx)
    options = unreal.FbxImportUI()
    options.automated_import_should_detect_type = False
    options.mesh_type_to_import = unreal.FBXImportType.FBXIT_STATIC_MESH
    options.import_mesh = True
    options.import_materials = False
    options.import_textures = False
    options.static_mesh_import_data.combine_meshes = True
    options.static_mesh_import_data.auto_generate_collision = False
    options.static_mesh_import_data.normal_import_method = unreal.FBXNormalImportMethod.FBXNIM_IMPORT_NORMALS_AND_TANGENTS
    task = unreal.AssetImportTask()
    task.automated = True
    task.save = False
    task.options = options
    task.filename = str(fbx)
    task.destination_path = '/Game/_CandidateImport'
    task.destination_name = name
    assets.import_asset_tasks([task])
    assert len(task.imported_object_paths) == 1, list(task.imported_object_paths)
    imported = unreal.load_object(None, task.imported_object_paths[0])
    old_slots = list(original.get_editor_property('static_materials'))
    new_slots = list(imported.get_editor_property('static_materials'))
    assert [str(x.material_slot_name) for x in old_slots] == [str(x.material_slot_name) for x in new_slots]
    dynamic = read_source(imported)
    assert dynamic.get_triangle_count() == expected, (category, dynamic.get_triangle_count())
    assert not lib.does_asset_exist(directory + '/' + name)
    mesh = assets.duplicate_asset(name, directory, original)
    replace_geometry(dynamic, mesh)
    tree = components()
    child = category + '_OptimizedV03'
    params = unreal.AddNewSubobjectParams(parent_handle=tree['DefaultSceneRoot'][0], new_class=unreal.StaticMeshComponent, blueprint_context=bp)
    handle, reason = sub.add_new_subobject(params)
    assert not str(reason), reason
    assert sub.rename_subobject(handle, unreal.Text(child))
    tree = components()
    configure(tree[child][1], tree[category][1])
    tree[child][1].set_static_mesh(mesh)
    collision_only(tree[category][1])
    replacement_assets[original.get_path_name()] = mesh
    record = dict(original=original.get_path_name(), path=mesh.get_path_name(), triangles=expected,
                  fallback_triangles=mesh.get_num_triangles(0), materials=[str(x.material_slot_name) for x in old_slots], shadows=[])
    proof['groups'][category] = record
    packages.append(mesh.get_outermost())
    if category == 'Chairs':
        added = 0
        for label, lo, hi in [('Main', (-5,-1017,-10), (815,5,200)),
                              ('Adjacent', (-225,-2033,-10), (815,-1017,200)),
                              ('Remainder', None, None)]:
            if lo is None:
                part = dynamic
            else:
                box = unreal.Box()
                box.min = unreal.Vector(*lo)
                box.max = unreal.Vector(*hi)
                box.is_valid = True
                _, selection = dynamic.select_mesh_elements_in_box(box)
                part = unreal.DynamicMesh()
                dynamic.copy_mesh_selection_to_mesh(part, selection, False, True)
                dynamic.delete_selected_triangles_from_mesh(selection)
            count = part.get_triangle_count()
            assert count > 0
            added += count
            shadow = components()['Chairs_' + label + '_Shadow'][1].get_editor_property('static_mesh')
            replace_geometry(part, shadow)
            record['shadows'].append(dict(label=label, path=shadow.get_path_name(), triangles=count))
            packages.append(shadow.get_outermost())
        assert added == expected
    unreal.log('KDFurniture geometry complete ' + category)
unreal.BlueprintEditorLibrary.compile_blueprint(bp)
unreal.SystemLibrary.execute_console_command(world, 'Editor.AsyncAssetCompilationFinishAll')
assert unreal.EditorLoadingAndSavingUtils.save_packages(packages + [bp.get_outermost()], False)
world = unreal.EditorLoadingAndSavingUtils.load_map('/Game/Main/Stage/KDStage')
placed = next(actor for actor in unreal.GameplayStatics.get_all_actors_of_class(world, unreal.Actor) if actor.get_actor_label() == 'BP_Floor03')
for component in placed.get_components_by_class(unreal.StaticMeshComponent):
    if component.get_name() in ('Chairs', 'Laptops'):
        collision_only(component)
actors = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
for actor in list(unreal.GameplayStatics.get_all_actors_of_class(world, unreal.StaticMeshActor)):
    original_component = actor.get_component_by_class(unreal.StaticMeshComponent)
    original_mesh = original_component.get_editor_property('static_mesh')
    if not original_mesh or original_mesh.get_path_name() not in replacement_assets:
        continue
    child = actor.get_actor_label() + '_OptimizedV03'
    tree = components()
    params = unreal.AddNewSubobjectParams(parent_handle=tree['DefaultSceneRoot'][0], new_class=unreal.StaticMeshComponent, blueprint_context=bp)
    handle, reason = sub.add_new_subobject(params)
    assert not str(reason), reason
    assert sub.rename_subobject(handle, unreal.Text(child))
    target = components()[child][1]
    configure(target, original_component)
    target.set_static_mesh(replacement_assets[original_mesh.get_path_name()])
    collision_only(original_component)
    proof['world_copies'].append(dict(original=actor.get_actor_label(), visual='BP_Floor03.' + child,
                                      original_mesh=original_mesh.get_path_name(), mesh=target.get_editor_property('static_mesh').get_path_name()))
assert len(proof['world_copies']) == 2, proof['world_copies']
unreal.BlueprintEditorLibrary.compile_blueprint(bp)
assert unreal.EditorLoadingAndSavingUtils.save_packages([bp.get_outermost()], False)
assert unreal.EditorLoadingAndSavingUtils.save_map(world, '/Game/Main/Stage/KDStage')
verify_world('furniture_after')
before = json.loads((out / 'world_furniture_before.json').read_text(encoding='utf8'))
after = json.loads((out / 'world_furniture_after.json').read_text(encoding='utf8'))
assert before['tested'] == after['tested'] and before['sha256_trace'] == after['sha256_trace']
proof['collision_rays'] = before['tested']
proof['collision_sha256'] = before['sha256_trace']
(out / 'furniture_geometry_proof.json').write_text(json.dumps(proof, indent=2), encoding='utf8')
unreal.log('KDFurniture candidate complete')
