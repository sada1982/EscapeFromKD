import argparse
import ctypes as c
from ctypes import wintypes as w
import datetime
import json
from pathlib import Path
import time

u = c.WinDLL('user32', use_last_error=True)
k = c.WinDLL('kernel32', use_last_error=True)

class Placement(c.Structure):
    _fields_ = [('length', w.UINT), ('flags', w.UINT), ('showCmd', w.UINT), ('minimum', w.POINT), ('maximum', w.POINT), ('normal', w.RECT)]

u.GetForegroundWindow.restype = w.HWND
u.GetWindowThreadProcessId.argtypes = [w.HWND, c.POINTER(w.DWORD)]
u.GetWindowPlacement.argtypes = [w.HWND, c.POINTER(Placement)]
u.GetWindowTextW.argtypes = [w.HWND, w.LPWSTR, c.c_int]
u.IsWindow.argtypes = [w.HWND]
u.IsIconic.argtypes = [w.HWND]
u.IsZoomed.argtypes = [w.HWND]
u.IsWindowVisible.argtypes = [w.HWND]
u.ShowWindowAsync.argtypes = [w.HWND, c.c_int]
k.OpenProcess.argtypes = [w.DWORD, w.BOOL, w.DWORD]
k.OpenProcess.restype = w.HANDLE
k.QueryFullProcessImageNameW.argtypes = [w.HANDLE, w.DWORD, w.LPWSTR, c.POINTER(w.DWORD)]
k.GetProcessTimes.argtypes = [w.HANDLE, c.POINTER(w.FILETIME), c.POINTER(w.FILETIME), c.POINTER(w.FILETIME), c.POINTER(w.FILETIME)]
k.CloseHandle.argtypes = [w.HANDLE]

def require(condition, message):
    if not condition:
        raise RuntimeError(message)

def foreground():
    hwnd = u.GetForegroundWindow()
    pid = w.DWORD()
    u.GetWindowThreadProcessId(hwnd, c.byref(pid))
    return dict(hwnd=int(hwnd or 0), pid=pid.value)

def window_state(hwnd):
    require(u.IsWindow(hwnd), 'Target HWND no longer exists')
    pid = w.DWORD()
    u.GetWindowThreadProcessId(hwnd, c.byref(pid))
    p = Placement(length=c.sizeof(Placement))
    require(u.GetWindowPlacement(hwnd, c.byref(p)), 'GetWindowPlacement failed')
    title = c.create_unicode_buffer(1024)
    u.GetWindowTextW(hwnd, title, len(title))
    return dict(hwnd=hwnd, pid=pid.value, title=title.value, visible=bool(u.IsWindowVisible(hwnd)), iconic=bool(u.IsIconic(hwnd)), zoomed=bool(u.IsZoomed(hwnd)), flags=p.flags, showCmd=p.showCmd, normal_rect=[p.normal.left,p.normal.top,p.normal.right,p.normal.bottom], min_position=[p.minimum.x,p.minimum.y], max_position=[p.maximum.x,p.maximum.y])

def process_identity(pid):
    handle = k.OpenProcess(0x1000, False, pid)
    require(handle, 'Cannot open target process for identity query')
    try:
        path = c.create_unicode_buffer(32768)
        size = w.DWORD(len(path))
        require(k.QueryFullProcessImageNameW(handle, 0, path, c.byref(size)), 'Cannot query process executable')
        creation, exit_time, kernel, user = w.FILETIME(), w.FILETIME(), w.FILETIME(), w.FILETIME()
        require(k.GetProcessTimes(handle, c.byref(creation), c.byref(exit_time), c.byref(kernel), c.byref(user)), 'Cannot query process creation time')
        return dict(pid=pid, exe=path.value, creation_filetime=(creation.dwHighDateTime<<32)|creation.dwLowDateTime)
    finally:
        k.CloseHandle(handle)

def save(path, data):
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding='utf8')

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['inspect','minimize','restore'])
    parser.add_argument('--pid', type=int, required=True)
    parser.add_argument('--hwnd', type=int, required=True)
    parser.add_argument('--exe', type=Path, required=True)
    parser.add_argument('--state', type=Path, required=True)
    args = parser.parse_args()
    current = window_state(args.hwnd)
    identity = process_identity(args.pid)
    require(current['pid']==args.pid, 'HWND belongs to a different PID')
    require(Path(identity['exe']).resolve()==args.exe.resolve(strict=True), 'Live executable differs from expected executable')
    require(args.exe.name.lower()=='unrealeditor.exe', 'This helper is restricted to UnrealEditor.exe')
    require(current['title']=='myProject - Unreal Editor', 'Editor window title differs from verified target')
    if args.action=='inspect':
        print(json.dumps(dict(identity=identity, window=current, foreground=foreground()), ensure_ascii=False))
        return
    if args.action=='minimize':
        require(not args.state.exists(), 'State file already exists; refuse to overwrite restoration record')
        require(current['visible'] and not current['iconic'] and current['showCmd'] in [1,3], 'Target is not a visible normal/maximized Editor')
        original = current
        record = dict(identity=identity, original=original, events=[])
        command = 7
    else:
        record = json.loads(args.state.read_text(encoding='utf8'))
        require(record['identity']==identity, 'Editor PID/executable/creation time changed since minimize')
        original = record['original']
        require(original['hwnd']==args.hwnd, 'Restoration HWND differs')
        require(current['iconic'], 'Editor is already restored or was changed by the user; no automatic operation performed')
        require(current['normal_rect']==original['normal_rect'], 'Normal rect changed while minimized; no automatic operation performed')
        require(current['max_position']==original['max_position'], 'Max position changed while minimized')
        if original['zoomed']:
            require(current['flags']&2, 'WPF_RESTORETOMAXIMIZED was not preserved')
        command = 4
    before = foreground()
    require(before['pid']!=args.pid, 'Editor is foreground; user may be working in it')
    event = dict(action=args.action, utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), qpc_ns=time.perf_counter_ns(), command=command, before=current, foreground_before=before)
    record['events'].append(event)
    save(args.state, record)
    require(u.ShowWindowAsync(args.hwnd, command), 'ShowWindowAsync did not accept the request')
    observed = []
    success = False
    for attempt in range(100):
        time.sleep(0.05)
        fg = foreground()
        if not observed or observed[-1]['value']!=fg:
            observed.append(dict(qpc_ns=time.perf_counter_ns(), value=fg))
        after = window_state(args.hwnd)
        if args.action=='minimize':
            success = after['iconic'] and after['normal_rect']==original['normal_rect']
        else:
            success = not after['iconic'] and after['showCmd']==original['showCmd'] and after['zoomed']==original['zoomed'] and after['normal_rect']==original['normal_rect'] and after['max_position']==original['max_position']
        if success:
            break
    event.update(after=after, foreground_after=foreground(), foreground_samples=observed, state_verified=success)
    event['foreground_unchanged'] = event['foreground_after']==before and all(sample['value']==before for sample in observed)
    save(args.state, record)
    print(json.dumps(event, ensure_ascii=False))
    require(success, 'Expected window placement was not observed; restoration record retained')
    require(event['foreground_unchanged'], 'Foreground changed during observation; do not accept this measurement as a focus-preserving trial')

if __name__=='__main__':
    main()
