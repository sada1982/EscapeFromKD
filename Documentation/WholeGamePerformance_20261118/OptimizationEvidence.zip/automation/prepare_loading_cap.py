import difflib
import hashlib
import json
from pathlib import Path

here = Path(__file__).resolve().parent
source = here.parents[2] / "Build/Exhibit/Source/myProject"
output = here / "LoadingCapCandidate"
output.mkdir(exist_ok=True)
original_h = (source / "ExhibitStartupGate.h").read_text(encoding="utf-8-sig")
original_cpp = (source / "ExhibitStartupGate.cpp").read_text(encoding="utf-8-sig")
header, cpp = original_h, original_cpp

def change(text, old, new):
    assert text.count(old) == 1, old
    return text.replace(old, new)

header = change(header, "class APlayerController;", "class APlayerController;\nclass IConsoleVariable;")
header = change(header, "    void ReleaseInput();", "    void ReleaseInput();\n"
                "    void UpdateLoadingFrameCap(uint32 PsoPending);\n"
                "    void RestoreLoadingFrameCap();\n"
                "    void LoadingFrameCapChanged(IConsoleVariable* Variable);")
header = change(header, "    FString Reason, Diagnostics;", "    FString Reason, Diagnostics;\n"
                "    IConsoleVariable* LoadingMaxFps = nullptr;\n"
                "    FDelegateHandle LoadingMaxFpsHandle;\n"
                "    FString PreviousMaxFps, LoadingCapStatus = TEXT(\"disabled\");\n"
                "    uint32 PreviousMaxFpsPriority = 0;\n"
                "    int32 LoadingFpsLimit = 0, LoadingCapApplies = 0, LoadingCapRestores = 0;\n"
                "    bool bLoadingCapActive = false, bWritingLoadingCap = false, bLoadingCapExternalChange = false;")
cpp = change(cpp, "    if (InPlayer.GetPawn()) StartingPawn = InPlayer.GetPawn()->GetActorLocation();", """    FParse::Value(FCommandLine::Get(),TEXT("KDStartupMaxFPS="),LoadingFpsLimit);
    if (LoadingFpsLimit != 0 && LoadingFpsLimit != 30)
    {
        LoadingFpsLimit = 0;
        LoadingCapStatus = TEXT("invalid_argument_disabled");
    }
    if (LoadingFpsLimit == 30) LoadingCapStatus = TEXT("waiting_for_pso");
    if (InPlayer.GetPawn()) StartingPawn = InPlayer.GetPawn()->GetActorLocation();""")
cpp = change(cpp, "    const uint32 PsoPending = FShaderPipelineCache::NumPrecompilesRemaining();", "    const uint32 PsoPending = FShaderPipelineCache::NumPrecompilesRemaining();\n    UpdateLoadingFrameCap(PsoPending);")
functions = '''void FExhibitStartupGate::LoadingFrameCapChanged(IConsoleVariable*)
{
    if (bLoadingCapActive && !bWritingLoadingCap) bLoadingCapExternalChange = true;
}

void FExhibitStartupGate::UpdateLoadingFrameCap(uint32 PsoPending)
{
    if (LoadingFpsLimit != 30 || OpenQpc) return;
    if (bLoadingCapActive && (PsoPending == 0 || bLoadingCapExternalChange)) RestoreLoadingFrameCap();
    if (bLoadingCapActive || bLoadingCapExternalChange || PsoPending == 0) return;
    LoadingMaxFps = IConsoleManager::Get().FindConsoleVariable(TEXT("t.MaxFPS"));
    if (!LoadingMaxFps) { LoadingCapStatus = TEXT("cvar_missing");return; }
    const float Current = LoadingMaxFps->GetFloat();
    if (!FMath::IsFinite(Current)) { LoadingCapStatus = TEXT("invalid_original_value");return; }
    if (Current > 0 && Current <= LoadingFpsLimit) { LoadingCapStatus = TEXT("existing_cap_already_lower");return; }
    PreviousMaxFps = LoadingMaxFps->GetString();
    PreviousMaxFpsPriority = LoadingMaxFps->GetFlags() & ECVF_SetByMask;
    LoadingMaxFpsHandle = LoadingMaxFps->OnChangedDelegate().AddRaw(this,&FExhibitStartupGate::LoadingFrameCapChanged);
    bLoadingCapActive = bWritingLoadingCap = true;
    if (PreviousMaxFpsPriority == ECVF_SetByConstructor)
        LoadingMaxFps->Set(static_cast<float>(LoadingFpsLimit),ECVF_SetByConstructor);
    else
        LoadingMaxFps->ReplaceCurrentPriorityAndTag(static_cast<float>(LoadingFpsLimit));
    bWritingLoadingCap = false;
    ++LoadingCapApplies;
    LoadingCapStatus = TEXT("active");
    if (LoadingMaxFps->GetFloat() != LoadingFpsLimit || (LoadingMaxFps->GetFlags() & ECVF_SetByMask) != PreviousMaxFpsPriority)
    {
        bLoadingCapExternalChange = true;
        RestoreLoadingFrameCap();
    }
}

void FExhibitStartupGate::RestoreLoadingFrameCap()
{
    if (!bLoadingCapActive || !LoadingMaxFps) return;
    const bool Owned = !bLoadingCapExternalChange && LoadingMaxFps->GetFloat() == LoadingFpsLimit &&
        (LoadingMaxFps->GetFlags() & ECVF_SetByMask) == PreviousMaxFpsPriority;
    LoadingMaxFps->OnChangedDelegate().Remove(LoadingMaxFpsHandle);
    LoadingMaxFpsHandle.Reset();
    bLoadingCapActive = false;
    if (Owned)
    {
        if (PreviousMaxFpsPriority == ECVF_SetByConstructor)
            LoadingMaxFps->Set(*PreviousMaxFps,ECVF_SetByConstructor);
        else
            LoadingMaxFps->ReplaceCurrentPriorityAndTag(*PreviousMaxFps);
        ++LoadingCapRestores;
        LoadingCapStatus = LoadingMaxFps->GetString() == PreviousMaxFps &&
            (LoadingMaxFps->GetFlags() & ECVF_SetByMask) == PreviousMaxFpsPriority ? TEXT("restored") : TEXT("restore_changed");
        if (LoadingCapStatus != TEXT("restored")) bLoadingCapExternalChange = true;
    }
    else
    {
        bLoadingCapExternalChange = true;
        LoadingCapStatus = TEXT("external_change_preserved");
    }
}

'''
cpp = change(cpp, "void FExhibitStartupGate::ReleaseInput()\n{", functions + "void FExhibitStartupGate::ReleaseInput()\n{\n    RestoreLoadingFrameCap();")
cpp = change(cpp, "    if (!bRecording) return;\n    FFileHelper::SaveStringToFile(Diagnostics", '''    if (!bRecording) return;
    const IConsoleVariable* MaxFps = IConsoleManager::Get().FindConsoleVariable(TEXT("t.MaxFPS"));
    const FString CapProof = FString::Printf(TEXT("requested_fps=%d\\nstatus=%s\\napplies=%d\\nrestores=%d\\nactive=%d\\nexternal_change=%d\\nprevious_value=%s\\nprevious_priority=%u\\nfinal_value=%s\\nfinal_priority=%u\\n"),
        LoadingFpsLimit,*LoadingCapStatus,LoadingCapApplies,LoadingCapRestores,bLoadingCapActive?1:0,bLoadingCapExternalChange?1:0,
        *PreviousMaxFps,PreviousMaxFpsPriority,MaxFps?*MaxFps->GetString():TEXT("missing"),MaxFps?(MaxFps->GetFlags() & ECVF_SetByMask):0);
    FFileHelper::SaveStringToFile(CapProof,*FPaths::Combine(Directory,TEXT("startup_frame_cap.txt")),FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM);
    FFileHelper::SaveStringToFile(Diagnostics''')
proof = dict(flag="-KDStartupMaxFPS=0|30", default=0, built=False, files={})
for name, before, after in [("ExhibitStartupGate.h", original_h, header), ("ExhibitStartupGate.cpp", original_cpp, cpp)]:
    (output / name).write_text(after, encoding="utf8")
    (output / (name + ".patch.txt")).write_text("".join(difflib.unified_diff(before.splitlines(True), after.splitlines(True), fromfile="formal/"+name, tofile="candidate/"+name)), encoding="utf8")
    proof["files"][name] = dict(source_sha256=hashlib.sha256((source/name).read_bytes()).hexdigest(), candidate_sha256=hashlib.sha256((output/name).read_bytes()).hexdigest())
(output / "proof.json").write_text(json.dumps(proof, indent=2), encoding="utf8")
print(output)
