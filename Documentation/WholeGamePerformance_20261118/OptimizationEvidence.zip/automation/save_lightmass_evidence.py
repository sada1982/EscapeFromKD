import hashlib
import json
from pathlib import Path
import shutil

out = Path(__file__).resolve().parent
evidence = out / 'LightmassEvidence'
evidence.mkdir(exist_ok=False)
routes = {'Lumen': Path('C:/Users/motoo/AppData/Local/Temp/KDWholeGame_7dfghgrz/route'),
          'Bake': Path('C:/Users/motoo/AppData/Local/Temp/KDWholeGame_sl1502nv/route')}
manifest = []
for label, route in routes.items():
    folder = evidence / label
    folder.mkdir()
    for name in ('feet_00_Baseline.png', 'wheels_00_Baseline.png', 'exit_00_Baseline.png',
                 'quality_poses.csv', 'quality_result.txt', 'lightmass_prototype.txt', 'settings.txt',
                 'baked_gi_trial.txt', 'baked_gi_lights.csv', 'isolation.json', 'startup_result.txt'):
        path = route / name
        if path.is_file():
            target = folder / name
            shutil.copy2(path, target)
            manifest.append(dict(source=str(path), evidence=str(target), sha256=hashlib.sha256(target.read_bytes()).hexdigest()))
    result = dict(rejected_for_quality=True, runtime_completed=True, performance_measured=False,
                  reason='Visible PC backside reflection/brightness and chair/header shading differences; UV warnings remain. Whole-stage and enemy lighting untested.')
    (folder / 'quality_decision.json').write_text(json.dumps(result, indent=2), encoding='utf8')
(evidence / 'manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf8')
print(str(evidence))
