import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil

parser = argparse.ArgumentParser()
parser.add_argument('--source-project', required=True)
args = parser.parse_args()
out = Path(__file__).resolve().parent
work = Path(os.environ['LOCALAPPDATA']) / 'KDLightmassTrial_20261118'
source = Path(args.source_project).resolve()
assert source != work and (source / 'Source/myProject/Survey.h').is_file()
assert (work / 'myProject.uproject').is_file(), 'Run prepare_lightmass_trial.py first.'
record_path = out / 'lightmass_probe_source.json'
assert not record_path.exists(), 'Do not overwrite an existing recorded prototype source.'
originals = {path.relative_to(source).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest()
             for path in (source / 'Source').rglob('*') if path.is_file()}
backup = work / 'Saved/LightmassProbe/SourceBefore'
assert not backup.exists()
shutil.copytree(work / 'Source', backup, copy_function=shutil.copy2)
shutil.copytree(source / 'Source', work / 'Source', dirs_exist_ok=True, copy_function=shutil.copy2)
module = work / 'Source/myProject'
for name in ('BakedGITrial.h', 'LightmassPrototype.h'):
    shutil.copy2(out / name, module / name)

def replace_once(path, before, after):
    with path.open(encoding='utf8', newline='') as stream:
        text = stream.read()
    newline = '\r\n' if '\r\n' in text else '\n'
    before = before.replace('\n', newline)
    after = after.replace('\n', newline)
    assert text.count(before) == 1, (path, before, text.count(before))
    with path.open('w', encoding='utf8', newline='') as stream:
        stream.write(text.replace(before, after, 1))

replace_once(module / 'myProject.cpp', '#include "GalleryMaterialCheck.h"',
             '#include "GalleryMaterialCheck.h"\n#include "LightmassPrototype.h"')
replace_once(module / 'myProject.cpp',
    'if (!World->GetOutermost()->GetName().EndsWith(TEXT("/KDStage")) || Char->GetClass()->GetName()!=TEXT("You_C"))',
    'if ((!World->GetOutermost()->GetName().EndsWith(TEXT("/KDStage")) && !IsIsolatedLightmassMap(World)) || Char->GetClass()->GetName()!=TEXT("You_C"))')
replace_once(module / 'myProject.cpp', '            StartupWorld = World;',
    '            if (!InitializeIsolatedLightmassPrototype(World,Dir))\n'
    '            {\n'
    '                Finish(false,TEXT("lightmass_prototype_invalid"));\n'
    '                return;\n'
    '            }\n'
    '            StartupWorld = World;')
replace_once(module / 'LightCandidates.h', '#include "CoreMinimal.h"',
    '#include "CoreMinimal.h"\n#include "LightmassPrototype.h"')
replace_once(module / 'LightCandidates.h', '        if (Lights!=61 || Mega!=42 || Shadowed!=42)',
    '        if (IsIsolatedLightmassMap(World))\n'
    '        {\n'
    '            const bool Valid=Id==TEXT("Baseline") && Lights==12 && Mega==12 && Shadowed==12;\n'
    '            Record(EvidenceDir,Evidence+(Valid?TEXT("success=1\\napplied=0\\ncropped_lightmass_trial=1\\n"):TEXT("success=0\\nreason=cropped_light_configuration_mismatch\\n")));\n'
    '            return Valid;\n'
    '        }\n'
    '        if (Lights!=61 || Mega!=42 || Shadowed!=42)')
replace_once(module / 'Survey.h',
    '            if (Chosen.IsEmpty() || Chosen.Contains(P.Name)) Poses.Add(P);',
    '            if ((!IsIsolatedLightmassMap(Char->GetWorld()) || FString(P.Name).StartsWith(TEXT("Classroom"))) &&\n'
    '                (Chosen.IsEmpty() || Chosen.Contains(P.Name))) Poses.Add(P);')
replace_once(module / 'QualitySweep.h', '            FString Filter;',
    '            if (IsIsolatedLightmassMap(Char->GetWorld()))\n'
    '                Poses.RemoveAll([](const FPose& P){return FString(P.Name)!=TEXT("feet") && FString(P.Name)!=TEXT("wheels") && FString(P.Name)!=TEXT("exit");});\n'
    '            FString Filter;')
replace_once(module / 'QualitySweep.h', '            FParse::Value(FCommandLine::Get(),TEXT("KDQualityCandidates="),List,false);',
    '            if (IsIsolatedLightmassMap(Char->GetWorld())) List=TEXT("Baseline,Baseline");\n'
    '            FParse::Value(FCommandLine::Get(),TEXT("KDQualityCandidates="),List,false);')
for relative, digest in originals.items():
    assert hashlib.sha256((source / relative).read_bytes()).hexdigest() == digest, relative
    assert (source / relative).stat().st_ino != (work / relative).stat().st_ino, relative
files = {path.relative_to(work).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest()
         for path in (work / 'Source').rglob('*') if path.is_file()}
record = dict(project=str(work), source_project=str(source), source_original_sha256=originals,
    prototype_sha256=files, original_source_unchanged=True, heavy_commands_executed=False,
    guards='Exact two /Game/Diagnostics/LightmassTrial maps plus -KDLightmassPrototype; normal KDStage still requires 61/42/42.')
record_path.write_text(json.dumps(record, indent=2), encoding='utf8')
print('KD_LIGHTMASS_PROBE_PREPARED', work)
