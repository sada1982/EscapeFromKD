#pragma once
#include "CoreMinimal.h"
#include "Components/RectLightComponent.h"
#include "Engine/Level.h"
#include "Engine/MapBuildDataRegistry.h"
#include "Engine/World.h"
#include "EngineUtils.h"
#include "Misc/CommandLine.h"
#include "Misc/FileHelper.h"
#include "Misc/Parse.h"
#include "Misc/Paths.h"

inline bool InitializeIsolatedBakedGITrial(UWorld* World, const FString& Directory)
{
    if(!FParse::Param(FCommandLine::Get(),TEXT("KDBakedGITrial"))) return true;
    auto Record=[&Directory](const FString& Text)
    {
        FFileHelper::SaveStringToFile(Text,*FPaths::Combine(Directory,TEXT("baked_gi_trial.txt")),FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM);
    };
    if(!World || !World->IsGameWorld() || !World->GetMapName().EndsWith(TEXT("KDStage_BakeTrial")))
    {
        Record(TEXT("success=0\nreason=requires_isolated_bake_game_world\n"));
        return false;
    }
    ULevel* Level=World->PersistentLevel;
    UMapBuildDataRegistry* Registry=Level?Level->MapBuildData.Get():nullptr;
    int32 BeforeMeshes=0, BeforeClusters=0;
    if(Registry) Registry->GetLightmapResourceClusterStats(BeforeMeshes,BeforeClusters);
    const bool HasVolume=Registry && Registry->GetLevelPrecomputedVolumetricLightmapBuildData(Level->LevelBuildDataId)!=nullptr;
    if(!Registry || BeforeMeshes<=0 || BeforeClusters<=0 || !HasVolume)
    {
        Record(FString::Printf(TEXT("success=0\nreason=missing_baked_mesh_or_volume_data\nmeshes=%d\nclusters=%d\nvolume=%d\n"),BeforeMeshes,BeforeClusters,HasVolume?1:0));
        return false;
    }
    TArray<URectLightComponent*> Lights;
    for(TActorIterator<AActor> It(World);It;++It)
    {
        if(URectLightComponent* Light=It->FindComponentByClass<URectLightComponent>()) Lights.Add(Light);
    }
    if(Lights.Num()!=12)
    {
        Record(FString::Printf(TEXT("success=0\nreason=unexpected_light_count\nlights=%d\n"),Lights.Num()));
        return false;
    }
    for(URectLightComponent* Light:Lights)
    {
        if(Light->Mobility!=EComponentMobility::Stationary || !Light->CastShadows || !Light->CastDynamicShadows)
        {
            Record(TEXT("success=0\nreason=unexpected_baked_light_settings\n"));
            return false;
        }
    }
    FString LightRows=TEXT("component,intensity,radius,allow_megalights,movable,transform_unchanged\n");
    bool Unchanged=true;
    for(URectLightComponent* Light:Lights)
    {
        const FTransform Transform=Light->GetComponentTransform();
        const float Intensity=Light->Intensity;
        const float Radius=Light->AttenuationRadius;
        const bool Mega=Light->bAllowMegaLights;
        Light->SetMobility(EComponentMobility::Movable);
        const bool Same=Light->GetComponentTransform().Equals(Transform,0.0001f) &&
            Light->Intensity==Intensity && Light->AttenuationRadius==Radius && Light->bAllowMegaLights==Mega;
        Unchanged &= Same && Light->Mobility==EComponentMobility::Movable;
        LightRows+=FString::Printf(TEXT("%s,%.4f,%.4f,%d,%d,%d\n"),*Light->GetName(),Intensity,Radius,Mega?1:0,
            Light->Mobility==EComponentMobility::Movable?1:0,Same?1:0);
    }
    int32 AfterMeshes=0, AfterClusters=0;
    Registry->GetLightmapResourceClusterStats(AfterMeshes,AfterClusters);
    const bool SameRegistry=Level->MapBuildData==Registry && BeforeMeshes==AfterMeshes && BeforeClusters==AfterClusters &&
        Registry->GetLevelPrecomputedVolumetricLightmapBuildData(Level->LevelBuildDataId)!=nullptr;
    const bool Success=Unchanged && SameRegistry;
    FFileHelper::SaveStringToFile(LightRows,*FPaths::Combine(Directory,TEXT("baked_gi_lights.csv")),FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM);
    Record(FString::Printf(TEXT("success=%d\nlights=%d\nmeshes_before=%d\nmeshes_after=%d\nclusters_before=%d\nclusters_after=%d\nvolume=%d\nquality_verified=0\n"),
        Success?1:0,Lights.Num(),BeforeMeshes,AfterMeshes,BeforeClusters,AfterClusters,HasVolume?1:0));
    return Success;
}
