#pragma once
#include "LightCandidates.h"
#include "Camera/PlayerCameraManager.h"
#include "GameFramework/Character.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "GameFramework/PlayerController.h"
#include "HAL/FileManager.h"
#include "Misc/DefaultValueHelper.h"
#include "SceneView.h"
#include "SceneViewExtension.h"
#include "UnrealClient.h"

class FQualityExposure final : public FSceneViewExtensionBase
{
public:
    FQualityExposure(const FAutoRegister& AutoRegister) : FSceneViewExtensionBase(AutoRegister) {}
    bool Fixed=false;
    float Ev=0, Last=0;
    virtual void SetupViewFamily(FSceneViewFamily& Family) override
    {
        if (Fixed) { Family.ExposureSettings.bFixed=true; Family.ExposureSettings.FixedEV100=Ev; }
    }
    virtual void SetupView(FSceneViewFamily&,FSceneView& View) override { Last=View.GetLastEyeAdaptationExposure(); }
};

struct FLightQualitySweep
{
    bool Enabled=false,Initialized=false,Finished=false;
    int32 PoseIndex=0,Trial=0,Frame=0,SettleFrames=120;
    FIsolatedLightCandidate Light;
    TSharedPtr<FQualityExposure,ESPMode::ThreadSafe> Exposure;
    FString Records=TEXT("view,trial,candidate,ev,x,y,z,pitch,yaw,fov\n");
    struct FPose { const TCHAR* Name; FVector P; FRotator R; };
    TArray<FPose> Poses;
    TArray<FString> Candidates;
    FString ReferencePath;
    TMap<FString,float> ReferenceEv;
    bool ReadReference(FString& Error)
    {
        const TCHAR* Cursor=FCommandLine::Get();
        FString Token;int32 Arguments=0;
        while (FParse::Token(Cursor,Token,false))
            if (Token.Equals(TEXT("-KDQualityReference"),ESearchCase::IgnoreCase) || Token.StartsWith(TEXT("-KDQualityReference="),ESearchCase::IgnoreCase)) ++Arguments;
        if (Arguments==0) return true;
        if (Arguments!=1 || !FParse::Value(FCommandLine::Get(),TEXT("KDQualityReference="),ReferencePath,false) || ReferencePath.IsEmpty())
        { Error=TEXT("reference_argument_missing_or_duplicate");return false; }
        FString Csv;TArray<FString> Lines;
        if (!FFileHelper::LoadFileToString(Csv,*ReferencePath)) { Error=TEXT("reference_file_unreadable");return false; }
        Csv.ParseIntoArrayLines(Lines,true);
        if (Lines.IsEmpty() || Lines[0].TrimStartAndEnd()!=TEXT("view,trial,candidate,ev,x,y,z,pitch,yaw,fov"))
        { Error=TEXT("reference_header_invalid");return false; }
        for (int32 Index=1;Index<Lines.Num();++Index)
        {
            TArray<FString> Cells;Lines[Index].ParseIntoArray(Cells,TEXT(","),false);
            for (FString& Cell : Cells) Cell.TrimStartAndEndInline();
            int32 SourceTrial=0;
            if (Cells.Num()!=10 || !FDefaultValueHelper::ParseInt(Cells[1],SourceTrial))
            { Error=FString::Printf(TEXT("reference_row_invalid_%d"),Index+1);return false; }
            if (SourceTrial!=0 || Cells[2]!=TEXT("Baseline")) continue;
            float Ev=0;
            if (Cells[0].IsEmpty() || !FDefaultValueHelper::ParseFloat(Cells[3],Ev) || !FMath::IsFinite(Ev))
            { Error=FString::Printf(TEXT("reference_ev_invalid_%d"),Index+1);return false; }
            if (ReferenceEv.Contains(Cells[0]))
            { Error=TEXT("reference_view_duplicate_")+Cells[0];return false; }
            ReferenceEv.Add(Cells[0],Ev);
        }
        for (const FPose& Pose : Poses)
            if (!ReferenceEv.Contains(Pose.Name)) { Error=TEXT("reference_view_missing_")+FString(Pose.Name);return false; }
        return true;
    }
    void Update(const FString& Dir,APlayerController* Player,ACharacter* Char,float)
    {
        if (Finished) return;
        if (!Initialized)
        {
            Initialized=true;
            FParse::Value(FCommandLine::Get(),TEXT("KDQualitySettleFrames="),SettleFrames);
            SettleFrames=FMath::Clamp(SettleFrames,120,1200);
            FFileHelper::SaveStringToFile(FString::Printf(TEXT("settle_frames=%d\ntrial_0_capture_frame=%d\nother_capture_frame=%d\n"),SettleFrames,180+SettleFrames,SettleFrames),*FPaths::Combine(Dir,TEXT("quality_timing.txt")),FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM);
            Exposure=FSceneViewExtensions::NewExtension<FQualityExposure>();
            Poses={{TEXT("feet"),{402,-440,98.15},{-34,-176,0}},
                   {TEXT("wheels"),{402,-724,98.15},{-34,-5,0}},
                   {TEXT("exit"),{120,-890,98.15},{0,180,0}},
                   {TEXT("atrium3"),{-117,-550,98.15},{-25,-155,0}},
                   {TEXT("gallery3"),{-117,-420,98.15},{0,90,0}},
                   {TEXT("gallery2"),{-105,-850,-216.85},{-3,90,0}},
                   {TEXT("atrium1"),{-950,-700,-531.85},{20,35,0}},
                   {TEXT("atrium1up"),{-950,-700,-531.85},{55,35,0}},
                   {TEXT("exit1"),{700,-220,-531.85},{0,0,0}}};
            FString Filter;
            if (FParse::Value(FCommandLine::Get(),TEXT("KDQualityViews="),Filter,false))
            {
                TArray<FString> Wanted;Filter.ParseIntoArray(Wanted,TEXT(","),true);
                Poses.RemoveAll([&](const FPose& P){return !Wanted.Contains(P.Name);});
            }
            FString List=TEXT("Baseline,Baseline,Upper1600Raw,Upper1600Comp,Middle1600Raw,Middle1600Comp,Lower1600Raw,Lower1600Comp,AtriumRect1300Raw,AtriumRect1300Comp,ClassroomFill780Raw,ClassroomFill780Comp,NearGalleryFill550Raw,NearGalleryFill550Comp");
            FParse::Value(FCommandLine::Get(),TEXT("KDQualityCandidates="),List,false);
            List.ParseIntoArray(Candidates,TEXT(","),true);
            if (Poses.IsEmpty() || Candidates.IsEmpty()) { Finished=true;FPlatformMisc::RequestExit(false,TEXT("KDQualityEmpty"));return; }
            FString ReferenceError;
            if (!ReadReference(ReferenceError))
            {
                Finished=true;Exposure.Reset();
                FFileHelper::SaveStringToFile(TEXT("success=0\nreason=")+ReferenceError+TEXT("\n"),*FPaths::Combine(Dir,TEXT("quality_result.txt")),FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM);
                FPlatformMisc::RequestExit(false,TEXT("KDQualityReferenceInvalid"));return;
            }
            if (!ReferencePath.IsEmpty())
                FFileHelper::SaveStringToFile(TEXT("source=")+ReferencePath+TEXT("\nselection=candidate_Baseline_trial_0\n"),*FPaths::Combine(Dir,TEXT("quality_reference.txt")),FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM);
        }
        const FPose& Pose=Poses[PoseIndex];
        if (Frame==0)
        {
            if (!Light.Restore()) { Finished=true;FPlatformMisc::RequestExit(false,TEXT("KDQualityRestoreFailed"));return; }
            const FString Evidence=FPaths::Combine(Dir,FString::Printf(TEXT("%s_%02d"),Pose.Name,Trial));
            IFileManager::Get().MakeDirectory(*Evidence,true);
            if (!Light.Apply(Char->GetWorld(),Candidates[Trial],Evidence))
            { Finished=true;FPlatformMisc::RequestExit(false,TEXT("KDQualityApplyFailed"));return; }
            if (Trial==0)
            {
                Exposure->Fixed=!ReferenceEv.IsEmpty();
                if (Exposure->Fixed) Exposure->Ev=ReferenceEv.FindChecked(Pose.Name);
                Char->GetCharacterMovement()->StopMovementImmediately();
                Char->SetActorLocation(Pose.P,false,nullptr,ETeleportType::TeleportPhysics);
            }
        }
        Player->SetControlRotation(Pose.R);
        ++Frame;
        if (Trial==0 && Frame==180 && ReferenceEv.IsEmpty())
        {
            const auto* Lens=IConsoleManager::Get().FindConsoleVariable(TEXT("r.EyeAdaptation.LensAttenuation"));
            const auto* Ext=IConsoleManager::Get().FindConsoleVariable(TEXT("r.DefaultFeature.AutoExposure.ExtendDefaultLuminanceRange"));
            const float Scale=(Lens && Ext && Ext->GetInt()!=0)?0.78f/FMath::Max(0.01f,Lens->GetFloat()):1.0f;
            Exposure->Ev=Exposure->Last>0.0001f?-FMath::Log2(Exposure->Last*Scale):0.f;
            Exposure->Fixed=true;
        }
        const int32 CaptureFrame=Trial==0?180+SettleFrames:SettleFrames;
        if (Frame==CaptureFrame)
        {
            if (FScreenshotRequest::IsScreenshotRequested()) { --Frame;return; }
            APlayerCameraManager* Camera=Player->PlayerCameraManager.Get();
            const FVector P=Camera->GetCameraLocation();const FRotator R=Camera->GetCameraRotation();
            Records+=FString::Printf(TEXT("%s,%d,%s,%.7f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f\n"),Pose.Name,Trial,*Candidates[Trial],Exposure->Ev,P.X,P.Y,P.Z,R.Pitch,R.Yaw,Camera->GetFOVAngle());
            FScreenshotRequest::RequestScreenshot(FPaths::Combine(Dir,FString::Printf(TEXT("%s_%02d_%s.png"),Pose.Name,Trial,*Candidates[Trial])),false,false);
        }
        if (Frame>CaptureFrame+8 && !FScreenshotRequest::IsScreenshotRequested())
        {
            Frame=0;
            if (++Trial==Candidates.Num()) { Trial=0;++PoseIndex; }
            if (PoseIndex==Poses.Num())
            {
                Finished=true;
                const bool Restored=Light.Restore();
                FFileHelper::SaveStringToFile(Records,*FPaths::Combine(Dir,TEXT("quality_poses.csv")),FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM);
                FFileHelper::SaveStringToFile(Restored?TEXT("success=1\n"):TEXT("success=0\n"),*FPaths::Combine(Dir,TEXT("quality_result.txt")));
                Exposure.Reset();
                FPlatformMisc::RequestExit(false,TEXT("KDQualityComplete"));
            }
        }
    }
};
