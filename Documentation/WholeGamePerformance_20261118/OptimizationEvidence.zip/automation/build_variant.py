import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile

here = Path(__file__).resolve().parent
root = here.parents[2]
previous = here.parent / "WholeGame_20261118"
parser = argparse.ArgumentParser()
parser.add_argument("name")
parser.add_argument("--baseline", action="store_true")
parser.add_argument("--production", action="store_true")
parser.add_argument("--max-workers", type=int)
parser.add_argument("--gate-source", type=Path)
parser.add_argument("--cap-ownership-test", action="store_true")
args = parser.parse_args()
assert args.name.isalnum()
assert not (args.baseline and args.gate_source)
assert not (args.cap_ownership_test and (args.baseline or args.production))
output = here / "Variants" / args.name
output.mkdir(parents=True, exist_ok=False)
work = Path(os.environ["LOCALAPPDATA"]) / "KDGateTraceDev_20261117"
module = work / "Source/myProject"
engine = Path("C:/Program Files/Epic Games/UE_5.8/Engine")
formal = root / "Saved/ExhibitBuild_20261117_ExitCull/Windows"

def source(rel):
    if args.baseline:
        return subprocess.check_output(["git", "show", "HEAD:" + rel], cwd=root).decode("utf-8-sig")
    return (root / rel).read_text(encoding="utf-8-sig")

for filename in ("ExhibitStartupGate.cpp", "ExhibitStartupGate.h", "myProject.Build.cs"):
    content = (args.gate_source / filename).read_text(encoding="utf8") if args.gate_source and filename.startswith("ExhibitStartupGate.") else source("Build/Exhibit/Source/myProject/" + filename)
    (module / filename).write_text(content, encoding="utf8")
cpp = source("Build/Exhibit/Source/myProject/myProject.cpp")

def insert(old, new):
    global cpp
    assert cpp.count(old) == 1, old
    cpp = cpp.replace(old, new)

if not args.production:
    if (here / "GalleryMaterialCheck.h").exists():
        shutil.copyfile(here / "GalleryMaterialCheck.h", module / "GalleryMaterialCheck.h")
        insert('#include "Engine/World.h"', '#include "Engine/World.h"\n#include "GalleryMaterialCheck.h"')
        insert('            StartupWorld = World;', '''            if (!Dir.IsEmpty() && !ValidateGalleryMaterials(World,Dir))
            {
                Finish(false,TEXT("gallery_material_mismatch"));
                return;
            }
            StartupWorld = World;''')
    survey = here / "Survey.h"
    if not survey.exists():
        shutil.copyfile(previous / "Survey.h", survey)
    shutil.copyfile(survey, module / "Survey.h")
    insert('#include "Engine/World.h"', '#include "Engine/World.h"\n#include "Survey.h"')
    insert('    FExhibitStartupGate Startup;', '    FExhibitStartupGate Startup;\n    FWholeGameSurvey Survey;')
    branches = '''            if (Survey.Enabled)
            {
                if (!Survey.Initialized) Startup.WriteReport(Dir);
                Survey.Update(Dir,Player,Char,Delta);
                if (Survey.Round>Survey.Rounds) WriteSettings(World,Player,Char,TEXT("final"));
                return;
            }
'''
    if (here / "Stress.h").exists():
        shutil.copyfile(here / "Stress.h", module / "Stress.h")
        insert('#include "Survey.h"', '#include "Survey.h"\n#include "Stress.h"')
        insert('    FWholeGameSurvey Survey;', '    FWholeGameSurvey Survey;\n    FEnemyStressTest Stress;')
        branches = '''            if (Stress.Enabled)
            {
                if (!Stress.Initialized) Startup.WriteReport(Dir);
                Stress.Update(Dir,Player,Char,Delta);
                if (Stress.Finished) WriteSettings(World,Player,Char,TEXT("final"));
                return;
            }
''' + branches
        insert('        bPhoto=FParse::Param', '        Stress.Enabled=FParse::Param(Cmd,TEXT("KDEnemyStress"));\n        bPhoto=FParse::Param')
    if (here / "LightCandidates.h").exists():
        shutil.copyfile(here / "LightCandidates.h", module / "LightCandidates.h")
    if (here / "QualitySweep.h").exists():
        shutil.copyfile(here / "QualitySweep.h", module / "QualitySweep.h")
        insert('#include "Survey.h"', '#include "Survey.h"\n#include "QualitySweep.h"')
        insert('    FWholeGameSurvey Survey;', '    FWholeGameSurvey Survey;\n    FLightQualitySweep Quality;')
        branches = '''            if (Quality.Enabled)
            {
                if (!Quality.Initialized) Startup.WriteReport(Dir);
                Quality.Update(Dir,Player,Char,Delta);
                if (Quality.Finished) WriteSettings(World,Player,Char,TEXT("final"));
                return;
            }
''' + branches
        insert('        bPhoto=FParse::Param', '        Quality.Enabled=FParse::Param(Cmd,TEXT("KDLightQuality"));\n        bPhoto=FParse::Param')
    insert('    bool bRoute = false, bBypassGate = false;', '    bool bRoute = false, bBypassGate = false;\n    bool LoadingCaptured=false;')
    insert('        Startup.Tick(Now);', '''        Startup.Tick(Now);
        if (!Startup.IsOpen() && ReadyQpc && Seconds(Now,ReadyQpc)>30 && !LoadingCaptured)
        {
            FScreenshotRequest::RequestScreenshot(FPaths::Combine(Dir,TEXT("startup_loading.png")),true,false);
            LoadingCaptured=true;
        }''')
    insert('            GoQpc=Now;', branches + '            GoQpc=Now;')
    insert('        bPhoto=FParse::Param', '        Survey.Enabled=FParse::Param(Cmd,TEXT("KDWholeGameSurvey"));\n        bPhoto=FParse::Param')
    if (here / "prepare_full_route.py").exists():
        namespace = {"cpp": cpp, "here": here, "module": module}
        exec((here / "prepare_full_route.py").read_text(encoding="utf8"), namespace)
        cpp = namespace["cpp"]
    if args.cap_ownership_test:
        namespace = {"cpp": cpp, "here": here, "module": module}
        exec((here / "prepare_cap_ownership.py").read_text(encoding="utf8"), namespace)
        cpp = namespace["cpp"]
(module / "myProject.cpp").write_text(cpp, encoding="utf8")
shutil.copytree(module, output / "SourceSnapshot")
with (output / "build.log").open("wb") as log:
    result = subprocess.run([str(engine / "Build/BatchFiles/Build.bat"), "myProject", "Win64", "Shipping",
                             "-Project=" + str(work / "myProject.uproject"), "-NoLiveCoding", "-NoHotReload", "-WaitMutex"],
                            stdout=log, stderr=log, creationflags=subprocess.CREATE_NO_WINDOW)
if result.returncode:
    print((output / "build.log").read_text(encoding="utf8", errors="replace")[-6000:])
    sys.exit(result.returncode)

pak = Path("myProject/Content/Paks/myProject-Windows.pak")
exe = Path("myProject/Binaries/Win64/myProject-Win64-Shipping.exe")
windows = output / "Windows"
for path in formal.rglob("*"):
    if not path.is_file():
        continue
    rel = path.relative_to(formal)
    if rel in (pak, exe) or "Saved" in rel.parts:
        continue
    target = windows / rel
    target.parent.mkdir(parents=True, exist_ok=True)
    os.link(path, target)
(windows / exe).parent.mkdir(parents=True, exist_ok=True)
shutil.copyfile(work / "Binaries/Win64" / exe.name, windows / exe)

uepak = engine / "Binaries/Win64/UnrealPak.exe"
def pak_run(*values):
    return subprocess.check_output([str(uepak), *map(str, values)], stderr=subprocess.STDOUT,
        creationflags=subprocess.CREATE_NO_WINDOW).decode(errors="replace")
def entries(path):
    rows = re.findall(r'"([^"\r\n]+)" offset: [^\r\n]+?sha1: ([0-9A-Fa-f]+), compression: (\w+)\.', pak_run(path, "-List"))
    return {name: (digest, method) for name, digest, method in rows}
original = entries(formal / pak)
entry = "myProject/Config/Windows/WindowsEngine.ini"
assert entry in original
scratch = Path(tempfile.mkdtemp(prefix="KDOptPak_"))
raw = scratch / "raw"
pak_run(formal / pak, "-Extract", raw)
settings = source("Build/Exhibit/Config/Windows/WindowsEngine.ini")
if args.max_workers:
    settings += "\nr.pso.PrecompileThreadPoolSizeMax=" + str(args.max_workers) + "\n"
(raw / entry).write_text(settings, encoding="utf8")
listing = scratch / "files.txt"
listing.write_text("\n".join('"' + (raw / key).as_posix() + '" "../../../' + key + '"' +
    (" -compress" if method != "None" else "") for key, (_, method) in original.items()) + "\n", encoding="utf8")
pak_run(windows / pak, "-Create=" + str(listing), "-patchpaddingalign=2048", "-compressionformats=Oodle",
        "-compresslevel=4", "-compressmethod=Kraken", "-platform=Windows", "-unattended")
pak_run(windows / pak, "-Test")
modified = entries(windows / pak)
assert set(original) == set(modified)
assert all(original[k] == modified[k] for k in original if k != entry)
proof = dict(name=args.name, baseline=args.baseline, production=args.production, max_workers=args.max_workers,
             cap_ownership_test=args.cap_ownership_test,
             gate_source=str(args.gate_source.resolve()) if args.gate_source else None,
             exe=str(windows / exe), pak_changed_entry=entry, other_pak_entries_unchanged=len(original)-1,
             settings=settings, exe_sha256=hashlib.sha256((windows / exe).read_bytes()).hexdigest(),
             pak_sha256=hashlib.sha256((windows / pak).read_bytes()).hexdigest())
(output / "proof.json").write_text(json.dumps(proof, indent=2), encoding="utf8")
print(proof["exe"], flush=True)
