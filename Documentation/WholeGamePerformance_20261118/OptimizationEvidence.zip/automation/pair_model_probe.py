import hashlib
import json
import os
from pathlib import Path
import shutil
import sys

here = Path(__file__).resolve().parent
probe = here / "Variants" / sys.argv[1] / "Windows"
binary = Path("myProject/Binaries/Win64/myProject-Win64-Shipping.exe")
for source_name, target_name in zip(sys.argv[2::2], sys.argv[3::2]):
    source = here / "Variants" / source_name / "Windows"
    target = here / "Variants" / target_name / "Windows"
    target.mkdir(parents=True, exist_ok=False)
    for item in source.rglob("*"):
        if not item.is_file():
            continue
        relative = item.relative_to(source)
        if "Saved" in relative.parts:
            continue
        destination = target / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        if relative == binary:
            shutil.copyfile(probe / binary, destination)
        else:
            os.link(item, destination)
    proof = dict(source=source_name, probe=sys.argv[1], exe_sha256=hashlib.sha256((target / binary).read_bytes()).hexdigest())
    (target.parent / "probe_pair.json").write_text(json.dumps(proof, indent=2), encoding="utf8")
    print(proof)
