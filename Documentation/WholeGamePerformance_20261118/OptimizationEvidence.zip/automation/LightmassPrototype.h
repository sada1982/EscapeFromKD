#pragma once
#include "BakedGITrial.h"

inline bool IsIsolatedLightmassMap(const UWorld* World)
{
    if(!World || !World->IsGameWorld() || !FParse::Param(FCommandLine::Get(),TEXT("KDLightmassPrototype"))) return false;
    const FString Map=World->GetOutermost()->GetName();
    return Map==TEXT("/Game/Diagnostics/LightmassTrial/KDStage_BakeTrial") ||
        Map==TEXT("/Game/Diagnostics/LightmassTrial/KDStage_LumenTrial");
}

inline bool InitializeIsolatedLightmassPrototype(UWorld* World,const FString& Directory)
{
    if(!IsIsolatedLightmassMap(World)) return true;
    const bool Bake=World->GetOutermost()->GetName()==TEXT("/Game/Diagnostics/LightmassTrial/KDStage_BakeTrial");
    const bool RequestedBake=FParse::Param(FCommandLine::Get(),TEXT("KDBakedGITrial"));
    if(Bake!=RequestedBake)
    {
        FFileHelper::SaveStringToFile(TEXT("success=0\nreason=bake_flag_map_mismatch\n"),
            *FPaths::Combine(Directory,TEXT("lightmass_prototype.txt")),FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM);
        return false;
    }
    if(!InitializeIsolatedBakedGITrial(World,Directory)) return false;
    int32 Lights=0;
    bool Valid=true;
    for(TActorIterator<AActor> It(World);It;++It)
    {
        TInlineComponentArray<ULightComponent*> Components(*It);
        for(ULightComponent* Light:Components)
        {
            ++Lights;
            Valid &= Cast<URectLightComponent>(Light)!=nullptr && Light->Mobility==EComponentMobility::Movable &&
                Light->CastShadows && Light->CastDynamicShadows && Light->bAllowMegaLights;
        }
    }
    Valid &= Lights==12;
    FFileHelper::SaveStringToFile(FString::Printf(TEXT("success=%d\nmap=%s\nlights=%d\nbaked=%d\ncropped_room=1\nquality_verified=0\n"),Valid?1:0,
        *World->GetOutermost()->GetName(),Lights,Bake?1:0),*FPaths::Combine(Directory,TEXT("lightmass_prototype.txt")),FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM);
    return Valid;
}
