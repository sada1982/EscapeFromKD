import argparse
import csv
import json
from pathlib import Path


parser=argparse.ArgumentParser()
parser.add_argument("run",type=Path)
args=parser.parse_args()
meta=json.loads((args.run / "metadata.json").read_text(encoding="utf8"))
route=Path(meta["route"])
read=lambda path:dict(line.split("=",1) for line in path.read_text(encoding="utf-8-sig").splitlines() if "=" in line)
gate=read(route / "startup_result.txt")
cap=read(route / "startup_frame_cap.txt")
close=json.loads((route / "close_request.json").read_text(encoding="utf8"))
assert meta["returncode"]==0 and meta["monitor_returncode"]==0
assert close["sent"] and close["pid"]==meta["game_pid"] and close["foreground_before"]==close["foreground_after"]
assert close["desktop"]!=close["input_desktop"]
assert int(gate["start_qpc"])>0 and gate["open_qpc"]=="0"
assert gate["input_restored"]=="1"
assert cap["requested_fps"]=="30" and cap["status"]=="restored"
assert cap["applies"]==cap["restores"]=="1" and cap["active"]==cap["external_change"]=="0"
assert float(cap["previous_value"])==float(cap["final_value"])==0
assert cap["previous_priority"]==cap["final_priority"]
with (route / "startup.csv").open(encoding="utf-8-sig",newline="") as stream:
    rows=list(csv.DictReader(stream))
assert rows and int(rows[-1]["pso_pending"])>0 and rows[-1]["input_guard"]=="1"
watch=args.run.parent / (args.run.name+"Window")
control=json.loads((args.run.parent / (args.run.name+"Control") / "execution.json").read_text(encoding="utf8"))
initial=json.loads((watch / "ready.json").read_text(encoding="utf8"))["initial_window"]
with (watch / "window_state.csv").open(encoding="utf-8-sig",newline="") as stream:
    observed=list(csv.DictReader(stream))
for row in observed:
    assert row["iconic"]=="0" and int(row["foreground_pid"])!=initial["pid"]
    assert int(row["showCmd"])==(1 if control["expected_window"]=="normal" else 3)
    assert [int(row[key]) for key in ("rect_left","rect_top","rect_right","rect_bottom")]==initial["normal_rect"]
result=dict(all_checks_passed=True,normal_exit=True,gate=gate,cap=cap,close_request=close,
            last_pending=int(rows[-1]["pso_pending"]),launch_power=control.get("launch_power"),window_samples=len(observed))
(args.run / "cap_close_audit.json").write_text(json.dumps(result,indent=2),encoding="utf8")
print("Early close restored cap/input while PSOs were still pending; normal exit0.")
