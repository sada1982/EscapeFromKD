import argparse
import bisect
import collections
import csv
import json
import math
from pathlib import Path
import statistics

parser = argparse.ArgumentParser()
parser.add_argument("run", type=Path)
args = parser.parse_args()
run = args.run.resolve()
meta = json.loads((run / "metadata.json").read_text(encoding="utf8"))
route = Path(meta["route"])
frequency = meta["start"]["frequency"]

def read(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))

def stats(values):
    values = sorted(values)
    if not values:
        return None
    n = len(values)
    return dict(n=n, mean_ms=statistics.mean(values), fps=1000/statistics.mean(values),
                p99_ms=values[math.ceil(n*.99)-1], max_ms=values[-1],
                over=sum(x>1000/60 for x in values), over_pct=100*sum(x>1000/60 for x in values)/n)

presents = [r for r in read(run / "presents_native.csv") if int(r["ProcessID"])==meta["game_pid"] and r["Runtime"]=="DXGI"]
swapchain = collections.Counter(r["SwapChainAddress"] for r in presents).most_common(1)[0][0]
presents = sorted((r for r in presents if r["SwapChainAddress"]==swapchain), key=lambda r:int(r["QPCTime"]))
intervals = [(int(a["QPCTime"]),int(b["QPCTime"]),(int(b["QPCTime"])-int(a["QPCTime"]))*1000/frequency)
             for a,b in zip(presents,presents[1:])]
windows = []
kind = "stress" if (route / "stress_events.csv").exists() else "route"
if kind == "stress":
    events = read(route / "stress_events.csv")
    start = next(int(e["qpc"]) for e in events if e["event"]=="sample_begin")
    end = next(int(e["qpc"]) for e in events if e["event"]=="sample_end")
    windows.append(("all",start,end))
    for seconds in range(0,math.ceil((end-start)/frequency),15):
        windows.append((f"seconds_{seconds:03d}",start+seconds*frequency,min(end,start+(seconds+15)*frequency)))
else:
    events = read(route / "events.csv")
    lap_windows = collections.defaultdict(dict)
    for e in events:
        if e["event"] in ("lap_start","lap_end"):
            lap_windows[int(e["lap"])][e["event"]]=int(e["qpc"])
    for lap, pair in lap_windows.items():
        if len(pair)==2:
            windows.append((f"lap_{lap}",pair["lap_start"],pair["lap_end"]))
    for lap, pair in lap_windows.items():
        if len(pair)!=2:
            continue
        previous = pair["lap_start"]
        for e in events:
            if int(e["lap"])==lap and e["event"]=="waypoint":
                qpc=int(e["qpc"])
                windows.append((f"lap_{lap}_leg_{int(e['leg']):02d}",previous,qpc))
                previous=qpc
result = dict(kind=kind, windows={})
records=[]
for name,start,end in windows:
    selected=[r for r in intervals if start<=r[0]<r[1]<=end]
    result["windows"][name]=dict(start=start,end=end,**(stats([r[2] for r in selected]) or {}))
    if name=="all" or (name.startswith("lap_") and "_leg_" not in name):
        records.extend(dict(window=name,q0=q0,q1=q1,ms=ms) for q0,q1,ms in selected)
if kind=="route":
    result["first_lap"]=stats([r["ms"] for r in records if r["window"]=="lap_1"])
    result["warm_laps"]=stats([r["ms"] for r in records if r["window"]!="lap_1"])
(run / "summary.json").write_text(json.dumps(result,indent=2),encoding="utf8")
if records:
    with (run / "intervals.csv").open("w",encoding="utf-8-sig",newline="") as stream:
        writer=csv.DictWriter(stream,fieldnames=list(records[0]))
        writer.writeheader();writer.writerows(records)
print(json.dumps({k:v for k,v in result.items() if k!="windows"},indent=2))
print(json.dumps(result["windows"].get("all",{}),indent=2))
