import csv
import json
from pathlib import Path
import shutil
import statistics
import subprocess
import sys
import tempfile

base = Path(__file__).resolve().parent
trace = Path('C:/Users/motoo/AppData/Local/Temp/KDWholeGame_w8myswcy/game.utrace')
events_file = trace.parent/'route/survey_events.csv'
output = base/'AllWaitCPU2Trace'
output.mkdir(exist_ok=True)
scratch = Path(tempfile.mkdtemp(prefix='KDAllWaitExport_'))
insights = Path('C:/Program Files/Epic Games/UE_5.8/Engine/Binaries/Win64/UnrealInsights.exe')
launcher = base.parent/'Exhibit42_20261116/private_launch.py'
columns = ' -columns=ThreadId,ThreadName,TimerName,StartTime,EndTime,Duration,Depth'

def export(label, commands):
    response = scratch/(label+'.rsp')
    response.write_text('\n'.join(commands)+'\n', encoding='utf8')
    log = scratch/(label+'.log')
    command = [sys.executable, '-B', str(launcher), str(insights), str(scratch/(label+'Desktop')), '-OpenTraceFile='+str(trace), '-ABSLOG='+str(log), '-AutoQuit', '-NoUI', '-ExecOnAnalysisCompleteCmd=@='+str(response), '-unattended', '-NoSplash']
    result = subprocess.run(command, capture_output=True, creationflags=subprocess.CREATE_NO_WINDOW|subprocess.BELOW_NORMAL_PRIORITY_CLASS)
    if log.exists():
        shutil.copyfile(log, output/log.name)
    (output/(label+'_launcher.txt')).write_bytes(result.stdout+result.stderr)
    result.check_returncode()

def read(path):
    with path.open(encoding='utf-8-sig', newline='') as stream:
        return list(csv.DictReader(stream))

marks_file = scratch/'anchors.csv'
threads_file = scratch/'threads.csv'
export('anchors', ['TimingInsights.ExportThreads '+threads_file.as_posix(), 'TimingInsights.ExportTimingEvents '+marks_file.as_posix()+columns+' -threads=GameThread -timers=KD_SurveyMeasureStart,KD_SurveyMeasureEnd'])
for file in [marks_file, threads_file]:
    shutil.copyfile(file, output/file.name)
print('Thread map exported: '+str(output/'threads.csv'), flush=True)
events = read(events_file)
marks = read(marks_file)
offsets = []
for event, timer in [('sample_begin','KD_SurveyMeasureStart'),('sample_end','KD_SurveyMeasureEnd')]:
    clock_rows = sorted([row for row in events if row['event']==event], key=lambda row:int(row['qpc']))
    trace_rows = sorted([row for row in marks if row['TimerName']==timer], key=lambda row:float(row['StartTime']))
    if not clock_rows or len(clock_rows)!=len(trace_rows):
        raise ValueError('Missing trace/QPC anchor '+event)
    offsets.extend(float(mark['StartTime'])-int(row['qpc'])/10000000 for row,mark in zip(clock_rows,trace_rows))
offset = statistics.median(offsets)
spread = (max(offsets)-min(offsets))*1000
if spread>5:
    raise ValueError('QPC/trace anchor spread exceeds 5ms')
first = next(row for row in events if row['event']=='sample_begin')
origin = int(first['qpc'])/10000000+offset
windows, commands = [], []
for index, relative in enumerate([0,15,35,55]):
    start, end = origin+relative, origin+relative+3
    file = scratch/f'window_{index}.csv'
    commands.append('TimingInsights.ExportTimingEvents '+file.as_posix()+columns+f' -threads=* -startTime={start:.9f} -endTime={end:.9f}')
    windows.append(dict(scene=f'AfterGate_{relative}s',tour=1,start=start,end=end,relative_start=relative,events_csv=file.name))
manifest = dict(trace=str(trace),source_events=str(events_file),qpc_frequency=10000000,clock_offset_s=offset,anchor_spread_ms=spread,anchor_count=len(offsets),sample_begin_qpc=int(first['qpc']),windows=windows)
(output/'windows.json').write_text(json.dumps(manifest,indent=2),encoding='utf8')
export('windows', commands)
for window in windows:
    shutil.copyfile(scratch/window['events_csv'],output/window['events_csv'])
print(json.dumps(dict(output=str(output),anchor_spread_ms=spread,windows=windows)))
