from pathlib import Path
import os

script = Path(os.environ['KD_MODEL_EVIDENCE']) / 'make_furniture.py'
code = script.read_text(encoding='utf8')
prefix = code.split("\nunreal.SystemLibrary.execute_console_command(world, 'Editor.AsyncAssetCompilationFinishAll')\nverify_world('furniture_before')")[0]
exec(compile(prefix, str(script), 'exec'))
proof = dict(project=str(project), groups={}, world_copies=[])
replacement_assets = {}
for category, expected in [('Chairs', 333618), ('Laptops', 31500)]:
    original = unreal.load_asset('/Game/Main/Stage/Floor03/SurveyV02/SM_F03V02_' + category)
    mesh = unreal.load_asset('/Game/Main/Stage/Floor03/OptimizedV03/SM_F03V03_' + category)
    assert mesh and mesh.get_num_nanite_triangles() == expected
    replacement_assets[original.get_path_name()] = mesh
    record = dict(original=original.get_path_name(), path=mesh.get_path_name(), triangles=expected,
        fallback_triangles=mesh.get_num_triangles(0),
        materials=[str(x.material_slot_name) for x in original.get_editor_property('static_materials')], shadows=[])
    if category == 'Chairs':
        for label in ('Main', 'Adjacent', 'Remainder'):
            shadow = unreal.load_asset('/Game/Main/Stage/Floor03/ShadowCasters/SM_Chairs_' + label + '_Shadow')
            record['shadows'].append(dict(label=label, path=shadow.get_path_name(), triangles=shadow.get_num_nanite_triangles()))
    proof['groups'][category] = record
tail = code.split("assert unreal.EditorLoadingAndSavingUtils.save_packages(packages + [bp.get_outermost()], False)\n", 1)[1]
exec(compile(tail, str(script), 'exec'))
