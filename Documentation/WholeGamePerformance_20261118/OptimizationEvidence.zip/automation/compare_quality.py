import argparse
import csv
import json
import math
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFont

def read_poses(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        rows = list(csv.DictReader(stream))
    if not rows or not {"view", "trial", "candidate", "ev", "x", "y", "z", "pitch", "yaw", "fov"}.issubset(rows[0]):
        raise ValueError("Missing quality pose records/columns: " + str(path))
    seen = set()
    for row in rows:
        row["trial"] = int(row["trial"])
        key = row["view"], row["trial"]
        if key in seen:
            raise ValueError("Duplicate view/trial: " + str(key))
        seen.add(key)
        for field in ("ev", "x", "y", "z", "pitch", "yaw", "fov"):
            row[field] = float(row[field])
            if not math.isfinite(row[field]):
                raise ValueError("Non-finite pose/exposure: " + str(key))
        row["file"] = path.parent / (row["view"] + "_" + str(row["trial"]).zfill(2) + "_" + row["candidate"] + ".png")
        if not row["file"].is_file():
            raise FileNotFoundError(row["file"])
    return rows

def comparable(reference, other):
    failures = []
    if abs(reference["ev"] - other["ev"]) > 0.00001:
        failures.append("exposure")
    if sum((reference[k] - other[k]) ** 2 for k in ("x", "y", "z")) ** 0.5 > 0.1:
        failures.append("camera_position")
    if any(abs((reference[k] - other[k] + 180) % 360 - 180) > 0.01 for k in ("pitch", "yaw")):
        failures.append("camera_rotation")
    if abs(reference["fov"] - other["fov"]) > 0.01:
        failures.append("fov")
    return failures

def load_image(path):
    with Image.open(path) as image:
        return np.array(image.convert("RGB"), dtype=np.uint8)

def metrics(reference, candidate, aa_delta):
    signed = candidate.astype(np.float32) - reference.astype(np.float32)
    absolute = np.abs(signed)
    per_pixel = absolute.mean(axis=2)
    aa_pixel = aa_delta.mean(axis=2)
    luma = signed @ np.array([0.2126, 0.7152, 0.0722], dtype=np.float32)
    mse = float(np.square(signed).mean())
    noise = max(1.0, float(np.percentile(aa_pixel, 99)))
    result = dict(mae_rgb_255=float(absolute.mean()), p95_pixel_abs_rgb_255=float(np.percentile(per_pixel, 95)),
                  p99_pixel_abs_rgb_255=float(np.percentile(per_pixel, 99)),
                  signed_luma_mean_255=float(luma.mean()), absolute_luma_mean_255=float(np.abs(luma).mean()),
                  aa_mae_rgb_255=float(aa_delta.mean()), aa_p99_pixel_abs_rgb_255=float(np.percentile(aa_pixel, 99)),
                  above_aa_p99_or_1_percent=float((per_pixel > noise).mean() * 100),
                  brighter_gt_3_percent=float((luma > 3).mean() * 100), darker_gt_3_percent=float((luma < -3).mean() * 100),
                  psnr_db=10 * math.log10(255 * 255 / mse) if mse else None)
    result["excess_mae_over_aa_255"] = result["mae_rgb_255"] - result["aa_mae_rgb_255"]
    return result

def heat(delta, gain):
    value = np.clip(np.abs(delta).mean(axis=2) * gain, 0, 255).astype(np.uint8)
    return Image.fromarray(np.stack([value, value // 3, np.zeros_like(value)], axis=2))

def box_for(rect, width, height):
    if len(rect) != 4 or not all(math.isfinite(v) for v in rect):
        raise ValueError("Invalid normalized ROI")
    x0, y0, x1, y1 = rect
    if not (0 <= x0 < x1 <= 1 and 0 <= y0 < y1 <= 1):
        raise ValueError("ROI must use normalized left,top,right,bottom within 0..1")
    box = (round(x0 * width), round(y0 * height), round(x1 * width), round(y1 * height))
    if box[2] == box[0] or box[3] == box[1]:
        raise ValueError("Empty ROI after conversion")
    return box

def make_sheet(rows, destination, width=640, height=360):
    try:
        font = ImageFont.truetype("C:/Windows/Fonts/segoeui.ttf", 17)
    except OSError:
        font = ImageFont.load_default()
    columns = max(len(row) for row in rows)
    sheet = Image.new("RGB", (columns * width, len(rows) * (height + 54)), (26, 28, 32))
    draw = ImageDraw.Draw(sheet)
    for y, row in enumerate(rows):
        for x, (label, image) in enumerate(row):
            thumbnail = image.copy()
            thumbnail.thumbnail((width - 8, height - 8), Image.Resampling.LANCZOS)
            sheet.paste(thumbnail, (x * width + (width - thumbnail.width) // 2, y * (height + 54) + 50))
            draw.text((x * width + 7, y * (height + 54) + 5), label, font=font, fill=(235, 237, 240))
    sheet.save(destination)

def main():
    parser = argparse.ArgumentParser(description="Compare fixed-exposure quality captures against Baseline trial 0 and the trial 1 A/A noise reference.")
    parser.add_argument("reference", type=Path)
    parser.add_argument("candidate", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--roi-json", type=Path)
    parser.add_argument("--label", default="Candidate")
    parser.add_argument("--diff-gain", type=float, default=8.0)
    args = parser.parse_args()
    if not 0 < args.diff_gain <= 100:
        raise ValueError("diff gain must be >0 and <=100")
    baseline_rows = read_poses(args.reference)
    candidate_rows = read_poses(args.candidate)
    roi_config = json.loads(args.roi_json.read_text(encoding="utf8")) if args.roi_json else {"validated": False, "views": {}}
    args.output.mkdir(parents=True, exist_ok=True)
    all_metrics, comparisons = [], []
    for view in dict.fromkeys(row["view"] for row in candidate_rows):
        reference_matches = [r for r in baseline_rows if r["view"] == view and r["candidate"] == "Baseline" and r["trial"] == 0]
        aa_matches = [r for r in baseline_rows if r["view"] == view and r["candidate"] == "Baseline" and r["trial"] == 1]
        if len(reference_matches) != 1 or len(aa_matches) != 1:
            raise ValueError("Reference requires Baseline trials 0 and 1 for view " + view)
        ref, repeat = reference_matches[0], aa_matches[0]
        original, aa = load_image(ref["file"]), load_image(repeat["file"])
        if original.shape != aa.shape:
            raise ValueError("A/A image dimensions differ: " + view)
        aa_errors = comparable(ref, repeat)
        aa_delta = np.abs(aa.astype(np.float32) - original.astype(np.float32))
        height, width = original.shape[:2]
        if "expected_size" in roi_config and roi_config["expected_size"] != [width, height]:
            raise ValueError("Validated ROI image size mismatch: " + view)
        regions = [("whole", (0, 0, width, height))]
        regions += [(r["name"], box_for(r["rect"], width, height)) for r in roi_config.get("views", {}).get(view, [])]
        if len({name for name, _ in regions}) != len(regions):
            raise ValueError("Duplicate ROI name: " + view)
        marked_original = Image.fromarray(original)
        overlay = ImageDraw.Draw(marked_original)
        for name, box in regions[1:]:
            overlay.rectangle(box, outline=(255, 220, 0), width=3)
            overlay.text((box[0] + 4, box[1] + 4), name, fill=(255, 220, 0))
        whole_rows = [[("Baseline 0 (ROI boundaries marked)", marked_original), ("A/A absolute RGB difference x" + str(args.diff_gain), heat(aa_delta, args.diff_gain))]]
        roi_rows = {name: [] for name, _ in regions[1:]}
        selected = [("AA", "Baseline trial 1", repeat, aa)]
        selected += [("candidate", args.label + " / " + r["candidate"] + " / trial " + str(r["trial"]), r, load_image(r["file"])) for r in candidate_rows if r["view"] == view]
        for kind, label, row, pixels in selected:
            if pixels.shape != original.shape:
                raise ValueError("Image dimensions differ: " + str(row["file"]))
            errors = comparable(ref, row) + (["aa_reference_not_comparable"] if aa_errors else [])
            diff = np.abs(pixels.astype(np.float32) - original.astype(np.float32))
            for region, box in regions:
                x0, y0, x1, y1 = box
                values = metrics(original[y0:y1, x0:x1], pixels[y0:y1, x0:x1], aa_delta[y0:y1, x0:x1])
                all_metrics.append(dict(view=view, kind=kind, label=label, region=region, comparable=not errors,
                                        comparison_errors=";".join(errors), roi_validated=bool(roi_config.get("validated")) if region != "whole" else True,
                                        x0=x0, y0=y0, x1=x1, y1=y1, **values))
                if region != "whole" and kind != "AA":
                    crop = (slice(y0, y1), slice(x0, x1))
                    roi_rows[region].append([("Baseline 0", Image.fromarray(original[crop])),
                                             (label, Image.fromarray(pixels[crop])),
                                             ("A/A diff x" + str(args.diff_gain), heat(aa_delta[crop], args.diff_gain)),
                                             ("Candidate diff x" + str(args.diff_gain), heat(diff[crop], args.diff_gain))])
            comparisons.append(dict(view=view, kind=kind, label=label, reference=str(ref["file"]), image=str(row["file"]), comparable=not errors, errors=errors))
            if kind != "AA":
                whole_rows.append([(label + (" [POSE/EV MISMATCH]" if errors else ""), Image.fromarray(pixels)),
                                   ("Absolute RGB difference x" + str(args.diff_gain), heat(diff, args.diff_gain))])
        make_sheet(whole_rows, args.output / ("whole_contact_" + view + ".png"))
        for name, rows in roi_rows.items():
            if rows:
                make_sheet(rows, args.output / ("roi_contact_" + view + "_" + name + ".png"), 400, 260)
    with (args.output / "metrics.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(all_metrics[0]))
        writer.writeheader(); writer.writerows(all_metrics)
    report = dict(reference=str(args.reference), candidate=str(args.candidate), roi_config=roi_config, comparisons=comparisons,
                  metrics=all_metrics, notes=["RGB and luma differences use encoded screenshot values (0..255), not scene-linear HDR.",
                  "A/A is temporal/render variation at matching exposure and camera; it is not a universal perceptual acceptance threshold.",
                  "Positive signed luma indicates a brighter candidate; inspect contact ROIs for contact-shadow loss.",
                  "No automatic quality approval is inferred from these metrics. Unvalidated ROI boundaries require visual inspection.",
                  "No resizing, alignment, exposure compensation or denoising is applied before metrics."])
    (args.output / "report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf8")
    print(json.dumps(dict(output=str(args.output), comparisons=len(comparisons), metric_rows=len(all_metrics),
                          pose_exposure_mismatches=sum(not c["comparable"] for c in comparisons)), ensure_ascii=False))

if __name__ == "__main__":
    main()
