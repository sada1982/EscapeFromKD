import argparse
import csv
import ctypes as c
from ctypes import wintypes as w
from datetime import datetime
import json
import os
from pathlib import Path
import time


class ThreadEntry(c.Structure):
    _fields_ = [("size", w.DWORD), ("usage", w.DWORD), ("tid", w.DWORD),
                ("pid", w.DWORD), ("base_priority", w.LONG), ("delta_priority", w.LONG), ("flags", w.DWORD)]


kernel = c.WinDLL("kernel32", use_last_error=True)
kernel.OpenProcess.argtypes = [w.DWORD, w.BOOL, w.DWORD]
kernel.OpenProcess.restype = w.HANDLE
kernel.OpenThread.argtypes = [w.DWORD, w.BOOL, w.DWORD]
kernel.OpenThread.restype = w.HANDLE
kernel.CloseHandle.argtypes = [w.HANDLE]
kernel.WaitForSingleObject.argtypes = [w.HANDLE, w.DWORD]
kernel.WaitForSingleObject.restype = w.DWORD
kernel.GetProcessTimes.argtypes = [w.HANDLE] + [c.POINTER(w.FILETIME)] * 4
kernel.GetThreadTimes.argtypes = [w.HANDLE] + [c.POINTER(w.FILETIME)] * 4
kernel.GetProcessIdOfThread.argtypes = [w.HANDLE]
kernel.GetProcessIdOfThread.restype = w.DWORD
kernel.GetThreadDescription.argtypes = [w.HANDLE, c.POINTER(c.c_void_p)]
kernel.GetThreadDescription.restype = c.c_long
kernel.LocalFree.argtypes = [c.c_void_p]
kernel.LocalFree.restype = c.c_void_p
kernel.QueryFullProcessImageNameW.argtypes = [w.HANDLE, w.DWORD, w.LPWSTR, c.POINTER(w.DWORD)]
kernel.CreateToolhelp32Snapshot.argtypes = [w.DWORD, w.DWORD]
kernel.CreateToolhelp32Snapshot.restype = w.HANDLE
kernel.Thread32First.argtypes = [w.HANDLE, c.POINTER(ThreadEntry)]
kernel.Thread32Next.argtypes = [w.HANDLE, c.POINTER(ThreadEntry)]
kernel.QueryPerformanceCounter.argtypes = [c.POINTER(c.c_longlong)]
kernel.QueryPerformanceFrequency.argtypes = [c.POINTER(c.c_longlong)]


def qpc():
    value = c.c_longlong()
    kernel.QueryPerformanceCounter(c.byref(value))
    return value.value


def clock_times(handle, thread=False):
    fields = [w.FILETIME() for _ in range(4)]
    begin = qpc()
    function = kernel.GetThreadTimes if thread else kernel.GetProcessTimes
    if not function(handle, *(c.byref(value) for value in fields)):
        raise c.WinError(c.get_last_error())
    end = qpc()
    values = [(value.dwHighDateTime << 32) | value.dwLowDateTime for value in fields]
    return dict(qpc=(begin + end) // 2, created=values[0], kernel=values[2], user=values[3])


def process_image(handle):
    buffer = c.create_unicode_buffer(32768)
    length = w.DWORD(len(buffer))
    if not kernel.QueryFullProcessImageNameW(handle, 0, buffer, c.byref(length)):
        raise c.WinError(c.get_last_error())
    return buffer.value


def normalized(path):
    return os.path.normcase(str(Path(path).resolve(strict=True)))


def threads_for(pid):
    handle = kernel.CreateToolhelp32Snapshot(0x00000004, 0)
    if handle == c.c_void_p(-1).value:
        raise c.WinError(c.get_last_error())
    entries = []
    try:
        entry = ThreadEntry()
        entry.size = c.sizeof(entry)
        valid = kernel.Thread32First(handle, c.byref(entry))
        while valid:
            if entry.pid == pid:
                entries.append(entry.tid)
            valid = kernel.Thread32Next(handle, c.byref(entry))
    finally:
        kernel.CloseHandle(handle)
    return entries


def read_thread(pid, tid):
    handle = kernel.OpenThread(0x0800, False, tid)
    if not handle:
        return None
    try:
        if kernel.GetProcessIdOfThread(handle) != pid:
            return None
        result = clock_times(handle, thread=True)
        pointer = c.c_void_p()
        status = kernel.GetThreadDescription(handle, c.byref(pointer))
        try:
            result["description"] = c.wstring_at(pointer) if status >= 0 and pointer.value else ""
            result["description_hresult"] = status
        finally:
            if pointer.value:
                kernel.LocalFree(pointer)
        return result
    except OSError:
        return None
    finally:
        kernel.CloseHandle(handle)


def deltas(current, previous, frequency):
    if previous is None or current["created"] != previous["created"]:
        return None
    elapsed = (current["qpc"] - previous["qpc"]) / frequency
    user = (current["user"] - previous["user"]) / 1e7
    kern = (current["kernel"] - previous["kernel"]) / 1e7
    if elapsed <= 0 or user < 0 or kern < 0:
        raise RuntimeError("Non-monotonic CPU counters")
    return elapsed, user, kern, (user + kern) / elapsed * 100


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("metadata", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--seconds", type=float, default=1800)
    args = parser.parse_args()
    destination = args.output or args.metadata.parent
    destination.mkdir(parents=True, exist_ok=True)
    frequency_value = c.c_longlong()
    kernel.QueryPerformanceFrequency(c.byref(frequency_value))
    frequency = frequency_value.value
    state = dict(metadata=str(args.metadata.resolve()), qpc_frequency=frequency,
                 cpu_units="one logical core = 100%; actual user+kernel CPU time, not scope wall time",
                 reads_only="OpenProcess query/synchronize, OpenThread query; no suspend, affinity, priority, input, or GPU calls",
                 delta_limit="Thread sum includes IDs observed in both samples; newly created/exited or unreadable threads are flagged and may explain the process residual.",
                 samples=0, rows=0, start_qpc=qpc())
    state_path = destination / "thread_cpu_state.json"
    if state_path.exists():
        raise FileExistsError(state_path)
    handle = None
    try:
        deadline = time.monotonic() + 180
        while True:
            try:
                meta = json.loads(args.metadata.read_text(encoding="utf-8-sig"))
                route = Path(meta["route"]).resolve(strict=True)
                isolation = json.loads((route / "isolation.json").read_text(encoding="utf-8-sig"))
                pid = int(meta["game_pid"])
                break
            except (FileNotFoundError, json.JSONDecodeError, KeyError):
                if time.monotonic() > deadline:
                    raise TimeoutError("metadata game_pid and route isolation.json not ready")
                time.sleep(.1)
        if pid != int(isolation["pid"]) or pid <= 0:
            raise RuntimeError("metadata/isolation PID mismatch")
        expected = normalized(meta["exe"])
        if normalized(isolation["args"][0]) != expected:
            raise RuntimeError("metadata/isolation executable mismatch")
        if not isolation.get("desktop", "").startswith("KDExhibit_") or isolation["desktop"] == isolation["input_desktop_start"]:
            raise RuntimeError("Expected isolated game desktop")
        handle = kernel.OpenProcess(0x1000 | 0x100000, False, pid)
        if not handle:
            raise c.WinError(c.get_last_error())
        if kernel.WaitForSingleObject(handle, 0) != 258:
            raise RuntimeError("Game process has already exited")
        if normalized(process_image(handle)) != expected:
            raise RuntimeError("Live process executable mismatch")
        first = clock_times(handle)
        created_utc = first["created"] / 1e7 - 11644473600
        launcher_utc = datetime.fromisoformat(isolation["utc_start"]).timestamp()
        metadata_utc = meta["start"]["utc_epoch_ns"] / 1e9
        if not launcher_utc - 2 <= created_utc <= launcher_utc + 30 or created_utc < metadata_utc - 2:
            raise RuntimeError("Process creation time does not match this isolated launch")
        state.update(pid=pid, exe=expected, route=str(route), creation_filetime=first["created"],
                     creation_utc_epoch=created_utc, isolation_desktop=isolation["desktop"], identity_verified=True)
        state_path.write_text(json.dumps(state, indent=2), encoding="utf8")
        previous_process = None
        previous_threads = {}
        started = time.monotonic()
        next_sample = started
        with (destination / "thread_cpu.csv").open("x", encoding="utf8", newline="") as thread_file, \
                (destination / "thread_process_cpu.csv").open("x", encoding="utf8", newline="") as process_file:
            tw = csv.writer(thread_file)
            pw = csv.writer(process_file)
            tw.writerow(["sample", "qpc", "utc_epoch_ns", "pid", "tid", "thread_creation_filetime", "description", "description_hresult",
                         "user_cpu_100ns", "kernel_cpu_100ns", "elapsed_s", "delta_user_s", "delta_kernel_s", "cpu_pct_one_core", "status"])
            pw.writerow(["sample", "qpc", "utc_epoch_ns", "pid", "elapsed_s", "delta_user_s", "delta_kernel_s", "cpu_pct_one_core",
                         "common_thread_cpu_s", "process_minus_common_threads_s", "observed_threads", "new_threads", "departed_threads", "unreadable_threads", "read_window_ms"])
            while True:
                if kernel.WaitForSingleObject(handle, 0) != 258:
                    state["stop_reason"] = "game_exited"
                    break
                if (args.metadata.parent / "done.flag").exists():
                    state["stop_reason"] = "run_done_flag"
                    break
                if time.monotonic() - started >= args.seconds:
                    state["stop_reason"] = "sampler_time_limit"
                    break
                wait = next_sample - time.monotonic()
                if wait > 0:
                    time.sleep(min(wait, .2))
                    continue
                read_begin = qpc()
                utc_ns = time.time_ns()
                process = clock_times(handle)
                sample = state["samples"]
                current_threads = {}
                common_cpu = 0.0
                new_threads = unreadable = 0
                for tid in threads_for(pid):
                    current = read_thread(pid, tid)
                    if current is None:
                        unreadable += 1
                        continue
                    current_threads[tid] = current
                    values = deltas(current, previous_threads.get(tid), frequency)
                    if values:
                        common_cpu += values[1] + values[2]
                    else:
                        new_threads += 1
                    tw.writerow([sample, current["qpc"], utc_ns, pid, tid, current["created"], current["description"], current["description_hresult"],
                                 current["user"], current["kernel"], *(values or ["", "", "", ""]), "delta" if values else "first_observation"])
                    state["rows"] += 1
                if not current_threads and kernel.WaitForSingleObject(handle, 0) == 258:
                    raise RuntimeError("Live game yielded zero readable threads; thread CPU evidence is invalid")
                process_delta = deltas(process, previous_process, frequency)
                residual = process_delta[1] + process_delta[2] - common_cpu if process_delta else ""
                pw.writerow([sample, process["qpc"], utc_ns, pid, *(process_delta or ["", "", "", ""]),
                             common_cpu, residual, len(current_threads), new_threads,
                             len(set(previous_threads) - set(current_threads)), unreadable, (qpc() - read_begin) / frequency * 1000])
                thread_file.flush()
                process_file.flush()
                previous_process, previous_threads = process, current_threads
                state["samples"] += 1
                next_sample += 1.0
                if next_sample < time.monotonic():
                    next_sample = time.monotonic() + 1.0
    except Exception as error:
        state["stop_reason"] = "error"
        state["error"] = str(error)
        raise
    finally:
        if handle:
            kernel.CloseHandle(handle)
        state["end_qpc"] = qpc()
        state_path.write_text(json.dumps(state, indent=2), encoding="utf8")


if __name__ == "__main__":
    main()
