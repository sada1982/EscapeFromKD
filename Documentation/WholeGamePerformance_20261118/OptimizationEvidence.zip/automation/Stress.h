#pragma once
#include "Animation/AnimSingleNodeInstance.h"
#include "Animation/AnimationAsset.h"
#include "Camera/PlayerCameraManager.h"
#include "Components/CapsuleComponent.h"
#include "Components/DecalComponent.h"
#include "Components/LightComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Engine/World.h"
#include "Engine/LatentActionManager.h"
#include "Engine/OverlapResult.h"
#include "Engine/SkeletalMesh.h"
#include "EngineUtils.h"
#include "GameFramework/Character.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "GameFramework/PlayerController.h"
#include "HAL/PlatformMemory.h"
#include "HAL/PlatformTime.h"
#include "Misc/App.h"
#include "Misc/CommandLine.h"
#include "Misc/FileHelper.h"
#include "Misc/Parse.h"
#include "Misc/Paths.h"
#include "ProfilingDebugging/CpuProfilerTrace.h"
#include "PhysicsEngine/PhysicsAsset.h"
#include "RenderTimer.h"
#include "ShaderPipelineCache.h"
#include "UObject/UObjectIterator.h"
#include "UObject/UnrealType.h"
#include "UnrealClient.h"

struct FEnemyStressTest
{
    bool Enabled=false, Initialized=false, Finished=false;
    int32 EnemyCount=10, Phase=0, Frame=0, Shots=0, Hits=0, MinVisible=MAX_int32;
    double Duration=120.0, LastShot=0.0, LastInventory=0.0;
    uint64 WarmQpc=0, SampleQpc=0, EndQpc=0;
    FString Site=TEXT("corridor");
    TArray<TWeakObjectPtr<ACharacter>> Enemies;
    TArray<FVector> Homes, LastPositions;
    TArray<double> Distances, LastHitEnd;
    TArray<int32> Directions;
    UFunction* FireStart=nullptr;
    UFunction* FireStop=nullptr;
    FNumericProperty* ShotProperty=nullptr;
    FNumericProperty* HitEndProperty=nullptr;
    FBoolProperty* PreviewProperty=nullptr;
    FBoolProperty* HitProperty=nullptr;
    FStructProperty* StartTransformProperty=nullptr;
    FString Frames=TEXT("qpc,frame,elapsed,world_delta,app_delta,shots,hit_updates,reacting,gt_ms,rt_ms,rhi_ms,gpu_ms,gt_wait_ms,rt_wait_ms\n");
    FString Events=TEXT("event,qpc,elapsed,shots,hit_updates\n");
    FString Inventory=TEXT("label,qpc_begin,qpc_end,elapsed,enemies,actors,components,decals,registered_decals,niagara,active_niagara,lights,used_physical_B,used_virtual_B,in_frustum,visible,pso_pending\n");
    FString Actors=TEXT("label,qpc,index,actor,x,y,z,yaw,speed,distance,preview_enabled,preview_state,hit_reacting,in_frustum,visible,document_bone,mesh,animation,physics_asset\n");

    static double Seconds(uint64 Now,uint64 Begin)
    {
        return static_cast<double>(Now-Begin)*FPlatformTime::GetSecondsPerCycle64();
    }
    static void Write(const FString& Dir,const TCHAR* File,const FString& Value)
    {
        FFileHelper::SaveStringToFile(Value,*FPaths::Combine(Dir,File),FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM);
    }
    static double Number(FNumericProperty* Property,UObject* Object)
    {
        return Property?Property->GetFloatingPointPropertyValue(Property->ContainerPtrToValuePtr<void>(Object)):0.0;
    }
    void Mark(const TCHAR* Label,uint64 Now)
    {
        Events+=FString::Printf(TEXT("%s,%llu,%.6f,%d,%d\n"),Label,Now,SampleQpc?Seconds(Now,SampleQpc):0.0,Shots,Hits);
    }
    void Save(const FString& Dir)
    {
        Write(Dir,TEXT("stress_frames.csv"),Frames);
        Write(Dir,TEXT("stress_events.csv"),Events);
        Write(Dir,TEXT("stress_inventory.csv"),Inventory);
        Write(Dir,TEXT("stress_actors.csv"),Actors);
    }
    void Finish(const FString& Dir,ACharacter* Char,bool Success,const TCHAR* Reason)
    {
        if (FireStop) Char->ProcessEvent(FireStop,nullptr);
        Finished=true;
        Save(Dir);
        Write(Dir,TEXT("stress_result.txt"),FString::Printf(TEXT("success=%d\nreason=%s\nsite=%s\nenemies=%d\nduration=%.3f\nshots=%d\nhit_updates=%d\nmin_visible=%d\n"),Success?1:0,Reason,*Site,Enemies.Num(),Duration,Shots,Hits,MinVisible));
        FPlatformMisc::RequestExit(false,TEXT("KDEnemyStressComplete"));
    }
    void Snapshot(const FString& Dir,const TCHAR* Label,ACharacter* Char,APlayerController* Player)
    {
        const uint64 Begin=FPlatformTime::Cycles64();
        UWorld* World=Char->GetWorld();
        int32 ActorCount=0,ComponentCount=0,Decals=0,RegisteredDecals=0,Niagara=0,ActiveNiagara=0,Lights=0,Projected=0,Visible=0;
        for (TActorIterator<AActor> It(World);It;++It) ++ActorCount;
        UClass* NiagaraClass=FindObject<UClass>(nullptr,TEXT("/Script/Niagara.NiagaraComponent"));
        for (TObjectIterator<UActorComponent> It;It;++It)
        {
            if (It->GetWorld()!=World || It->HasAnyFlags(RF_ClassDefaultObject)) continue;
            ++ComponentCount;
            if (It->IsA<UDecalComponent>()) { ++Decals; RegisteredDecals+=It->IsRegistered()?1:0; }
            if (It->IsA<ULightComponent>()) ++Lights;
            if (NiagaraClass && It->IsA(NiagaraClass)) { ++Niagara; ActiveNiagara+=It->IsActive()?1:0; }
        }
        int32 Width=0,Height=0;
        Player->GetViewportSize(Width,Height);
        const FVector Eye=Player->PlayerCameraManager->GetCameraLocation();
        for (int32 Index=0;Index<Enemies.Num();++Index)
        {
            ACharacter* Enemy=Enemies[Index].Get();
            if (!Enemy) continue;
            const FVector P=Enemy->GetActorLocation();
            bool InFrame=false,HasSight=false;
            for (const FVector Offset : {FVector(0,0,25),FVector(0,0,70),FVector(0,-24,25),FVector(0,24,25)})
            {
                FVector2D Screen;
                const FVector Point=P+Offset;
                const bool Inside=Player->ProjectWorldLocationToScreen(Point,Screen) && Screen.X>=0 && Screen.X<Width && Screen.Y>=0 && Screen.Y<Height;
                InFrame|=Inside;
                if (Inside)
                {
                    FHitResult Hit;
                    FCollisionQueryParams Params(SCENE_QUERY_STAT(KDStressSight),true,Char);
                    const bool Blocked=World->LineTraceSingleByChannel(Hit,Eye,Point,ECC_Visibility,Params);
                    HasSight|=Blocked && Hit.GetActor()==Enemy;
                }
            }
            Projected+=InFrame?1:0; Visible+=HasSight?1:0;
            USkeletalMeshComponent* Mesh=Enemy->GetMesh();
            UAnimSingleNodeInstance* Anim=Mesh?Mesh->GetSingleNodeInstance():nullptr;
            FIntProperty* State=FindFProperty<FIntProperty>(Enemy->GetClass(),TEXT("PreviewState"));
            Actors+=FString::Printf(TEXT("%s,%llu,%d,%s,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%d,%d,%d,%d,%d,%d,%s,%s,%s\n"),
                Label,Begin,Index,*Enemy->GetName(),P.X,P.Y,P.Z,Enemy->GetActorRotation().Yaw,Enemy->GetVelocity().Size(),Distances[Index],
                PreviewProperty->GetPropertyValue_InContainer(Enemy)?1:0,State?State->GetPropertyValue_InContainer(Enemy):-1,
                HitProperty->GetPropertyValue_InContainer(Enemy)?1:0,InFrame?1:0,HasSight?1:0,
                Mesh?Mesh->GetBoneIndex(TEXT("document")):-1,*GetPathNameSafe(Mesh?Mesh->GetSkeletalMeshAsset():nullptr),
                *GetPathNameSafe(Anim?Anim->GetCurrentAsset():nullptr),*GetPathNameSafe(Mesh?Mesh->GetPhysicsAsset():nullptr));
        }
        MinVisible=FMath::Min(MinVisible,Visible);
        const FPlatformMemoryStats Memory=FPlatformMemory::GetStats();
        const uint64 End=FPlatformTime::Cycles64();
        Inventory+=FString::Printf(TEXT("%s,%llu,%llu,%.6f,%d,%d,%d,%d,%d,%d,%d,%d,%llu,%llu,%d,%d,%u\n"),
            Label,Begin,End,SampleQpc?Seconds(Begin,SampleQpc):0.0,Enemies.Num(),ActorCount,ComponentCount,Decals,RegisteredDecals,
            Niagara,ActiveNiagara,Lights,static_cast<uint64>(Memory.UsedPhysical),static_cast<uint64>(Memory.UsedVirtual),Projected,Visible,FShaderPipelineCache::NumPrecompilesRemaining());
    }
    bool Init(const FString& Dir,ACharacter* Char,APlayerController* Player)
    {
        Initialized=true;
        FParse::Value(FCommandLine::Get(),TEXT("KDStressEnemies="),EnemyCount);
        FParse::Value(FCommandLine::Get(),TEXT("KDStressSeconds="),Duration);
        FParse::Value(FCommandLine::Get(),TEXT("KDStressSite="),Site);
        EnemyCount=FMath::Clamp(EnemyCount,1,10); Duration=FMath::Clamp(Duration,10.0,600.0);
        UWorld* World=Char->GetWorld();
        ACharacter* Original=nullptr;
        for (TActorIterator<ACharacter> It(World);It;++It)
            if (It->GetClass()->GetName().StartsWith(TEXT("BP_AdmissionRobot")))
            {
                if (Original) { Finish(Dir,Char,false,TEXT("unexpected_existing_enemy_count")); return false; }
                Original=*It;
            }
        FireStart=Char->FindFunction(TEXT("StartFiring")); FireStop=Char->FindFunction(TEXT("StopFiring"));
        ShotProperty=FindFProperty<FNumericProperty>(Char->GetClass(),TEXT("NextShotTime"));
        if (!Original || !FireStart || !FireStop || !ShotProperty || !Player->PlayerCameraManager)
        { Finish(Dir,Char,false,TEXT("missing_enemy_or_fire_api")); return false; }
        PreviewProperty=FindFProperty<FBoolProperty>(Original->GetClass(),TEXT("PreviewEnabled"));
        HitProperty=FindFProperty<FBoolProperty>(Original->GetClass(),TEXT("IsHitReacting"));
        HitEndProperty=FindFProperty<FNumericProperty>(Original->GetClass(),TEXT("HitReactEndTime"));
        StartTransformProperty=FindFProperty<FStructProperty>(Original->GetClass(),TEXT("StartTransform"));
        if (!PreviewProperty || !HitProperty || !HitEndProperty || !StartTransformProperty || StartTransformProperty->Struct!=TBaseStructure<FTransform>::Get() || !Original->FindFunction(TEXT("PlayWalk")) || !Original->FindFunction(TEXT("PlayRun")) || !Original->FindFunction(TEXT("PlayIdle")))
        { Finish(Dir,Char,false,TEXT("missing_enemy_api")); return false; }
        const FVector Corridor[]={ {-1400,350,98.15},{-1270,180,98.15},{-1270,480,98.15},{-1390,180,98.15},{-1390,480,98.15},
            {-1520,180,98.15},{-1520,350,98.15},{-1520,480,98.15},{-1670,250,98.15},{-1670,450,98.15} };
        FVector PlayerPosition(-1060,350,98.15);
        if (Site==TEXT("atrium"))
        {
            PlayerPosition=FVector(-550,-650,-531.85);
            Homes.Add(FVector(-1000,-650,-531.85));
            for (const double X : {-1000.0,-1180.0})
                for (const double Y : {-850.0,-750.0,-650.0,-550.0,-450.0})
                    if (X!=-1000.0 || Y!=-650.0) Homes.Add(FVector(X,Y,-531.85));
        }
        else if (Site==TEXT("corridor")) Homes.Append(Corridor,UE_ARRAY_COUNT(Corridor));
        else { Finish(Dir,Char,false,TEXT("unknown_site")); return false; }
        Char->ProcessEvent(FireStop,nullptr);
        Char->GetCharacterMovement()->StopMovementImmediately();
        PreviewProperty->SetPropertyValue_InContainer(Original,false);
        World->GetLatentActionManager().RemoveActionsForObject(Original);
        HitProperty->SetPropertyValue_InContainer(Original,false);
        HitEndProperty->SetFloatingPointPropertyValue(HitEndProperty->ContainerPtrToValuePtr<void>(Original),0.0);
        Original->ProcessEvent(Original->FindFunction(TEXT("PlayIdle")),nullptr);
        FCollisionQueryParams Params(SCENE_QUERY_STAT(KDStressPlacement),false,Char);
        Params.AddIgnoredActor(Original);
        FString Placement=TEXT("role,index,x,y,z,floor_hit,floor_z,capsule_blocked,capsule_radius,capsule_half_height,floor_actor,floor_component\n");
        FString Blockers=TEXT("role,index,actor,component,component_x,component_y,component_z,bounds_x,bounds_y,bounds_z,extent_x,extent_y,extent_z\n");
        bool PlacementFailed=false;
        for (int32 Index=-1;Index<EnemyCount;++Index)
        {
            const FVector P=Index<0?PlayerPosition:Homes[Index];
            UCapsuleComponent* Capsule=Index<0?Char->GetCapsuleComponent():Original->GetCapsuleComponent();
            TArray<FOverlapResult> Overlaps;
            const bool Blocked=World->OverlapMultiByChannel(Overlaps,P,FQuat::Identity,ECC_Pawn,
                FCollisionShape::MakeCapsule(Capsule->GetScaledCapsuleRadius(),Capsule->GetScaledCapsuleHalfHeight()),Params);
            for (const FOverlapResult& Overlap : Overlaps)
            {
                UPrimitiveComponent* Component=Overlap.GetComponent();
                if (!Overlap.bBlockingHit || !Component) continue;
                const FVector Location=Component->GetComponentLocation(),Center=Component->Bounds.Origin,Extent=Component->Bounds.BoxExtent;
                Blockers+=FString::Printf(TEXT("%s,%d,%s,%s,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f\n"),
                    Index<0?TEXT("player"):TEXT("enemy"),Index,*GetPathNameSafe(Overlap.GetActor()),*Component->GetPathName(),
                    Location.X,Location.Y,Location.Z,Center.X,Center.Y,Center.Z,Extent.X,Extent.Y,Extent.Z);
            }
            FHitResult Floor;
            const bool FloorHit=World->LineTraceSingleByChannel(Floor,P,P-FVector(0,0,220),ECC_Visibility,Params);
            Placement+=FString::Printf(TEXT("%s,%d,%.4f,%.4f,%.4f,%d,%.4f,%d,%.4f,%.4f,%s,%s\n"),
                Index<0?TEXT("player"):TEXT("enemy"),Index,P.X,P.Y,P.Z,FloorHit?1:0,Floor.ImpactPoint.Z,Blocked?1:0,
                Capsule->GetScaledCapsuleRadius(),Capsule->GetScaledCapsuleHalfHeight(),*GetPathNameSafe(Floor.GetActor()),*GetPathNameSafe(Floor.GetComponent()));
            if (Blocked || !FloorHit || FMath::Abs((P.Z-Capsule->GetScaledCapsuleHalfHeight())-Floor.ImpactPoint.Z)>10)
                PlacementFailed=true;
        }
        Write(Dir,TEXT("stress_placement.csv"),Placement);
        Write(Dir,TEXT("stress_blockers.csv"),Blockers);
        if (PlacementFailed) { Finish(Dir,Char,false,TEXT("placement_collision_or_floor")); return false; }
        Char->SetActorLocation(PlayerPosition,false,nullptr,ETeleportType::TeleportPhysics);
        Player->SetControlRotation(FRotator(-4,180,0));
        Original->SetActorLocation(Homes[0],false,nullptr,ETeleportType::TeleportPhysics);
        Original->SetActorRotation(FRotator(0,0,0));
        *StartTransformProperty->ContainerPtrToValuePtr<FTransform>(Original)=Original->GetActorTransform();
        Enemies.Add(Original);
        for (int32 Index=1;Index<EnemyCount;++Index)
        {
            FActorSpawnParameters Spawn;
            Spawn.Template=Original; Spawn.ObjectFlags|=RF_Transient;
            Spawn.Name=FName(*FString::Printf(TEXT("KDStressEnemy_%02d"),Index));
            Spawn.SpawnCollisionHandlingOverride=ESpawnActorCollisionHandlingMethod::DontSpawnIfColliding;
            Spawn.TransformScaleMethod=ESpawnActorScaleMethod::OverrideRootScale;
            const FTransform SpawnTransform(FRotator::ZeroRotator,Homes[Index],Original->GetActorScale3D());
            ACharacter* Enemy=World->SpawnActor<ACharacter>(Original->GetClass(),SpawnTransform,Spawn);
            if (!Enemy) { Finish(Dir,Char,false,TEXT("spawn_collision")); return false; }
            Enemies.Add(Enemy);
            *StartTransformProperty->ContainerPtrToValuePtr<FTransform>(Enemy)=Enemy->GetActorTransform();
            PreviewProperty->SetPropertyValue_InContainer(Enemy,true);
            Enemy->ProcessEvent(Enemy->FindFunction(Index%2?TEXT("PlayWalk"):TEXT("PlayRun")),nullptr);
        }
        for (const auto& Weak : Enemies)
        {
            ACharacter* Enemy=Weak.Get();
            LastPositions.Add(Enemy->GetActorLocation()); Distances.Add(0); Directions.Add(1);
            LastHitEnd.Add(Number(HitEndProperty,Enemy));
            if (!Enemy->GetMesh() || Enemy->GetMesh()->GetBoneIndex(TEXT("document"))<0)
            { Finish(Dir,Char,false,TEXT("missing_agreement_mesh")); return false; }
        }
        WarmQpc=FPlatformTime::Cycles64();
        Frames.Reserve(static_cast<int32>(Duration*200*220));
        Mark(TEXT("initialized"),WarmQpc);
        Write(Dir,TEXT("stress_meta.txt"),FString::Printf(TEXT("site=%s\nenemies=%d\nseconds=%.3f\nqpc_frequency=%lld\noriginal=%s\nmovement=existing_BP_forward_input_bounded_runtime_only\n"),*Site,EnemyCount,Duration,FMath::RoundToInt64(1.0/FPlatformTime::GetSecondsPerCycle64()),*Original->GetPathName()));
        return true;
    }
    void Update(const FString& Dir,APlayerController* Player,ACharacter* Char,float Delta)
    {
        if (Finished) return;
        if (!Initialized && !Init(Dir,Char,Player)) return;
        const uint64 Now=FPlatformTime::Cycles64();
        ACharacter* Target=Enemies[0].Get();
        if (!Target) { Finish(Dir,Char,false,TEXT("target_lost")); return; }
        Player->SetControlRotation((Target->GetActorLocation()+FVector(0,0,28)-Player->PlayerCameraManager->GetCameraLocation()).Rotation());
        int32 Reacting=0;
        for (int32 Index=0;Index<Enemies.Num();++Index)
        {
            ACharacter* Enemy=Enemies[Index].Get();
            if (!Enemy) { Finish(Dir,Char,false,TEXT("enemy_lost")); return; }
            const FVector P=Enemy->GetActorLocation();
            Distances[Index]+=FVector::Dist(P,LastPositions[Index]); LastPositions[Index]=P;
            const bool Hit=HitProperty->GetPropertyValue_InContainer(Enemy);
            Reacting+=Hit?1:0;
            const double HitEnd=Number(HitEndProperty,Enemy);
            if (Phase==1 && HitEnd>LastHitEnd[Index]) ++Hits;
            LastHitEnd[Index]=HitEnd;
            if (Index>0 && !Hit)
            {
                if (P.X>Homes[Index].X+20) Directions[Index]=-1;
                if (P.X<Homes[Index].X-20) Directions[Index]=1;
                Enemy->SetActorRotation(FRotator(0,Directions[Index]>0?0:180,0));
            }
            if (FMath::Abs(P.Z-Homes[Index].Z)>40)
            {
                const FVector Start=StartTransformProperty->ContainerPtrToValuePtr<FTransform>(Enemy)->GetLocation();
                const FIntProperty* State=FindFProperty<FIntProperty>(Enemy->GetClass(),TEXT("PreviewState"));
                Write(Dir,TEXT("stress_position_failure.txt"),FString::Printf(TEXT("reason=enemy_floor_mismatch\nindex=%d\nactor=%s\nqpc=%llu\nphase=%d\nwarm_elapsed=%.6f\nactual=%s\nexpected=%s\nstart_transform=%s\nvelocity=%s\nmovement_mode=%d\npreview_enabled=%d\npreview_state=%d\nhit_reacting=%d\n"),
                    Index,*Enemy->GetPathName(),Now,Phase,Seconds(Now,WarmQpc),*P.ToString(),*Homes[Index].ToString(),*Start.ToString(),*Enemy->GetVelocity().ToString(),
                    static_cast<int32>(Enemy->GetCharacterMovement()->MovementMode),PreviewProperty->GetPropertyValue_InContainer(Enemy)?1:0,State?State->GetPropertyValue_InContainer(Enemy):-1,Hit?1:0));
                Snapshot(Dir,TEXT("failure"),Char,Player);
                Finish(Dir,Char,false,TEXT("enemy_floor_mismatch")); return;
            }
        }
        if (Phase==0)
        {
            if (Seconds(Now,WarmQpc)<10 || FShaderPipelineCache::NumPrecompilesRemaining()!=0) return;
            Snapshot(Dir,TEXT("start"),Char,Player);
            SampleQpc=FPlatformTime::Cycles64(); LastShot=Number(ShotProperty,Char);
            Mark(TEXT("sample_begin"),SampleQpc);
            TRACE_CPUPROFILER_EVENT_SCOPE(KD_StressMeasureStart);
            Char->ProcessEvent(FireStart,nullptr);
            Phase=1;
            return;
        }
        if (Phase==1)
        {
            ++Frame;
            const double Elapsed=Seconds(Now,SampleQpc), Shot=Number(ShotProperty,Char);
            Shots+=Shot>LastShot?1:0; LastShot=Shot;
            Frames+=FString::Printf(TEXT("%llu,%d,%.6f,%.8f,%.8f,%d,%d,%d,%.5f,%.5f,%.5f,%.5f,%.5f,%.5f\n"),
                Now,Frame,Elapsed,Delta,FApp::GetDeltaTime(),Shots,Hits,Reacting,FPlatformTime::ToMilliseconds(GGameThreadTime),
                FPlatformTime::ToMilliseconds(GRenderThreadTime),FPlatformTime::ToMilliseconds(GRHIThreadTime),FPlatformTime::ToMilliseconds(RHIGetGPUFrameCycles()),
                FPlatformTime::ToMilliseconds(GGameThreadWaitTime),FPlatformTime::ToMilliseconds(GRenderThreadWaitTime));
            if (Elapsed-LastInventory>=15 && Elapsed<Duration-1) { Snapshot(Dir,TEXT("during"),Char,Player); LastInventory=Elapsed; }
            if (Elapsed<Duration) return;
            TRACE_CPUPROFILER_EVENT_SCOPE(KD_StressMeasureEnd);
            Mark(TEXT("sample_end"),Now); EndQpc=Now;
            Char->ProcessEvent(FireStop,nullptr);
            Snapshot(Dir,TEXT("end"),Char,Player); Save(Dir);
            FScreenshotRequest::RequestScreenshot(FPaths::Combine(Dir,TEXT("stress_end.png")),false,false);
            Phase=2;
            return;
        }
        if (Phase==2 && Seconds(Now,EndQpc)>=3 && !FScreenshotRequest::IsScreenshotRequested())
        {
            Snapshot(Dir,TEXT("cooldown"),Char,Player);
            Finish(Dir,Char,Shots>0 && Hits>0,TEXT("duration_complete"));
        }
    }
};
