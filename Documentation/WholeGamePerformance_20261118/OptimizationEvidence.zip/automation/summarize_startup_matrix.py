import argparse
import collections
import csv
import json
from pathlib import Path
import statistics


here = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument("runs", nargs="+")
parser.add_argument("--output", type=Path, default=here / "loading_worker_comparison.json")
args = parser.parse_args()


def read_csv(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        yield from csv.DictReader(stream)


def pairs(path):
    return dict(line.split("=",1) for line in path.read_text(encoding="utf-8-sig").splitlines() if "=" in line)


def numeric_stats(rows,keys):
    output = {}
    for key in keys:
        values = []
        for row in rows:
            try:
                values.append(float(row[key]))
            except (ValueError,KeyError):
                pass
        output[key] = dict(n=len(values),mean=statistics.mean(values),minimum=min(values),maximum=max(values),first=values[0],last=values[-1]) if values else None
    return output


reports = []
for name in args.runs:
    run = Path(name) if Path(name).is_dir() else here / name
    meta = json.loads((run / "metadata.json").read_text(encoding="utf8"))
    route = Path(meta["route"])
    freq = meta["start"]["frequency"]
    gate = pairs(route / "startup_result.txt")
    cap = pairs(route / "startup_frame_cap.txt")
    summary = json.loads((run / "summary.json").read_text(encoding="utf8"))
    control = json.loads((here / (run.name+"Control") / "execution.json").read_text(encoding="utf8"))
    window = json.loads((here / (run.name+"Window") / "sample_window_audit.json").read_text(encoding="utf8"))
    thread_root = here / (run.name+"Threads")
    sampler = json.loads((thread_root / "thread_cpu_state.json").read_text(encoding="utf8"))
    start,end = int(gate["start_qpc"]),int(gate["open_qpc"])
    stages = [("loading",start,end)] + [("postgate_round_"+str(row["round"]),int(row["q0"]),int(row["q1"])) for row in summary["per_round"]]
    windows = {}
    for label,low,high in stages:
        duration = (high-low)/freq
        groups = collections.defaultdict(float)
        tids = collections.defaultdict(set)
        for row in read_csv(thread_root / "thread_cpu.csv"):
            if not row["elapsed_s"]:
                continue
            finish = int(row["qpc"])
            begin = finish - float(row["elapsed_s"])*freq
            if low <= begin < finish <= high:
                description = row["description"] or "<unnamed>"
                group = "PSOPrecompilePool" if description.startswith("PSOPrecompilePool") else description
                groups[group] += float(row["delta_user_s"])+float(row["delta_kernel_s"])
                tids[group].add((row["tid"],row["thread_creation_filetime"]))
        process_cpu = process_seconds = 0.0
        observations = []
        for row in read_csv(thread_root / "thread_process_cpu.csv"):
            if not row["elapsed_s"]:
                continue
            finish = int(row["qpc"])
            begin = finish-float(row["elapsed_s"])*freq
            if low <= begin < finish <= high:
                process_cpu += float(row["delta_user_s"])+float(row["delta_kernel_s"])
                process_seconds += float(row["elapsed_s"])
                observations.append(row)
        gpu = [row for row in read_csv(run / "monitor_nvidia.csv") if low <= int(row["qpc_delivery"]) <= high]
        memory = [row for row in read_csv(run / "monitor_process.csv") if row["role"]=="game" and low <= int(row["qpc"]) <= high]
        windows[label] = dict(q0=low,q1=high,duration_s=duration,process_cpu_s=process_cpu,
            process_observed_delta_seconds=process_seconds,process_observed_avg_cores=process_cpu/process_seconds if process_seconds else None,
            thread_cpu_s=sum(groups.values()),thread_cumulative_core_lower_bound=sum(groups.values())/duration,
            thread_groups=[dict(name=key,cpu_s=value,unique_threads=len(tids[key])) for key,value in sorted(groups.items(),key=lambda pair:-pair[1])],
            observed_threads=numeric_stats(observations,["observed_threads","unreadable_threads","read_window_ms"]),
            gpu=numeric_stats(gpu,["memory.used [MiB]","temperature.gpu","utilization.gpu [%]","power.draw [W]","clocks.current.graphics [MHz]"]),
            game_memory=numeric_stats(memory,["local_usage_B","local_budget_B","evicted_process_B","private_B","working_set_B"]))
    startup = list(read_csv(route / "startup.csv"))
    before_open = [row for row in startup if int(row["qpc"]) <= end]
    late_pending = [row for row in before_open if int(row["pso_pending"])>0]
    reports.append(dict(run=run.name,workers=control["workers"],loading_fps=control["loading_fps"],expected_window=control["expected_window"],
        exe_sha256=control["exe_sha256"],pak_sha256=control["pak_sha256"],normal_exit=meta.get("returncode")==0,
        sampler_identity_verified=sampler.get("identity_verified"),window_stable=window["all_rounds_observed_stable"],
        gate=gate,cap=cap,loading_seconds=(end-start)/freq,
        last_pending_elapsed_s=(int(late_pending[-1]["qpc"])-start)/freq if late_pending else None,
        max_pending=max(int(row["pso_pending"]) for row in before_open),
        windows=windows,postgate=summary["per_round"],
        exclusion=(run / "exclusion.txt").read_text(encoding="utf-8-sig") if (run / "exclusion.txt").exists() else None))
result = dict(runs=reports,limitations=[
    "New distribution/UserDir; OS and driver global caches were not cleared.",
    "Same automatic loading screenshot at30seconds is included in every diagnostic startup.",
    "Actual CPU sums include only per-thread deltas completely inside each window; boundary and unobserved/exited threads are omitted. Parallel thread CPU is not critical-path frame time.",
    "GPU and memory observations are approximately1second samples; no attribution of an isolated frame is implied.",
    "Editor placement/foreground is sampled every250ms; shorter changes can be missed. Slate0 is the root-established run condition, not modified by the runner."])
args.output.write_text(json.dumps(result,indent=2),encoding="utf8")
for row in reports:
    print(row["run"],"load_s=",round(row["loading_seconds"],3),"cap=",row["cap"]["status"],
          "load_CPUcores=",row["windows"]["loading"]["process_observed_avg_cores"],
          "post=",[(item["round"],item["present"]) for item in row["postgate"]])
