import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile


here = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument("source", type=Path)
parser.add_argument("name")
parser.add_argument("--execute", action="store_true")
args = parser.parse_args()
assert args.name.isalnum()
source = args.source.resolve(strict=True)
proof = json.loads((source / "proof.json").read_text(encoding="utf8"))
gate = (source / "SourceSnapshot/ExhibitStartupGate.cpp").read_text(encoding="utf8")
assert "ResourceReadyQpc" in gate and "LoadingFpsLimit" in gate
assert "WallMs <= 33.34 || (Now - ResourceReadyQpc) * SecondsPerCycle >= 1.0" in gate
before = proof["settings"]
assert len(re.findall(r"^t\.MaxFPS=0$", before, flags=re.M)) == 1
after = before
assert "r.PSOPrecaching.MinPriorityForActivePrecacheRequests=0" in after
assert "r.PSOPrecaching.TaskPriorityThreshold=0" in after
output = here / "Variants" / args.name
entry = "myProject/Config/DefaultGameUserSettings.ini"
pak_relative = Path("myProject/Content/Paks/myProject-Windows.pak")
exe_relative = Path("myProject/Binaries/Win64/myProject-Win64-Shipping.exe")
plan = dict(source=str(source), output=str(output), same_exe_sha256=proof["exe_sha256"],
            only_ini_change="DefaultGameUserSettings FrameRateLimit=0 -> 20; WindowsEngine.ini unchanged", purpose="loading liveness only; not a 60FPS performance run")
if not args.execute:
    print(json.dumps(plan, indent=2))
    raise SystemExit(0)
output.mkdir(exist_ok=False)
scratch = Path(tempfile.mkdtemp(prefix="KDLowFPSPak_"))
uepak = Path("C:/Program Files/Epic Games/UE_5.8/Engine/Binaries/Win64/UnrealPak.exe")


def digest(path):
    value = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(4*1024*1024), b""):
            value.update(block)
    return value.hexdigest()


def pak_run(*values):
    result = subprocess.run([str(uepak), *map(str, values)], stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW)
    text = result.stdout.decode(errors="replace")
    with (output / "unrealpak.log").open("a", encoding="utf8") as stream:
        stream.write(text)
    result.check_returncode()
    return text


def entries(path):
    return {name:(sha1,method) for name,sha1,method in re.findall(r'"([^"\r\n]+)" offset: [^\r\n]+?sha1: ([0-9A-Fa-f]+), compression: (\w+)\.',pak_run(path,"-List"))}


assert digest(source / "Windows" / exe_relative) == proof["exe_sha256"]
assert digest(source / "Windows" / pak_relative) == proof["pak_sha256"]
original = entries(source / "Windows" / pak_relative)
assert entry in original
raw = scratch / "raw"
pak_run(source / "Windows" / pak_relative, "-Extract", raw)
assert (raw / "myProject/Config/Windows/WindowsEngine.ini").read_text(encoding="utf-8-sig") == before
user_before = (raw / entry).read_text(encoding="utf-8-sig")
assert len(re.findall(r"^FrameRateLimit=0(?:\.0+)?$",user_before,flags=re.M)) == 1
user_after = re.sub(r"^FrameRateLimit=0(?:\.0+)?$","FrameRateLimit=20.000000",user_before,flags=re.M)
(raw / entry).write_text(user_after, encoding="utf8")
listing = scratch / "files.txt"
listing.write_text("\n".join('"'+(raw/key).as_posix()+'" "../../../'+key+'"'+(" -compress" if method!="None" else "")
                            for key,(_,method) in original.items())+"\n",encoding="utf8")
windows = output / "Windows"
for path in (source / "Windows").rglob("*"):
    if not path.is_file():
        continue
    relative = path.relative_to(source / "Windows")
    if relative == pak_relative or "Saved" in relative.parts:
        continue
    target = windows / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    os.link(path,target)
    assert os.path.samefile(path,target)
pak_run(windows / pak_relative,"-Create="+str(listing),"-patchpaddingalign=2048","-compressionformats=Oodle",
        "-compresslevel=4","-compressmethod=Kraken","-platform=Windows","-unattended")
pak_run(windows / pak_relative,"-Test")
modified = entries(windows / pak_relative)
assert set(original) == set(modified)
assert [key for key in original if original[key] != modified[key]] == [entry]
pak_run(windows / pak_relative,"-Extract",scratch / "verified","-Filter="+entry)
assert (scratch / "verified" / entry).read_text(encoding="utf-8-sig") == user_after
shutil.copytree(source / "SourceSnapshot",output / "SourceSnapshot")
plan.update(name=args.name, settings=after, exe=str(windows/exe_relative), exe_sha256=proof["exe_sha256"],
            pak_sha256=digest(windows/pak_relative), pak_changed_entry=entry, other_pak_entries_unchanged=len(original)-1,
            initial_max_fps=20, frame_rate_limit=20, game_user_settings_before=user_before, game_user_settings_after=user_after,
            unrealpak_test="passed", scratch=str(scratch))
(output / "proof.json").write_text(json.dumps(plan,indent=2),encoding="utf8")
assert digest(source / "Windows" / pak_relative) == proof["pak_sha256"]
print(json.dumps(plan,indent=2))
