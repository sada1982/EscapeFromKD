import argparse
import configparser
import hashlib
import json
import os
from pathlib import Path
import shutil

parser = argparse.ArgumentParser()
parser.add_argument('--backend', choices=('cpu', 'gpu'), required=True)
args = parser.parse_args()
out = Path(__file__).resolve().parent
source = out.parents[2]
work = Path(os.environ['LOCALAPPDATA']) / 'KDLightmassTrial_20261118'
assert not work.exists(), work
work.mkdir()
for directory in ('Content', 'Config'):
    shutil.copytree(source / directory, work / directory, copy_function=shutil.copy2)
original_files = []
for directory in ('Content', 'Config'):
    for original in (source / directory).rglob('*'):
        if not original.is_file():
            continue
        relative = original.relative_to(source)
        copied = work / relative
        digest = hashlib.sha256(original.read_bytes()).hexdigest()
        assert original.stat().st_ino != copied.stat().st_ino
        assert hashlib.sha256(copied.read_bytes()).hexdigest() == digest
        original_files.append(dict(path=relative.as_posix(), sha256=digest))
for relative in ('Config/Windows/WindowsEngine.ini', 'Config/DefaultGameUserSettings.ini'):
    destination = work / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source / 'Build/Exhibit' / relative, destination)
descriptor = json.loads((source / 'myProject.uproject').read_text(encoding='utf8'))
descriptor['Modules'] = [dict(Name='myProject', Type='Runtime', LoadingPhase='Default', TargetAllowList=['Game'])]
shutil.copytree(source / 'Build/Exhibit/Source', work / 'Source', copy_function=shutil.copy2)
for plugin in descriptor['Plugins']:
    if plugin['Name'] == 'ModelContextProtocol':
        plugin['Enabled'] = False
if args.backend == 'gpu':
    descriptor['Plugins'].append(dict(Name='GPULightmass', Enabled=True))
(work / 'myProject.uproject').write_text(json.dumps(descriptor, indent=2), encoding='utf8')
config_path = work / 'Config/DefaultEngine.ini'
config = config_path.read_text(encoding='utf8')
assert config.count('r.AllowStaticLighting=False') == 1
assert config.count('r.DynamicGlobalIlluminationMethod=1') == 1
config = config.replace('r.AllowStaticLighting=False', 'r.AllowStaticLighting=True')
config = config.replace('r.DynamicGlobalIlluminationMethod=1', 'r.DynamicGlobalIlluminationMethod=0')
if args.backend == 'gpu':
    config += '\n[/Script/Engine.RendererSettings]\nr.VirtualTextures=True\nr.VirtualTexturedLightmaps=True\n'
config_path.write_text(config, encoding='utf8')
record = dict(project=str(work), backend=args.backend, source=str(source),
    stage='prepared_only', original_files=original_files, independent_files=True,
    warning='Isolated technical prototype; appearance is not validated.')
(out / 'lightmass_trial_project.json').write_text(json.dumps(record, indent=2), encoding='utf8')
print(work)
