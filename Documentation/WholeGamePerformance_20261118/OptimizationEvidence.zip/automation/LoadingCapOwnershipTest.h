#pragma once
#include "CoreMinimal.h"
#include "HAL/IConsoleManager.h"
#include "HAL/PlatformTime.h"
#include "Misc/CommandLine.h"
#include "Misc/FileHelper.h"
#include "Misc/Parse.h"
#include "Misc/Paths.h"
#include "ShaderPipelineCache.h"

struct FLoadingCapOwnershipTest
{
    bool Enabled=false, Injected=false, Finished=false, Valid=false;
    uint64 ArmedQpc=0, WriteQpc=0;
    int32 WriteCallbacks=0;
    uint32 OriginalPriority=0;
    FString OriginalValue, Status;
    FString Records=TEXT("event,qpc,pso_pending,value,priority,write_callbacks\n");

    void Record(const TCHAR* Event,uint64 Now,IConsoleVariable* Variable)
    {
        Records+=FString::Printf(TEXT("%s,%llu,%u,%s,%u,%d\n"),Event,Now,FShaderPipelineCache::NumPrecompilesRemaining(),
            Variable?*Variable->GetString():TEXT("missing"),Variable?(Variable->GetFlags()&ECVF_SetByMask):0,WriteCallbacks);
    }
    void Save(const FString& Dir)
    {
        FFileHelper::SaveStringToFile(Records,*FPaths::Combine(Dir,TEXT("cap_ownership_events.csv")),FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM);
        const FString Result=FString::Printf(TEXT("status=%s\narmed_qpc=%llu\nwrite_qpc=%llu\noriginal_value=%s\noriginal_priority=%u\ninjected=%d\nwrite_callbacks=%d\nfinished=%d\n"),
            *Status,ArmedQpc,WriteQpc,*OriginalValue,OriginalPriority,Injected?1:0,WriteCallbacks,Finished?1:0);
        FFileHelper::SaveStringToFile(Result,*FPaths::Combine(Dir,TEXT("cap_ownership_result.txt")),FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM);
    }
    void BeforeGate(const FString& Dir,uint64 Now)
    {
        Enabled=FParse::Param(FCommandLine::Get(),TEXT("KDLoadingCapOwnershipTest"));
        if (!Enabled) return;
        ArmedQpc=Now;
        IConsoleVariable* Variable=IConsoleManager::Get().FindConsoleVariable(TEXT("t.MaxFPS"));
        int32 Requested=0;
        FParse::Value(FCommandLine::Get(),TEXT("KDStartupMaxFPS="),Requested);
        OriginalValue=Variable?Variable->GetString():TEXT("missing");
        OriginalPriority=Variable?(Variable->GetFlags()&ECVF_SetByMask):0;
        Valid=!Dir.IsEmpty() && Variable && Variable->GetFloat()==0.0f && Requested==30;
        Status=Valid?TEXT("armed"):TEXT("invalid_initial_conditions");
        Record(TEXT("before_gate"),Now,Variable);
        if (!Dir.IsEmpty()) Save(Dir);
    }
    void Tick(const FString& Dir,uint64 Now,bool GateOpen)
    {
        if (!Enabled || Finished || Dir.IsEmpty()) return;
        IConsoleVariable* Variable=IConsoleManager::Get().FindConsoleVariable(TEXT("t.MaxFPS"));
        if (GateOpen)
        {
            Finished=true;
            if (Valid) Status=Injected?TEXT("gate_open_after_external_write"):TEXT("not_injected_before_gate_open");
            Record(TEXT("after_gate"),Now,Variable);
            Save(Dir);
            return;
        }
        if (!Valid || Injected || !Variable || (Now-ArmedQpc)*FPlatformTime::GetSecondsPerCycle64()<2.0 ||
            FShaderPipelineCache::NumPrecompilesRemaining()==0 || Variable->GetFloat()!=30.0f ||
            (Variable->GetFlags()&ECVF_SetByMask)!=OriginalPriority) return;
        Record(TEXT("before_write"),FPlatformTime::Cycles64(),Variable);
        const FDelegateHandle Handle=Variable->OnChangedDelegate().AddLambda([this](IConsoleVariable*) { ++WriteCallbacks; });
        WriteQpc=FPlatformTime::Cycles64();
        Variable->ReplaceCurrentPriorityAndTag(TEXT("30"));
        Variable->OnChangedDelegate().Remove(Handle);
        Injected=true;
        Status=TEXT("external_same_value_written");
        Record(TEXT("after_write"),FPlatformTime::Cycles64(),Variable);
        Save(Dir);
    }
};
