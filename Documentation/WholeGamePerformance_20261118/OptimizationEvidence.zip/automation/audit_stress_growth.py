import argparse
import csv
import json
import math
from pathlib import Path
import statistics


parser = argparse.ArgumentParser()
parser.add_argument("run", type=Path)
args = parser.parse_args()
meta = json.loads((args.run / "metadata.json").read_text(encoding="utf8"))
route = Path(meta["route"])
frequency = meta["start"]["frequency"]


def rows(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def stats(values):
    values = sorted(values)
    if not values:
        return None
    return dict(n=len(values), mean_ms=statistics.mean(values), p99_ms=values[math.ceil(len(values)*.99)-1],
                max_ms=values[-1], over_16_67=sum(value > 1000/60 for value in values))


summary = json.loads((args.run / "summary.json").read_text(encoding="utf8"))
assert summary["kind"] == "stress"
start, end = (int(summary["windows"]["all"][key]) for key in ("start", "end"))
inventory = rows(route / "stress_inventory.csv")
intervals = rows(args.run / "intervals.csv")
frames = rows(route / "stress_frames.csv")
result = dict(source=str(args.run.resolve()), duration_s=(end-start)/frequency,
              limits="Raw frame statistics remain primary. Inventory brackets and two subsequent Present intervals are flagged as diagnostic proximity, not proven causal overhead. Visibility is sampled at inventory points, not a guarantee that all ten enemies are continuously visible.")
result["existing_exclusion"] = (args.run / "exclusion.txt").read_text(encoding="utf-8-sig") if (args.run / "exclusion.txt").exists() else None
brackets = []
near = set()
for snapshot in inventory:
    q0, q1 = int(snapshot["qpc_begin"]), int(snapshot["qpc_end"])
    overlap = [index for index,row in enumerate(intervals) if int(row["q0"]) < q1 and int(row["q1"]) > q0]
    after = [index for index,row in enumerate(intervals) if int(row["q0"]) >= q1][:2]
    tagged = sorted(set(overlap + after)) if start <= q0 <= end else []
    near.update(tagged)
    brackets.append(dict(label=snapshot["label"], elapsed_s=float(snapshot["elapsed"]),
                         duration_ms=(q1-q0)*1000/frequency, q0=q0, q1=q1,
                         overlapping_present_intervals=overlap, two_subsequent_present_intervals=after if tagged else [],
                         near_present_ms=[float(intervals[index]["ms"]) for index in tagged]))
result["inventory_brackets"] = brackets
result["all_raw"] = stats([float(row["ms"]) for row in intervals])
result["excluding_inventory_proximity_reference_only"] = stats([float(row["ms"]) for index,row in enumerate(intervals) if index not in near])
result["tagged_present_intervals"] = len(near)
result["first_last_15_seconds"] = {}
for label,q0,q1 in (("first",start,min(end,start+15*frequency)), ("last",max(start,end-15*frequency),end)):
    selected = [row for row in intervals if q0 <= int(row["q0"]) < int(row["q1"]) <= q1]
    engine = [row for row in frames if q0 <= int(row["qpc"]) <= q1]
    result["first_last_15_seconds"][label] = dict(q0=q0,q1=q1,present=stats([float(row["ms"]) for row in selected]),
        engine={key:stats([float(row[key]) for row in engine]) for key in ("gt_ms","rt_ms","rhi_ms","gpu_ms","gt_wait_ms","rt_wait_ms")})
keys = ["actors","components","decals","registered_decals","niagara","active_niagara","lights","used_physical_B","used_virtual_B"]
first = next(row for row in inventory if row["label"] == "start")
last = next(row for row in inventory if row["label"] == "end")
cooldown = next((row for row in inventory if row["label"] == "cooldown"), None)
result["inventory_snapshots"] = inventory
result["growth_start_to_end"] = {key:int(last[key])-int(first[key]) for key in keys}
result["growth_end_to_cooldown"] = {key:int(cooldown[key])-int(last[key]) for key in keys} if cooldown else None
result["minimum_visible_sampled"] = min(int(row["visible"]) for row in inventory)
result["maximum_inventory_pending"] = max(int(row["pso_pending"]) for row in inventory)
completion = dict(line.split("=",1) for line in (route / "stress_result.txt").read_text(encoding="utf-8-sig").splitlines() if "=" in line)
result["completion"] = completion
result["real_firing_observed"] = int(completion["shots"]) > 0 and int(completion["hit_updates"]) > 0
assert completion["success"] == "1" and result["real_firing_observed"]
(args.run / "stress_growth_audit.json").write_text(json.dumps(result,indent=2),encoding="utf8")
print(json.dumps({key:result[key] for key in ("duration_s","all_raw","first_last_15_seconds","growth_start_to_end","minimum_visible_sampled","completion")},indent=2))
