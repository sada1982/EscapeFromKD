import json
import os
from pathlib import Path
import unreal

out = Path(os.environ['KD_MODEL_EVIDENCE'])
project = Path(unreal.Paths.convert_relative_path_to_full(unreal.Paths.project_dir())).resolve()
assert project == Path(os.environ['LOCALAPPDATA']) / 'KDLightmassTrial_20261118', project
proof = json.loads((out / 'lightmass_room_proof.json').read_text(encoding='utf8'))
world = unreal.EditorLoadingAndSavingUtils.load_map(proof['map'])
assert world
settings = unreal.GameplayStatics.get_all_actors_of_class(world, unreal.WorldSettings)[0]
assert not settings.get_editor_property('force_no_precomputed_lighting')
registry = unreal.load_asset(proof['map'] + '_BuiltData')
assert registry, 'Lightmass did not save a readable MapBuildDataRegistry asset'
assert registry.get_class().get_name() == 'MapBuildDataRegistry'
mesh_rows = []
for actor in unreal.GameplayStatics.get_all_actors_of_class(world, unreal.StaticMeshActor):
    component = actor.get_component_by_class(unreal.StaticMeshComponent)
    mesh = component.get_editor_property('static_mesh')
    assert mesh.get_editor_property('light_map_coordinate_index') == 1
    assert mesh.get_editor_property('light_map_resolution') == 1024
    mesh_rows.append(dict(actor=actor.get_actor_label(), mesh=mesh.get_path_name(), lightmap_uv=1, resolution=1024))
light_rows = []
for actor in unreal.GameplayStatics.get_all_actors_of_class(world, unreal.RectLight):
    light = actor.get_component_by_class(unreal.RectLightComponent)
    assert light.get_editor_property('mobility') == unreal.ComponentMobility.STATIONARY
    light_rows.append(dict(actor=actor.get_actor_label(), mobility=str(light.get_editor_property('mobility')),
        cast_shadows=light.get_editor_property('cast_shadows'), intensity=light.get_editor_property('intensity'),
        indirect_lighting_intensity=light.get_editor_property('indirect_lighting_intensity')))
assert len(light_rows) == 12 and len(mesh_rows) == len(proof['parts'])
record = dict(project=str(project), map=proof['map'], registry=registry.get_path_name(),
    meshes=mesh_rows, lights=light_rows, stage='baked_package_readable_not_runtime_validated',
    limitation='Registry asset presence alone does not prove Level attachment, GI appearance, dynamic character shadows, or runtime mobility transition; Level attachment is checked by the runtime C++ hook.')
(out / 'lightmass_bake_verify.json').write_text(json.dumps(record, indent=2), encoding='utf8')
unreal.log('KDLightmass baked registry and map verified; runtime quality remains unverified')
