import hashlib
import json
import os
from pathlib import Path
import shutil

out = Path(__file__).resolve().parent
work = Path(os.environ['LOCALAPPDATA']) / 'KDLightmassTrial_20261118'
original = out / 'Variants/LightmassPreview'
destination = out / 'Variants/LightmassPreviewMap2'
assert original.is_dir() and not destination.exists()
shutil.copytree(original, destination)
binary = Path('Windows/myProject/Binaries/Win64/myProject-Win64-Shipping.exe')
shutil.copy2(work / 'Binaries/Win64/myProject-Win64-Shipping.exe', destination / binary)
assets = []
for source in (original / 'Windows/myProject/Content/Paks').iterdir():
    if source.is_file():
        relative = source.relative_to(original)
        before = hashlib.sha256(source.read_bytes()).hexdigest()
        after = hashlib.sha256((destination / relative).read_bytes()).hexdigest()
        assert before == after
        assets.append(dict(path=str(relative), sha256=before))
record = dict(archive=str(destination), exe=str(destination / binary),
              exe_sha256=hashlib.sha256((destination / binary).read_bytes()).hexdigest(),
              unchanged_cooked_assets=assets, purpose='Shipping-only in-memory default-map selection; original maps and warning-bearing bake preserved')
(out / 'lightmass_map2_package_proof.json').write_text(json.dumps(record, indent=2), encoding='utf8')
(out / 'LightmassLumenQuality/invalid.txt').write_text('invalid=1\nreason=Shipping ignored map URL and opened original KDStage; stopped through verified private-window WM_CLOSE; excluded from prototype comparison\n', encoding='utf8')
print(str(destination / binary))
