import hashlib
import json
from pathlib import Path

import bpy
from mathutils import Vector

out = Path(__file__).resolve().parent
project = out.parents[2]
records = []
for relative in ('Floor02/GameStairLink.blend', 'Floor02/Floor02_Plaza.blend', 'Floor01/EntranceGallery.blend'):
    source = project / 'SourceAssets/Stages' / relative
    before = hashlib.sha256(source.read_bytes()).hexdigest()
    bpy.ops.wm.open_mainfile(filepath=str(source))
    objects = []
    upward_faces = []
    for obj in bpy.data.objects:
        if obj.type != 'MESH':
            continue
        points = [obj.matrix_world @ Vector(corner) for corner in obj.bound_box]
        lo = [min(v[i] for v in points) for i in range(3)]
        hi = [max(v[i] for v in points) for i in range(3)]
        obj.data.calc_loop_triangles()
        objects.append(dict(name=obj.name, lo=lo, hi=hi, triangles=len(obj.data.loop_triangles),
                            collections=[c.name for c in obj.users_collection],
                            uv_layers=[x.name for x in obj.data.uv_layers]))
        if relative == 'Floor02/GameStairLink.blend' and not obj.name.startswith('UCX_'):
            for polygon in obj.data.polygons:
                normal = obj.matrix_world.to_3x3() @ polygon.normal
                if normal.z < 0.9 or polygon.area < 0.025:
                    continue
                vertices = [obj.matrix_world @ obj.data.vertices[i].co for i in polygon.vertices]
                upward_faces.append(dict(name=obj.name, area=polygon.area,
                    lo=[min(v[i] for v in vertices) for i in range(3)],
                    hi=[max(v[i] for v in vertices) for i in range(3)]))
    assert hashlib.sha256(source.read_bytes()).hexdigest() == before
    records.append(dict(source=relative, sha256=before, objects=objects, upward_faces=upward_faces))
(out / 'model_source_inventory.json').write_text(json.dumps(records, indent=2), encoding='utf8')
print('KD_MODEL_READ_COMPLETE', [(x['source'], len(x['objects'])) for x in records])
