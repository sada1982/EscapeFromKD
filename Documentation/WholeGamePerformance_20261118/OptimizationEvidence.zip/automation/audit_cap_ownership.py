import argparse
import csv
import json
from pathlib import Path


parser = argparse.ArgumentParser()
parser.add_argument("run",type=Path)
args = parser.parse_args()
meta = json.loads((args.run / "metadata.json").read_text(encoding="utf8"))
route = Path(meta["route"])
freq = meta["start"]["frequency"]


def pairs(path):
    return dict(line.split("=",1) for line in path.read_text(encoding="utf-8-sig").splitlines() if "=" in line)


own = pairs(route / "cap_ownership_result.txt")
cap = pairs(route / "startup_frame_cap.txt")
gate = pairs(route / "startup_result.txt")
with (route / "cap_ownership_events.csv").open(encoding="utf-8-sig",newline="") as stream:
    events = {row["event"]:row for row in csv.DictReader(stream)}
before,after = events["before_write"],events["after_write"]
assert meta["returncode"] == 0 and meta["monitor_returncode"] == 0
assert own["status"] == "gate_open_after_external_write" and own["injected"] == own["finished"] == "1"
assert float(own["original_value"]) == 0 and own["write_callbacks"] == "1"
assert (int(own["write_qpc"])-int(own["armed_qpc"]))/freq >= 2.0
assert int(before["pso_pending"]) > 0
assert float(before["value"]) == float(after["value"]) == 30
assert before["priority"] == after["priority"] == own["original_priority"]
assert before["write_callbacks"] == "0" and after["write_callbacks"] == "1"
assert cap["status"] == "external_change_preserved" and cap["external_change"] == "1" and cap["active"] == "0"
assert cap["applies"] == "1" and cap["restores"] == "0"
assert float(cap["previous_value"]) == 0 and float(cap["final_value"]) == 30
assert cap["previous_priority"] == cap["final_priority"] == own["original_priority"]
assert float(events["after_gate"]["value"]) == 30
settings_values=[line.split("=",1)[1] for line in (route / "settings.txt").read_text(encoding="utf-8-sig").splitlines() if line.startswith("t.MaxFPS=")]
assert float(settings_values[-1]) == 30
assert gate["reason"] == "settled" and gate["input_restored"] == "1" and gate["pso_min_priority"] == "0"
ordered = [int(gate[key]) for key in ("start_qpc","entrance_qpc","corridor_qpc","return_qpc","open_qpc")]
assert all(a < b for a,b in zip(ordered,ordered[1:]))
with (route / "startup.csv").open(encoding="utf-8-sig",newline="") as stream:
    for row in csv.DictReader(stream):
        if int(row["qpc"]) > ordered[-1]:
            continue
        if int(row["stable_frames"]) > 0:
            assert row["pso_pending"] == row["pso_active"] == row["async_packages"] == "0" and row["rhi_fence_ready"] == "1"
        if int(row["pso_pending"]) > 0:
            assert row["input_guard"] == "1" and row["stable_frames"] == "0"
result = dict(all_checks_passed=True,normal_exit=True,ownership=own,cap=cap,gate=gate,
              explanation="Accepted external SAME value and priority write invokes OnChanged; the cap retains external30 instead of restoring0. This exercises ownership beyond a value/priority equality guard.")
(args.run / "cap_ownership_audit.json").write_text(json.dumps(result,indent=2),encoding="utf8")
(args.run / "exclusion.txt").write_text("Diagnostic CVar-ownership validation; deliberate external30FPS limit. Excluded from60FPS performance acceptance.\n",encoding="utf8")
print("Cap ownership runtime evidence passed:",args.run.name)
