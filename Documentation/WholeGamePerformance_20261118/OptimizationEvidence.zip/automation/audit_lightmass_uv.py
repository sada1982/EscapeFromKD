import json
import math
import os
from pathlib import Path
import unreal

out = Path(os.environ['KD_MODEL_EVIDENCE'])
project = Path(unreal.Paths.convert_relative_path_to_full(unreal.Paths.project_dir())).resolve()
assert project == Path(os.environ['LOCALAPPDATA']) / 'KDLightmassTrial_20261118'
proof = json.loads((out / 'lightmass_room_proof.json').read_text(encoding='utf8'))
subsystem = unreal.get_default_object(unreal.StaticMeshEditorSubsystem)
rows = []
for part in proof['parts']:
    mesh = unreal.load_asset(part['asset'])
    settings = subsystem.get_lod_build_settings(mesh, 0)
    row = dict(asset=part['asset'], lightmap_index=mesh.get_editor_property('light_map_coordinate_index'),
               resolution=mesh.get_editor_property('light_map_resolution'),
               build={key: str(getattr(settings, next(name for name in dir(settings) if name.replace('_', '') == key))) for key in ('usefullprecisionuvs', 'generatelightmapuvs', 'srclightmapindex', 'dstlightmapindex')}, lods=[])
    for kind in (unreal.GeometryScriptLODType.SOURCE_MODEL, unreal.GeometryScriptLODType.RENDER_DATA):
        dynamic = unreal.DynamicMesh()
        options = unreal.GeometryScriptCopyMeshFromAssetOptions()
        options.apply_build_settings = False
        lod = unreal.GeometryScriptMeshReadLOD()
        lod.lod_type = kind
        _, result = unreal.GeometryScript_AssetUtils.copy_mesh_from_static_mesh(mesh, dynamic, options, lod)
        assert result == unreal.GeometryScriptOutcomePins.SUCCESS
        get_uv = getattr(dynamic, next(name for name in dir(dynamic) if name.replace('_', '') == 'gettriangleuvs'))
        low = [float('inf'), float('inf')]
        high = [-float('inf'), -float('inf')]
        outside = degenerate = 0
        area = 0.0
        for triangle in range(dynamic.get_triangle_count()):
            a, b, c, valid = get_uv(1, triangle)
            assert valid
            for uv in (a, b, c):
                assert math.isfinite(uv.x) and math.isfinite(uv.y)
                low = [min(low[0], uv.x), min(low[1], uv.y)]
                high = [max(high[0], uv.x), max(high[1], uv.y)]
                outside += not (0 <= uv.x <= 1 and 0 <= uv.y <= 1)
            size = abs((b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x)) * 0.5
            area += size
            degenerate += size <= 1e-15
        row['lods'].append(dict(type=str(kind), triangles=dynamic.get_triangle_count(), uv_sets=dynamic.get_num_uv_sets(),
                               uv1_min=low, uv1_max=high, uv1_area=area, uv1_outside_corners=outside, uv1_degenerate_triangles=degenerate))
    rows.append(row)
    unreal.log('KDLightmass UV source/render audited ' + part['name'])
(out / 'lightmass_uv_render_audit.json').write_text(json.dumps(rows, indent=2), encoding='utf8')
