import ctypes as c
from ctypes import wintypes as w
import json
from pathlib import Path
import sys
import time

u = c.WinDLL('user32', use_last_error=True)
k = c.WinDLL('kernel32', use_last_error=True)
proc = c.WINFUNCTYPE(c.c_ssize_t, w.HWND, w.UINT, w.WPARAM, w.LPARAM)
class WindowClass(c.Structure):
    _fields_ = [('style', w.UINT), ('proc', proc), ('classExtra', c.c_int), ('windowExtra', c.c_int), ('instance', w.HINSTANCE), ('icon', w.HICON), ('cursor', w.HANDLE), ('background', w.HBRUSH), ('menu', w.LPCWSTR), ('name', w.LPCWSTR)]
class Placement(c.Structure):
    _fields_ = [('length', w.UINT), ('flags', w.UINT), ('showCmd', w.UINT), ('minimum', w.POINT), ('maximum', w.POINT), ('normal', w.RECT)]
u.DefWindowProcW.argtypes = [w.HWND, w.UINT, w.WPARAM, w.LPARAM]
u.DefWindowProcW.restype = c.c_ssize_t
u.CreateWindowExW.argtypes = [w.DWORD, w.LPCWSTR, w.LPCWSTR, w.DWORD, c.c_int, c.c_int, c.c_int, c.c_int, w.HWND, w.HMENU, w.HINSTANCE, c.c_void_p]
u.CreateWindowExW.restype = w.HWND
u.GetWindowPlacement.argtypes = [w.HWND, c.POINTER(Placement)]
u.ShowWindow.argtypes = [w.HWND, c.c_int]
u.IsIconic.argtypes = [w.HWND]
u.IsZoomed.argtypes = [w.HWND]
u.GetForegroundWindow.restype = w.HWND
u.DestroyWindow.argtypes = [w.HWND]
u.GetThreadDesktop.argtypes = [w.DWORD]
u.GetThreadDesktop.restype = w.HANDLE
u.OpenInputDesktop.argtypes = [w.DWORD, w.BOOL, w.DWORD]
u.OpenInputDesktop.restype = w.HANDLE
u.GetUserObjectInformationW.argtypes = [w.HANDLE, c.c_int, c.c_void_p, w.DWORD, c.POINTER(w.DWORD)]
u.CloseDesktop.argtypes = [w.HANDLE]
k.GetModuleHandleW.argtypes = [w.LPCWSTR]
k.GetModuleHandleW.restype = w.HMODULE

def desktop_name(handle):
    text = c.create_unicode_buffer(512)
    length = w.DWORD()
    if not u.GetUserObjectInformationW(handle, 2, text, c.sizeof(text), c.byref(length)):
        raise c.WinError(c.get_last_error())
    return text.value

current = desktop_name(u.GetThreadDesktop(k.GetCurrentThreadId()))
input_handle = u.OpenInputDesktop(0, False, 1)
input_name = desktop_name(input_handle)
u.CloseDesktop(input_handle)
if current == input_name or not current.startswith('KDExhibit_'):
    raise RuntimeError('Dummy test requires the isolated private desktop launcher')

@proc
def window_proc(hwnd, message, wp, lp):
    return u.DefWindowProcW(hwnd, message, wp, lp)

instance = k.GetModuleHandleW(None)
wc = WindowClass(0, window_proc, 0, 0, instance, None, None, None, None, 'KDMinimizeDummy')
if not u.RegisterClassW(c.byref(wc)):
    raise c.WinError(c.get_last_error())

def state(hwnd):
    p = Placement(length=c.sizeof(Placement))
    if not u.GetWindowPlacement(hwnd, c.byref(p)):
        raise c.WinError(c.get_last_error())
    return dict(showCmd=p.showCmd, flags=p.flags, zoomed=bool(u.IsZoomed(hwnd)), iconic=bool(u.IsIconic(hwnd)), normal=[p.normal.left, p.normal.top, p.normal.right, p.normal.bottom], foreground=int(u.GetForegroundWindow() or 0))

results = []
for maximized in [False, True]:
    for restore in [4, 8]:
        hwnd = u.CreateWindowExW(0, wc.name, 'Private restore test', 0x00CF0000, 236, 153, 900, 600, None, None, instance, None)
        if not hwnd:
            raise c.WinError(c.get_last_error())
        try:
            u.ShowWindow(hwnd, 3 if maximized else 1)
            before = state(hwnd)
            u.ShowWindow(hwnd, 7)
            minimized = state(hwnd)
            u.ShowWindow(hwnd, restore)
            after = state(hwnd)
            results.append(dict(maximized=maximized, restore_command=restore, hwnd=int(hwnd), before=before, minimized=minimized, after=after, restored=after['zoomed']==before['zoomed'] and not after['iconic'] and after['normal']==before['normal']))
        finally:
            u.DestroyWindow(hwnd)
record = dict(private_desktop=current, input_desktop=input_name, results=results)
Path(sys.argv[1]).write_text(json.dumps(record, indent=2), encoding='utf8')
