import json
import os
from pathlib import Path
import unreal

out = Path(os.environ['KD_MODEL_EVIDENCE'])
project = Path(unreal.Paths.convert_relative_path_to_full(unreal.Paths.project_dir())).resolve()
assert project == Path(os.environ['LOCALAPPDATA']) / 'KDModelGalleryParts_20261118', project
world = unreal.EditorLoadingAndSavingUtils.load_map('/Game/Main/Stage/KDStage')
assert world
bp = unreal.load_asset('/Game/Main/Stage/BP_Floor03')
sub = unreal.get_engine_subsystem(unreal.SubobjectDataSubsystem)
sub_lib = unreal.SubobjectDataBlueprintFunctionLibrary

def templates():
    result = {}
    for handle in sub.k2_gather_subobject_data_for_blueprint(bp):
        data = sub_lib.get_data(handle)
        result[str(sub_lib.get_variable_name(data))] = sub_lib.get_object_for_blueprint(data, bp)
    return result

def instances():
    actor = next(actor for actor in unreal.GameplayStatics.get_all_actors_of_class(world, unreal.Actor) if actor.get_actor_label() == 'BP_Floor03')
    return {component.get_name(): component for component in actor.get_components_by_class(unreal.StaticMeshComponent)}

def paths(component):
    return [component.get_material(i).get_path_name() if component.get_material(i) else None for i in range(component.get_num_materials())]

original = instances()['Corridors']
assert original.get_editor_property('static_mesh').get_path_name() == '/Game/Main/Stage/Floor02/SM_F02_SharedGallery.SM_F02_SharedGallery'
materials = [original.get_material(i) for i in range(original.get_num_materials())]
expected = paths(original)
assert len(expected) == 13
assert expected[12] == '/Game/Main/Stage/Floor03/M_GalleryCeilingWhite.M_GalleryCeilingWhite', expected
before = {name: paths(component) for name, component in instances().items() if name.startswith('Gallery_')}
assert len(before) == 21
for name, component in templates().items():
    if name.startswith('Gallery_'):
        for index, material in enumerate(materials):
            component.set_material(index, material)
unreal.BlueprintEditorLibrary.compile_blueprint(bp)
template_records = {name: paths(component) for name, component in templates().items() if name.startswith('Gallery_')}
assert len(template_records) == 21 and all(value == expected for value in template_records.values())
assert unreal.EditorLoadingAndSavingUtils.save_packages([bp.get_outermost()], False)
for name, component in instances().items():
    if name.startswith('Gallery_'):
        for index, material in enumerate(materials):
            component.set_material(index, material)
        assert paths(component) == expected
assert unreal.EditorLoadingAndSavingUtils.save_map(world, '/Game/Main/Stage/KDStage')
world = unreal.EditorLoadingAndSavingUtils.load_map('/Game/Main/Stage/KDStage')
assert world
placed = instances()
assert paths(placed['Corridors']) == expected
instance_records = {name: paths(component) for name, component in placed.items() if name.startswith('Gallery_')}
assert len(instance_records) == 21 and all(value == expected for value in instance_records.values())
assert all(component.get_collision_enabled() == unreal.CollisionEnabled.NO_COLLISION for name, component in placed.items() if name.startswith('Gallery_'))
record = dict(project=str(project), expected_materials=expected, before=before,
              templates=template_records, saved_map_instances=instance_records, checked_slots_per_component=13,
              checked_templates=21, checked_instances=21, all_match=True)
(out / 'gallery_material_fix_proof.json').write_text(json.dumps(record, indent=2), encoding='utf8')
os.environ['KD_CENTRAL_RUN'] = str(out)
os.environ['KD_CENTRAL_VARIANT'] = 'gallery_parts_materialfix'
check = out.parent / 'CentralHitch_20261117/verify_world.py'
exec(compile(check.read_text(encoding='utf8'), str(check), 'exec'), {'__name__': '__main__'})
unreal.log('KDGallery effective materials verified on 21 templates and 21 saved level instances, 13 slots each')
