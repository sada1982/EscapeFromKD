import argparse
import ctypes as c
from ctypes import wintypes as w
from datetime import datetime
import json
from pathlib import Path

def require(condition, message):
    if not condition:
        raise RuntimeError(message)

def main():
    parser = argparse.ArgumentParser(description="Validate one isolated game window; optionally post WM_CLOSE without changing focus.")
    parser.add_argument("route", type=Path)
    parser.add_argument("--expected-pid", type=int, required=True)
    parser.add_argument("--expected-exe", type=Path, required=True)
    parser.add_argument("--send", action="store_true")
    parser.add_argument("--wait-seconds", type=float, default=20)
    args = parser.parse_args()
    require(0 <= args.wait_seconds <= 60, "wait must be 0..60 seconds")
    route = args.route.resolve(strict=True)
    expected = args.expected_exe.resolve(strict=True)
    variants = Path(__file__).resolve().parent / "Variants"
    require(expected.is_relative_to(variants), "target must be this task's isolated variant executable")
    require(expected.name == "myProject-Win64-Shipping.exe", "unexpected executable name")
    state = json.loads((route / "isolation.json").read_text(encoding="utf8"))
    require(state["pid"] == args.expected_pid and "exit_code" not in state, "PID mismatch or recorded process already exited")
    require(Path(state["args"][0]).resolve() == expected, "isolation executable mismatch")
    require("-KDExhibitRoute" in state["args"], "not the diagnostic game")
    require("-KDExhibitRouteDir=" + str(route) in state["args"], "route argument mismatch")
    require(state["desktop"].startswith("KDExhibit_") and state["desktop"] != state["input_desktop_start"], "not a private test desktop")

    kernel = c.WinDLL("kernel32", use_last_error=True)
    user = c.WinDLL("user32", use_last_error=True)
    kernel.OpenProcess.argtypes = [w.DWORD, w.BOOL, w.DWORD]; kernel.OpenProcess.restype = w.HANDLE
    kernel.QueryFullProcessImageNameW.argtypes = [w.HANDLE, w.DWORD, w.LPWSTR, c.POINTER(w.DWORD)]
    kernel.GetProcessTimes.argtypes = [w.HANDLE, c.POINTER(w.FILETIME), c.POINTER(w.FILETIME), c.POINTER(w.FILETIME), c.POINTER(w.FILETIME)]
    kernel.WaitForSingleObject.argtypes = [w.HANDLE, w.DWORD]; kernel.WaitForSingleObject.restype = w.DWORD
    kernel.GetExitCodeProcess.argtypes = [w.HANDLE, c.POINTER(w.DWORD)]
    kernel.CloseHandle.argtypes = [w.HANDLE]
    kernel.QueryPerformanceCounter.argtypes = [c.POINTER(c.c_longlong)]
    kernel.QueryPerformanceFrequency.argtypes = [c.POINTER(c.c_longlong)]
    user.OpenDesktopW.argtypes = [w.LPCWSTR, w.DWORD, w.BOOL, w.DWORD]; user.OpenDesktopW.restype = w.HANDLE
    user.OpenInputDesktop.argtypes = [w.DWORD, w.BOOL, w.DWORD]; user.OpenInputDesktop.restype = w.HANDLE
    user.GetUserObjectInformationW.argtypes = [w.HANDLE, c.c_int, c.c_void_p, w.DWORD, c.POINTER(w.DWORD)]
    user.CloseDesktop.argtypes = [w.HANDLE]
    user.GetWindowThreadProcessId.argtypes = [w.HWND, c.POINTER(w.DWORD)]
    user.GetClassNameW.argtypes = [w.HWND, w.LPWSTR, c.c_int]
    user.GetClientRect.argtypes = [w.HWND, c.POINTER(w.RECT)]
    user.IsWindowVisible.argtypes = [w.HWND]
    user.IsWindow.argtypes = [w.HWND]
    user.GetForegroundWindow.restype = w.HWND
    user.PostMessageW.argtypes = [w.HWND, w.UINT, w.WPARAM, w.LPARAM]; user.PostMessageW.restype = w.BOOL
    callback_type = c.WINFUNCTYPE(w.BOOL, w.HWND, w.LPARAM)
    user.EnumDesktopWindows.argtypes = [w.HANDLE, callback_type, w.LPARAM]

    def qpc():
        value = c.c_longlong()
        require(kernel.QueryPerformanceCounter(c.byref(value)), "QPC unavailable")
        return value.value

    frequency = c.c_longlong()
    require(kernel.QueryPerformanceFrequency(c.byref(frequency)), "QPC frequency unavailable")

    def desktop_name(handle):
        text = c.create_unicode_buffer(512); needed = w.DWORD()
        require(user.GetUserObjectInformationW(handle, 2, text, c.sizeof(text), c.byref(needed)), "desktop name unavailable")
        return text.value

    process = kernel.OpenProcess(0x1000 | 0x100000, False, args.expected_pid)
    require(process, "cannot query game process")
    desktop = None
    try:
        require(kernel.WaitForSingleObject(process, 0) == 258, "process is not running")
        image = c.create_unicode_buffer(32768); count = w.DWORD(len(image))
        require(kernel.QueryFullProcessImageNameW(process, 0, image, c.byref(count)), "image query failed")
        require(Path(image.value).resolve() == expected, "live process image mismatch")
        created, exited, kernel_time, user_time = w.FILETIME(), w.FILETIME(), w.FILETIME(), w.FILETIME()
        require(kernel.GetProcessTimes(process, c.byref(created), c.byref(exited), c.byref(kernel_time), c.byref(user_time)), "process creation time unavailable")
        creation_unix = ((created.dwHighDateTime << 32) | created.dwLowDateTime) / 10000000 - 11644473600
        launch_unix = datetime.fromisoformat(state["utc_start"]).timestamp()
        require(-1 <= creation_unix - launch_unix <= 10, "PID may have been recycled: creation time mismatch")
        desktop = user.OpenDesktopW(state["desktop"], 0, False, 0x0001 | 0x0040)
        require(desktop and desktop_name(desktop) == state["desktop"], "private desktop unavailable")
        current = user.OpenInputDesktop(0, False, 0x0001)
        require(current, "input desktop unavailable")
        try:
            input_name = desktop_name(current)
        finally:
            user.CloseDesktop(current)
        require(input_name != state["desktop"], "test desktop is the input desktop")
        windows = []

        @callback_type
        def collect(hwnd, ignored):
            pid = w.DWORD(); user.GetWindowThreadProcessId(hwnd, c.byref(pid))
            if pid.value == args.expected_pid and user.IsWindowVisible(hwnd):
                name = c.create_unicode_buffer(256); user.GetClassNameW(hwnd, name, len(name))
                rect = w.RECT(); user.GetClientRect(hwnd, c.byref(rect))
                if name.value == "UnrealWindow" and rect.right >= 640 and rect.bottom >= 360:
                    windows.append(dict(hwnd=int(hwnd), window_class=name.value, width=rect.right, height=rect.bottom))
            return True

        require(user.EnumDesktopWindows(desktop, collect, 0), "window enumeration failed")
        require(len(windows) == 1, "expected exactly one game window; found " + str(windows))
        report = dict(mode="send" if args.send else "verify_only", pid=args.expected_pid, image=image.value,
                      process_creation_unix=creation_unix, isolation_launch_unix=launch_unix, desktop=state["desktop"],
                      input_desktop=input_name, window=windows[0], foreground_before=int(user.GetForegroundWindow() or 0),
                      qpc_before=qpc(), qpc_frequency=frequency.value, sent=False)
        if args.send:
            hwnd = windows[0]["hwnd"]
            pid = w.DWORD(); user.GetWindowThreadProcessId(hwnd, c.byref(pid))
            require(user.IsWindow(hwnd) and pid.value == args.expected_pid, "window ownership changed")
            require(kernel.WaitForSingleObject(process, 0) == 258, "process exited before close")
            require(user.PostMessageW(hwnd, 0x0010, 0, 0), "WM_CLOSE post failed")
            report["sent"] = True
            (route / "close_request.json").write_text(json.dumps(report, indent=2), encoding="utf8")
            result = kernel.WaitForSingleObject(process, int(args.wait_seconds * 1000))
            report["wait_result"] = result
            if result == 0:
                code = w.DWORD()
                require(kernel.GetExitCodeProcess(process, c.byref(code)), "exit code query failed")
                report["exit_code"] = code.value
            elif result == 258:
                report["still_running"] = True
            else:
                report["wait_error"] = c.get_last_error()
        report["qpc_after"] = qpc()
        report["foreground_after"] = int(user.GetForegroundWindow() or 0)
        (route / "close_request.json").write_text(json.dumps(report, indent=2), encoding="utf8")
        print(json.dumps(report, indent=2))
    finally:
        if desktop:
            user.CloseDesktop(desktop)
        kernel.CloseHandle(process)

if __name__ == "__main__":
    main()
