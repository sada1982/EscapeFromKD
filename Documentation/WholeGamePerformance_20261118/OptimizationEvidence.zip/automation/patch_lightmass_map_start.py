import hashlib
import json
import os
from pathlib import Path

out = Path(__file__).resolve().parent
work = Path(os.environ['LOCALAPPDATA']) / 'KDLightmassTrial_20261118'
source = work / 'Source/myProject'
records = []
def patch(name, replacements):
    path = source / name
    before = path.read_bytes()
    text = before.decode('utf8')
    newline = '\r\n' if '\r\n' in text else '\n'
    text = text.replace('\r\n', '\n')
    for old, new in replacements:
        assert text.count(old) == 1, (name, old)
        text = text.replace(old, new, 1)
    after = text.replace('\n', newline).encode('utf8')
    backup = work / 'Saved/LightmassProbe/BeforeMapOverride' / name
    backup.parent.mkdir(parents=True, exist_ok=True)
    assert not backup.exists()
    backup.write_bytes(before)
    path.write_bytes(after)
    records.append(dict(path=str(path), before=hashlib.sha256(before).hexdigest(), after=hashlib.sha256(after).hexdigest()))

patch('myProject.Build.cs', [('"RenderCore", "RHI"', '"RenderCore", "RHI", "EngineSettings"')])
patch('myProject.cpp', [
    ('#include "Engine/World.h"', '#include "Engine/World.h"\n#include "GameMapsSettings.h"'),
    ('        if (IsRunningDedicatedServer() || IsRunningCommandlet()) return;',
     '        if (IsRunningDedicatedServer() || IsRunningCommandlet()) return;\n'
     '        if (FParse::Param(Cmd,TEXT("KDLightmassPrototype")))\n'
     '            UGameMapsSettings::SetGameDefaultMap(FParse::Param(Cmd,TEXT("KDBakedGITrial"))?\n'
     '                TEXT("/Game/Diagnostics/LightmassTrial/KDStage_BakeTrial"):TEXT("/Game/Diagnostics/LightmassTrial/KDStage_LumenTrial"));'),
    ('            if ((!World->GetOutermost()->GetName().EndsWith(TEXT("/KDStage")) && !IsIsolatedLightmassMap(World)) || Char->GetClass()->GetName()!=TEXT("You_C"))',
     '            if ((FParse::Param(FCommandLine::Get(),TEXT("KDLightmassPrototype")) && !IsIsolatedLightmassMap(World)) ||\n'
     '                (!World->GetOutermost()->GetName().EndsWith(TEXT("/KDStage")) && !IsIsolatedLightmassMap(World)) || Char->GetClass()->GetName()!=TEXT("You_C"))')])
(out / 'lightmass_map_override_patch.json').write_text(json.dumps(records, indent=2), encoding='utf8')
