import argparse
import csv
import ctypes as c
from ctypes import wintypes as w
import json
from pathlib import Path
import time

from editor_window_state import foreground, process_identity, window_state

parser = argparse.ArgumentParser()
parser.add_argument('metadata', type=Path)
parser.add_argument('output', type=Path)
parser.add_argument('--state', type=Path, required=True)
parser.add_argument('--seconds', type=float, default=300)
args = parser.parse_args()
state = json.loads(args.state.read_text(encoding='utf8'))
identity, original = state['identity'], state['original']
if process_identity(identity['pid'])!=identity:
    raise RuntimeError('Editor process identity changed')
args.output.mkdir(parents=True, exist_ok=False)
k = c.WinDLL('kernel32', use_last_error=True)
k.QueryPerformanceCounter.argtypes = [c.POINTER(c.c_longlong)]
k.QueryPerformanceFrequency.argtypes = [c.POINTER(c.c_longlong)]
frequency = c.c_longlong()
k.QueryPerformanceFrequency(c.byref(frequency))
def qpc():
    value = c.c_longlong()
    k.QueryPerformanceCounter(c.byref(value))
    return value.value

records, violations, metadata_seen = 0, 0, False
started = time.monotonic()
first_qpc = qpc()
reason = 'deadline'
fields = ['qpc','read_end_qpc','utc_epoch_ns','editor_pid','hwnd','iconic','zoomed','showCmd','flags','visible','rect_left','rect_top','rect_right','rect_bottom','foreground_hwnd','foreground_pid','metadata_seen','game_pid']
with (args.output/'window_state.csv').open('w', newline='', encoding='utf8') as stream:
    writer = csv.DictWriter(stream, fieldnames=fields)
    writer.writeheader()
    while time.monotonic()-started<args.seconds:
        iteration = time.monotonic()
        now = qpc()
        window = window_state(original['hwnd'])
        fg = foreground()
        if window['pid']!=identity['pid']:
            raise RuntimeError('Editor HWND ownership changed')
        metadata = {}
        try:
            metadata = json.loads(args.metadata.read_text(encoding='utf8'))
            if int(metadata['start']['qpc'])<first_qpc:
                raise RuntimeError('Metadata predates watcher; refusing stale run')
            metadata_seen = True
        except (FileNotFoundError, json.JSONDecodeError):
            pass
        rect = window['normal_rect']
        writer.writerow(dict(qpc=now,read_end_qpc=qpc(),utc_epoch_ns=time.time_ns(),editor_pid=window['pid'],hwnd=window['hwnd'],iconic=int(window['iconic']),zoomed=int(window['zoomed']),showCmd=window['showCmd'],flags=window['flags'],visible=int(window['visible']),rect_left=rect[0],rect_top=rect[1],rect_right=rect[2],rect_bottom=rect[3],foreground_hwnd=fg['hwnd'],foreground_pid=fg['pid'],metadata_seen=int(metadata_seen),game_pid=metadata.get('game_pid','')))
        stream.flush()
        records += 1
        if not window['iconic'] or window['normal_rect']!=original['normal_rect']:
            violations += 1
        if records==1:
            (args.output/'ready.json').write_text(json.dumps(dict(frequency=frequency.value,first_qpc=first_qpc,initial_window=window,initial_foreground=fg,metadata=str(args.metadata.resolve()),state=str(args.state.resolve())),indent=2),encoding='utf8')
            print('Window watcher ready, iconic='+str(window['iconic']),flush=True)
        if 'end' in metadata and 'returncode' in metadata:
            reason = 'metadata_complete'
            break
        if metadata.get('route') and (Path(metadata['route'])/'done.flag').exists():
            reason = 'route_done_flag'
            break
        if (args.output/'done.flag').exists():
            reason = 'explicit_done_flag'
            break
        time.sleep(max(0,.25-(time.monotonic()-iteration)))
result = dict(frequency=frequency.value,first_qpc=first_qpc,last_qpc=qpc(),samples=records,non_minimized_or_placement_changed_samples=violations,metadata_seen=metadata_seen,stop_reason=reason,limitation='Read-only250ms samples; a state transition shorter than the polling period can be missed. No activation or control operation is performed.')
(args.output/'summary.json').write_text(json.dumps(result,indent=2),encoding='utf8')
print(json.dumps(result),flush=True)
