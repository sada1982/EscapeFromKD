import argparse
import csv
import json
from pathlib import Path
import statistics

parser = argparse.ArgumentParser()
parser.add_argument('name')
parser.add_argument('candidate')
parser.add_argument('--scenes', default='ClassroomStart,ClassroomExit,Atrium3FDown')
parser.add_argument('--baseline', default='LightPerfBaseA')
args = parser.parse_args()
expected_scenes = set(args.scenes.split(','))
base = Path(__file__).resolve().parent
run = base/args.name
meta = json.loads((run/'metadata.json').read_text(encoding='utf8'))
summary = json.loads((run/'summary.json').read_text(encoding='utf8'))
route = Path(meta['route'])
def read(path):
    return list(csv.DictReader(path.open(encoding='utf-8-sig',newline='')))
def kv(path):
    return dict(line.split('=',1) for line in path.read_text(encoding='utf8').splitlines() if '=' in line)
light = kv(route/'light_candidate.txt')
result = kv(route/'survey_result.txt')
settings = kv(route/'settings.txt')
survey = kv(route/'survey_meta.txt')
isolation = json.loads((route/'isolation.json').read_text(encoding='utf8'))
assert meta['returncode']==0 and meta['monitor_returncode']==0
assert result['success']=='1' and result['invalid_scenes']=='0'
assert result['rounds']=='2' and result['scenes']==str(len(expected_scenes)) and survey['sample_frames']=='600'
assert not summary['invalid'] and len(summary['per_round'])==2*len(expected_scenes)
assert set(summary['per_scene'])==expected_scenes
assert light['candidate']==args.candidate and light['success']=='1'
assert light['lights']=='61' and light['mega']=='42' and light['legacy']=='19' and light['shadowed']=='42'
assert light['applied']==('0' if args.candidate=='Baseline' else '1')
assert isolation['desktop']!=isolation['input_desktop_start'] and isolation['input_desktop_start']==isolation['input_desktop_end']
fixed = {k:v for k,v in settings.items() if k.startswith(('r.','sg.','t.')) or k in ['map','pawn','viewport','max_walk_speed']}
if args.name!=args.baseline:
    baseline = json.loads((base/args.baseline/'audit.json').read_text(encoding='utf8'))
    assert fixed==baseline['settings'], 'Render settings differ from baseline'
windows = [(int(s['q0']),int(s['q1'])) for s in summary['per_round']]
def inside(value):
    q=int(value)
    return any(a<=q<=b for a,b in windows)
gpu = [r for r in read(run/'monitor_nvidia.csv') if inside(r['qpc_delivery'])]
process = [r for r in read(run/'monitor_process.csv') if inside(r['qpc'])]
def numeric(rows,key):
    values=[]
    for row in rows:
        try: values.append(float(row[key]))
        except (ValueError,KeyError): pass
    return dict(n=len(values),minimum=min(values),mean=statistics.mean(values),maximum=max(values)) if values else None
gpu_keys=['temperature.gpu','clocks.current.graphics [MHz]','clocks.current.memory [MHz]','memory.used [MiB]','utilization.gpu [%]','power.draw [W]']
proc_keys=['cpu_percent_one_core','local_budget_B','local_usage_B','nonlocal_usage_B','evicted_process_B','working_set_B']
gpu_stats={key:numeric(gpu,key) for key in gpu_keys}
flags={key:sorted(set(row[key] for row in gpu)) for key in ['pstate','clocks_event_reasons.sw_power_cap','clocks_event_reasons.sw_thermal_slowdown','clocks_event_reasons.hw_thermal_slowdown']}
process_stats={role:{key:numeric([r for r in process if r['role']==role],key) for key in proc_keys} for role in ['game','editor']}
output=dict(name=args.name,exe=meta['exe'],candidate=args.candidate,valid=True,returncode=meta['returncode'],monitor_returncode=meta['monitor_returncode'],light=light,settings=fixed,survey_result=result,private_desktop=isolation['desktop'],input_desktop=isolation['input_desktop_start'],gpu=gpu_stats,gpu_flags=flags,process=process_stats,per_scene=summary['per_scene'],per_round=[{'scene':r['scene'],'round':r['round'],'present':r['present'],'counters':r['counters']} for r in summary['per_round']],note='NVIDIA samples are coarse delivery-time samples restricted to measurement windows. Queue/process memory readings are per process; GPU total includes Editor and desktop. This candidate has one2-round run only; bracketed baseline runs bound time drift.')
(run/'audit.json').write_text(json.dumps(output,indent=2),encoding='utf8')
print(json.dumps(dict(name=args.name,valid=True,gpu=gpu_stats,gpu_flags=flags,game=process_stats['game']),ensure_ascii=False))
