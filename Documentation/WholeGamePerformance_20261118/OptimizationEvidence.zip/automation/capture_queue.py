import argparse
import json
from pathlib import Path
import subprocess
import time


parser = argparse.ArgumentParser()
parser.add_argument("metadata", type=Path)
parser.add_argument("output", type=Path)
parser.add_argument("--scheduler", action="store_true")
parser.add_argument("--wait-seconds", type=float, default=300)
args = parser.parse_args()
root = Path(__file__).resolve().parent.parent
out = args.output.resolve()
out.mkdir(parents=True, exist_ok=False)
deadline = time.monotonic() + args.wait_seconds
identity = None
while time.monotonic() < deadline:
    try:
        metadata = json.loads(args.metadata.read_text(encoding="utf8"))
        identity = json.loads((Path(metadata["route"]) / "isolation.json").read_text(encoding="utf8"))
        if identity["desktop"] == identity["input_desktop_start"]:
            raise RuntimeError("Game is not on an isolated desktop")
        break
    except (FileNotFoundError, json.JSONDecodeError):
        time.sleep(.1)
if identity is None:
    raise TimeoutError("No game isolation identity before deadline")
pid = str(identity["pid"])
commands = [("queue", [str(root / "StairWarmTrace_20261117/gpuqueue.exe"), "capture", pid, str(out)])]
if args.scheduler:
    commands.append(("scheduler", [str(root / "GalleryThreadTrace_20261117/sched_cap.exe"), pid, str(out / "scheduler")]))
running = []
for name, command in commands:
    with (out / (name + ".stdout")).open("wb") as stdout, (out / (name + ".stderr")).open("wb") as stderr:
        process = subprocess.Popen(command, stdout=stdout, stderr=stderr, creationflags=subprocess.CREATE_NO_WINDOW)
    running.append((name, process))
(out / "capture_identity.json").write_text(json.dumps(dict(game_pid=int(pid), metadata=str(args.metadata.resolve()), commands=commands), indent=2), encoding="utf8")
print("Capture started", pid, flush=True)
status = {name: process.wait() for name, process in running}
(out / "capture_results.json").write_text(json.dumps(status, indent=2), encoding="utf8")
print(status, flush=True)
raise SystemExit(0 if status["queue"] == 0 else 1)
