import argparse
import csv
import json
from pathlib import Path


parser = argparse.ArgumentParser()
parser.add_argument("run", type=Path)
parser.add_argument("--initial-fps", type=int, choices=[0,20], required=True)
args = parser.parse_args()
meta = json.loads((args.run / "metadata.json").read_text(encoding="utf8"))
route = Path(meta["route"])
frequency = meta["start"]["frequency"]


def pairs(path):
    return dict(line.split("=",1) for line in path.read_text(encoding="utf-8-sig").splitlines() if "=" in line)


gate = pairs(route / "startup_result.txt")
cap = pairs(route / "startup_frame_cap.txt")
assert meta["returncode"] == 0 and meta["monitor_returncode"] == 0
assert gate["reason"] == "settled" and gate["input_restored"] == "1" and gate["pso_min_priority"] == "0"
ordered = [int(gate[key]) for key in ("start_qpc","entrance_qpc","corridor_qpc","return_qpc","open_qpc")]
assert all(a < b for a,b in zip(ordered,ordered[1:]))
assert int(gate["exit_cull_completed_qpc"]) > 0
assert gate["pawn_start"] == gate["pawn_released"] and gate["control_start"] == gate["control_released"]
assert gate["room_view_start"] == gate["room_view_return"] and gate["room_fov_start"] == gate["room_fov_return"]
assert cap["requested_fps"] == "30" and cap["active"] == "0" and cap["external_change"] == "0"
assert float(cap["final_value"]) == args.initial_fps
assert int(cap["final_priority"]) == 0x05000000
if args.initial_fps == 20:
    assert cap["status"] == "existing_cap_already_lower" and cap["applies"] == cap["restores"] == "0"
else:
    assert cap["status"] == "restored" and int(cap["applies"]) > 0 and cap["applies"] == cap["restores"]
    assert float(cap["previous_value"]) == 0 and cap["previous_priority"] == cap["final_priority"]
settings = (route / "settings.txt").read_text(encoding="utf-8-sig")
sections = {}
for line in settings.splitlines():
    if line.startswith("[") and line.endswith("]"):
        section = line[1:-1]
        sections[section] = {}
    elif "=" in line:
        key,value = line.split("=",1)
        sections[section][key] = value
assert float(sections["final"]["t.MaxFPS"]) == args.initial_fps
if args.initial_fps == 20:
    assert float(sections["ready"]["t.MaxFPS"]) == 20
with (route / "startup.csv").open(encoding="utf-8-sig",newline="") as stream:
    rows = [row for row in csv.DictReader(stream) if int(row["qpc"]) <= ordered[-1]]
last_draws = 0
phase = None
ready_since = None
slow_ready = []
pending = []
for row in rows:
    now = int(row["qpc"])
    if row["view_phase"] != phase:
        phase = row["view_phase"]
        ready_since = None
    ready = row["rhi_fence_ready"] == "1" and int(row["viewport_draws"]) > last_draws and int(row["pso_pending"]) == 0 and int(row["async_packages"]) == 0
    ready_since = (now if ready_since is None else ready_since) if ready else None
    last_draws = int(row["viewport_draws"])
    if int(row["stable_frames"]) > 0:
        assert ready and int(row["pso_active"]) == 0
        if float(row["wall_ms"]) > 33.341:
            assert (now-ready_since)/frequency >= 1.0
            slow_ready.append(dict(qpc=now,phase=phase,wall_ms=float(row["wall_ms"]),continuous_ready_s=(now-ready_since)/frequency))
    if int(row["pso_pending"]) > 0 or int(row["async_packages"]) > 0:
        assert row["stable_frames"] == "0" and row["input_guard"] == "1"
        pending.append(now)
if args.initial_fps == 20:
    assert slow_ready and {row["phase"] for row in slow_ready} == {"room","entrance","corridor","returned_room"}
assert pending and (max(pending)-min(pending))/frequency > 1.0
pending_proof = pairs(route / "survey_result.txt")
assert pending_proof["success"] == "1" and pending_proof["rounds"] == "1" and pending_proof["scenes"] == "1"
result = dict(initial_fps=args.initial_fps,purpose="functional loading liveness only; excluded from 60FPS acceptance",
              startup_seconds=(ordered[-1]-ordered[0])/frequency,gate=gate,cap=cap,
              slow_ready_frames=slow_ready,pending_samples=len(pending),pending_span_s=(max(pending)-min(pending))/frequency,
              normal_exit=True,all_checks_passed=True)
(args.run / "lowfps_gate_audit.json").write_text(json.dumps(result,indent=2),encoding="utf8")
print(json.dumps({key:result[key] for key in ("initial_fps","purpose","startup_seconds","pending_samples","pending_span_s","normal_exit","all_checks_passed")},indent=2))
