import json
import os
from pathlib import Path
import unreal

out = Path(os.environ['KD_MODEL_EVIDENCE'])
project = Path(unreal.Paths.convert_relative_path_to_full(unreal.Paths.project_dir())).resolve()
assert project == Path(os.environ['LOCALAPPDATA']) / 'KDLightmassTrial_20261118'
proof = json.loads((out / 'lightmass_room_proof.json').read_text(encoding='utf8'))
usage = getattr(unreal.MaterialUsage, next(name for name in dir(unreal.MaterialUsage) if name.replace('_', '').lower() == 'matusagestaticlighting'))
rows = []
for path in sorted({path for part in proof['parts'] for path in part['materials'] if path}):
    material = unreal.load_asset(path)
    assert material
    parent = material.get_editor_property('parent') if isinstance(material, unreal.MaterialInstanceConstant) else None
    rows.append(dict(asset=path, kind=material.get_class().get_name(), parent=parent.get_path_name() if parent else None,
                     static_lighting=unreal.MaterialEditingLibrary.has_material_usage(material, usage)))
(out / 'lightmass_material_usage.json').write_text(json.dumps(rows, indent=2), encoding='utf8')
