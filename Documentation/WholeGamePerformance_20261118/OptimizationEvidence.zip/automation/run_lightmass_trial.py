import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

parser = argparse.ArgumentParser()
parser.add_argument('step', choices=('assets', 'validate_assets', 'audit_uv', 'audit_materials', 'fix_materials', 'bake', 'verify'))
parser.add_argument('--quality', choices=('Preview', 'Medium', 'High', 'Production'), default='Preview')
args = parser.parse_args()
out = Path(__file__).resolve().parent
work = Path(os.environ['LOCALAPPDATA']) / 'KDLightmassTrial_20261118'
project_proof = json.loads((out / 'lightmass_trial_project.json').read_text(encoding='utf8'))
assert Path(project_proof['project']) == work and work.is_dir()
assert project_proof['backend'] == 'cpu', 'This runner uses CPU Lightmass; GPU requires a ticking isolated editor.'
engine = Path('C:/Program Files/Epic Games/UE_5.8/Engine')
assert (engine / 'Binaries/Win64/UnrealLightmass.exe').is_file()
assert (engine / 'Binaries/DotNET/SwarmAgent.exe').is_file()
map_path = '/Game/Diagnostics/LightmassTrial/KDStage_BakeTrial'
command = [str(engine / 'Binaries/Win64/UnrealEditor-Cmd.exe'), str(work / 'myProject.uproject')]
if args.step == 'bake':
    proof = json.loads((out / 'lightmass_room_proof.json').read_text(encoding='utf8'))
    assert proof['map'] == map_path and proof['lights'] == 12
    command += ['-run=ResavePackages', '-buildlighting', '-AllowCommandletRendering',
                '-Map=' + map_path, '-Quality=' + args.quality, '-MapsOnly', '-ProjectOnly', '-IgnoreChangelist']
else:
    script = {'assets': 'make_lightmass_room.py', 'validate_assets': 'validate_lightmass_assets.py', 'audit_uv': 'audit_lightmass_uv.py', 'audit_materials': 'audit_lightmass_materials.py', 'fix_materials': 'fix_lightmass_materials.py', 'verify': 'verify_lightmass_bake.py'}[args.step]
    command += ['-run=pythonscript', '-script=' + str(out / script), '-nullrhi',
                '-EnablePlugins=GeometryScripting,PythonScriptPlugin']
log_path = out / ('lightmass_' + args.step + '_' + args.quality + '.log')
command += ['-unattended', '-NoSplash', '-NoSound', '-DisablePlugins=ModelContextProtocol', '-abslog=' + str(log_path)]
record = dict(step=args.step, quality=args.quality, command=command, log=str(log_path),
              status='running', project=str(work), baseline_project_unchanged=None)
record_path = out / ('lightmass_' + args.step + '_result.json')
record_path.write_text(json.dumps(record, indent=2), encoding='utf8')
if args.step == 'bake':
    swarm = subprocess.run(['powershell', '-NoProfile', '-NonInteractive', '-Command',
        '(Get-Process -Name SwarmAgent -ErrorAction SilentlyContinue).Id'],
        capture_output=True, text=True, creationflags=subprocess.CREATE_NO_WINDOW)
    assert not swarm.stdout.strip(), 'Existing SwarmAgent must be identified before a private-desktop bake; no external process is stopped.'
isolation_dir = out / ('LightmassPrivate_' + args.step + '_' + datetime.datetime.now().strftime('%Y%m%d_%H%M%S'))
launcher = out.parent / 'Exhibit42_20261116/private_launch.py'
launch = [sys.executable, '-B', str(launcher), command[0], str(isolation_dir), *command[1:]]
result = subprocess.run(launch, env=dict(os.environ, KD_MODEL_EVIDENCE=str(out)),
    creationflags=subprocess.CREATE_NO_WINDOW | subprocess.BELOW_NORMAL_PRIORITY_CLASS,
    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
isolation = json.loads((isolation_dir / 'isolation.json').read_text(encoding='utf8'))
assert isolation['desktop'] != isolation['input_desktop_start']
assert isolation['desktop'] != isolation['input_desktop_end']
record['private_desktop'] = isolation
source = Path(project_proof['source'])
for entry in project_proof['original_files']:
    assert hashlib.sha256((source / entry['path']).read_bytes()).hexdigest() == entry['sha256'], entry['path']
record['baseline_project_unchanged'] = True
record['exit_code'] = result.returncode
record['status'] = 'commandlet_finished'
if log_path.is_file():
    log = log_path.read_text(encoding='utf8', errors='replace')
    record['failed_build_marker'] = '[REPORT] Failed building lighting' in log
    record['log_sha256'] = hashlib.sha256(log_path.read_bytes()).hexdigest()
if args.step == 'bake':
    built_data = work / 'Content/Diagnostics/LightmassTrial/KDStage_BakeTrial_BuiltData.uasset'
    record['built_data_exists'] = built_data.is_file()
    record['built_data_bytes'] = built_data.stat().st_size if built_data.is_file() else 0
    record['built_data_sha256'] = hashlib.sha256(built_data.read_bytes()).hexdigest() if built_data.is_file() else None
record_path.write_text(json.dumps(record, indent=2), encoding='utf8')
assert result.returncode == 0 and not record.get('failed_build_marker', False), record
if args.step == 'bake':
    assert record['built_data_exists'] and record['built_data_bytes'] > 4096, record
print(json.dumps(record, ensure_ascii=True))
sys.exit(result.returncode)
