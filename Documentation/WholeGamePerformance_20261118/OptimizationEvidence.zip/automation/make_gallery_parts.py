import hashlib
import json
import os
from pathlib import Path
import struct
from collections import defaultdict
import unreal

out = Path(os.environ['KD_MODEL_EVIDENCE'])
project = Path(unreal.Paths.convert_relative_path_to_full(unreal.Paths.project_dir())).resolve()
assert project == Path(os.environ['LOCALAPPDATA']) / 'KDModelGalleryParts_20261118', project
lib = unreal.EditorAssetLibrary
api = unreal.GeometryScript_AssetUtils
sub = unreal.get_engine_subsystem(unreal.SubobjectDataSubsystem)
sub_lib = unreal.SubobjectDataBlueprintFunctionLibrary
bp = unreal.load_asset('/Game/Main/Stage/BP_Floor03')
world = unreal.EditorLoadingAndSavingUtils.load_map('/Game/Main/Stage/KDStage')
assert world
directory = '/Game/Main/Stage/Floor02/GalleryParts'
props = ['cast_shadow', 'cast_dynamic_shadow', 'cast_hidden_shadow', 'hidden_in_game', 'visible',
         'render_in_main_pass', 'render_in_depth_pass', 'receives_decals', 'render_custom_depth',
         'affect_distance_field_lighting', 'affect_dynamic_indirect_lighting',
         'affect_indirect_lighting_while_hidden', 'visible_in_ray_tracing',
         'visible_in_reflection_captures', 'visible_in_real_time_sky_captures',
         'relative_location', 'relative_rotation', 'relative_scale3d', 'override_materials']

def components():
    result = {}
    for handle in sub.k2_gather_subobject_data_for_blueprint(bp):
        data = sub_lib.get_data(handle)
        result[str(sub_lib.get_variable_name(data))] = (handle, sub_lib.get_object_for_blueprint(data, bp))
    return result

def read_source(mesh):
    dynamic = unreal.DynamicMesh()
    options = unreal.GeometryScriptCopyMeshFromAssetOptions()
    options.request_tangents = True
    options.apply_build_settings = False
    lod = unreal.GeometryScriptMeshReadLOD()
    lod.lod_type = unreal.GeometryScriptLODType.SOURCE_MODEL
    _, result = api.copy_mesh_from_static_mesh(mesh, dynamic, options, lod)
    assert result == unreal.GeometryScriptOutcomePins.SUCCESS
    return dynamic

def features(dynamic):
    records = []
    uv_method = next(name for name in dir(dynamic) if name.replace('_', '') == 'gettriangleuvs')
    channels = dynamic.get_num_uv_sets()
    for triangle in range(dynamic.get_triangle_count()):
        valid, a, b, c = dynamic.get_triangle_positions(triangle)
        normals = dynamic.get_triangle_normals(triangle)
        material, valid_material = dynamic.get_triangle_material_id(triangle)
        assert valid and valid_material and normals[-1]
        uvs = [getattr(dynamic, uv_method)(channel, triangle) for channel in range(channels)]
        assert all(value[-1] for value in uvs)
        corners = []
        for corner, (position, normal) in enumerate(zip((a, b, c), normals[-4:-1])):
            values = [position.x, position.y, position.z, normal.x, normal.y, normal.z]
            for layer in uvs:
                values.extend((layer[corner].x, layer[corner].y))
            corners.append(struct.pack('<' + 'f' * len(values), *(x if x != 0 else 0 for x in values)))
        a, b, c = corners
        key = struct.pack('<ii', material, channels) + min(a+b+c, b+c+a, c+a+b)
        records.append(hashlib.blake2b(key, digest_size=16).digest())
    return records

def digest(records):
    return hashlib.sha256(b''.join(sorted(records))).hexdigest()

def slots(mesh):
    return [(str(value.material_slot_name), value.material_interface.get_path_name() if value.material_interface else None)
            for value in mesh.get_editor_property('static_materials')]

def configure(target, original):
    target.set_mobility(original.get_editor_property('mobility'))
    for prop in props:
        if prop == 'visible':
            target.set_visibility(original.get_editor_property(prop), False)
        elif prop == 'hidden_in_game':
            target.set_hidden_in_game(original.get_editor_property(prop), False)
        else:
            target.set_editor_property(prop, original.get_editor_property(prop))
    target.set_collision_profile_name('NoCollision')
    target.set_collision_enabled(unreal.CollisionEnabled.NO_COLLISION)
    target.set_editor_property('can_ever_affect_navigation', False)
    target.set_editor_property('use_attach_parent_bound', False)

tree = components()
placed = next(actor for actor in unreal.GameplayStatics.get_all_actors_of_class(world, unreal.Actor) if actor.get_actor_label() == 'BP_Floor03')
original_component = next(component for component in placed.get_components_by_class(unreal.StaticMeshComponent) if component.get_name() == 'Corridors')
original = original_component.get_editor_property('static_mesh')
assert original.get_path_name() == '/Game/Main/Stage/Floor02/SM_F02_SharedGallery.SM_F02_SharedGallery', original.get_path_name()
original_properties = {prop: original_component.get_editor_property(prop) for prop in props}
original_materials = [original_component.get_material(i) for i in range(original_component.get_num_materials())]
assert len(original_materials) == 13
expected_materials = [material.get_path_name() if material else None for material in original_materials]
original_mobility = original_component.get_editor_property('mobility')
dynamic = read_source(original)
expected = dynamic.get_triangle_count()
source_hash = digest(features(dynamic))
unreal.log('KDGallery source features verified ' + str(expected))

# Keep disconnected pieces intact; group them at the existing floor slabs and atrium corners.
parents = {}
def find(vertex):
    parents.setdefault(vertex, vertex)
    while parents[vertex] != vertex:
        parents[vertex] = parents[parents[vertex]]
        vertex = parents[vertex]
    return vertex

triangle_vertices = []
triangle_positions = []
for triangle in range(expected):
    indices, valid = dynamic.get_triangle_indices(triangle)
    assert valid
    vertices = (indices.x, indices.y, indices.z)
    first = find(vertices[0])
    for vertex in vertices[1:]:
        parents[find(vertex)] = first
    triangle_vertices.append(vertices)
    valid, a, b, c = dynamic.get_triangle_positions(triangle)
    assert valid
    triangle_positions.append(((a.x,a.y,a.z), (b.x,b.y,b.z), (c.x,c.y,c.z)))
islands = defaultdict(list)
for triangle, vertices in enumerate(triangle_vertices):
    islands[find(vertices[0])].append(triangle)
groups = defaultdict(list)
island_records = []
for triangles in islands.values():
    points = [point for triangle in triangles for point in triangle_positions[triangle]]
    lo = [min(point[i] for point in points) for i in range(3)]
    hi = [max(point[i] for point in points) for i in range(3)]
    center = [(lo[i] + hi[i]) * 0.5 for i in range(3)]
    x, y, z = center
    if hi[2] - lo[2] > 450:
        floor = 'FullHeight'
    else:
        level = int((z + 648) // 315)
        floor = ['F01', 'F02', 'F03', 'F04', 'Roof'][max(0, min(4, level))]
    if y < -1000:
        wing = 'FarGlassWall'
    elif x < -1300 and y < 0:
        wing = 'WestGallery'
    elif y < 0:
        wing = 'EastGallery'
    elif x < -1037:
        wing = 'StairLobby'
    else:
        wing = 'FrontConnector'
    label = floor + '_' + wing
    groups[label].extend(triangles)
    island_records.append(dict(label=label, triangles=len(triangles), lo=lo, hi=hi))
proof = dict(project=str(project), original=original.get_path_name(), source_triangles=expected,
             original_nanite_triangles=original.get_num_nanite_triangles(),
             source_sha256=source_hash, feature_fields='position,normal,allUVchannels,materialID',
             uv_channels=dynamic.get_num_uv_sets(), islands=island_records, parts=[])
root_handle = tree['DefaultSceneRoot'][0]
all_features = []
packages = []
for label, triangles in sorted(groups.items()):
    _, selection = dynamic.convert_index_array_to_mesh_selection(triangles, unreal.GeometryScriptMeshSelectionType.TRIANGLES)
    part = unreal.DynamicMesh()
    dynamic.copy_mesh_selection_to_mesh(part, selection, False, True)
    assert part.get_triangle_count() == len(triangles)
    name = 'SM_Gallery_' + label
    assert not lib.does_asset_exist(directory + '/' + name)
    asset = unreal.AssetToolsHelpers.get_asset_tools().duplicate_asset(name, directory, original)
    options = unreal.GeometryScriptCopyMeshToAssetOptions()
    options.clean_assigned_materials = False
    options.enable_recompute_normals = False
    options.enable_recompute_tangents = False
    options.enable_remove_degenerates = False
    _, result = api.copy_mesh_to_static_mesh(part, asset, options, unreal.GeometryScriptMeshWriteLOD(), True)
    assert result == unreal.GeometryScriptOutcomePins.SUCCESS
    unreal.SystemLibrary.execute_console_command(world, 'Editor.AsyncAssetCompilationFinishAll')
    reread = read_source(asset)
    assert len(triangles) == reread.get_triangle_count()
    assert 0 < asset.get_num_nanite_triangles() <= len(triangles)
    assert slots(asset) == slots(original)
    all_features.extend(features(reread))
    child = 'Gallery_' + label
    params = unreal.AddNewSubobjectParams(parent_handle=root_handle, new_class=unreal.StaticMeshComponent, blueprint_context=bp)
    handle, reason = sub.add_new_subobject(params)
    assert not str(reason), reason
    assert sub.rename_subobject(handle, unreal.Text(child))
    tree = components()
    component = tree[child][1]
    component.set_mobility(original_mobility)
    for prop, value in original_properties.items():
        if prop == 'visible':
            component.set_visibility(value, False)
        elif prop == 'hidden_in_game':
            component.set_hidden_in_game(value, False)
        else:
            component.set_editor_property(prop, value)
    component.set_collision_profile_name('NoCollision')
    component.set_collision_enabled(unreal.CollisionEnabled.NO_COLLISION)
    component.set_editor_property('can_ever_affect_navigation', False)
    component.set_editor_property('use_attach_parent_bound', False)
    component.set_static_mesh(asset)
    for index, material in enumerate(original_materials):
        component.set_material(index, material)
    assert [component.get_material(i).get_path_name() if component.get_material(i) else None for i in range(13)] == expected_materials
    proof['parts'].append(dict(child=child, path=asset.get_path_name(), triangles=len(triangles),
                              nanite_triangles=asset.get_num_nanite_triangles(), bounds=str(part.get_mesh_bounding_box())))
    packages.append(asset.get_outermost())
    unreal.log('KDGallery part verified ' + label + ' ' + str(len(triangles)))
assert len(all_features) == expected and digest(all_features) == source_hash
proof['parts_sha256'] = digest(all_features)
def collision_only(component):
    component.set_visibility(False, False)
    component.set_hidden_in_game(True, False)
    for prop in ('cast_shadow', 'cast_dynamic_shadow', 'cast_hidden_shadow', 'visible_in_ray_tracing',
                 'affect_distance_field_lighting', 'affect_dynamic_indirect_lighting',
                 'affect_indirect_lighting_while_hidden', 'visible_in_reflection_captures', 'visible_in_real_time_sky_captures'):
        component.set_editor_property(prop, False)

collision_only(components()['Corridors'][1])
unreal.BlueprintEditorLibrary.compile_blueprint(bp)
unreal.SystemLibrary.execute_console_command(world, 'Editor.AsyncAssetCompilationFinishAll')
assert unreal.EditorLoadingAndSavingUtils.save_packages(packages + [bp.get_outermost()], False)
placed = next(actor for actor in unreal.GameplayStatics.get_all_actors_of_class(world, unreal.Actor) if actor.get_actor_label() == 'BP_Floor03')
original_component = next(component for component in placed.get_components_by_class(unreal.StaticMeshComponent) if component.get_name() == 'Corridors')
proof['original_collision'] = dict(profile=str(original_component.get_collision_profile_name()),
    mode=str(original_component.get_collision_enabled()), mesh=original_component.get_editor_property('static_mesh').get_path_name())
collision_only(original_component)
for name, (_, component) in components().items():
    if name.startswith('Gallery_'):
        assert [component.get_material(i).get_path_name() if component.get_material(i) else None for i in range(13)] == expected_materials
for component in placed.get_components_by_class(unreal.StaticMeshComponent):
    if component.get_name().startswith('Gallery_'):
        for index, material in enumerate(original_materials):
            component.set_material(index, material)
        assert [component.get_material(i).get_path_name() if component.get_material(i) else None for i in range(13)] == expected_materials
proof['effective_materials'] = expected_materials
assert unreal.EditorLoadingAndSavingUtils.save_map(world, '/Game/Main/Stage/KDStage')
(out / 'gallery_geometry_proof.json').write_text(json.dumps(proof, indent=2), encoding='utf8')
os.environ['KD_CENTRAL_RUN'] = str(out)
os.environ['KD_CENTRAL_VARIANT'] = 'gallery_parts'
check = out.parent / 'CentralHitch_20261117/verify_world.py'
exec(compile(check.read_text(encoding='utf8'), str(check), 'exec'), {'__name__': '__main__'})
unreal.log('KDGallery candidate complete')
