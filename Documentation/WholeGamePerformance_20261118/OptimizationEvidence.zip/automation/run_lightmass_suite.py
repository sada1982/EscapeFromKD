import argparse
from pathlib import Path
import sys

parser = argparse.ArgumentParser(add_help=False)
parser.add_argument('--trial-map', choices=('Lumen', 'Bake'), required=True)
args, remaining = parser.parse_known_args()
here = Path(__file__).resolve().parent
source = here / 'run_suite.py'
code = source.read_text(encoding='utf8')
needle = '              "-windowed", "-ResX=1920",'
assert code.count(needle) == 1
map_path = '/Game/Diagnostics/LightmassTrial/KDStage_' + ('BakeTrial' if args.trial_map == 'Bake' else 'LumenTrial')
code = code.replace(needle, '              ' + repr(map_path) + ', "-windowed", "-ResX=1920",', 1)
assert '-KDLightmassPrototype' not in remaining and '-KDBakedGITrial' not in remaining
remaining.append('-KDLightmassPrototype')
if args.trial_map == 'Bake':
    remaining.append('-KDBakedGITrial')
sys.argv = [str(source), *remaining]
exec(compile(code, str(source), 'exec'), {'__name__': '__main__', '__file__': str(source)})
