import argparse
import json
import os
from pathlib import Path
import subprocess
import sys

parser = argparse.ArgumentParser()
parser.add_argument('variant', choices=('GalleryParts', 'Furniture', 'LaptopOnly'))
parser.add_argument('--finish-map', action='store_true')
parser.add_argument('--fix-materials', action='store_true')
args = parser.parse_args()
out = Path(__file__).resolve().parent
work = Path(os.environ['LOCALAPPDATA']) / ('KDModel' + args.variant + '_20261118')
isolation = json.loads((out / (args.variant + '_isolation.json')).read_text(encoding='utf8'))
assert isolation['independent_files'] and Path(isolation['project']) == work
script = 'make_gallery_parts.py' if args.variant == 'GalleryParts' else 'make_furniture.py'
if args.variant == 'LaptopOnly':
    script = 'make_laptop_only.py'
if args.finish_map:
    assert args.variant == 'Furniture'
    script = 'finish_furniture_map.py'
if args.fix_materials:
    assert args.variant == 'GalleryParts' and not args.finish_map
    script = 'fix_gallery_materials.py'
engine = Path('C:/Program Files/Epic Games/UE_5.8/Engine')
cmd = [str(engine / 'Binaries/Win64/UnrealEditor-Cmd.exe'), str(work / 'myProject.uproject'),
       '-run=pythonscript', '-script=' + str(out / script), '-nullrhi', '-unattended', '-NoSplash', '-NoSound',
       '-DisablePlugins=ModelContextProtocol', '-EnablePlugins=GeometryScripting,PythonScriptPlugin',
       '-abslog=' + str(out / (args.variant + '_assets.log'))]
result = subprocess.run(cmd, env=dict(os.environ, KD_MODEL_EVIDENCE=str(out)),
    creationflags=subprocess.CREATE_NO_WINDOW | subprocess.BELOW_NORMAL_PRIORITY_CLASS,
    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
print('KD_MODEL_ASSETS_EXIT', args.variant, result.returncode)
sys.exit(result.returncode)
