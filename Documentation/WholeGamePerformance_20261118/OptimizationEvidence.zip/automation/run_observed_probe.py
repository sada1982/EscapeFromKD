import argparse
import csv
import ctypes
from ctypes import wintypes
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time


here = Path(__file__).resolve().parent
exe_relative = Path("myProject/Binaries/Win64/myProject-Win64-Shipping.exe")
pak_relative = Path("myProject/Content/Paks/myProject-Windows.pak")


def digest(path):
    value = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(4 * 1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()


def hidden(command, log):
    with log.open("wb") as stream:
        return subprocess.Popen(command, stdout=stream, stderr=stream,
                                creationflags=subprocess.CREATE_NO_WINDOW)


def read_values(path):
    return dict(line.split("=", 1) for line in path.read_text(encoding="utf-8-sig").splitlines() if "=" in line)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("name")
    parser.add_argument("--workers", type=int, choices=[15, 8, 4], default=15)
    parser.add_argument("--loading-fps", type=int, choices=[0, 30], default=0)
    parser.add_argument("--kind", choices=["startup", "stress"], default="startup")
    parser.add_argument("--enemies", type=int, choices=[1, 10], default=1)
    parser.add_argument("--site", choices=["atrium", "corridor"], default="atrium")
    parser.add_argument("--seconds", type=int, default=120)
    parser.add_argument("--editor", type=int, default=27448)
    parser.add_argument("--state", type=Path, default=here / "editor_minimize_A2.json")
    parser.add_argument("--expected-window", choices=["maximized", "minimized", "normal"], default="maximized")
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args()
    assert args.name.isalnum()
    assert 10 <= args.seconds <= 300
    base = here / "Variants/LoadingCapProbe"
    base_proof = json.loads((base / "proof.json").read_text(encoding="utf8"))
    settings = base_proof["settings"]
    assert "r.PSOPrecaching.MinPriorityForActivePrecacheRequests=0" in settings
    assert "r.PSOPrecaching.TaskPriorityThreshold=0" in settings
    assert "r.pso.PrecompileThreadPoolSizeMax" not in settings
    pak_source = base / "Windows" / pak_relative
    pak_hash = base_proof["pak_sha256"]
    if args.workers != 15:
        worker = here / "Variants" / ("GateAll" + str(args.workers))
        worker_proof = json.loads((worker / "proof.json").read_text(encoding="utf8"))
        assert worker_proof["settings"] == settings + "\nr.pso.PrecompileThreadPoolSizeMax=" + str(args.workers) + "\n"
        assert worker_proof["other_pak_entries_unchanged"] == base_proof["other_pak_entries_unchanged"] == 1772
        assert worker_proof["pak_changed_entry"] == base_proof["pak_changed_entry"]
        pak_source = worker / "Windows" / pak_relative
        pak_hash = worker_proof["pak_sha256"]
    run = here / args.name
    watch = here / (args.name + "Window")
    threads = here / (args.name + "Threads")
    control = here / (args.name + "Control")
    deploy = here / "FreshDeployments" / args.name / "Windows"
    extras = ["-KDStartupMaxFPS=" + str(args.loading_fps)]
    if args.kind == "startup":
        extras += ["-KDSurveyScenes=ClassroomStart", "-KDSurveyRounds=2", "-KDSurveyWarmFrames=120", "-KDSurveySampleFrames=600"]
    else:
        extras += ["-KDEnemyStress", "-KDStressEnemies=" + str(args.enemies),
                   "-KDStressSeconds=" + str(args.seconds), "-KDStressSite=" + args.site]
    runner_command = [sys.executable, "-B", str(here / "run_suite.py"), str(deploy / exe_relative),
                      args.name, "--editor", str(args.editor), "--timeout", "900", *extras]
    plan = dict(name=args.name, workers=args.workers, loading_fps=args.loading_fps, kind=args.kind,
                source=str(base), pak_source=str(pak_source), exe_sha256=base_proof["exe_sha256"], pak_sha256=pak_hash,
                deploy=str(deploy), run=str(run), watcher=str(watch), threads=str(threads),
                runner=runner_command, expected_window=args.expected_window,
                loading_capture="Same automatic startup_loading.png at 30 seconds in every diagnostic case; no extra readback.",
                freshness="New executable pathname and fresh per-run UserDir. OS/driver global caches are not cleared.")
    if not args.execute:
        print(json.dumps(plan, indent=2))
        return
    class Power(ctypes.Structure):
        _fields_=[("ac",wintypes.BYTE),("battery_flags",wintypes.BYTE),("battery_percent",wintypes.BYTE),("saver",wintypes.BYTE),("remaining_seconds",wintypes.DWORD),("full_seconds",wintypes.DWORD)]
    power=Power()
    if not ctypes.WinDLL("kernel32",use_last_error=True).GetSystemPowerStatus(ctypes.byref(power)):
        raise ctypes.WinError(ctypes.get_last_error())
    plan["launch_power"]={"ac":power.ac,"battery_percent":power.battery_percent,"saver":power.saver}
    assert power.ac == 1, "AC comparison requires AC power before launch"
    for path in (run, watch, threads, control, deploy.parent):
        if path.exists():
            raise FileExistsError(path)
    assert digest(base / "Windows" / exe_relative) == plan["exe_sha256"]
    assert digest(pak_source) == pak_hash
    control.mkdir()
    for source in (base / "Windows").rglob("*"):
        if not source.is_file():
            continue
        relative = source.relative_to(base / "Windows")
        if "Saved" in relative.parts:
            continue
        chosen = pak_source if relative == pak_relative else source
        target = deploy / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        os.link(chosen, target)
        assert os.path.samefile(chosen, target)
    plan["hardlink_identity_verified"] = True
    (control / "plan.json").write_text(json.dumps(plan, indent=2), encoding="utf8")
    watcher = hidden([sys.executable, "-B", str(here / "watch_editor_window.py"), str(run / "metadata.json"),
                      str(watch), "--state", str(args.state), "--seconds", "1100"], control / "watcher.log")
    sampler = None
    runner = None
    try:
        deadline = time.monotonic() + 15
        while not (watch / "ready.json").is_file():
            if watcher.poll() is not None or time.monotonic() >= deadline:
                raise RuntimeError("Window watcher did not become ready; no game launched")
            time.sleep(.1)
        initial = json.loads((watch / "ready.json").read_text(encoding="utf8"))
        window = initial["initial_window"]
        expected = (not window["iconic"] and window["zoomed"] and window["showCmd"] == 3) if args.expected_window == "maximized" else (window["iconic"] and window["showCmd"] == 2)
        if args.expected_window == "normal":
            expected = not window["iconic"] and not window["zoomed"] and window["showCmd"] == 1
        assert expected and window["pid"] == args.editor
        assert initial["initial_foreground"]["pid"] != args.editor
        runner = hidden(runner_command, control / "runner.log")
        deadline = time.monotonic() + 20
        while not (run / "metadata.json").is_file():
            if runner.poll() is not None or time.monotonic() >= deadline:
                raise RuntimeError("run_suite metadata not created")
            time.sleep(.1)
        sampler = hidden([sys.executable, "-B", str(here / "sample_thread_cpu.py"), str(run / "metadata.json"),
                          "--output", str(threads), "--seconds", "1050"], control / "sampler.log")
        result = runner.wait(timeout=1080)
        plan["runner_returncode"] = result
        if result:
            raise RuntimeError("run_suite failed; inspect runner.log and metadata before any retry")
    finally:
        if watch.exists():
            (watch / "done.flag").write_text("done\n", encoding="ascii")
        for role, process in (("watcher", watcher), ("sampler", sampler)):
            if process is not None:
                try:
                    plan[role + "_returncode"] = process.wait(timeout=15)
                except subprocess.TimeoutExpired:
                    plan[role + "_still_running_pid"] = process.pid
        if runner is not None and runner.poll() is None:
            plan["runner_still_running_pid"] = runner.pid
        (control / "execution.json").write_text(json.dumps(plan, indent=2), encoding="utf8")
    assert plan.get("watcher_returncode") == 0 and plan.get("sampler_returncode") == 0
    meta = json.loads((run / "metadata.json").read_text(encoding="utf8"))
    with (run / "monitor_process.csv").open(encoding="utf-8-sig",newline="") as stream:
        power_samples=[row["ac_power"] for row in csv.DictReader(stream) if row["role"]=="game"]
    if not power_samples or any(value!="1" for value in power_samples):
        (run / "exclusion.txt").write_text("AC power was not observed continuously during this comparison; retain as excluded evidence.\n",encoding="utf8")
        raise RuntimeError("AC condition changed or missing; performance comparison excluded")
    route = Path(meta["route"])
    gate = read_values(route / "startup_result.txt")
    cap = read_values(route / "startup_frame_cap.txt")
    assert gate["reason"] == "settled" and gate["input_restored"] == "1" and gate["pso_min_priority"] == "0"
    assert int(gate["start_qpc"]) < int(gate["entrance_qpc"]) < int(gate["corridor_qpc"]) < int(gate["return_qpc"]) < int(gate["open_qpc"])
    assert cap["active"] == "0" and cap["external_change"] == "0"
    if args.loading_fps:
        assert cap["status"] == "restored" and int(cap["applies"]) > 0 and cap["applies"] == cap["restores"]
        assert cap["previous_value"] == cap["final_value"] and cap["previous_priority"] == cap["final_priority"]
    else:
        assert cap["status"] == "disabled" and cap["applies"] == "0"
    state = json.loads((threads / "thread_cpu_state.json").read_text(encoding="utf8"))
    assert state["identity_verified"] and state["rows"] > 0 and state["pid"] == meta["game_pid"]
    analyzer = "analyze_suite.py" if args.kind == "startup" else "analyze_route_stress.py"
    subprocess.run([sys.executable, "-B", str(here / analyzer), str(run)], check=True, creationflags=subprocess.CREATE_NO_WINDOW)
    subprocess.run([sys.executable, "-B", str(here / "audit_window_samples.py"), str(run), str(watch),
                    "--expected", args.expected_window, "--include-startup"], check=True, creationflags=subprocess.CREATE_NO_WINDOW)
    window_audit = json.loads((watch / "sample_window_audit.json").read_text(encoding="utf8"))
    assert window_audit["all_rounds_observed_stable"], "Editor placement/foreground condition changed; retain run as excluded evidence"
    if args.kind == "stress":
        subprocess.run([sys.executable, "-B", str(here / "audit_stress_growth.py"), str(run)], check=True, creationflags=subprocess.CREATE_NO_WINDOW)
    (control / "gate_checks.json").write_text(json.dumps(dict(gate=gate, cap=cap, thread_state=state), indent=2), encoding="utf8")
    print("Completed", args.name, "normal game exit and gate/cap/thread checks passed; inspect window and performance summaries.", flush=True)


if __name__ == "__main__":
    main()
