import argparse
import bisect
import csv
import json
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('run', type=Path)
parser.add_argument('watch', type=Path)
parser.add_argument('--expected', choices=['maximized','minimized','normal'], default='maximized')
parser.add_argument('--include-startup', action='store_true')
args = parser.parse_args()
summary = json.loads((args.run/'summary.json').read_text(encoding='utf8'))
ready = json.loads((args.watch/'ready.json').read_text(encoding='utf8'))
rows = list(csv.DictReader((args.watch/'window_state.csv').open(encoding='utf-8-sig',newline='')))
times = [int(r['qpc']) for r in rows]
initial = ready['initial_window']
output = []
windows = list(summary['per_round']) if 'per_round' in summary else [dict(scene=name,round=0,q0=value['start'],q1=value['end']) for name,value in summary['windows'].items()]
if args.include_startup:
    meta = json.loads((args.run/'metadata.json').read_text(encoding='utf8'))
    gate = dict(line.split('=',1) for line in (Path(meta['route'])/'startup_result.txt').read_text(encoding='utf-8-sig').splitlines() if '=' in line)
    windows.insert(0,dict(scene='startup',round=0,q0=int(gate['start_qpc']),q1=int(gate['open_qpc'])))
for scene in windows:
    a,b = int(scene['q0']),int(scene['q1'])
    first = max(0,bisect.bisect_right(times,a)-1)
    last = min(len(rows)-1,bisect.bisect_left(times,b))
    selected = rows[first:last+1]
    covered = times[first]<=a and times[last]>=b
    bad_state, editor_foreground, foreground_changes = [], [], []
    previous = None
    for row in selected:
        iconic, zoomed = int(row['iconic']),int(row['zoomed'])
        expected = (iconic==0 and zoomed==1 and int(row['showCmd'])==3) if args.expected=='maximized' else (iconic==1 and int(row['showCmd'])==2)
        if args.expected=='normal':
            expected = iconic==0 and zoomed==0 and int(row['showCmd'])==1
        rect = [int(row[k]) for k in ['rect_left','rect_top','rect_right','rect_bottom']]
        if not expected or rect!=initial['normal_rect']:
            bad_state.append(int(row['qpc']))
        fg = (int(row['foreground_hwnd']),int(row['foreground_pid']))
        if fg[1]==initial['pid']:
            editor_foreground.append(int(row['qpc']))
        if previous is not None and fg!=previous:
            foreground_changes.append(dict(qpc=int(row['qpc']),hwnd=fg[0],pid=fg[1]))
        previous = fg
    gaps = [(int(y['qpc'])-int(x['qpc']))*1000/ready['frequency'] for x,y in zip(selected,selected[1:])]
    output.append(dict(scene=scene['scene'],round=scene['round'],q0=a,q1=b,covered=covered,window_samples=len(selected),unexpected_state_qpcs=bad_state,editor_foreground_qpcs=editor_foreground,foreground_changes=foreground_changes,max_poll_gap_ms=max(gaps) if gaps else None,condition_observed_stable=covered and not bad_state and not editor_foreground))
result = dict(expected=args.expected,rounds=output,all_rounds_observed_stable=all(r['condition_observed_stable'] for r in output),limitation='Read-only250ms observations, including bracketing samples. Stability is observed at sampling points; shorter transitions can be missed. Foreground changes to other applications are reported, not silently treated as constant workload.')
(args.watch/'sample_window_audit.json').write_text(json.dumps(result,indent=2),encoding='utf8')
print(json.dumps(result,indent=2))
