import hashlib
import json
import os
from pathlib import Path
import unreal

out = Path(os.environ['KD_MODEL_EVIDENCE'])
project = Path(unreal.Paths.convert_relative_path_to_full(unreal.Paths.project_dir())).resolve()
assert project == Path(os.environ['LOCALAPPDATA']) / 'KDLightmassTrial_20261118'
audit = json.loads((out / 'lightmass_material_usage.json').read_text(encoding='utf8'))
usage = getattr(unreal.MaterialUsage, next(name for name in dir(unreal.MaterialUsage) if name.replace('_', '').lower() == 'matusagestaticlighting'))
masters = {}
for row in audit:
    path = row['parent'] or row['asset']
    assert path.startswith('/Game/')
    material = unreal.load_asset(path)
    assert isinstance(material, unreal.Material)
    masters[path] = material
before_files = {str(p.relative_to(project)): hashlib.sha256(p.read_bytes()).hexdigest() for p in (project / 'Content').rglob('*') if p.is_file()}
changed = []
for path, material in masters.items():
    assert not unreal.MaterialEditingLibrary.has_material_usage(material, usage)
    result = unreal.MaterialEditingLibrary.set_material_usage(material, usage)
    assert unreal.MaterialEditingLibrary.has_material_usage(material, usage), path
    unreal.MaterialEditingLibrary.recompile_material(material)
    assert unreal.EditorAssetLibrary.save_loaded_asset(material, False)
    changed.append(dict(asset=path, result=str(result)))
assert all(unreal.MaterialEditingLibrary.has_material_usage(unreal.load_asset(row['asset']), usage) for row in audit)
after_files = {str(p.relative_to(project)): hashlib.sha256(p.read_bytes()).hexdigest() for p in (project / 'Content').rglob('*') if p.is_file()}
expected = {'Content/' + path.split('.')[0].removeprefix('/Game/') + '.uasset' for path in masters}
different = {name.replace('\\', '/') for name, digest in after_files.items() if before_files.get(name) != digest}
assert different == expected, (different, expected)
(out / 'lightmass_material_fix.json').write_text(json.dumps(dict(changed=changed, changed_files=sorted(different),
    mesh_map_built_data_unchanged=True, material_graph_parameters_edited=False), indent=2), encoding='utf8')
