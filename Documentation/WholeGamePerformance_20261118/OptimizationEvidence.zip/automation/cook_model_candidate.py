import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

parser = argparse.ArgumentParser()
parser.add_argument('variant', choices=('GalleryParts', 'Furniture', 'LaptopOnly'))
parser.add_argument('--binary-project', required=True)
parser.add_argument('--archive', required=True)
parser.add_argument('--settings-file', required=True)
args = parser.parse_args()
out = Path(__file__).resolve().parent
work = Path(os.environ['LOCALAPPDATA']) / ('KDModel' + args.variant + '_20261118')
proof = json.loads((out / (args.variant + '_content_proof.json')).read_text(encoding='utf8'))
assert Path(proof['project']) == work and proof['original_content_unchanged']
binary_project = Path(args.binary_project).resolve()
archive = Path(args.archive).resolve()
assert not archive.exists(), archive
engine = Path('C:/Program Files/Epic Games/UE_5.8/Engine')
binary = 'myProject-Win64-Shipping.exe'
receipt = binary_project / 'Binaries/Win64/myProject-Win64-Shipping.target'
metadata = json.loads(receipt.read_text(encoding='utf8'))
assert metadata['Configuration'] == 'Shipping' and metadata['TargetName'] == 'myProject'
products = metadata['BuildProducts'] + metadata['RuntimeDependencies']
for product in products:
    path = product['Path']
    if not path.startswith('$(ProjectDir)/') or path.endswith(('.pdb', '.lib', '.exp')):
        continue
    relative = Path(path.removeprefix('$(ProjectDir)/'))
    source = binary_project / relative
    assert source.is_file(), source
    target = work / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)
shutil.copy2(receipt, work / 'Binaries/Win64' / receipt.name)
settings = Path(args.settings_file).resolve()
assert settings.is_file()
shutil.copy2(settings, work / 'Config/Windows/WindowsEngine.ini')
cmd = [str(engine / 'Build/BatchFiles/RunUAT.bat'), 'BuildCookRun', '-project=' + str(work / 'myProject.uproject'),
       '-nop4', '-utf8output', '-platform=Win64', '-clientconfig=Shipping', '-skipbuild', '-cook',
       '-map=/Game/Main/Stage/KDStage', '-stage', '-pak', '-iostore', '-package', '-archive',
       '-archivedirectory=' + str(archive), '-nodebuginfo', '-nocompileeditor',
       '-unrealexe=' + str(engine / 'Binaries/Win64/UnrealEditor-Cmd.exe'), '-installed', '-unattended',
       '-AdditionalCookerOptions=-nullrhi']
with (out / (args.variant + '_cook.log')).open('wb') as log:
    result = subprocess.run(cmd, cwd=work, stdout=log, stderr=subprocess.STDOUT,
        creationflags=subprocess.CREATE_NO_WINDOW | subprocess.BELOW_NORMAL_PRIORITY_CLASS)
if result.returncode:
    sys.exit(result.returncode)
shipped = archive / 'Windows/myProject/Binaries/Win64' / binary
expected_hash = hashlib.sha256((binary_project / 'Binaries/Win64' / binary).read_bytes()).hexdigest()
assert hashlib.sha256(shipped.read_bytes()).hexdigest() == expected_hash
record = dict(variant=args.variant, archive=str(archive), exe=str(shipped), exe_sha256=expected_hash,
              binary_project=str(binary_project), content_proof=proof)
(out / (args.variant + '_package_proof.json')).write_text(json.dumps(record, indent=2), encoding='utf8')
print(shipped)
