#pragma once
#include "CoreMinimal.h"

struct FKDFullRoute
{
    struct FWaypoint { const TCHAR* Name; FVector Position; };
    static int32 Count() { return 28; }
    static const FWaypoint& At(int32 Index)
    {
        static const FWaypoint Points[]={
            {TEXT("F03_classroom_exit"),{402,-890,98.15}},
            {TEXT("F03_gallery_south"),{-117,-890,98.15}},
            {TEXT("F03_gallery_north"),{-117,109,98.15}},
            {TEXT("F03_gallery_west"),{-876,109,98.15}},
            {TEXT("F03_lobby_east"),{-876,308,98.15}},
            {TEXT("F03_stairs_approach"),{-1635,308,98.15}},
            {TEXT("F03_down_flight_entry"),{-1635,189,98.15}},
            {TEXT("F03_first_half_landing"),{-2145,200,-71.85}},
            {TEXT("F03_turn_half_landing"),{-2145,470,-71.85}},
            {TEXT("F03_return_flight_top"),{-2050,470,-71.85}},
            {TEXT("F03_return_flight_mid"),{-1910,470,-144.35}},
            {TEXT("F02_landing_west"),{-1730,470,-216.85}},
            {TEXT("F02_landing_turn"),{-1650,470,-216.85}},
            {TEXT("F02_down_flight_entry"),{-1650,200,-216.85}},
            {TEXT("F02_down_flight_top"),{-1770,200,-216.85}},
            {TEXT("F02_down_flight_mid"),{-1910,200,-301.85}},
            {TEXT("F02_lower_half_landing"),{-2145,200,-386.85}},
            {TEXT("F01_link_outer_corridor"),{-2145,-270,-386.85}},
            {TEXT("F01_link_east_turn"),{-1880,-270,-386.85}},
            {TEXT("F01_link_return_landing"),{-1880,-450,-386.85}},
            {TEXT("F01_last_flight_top"),{-1810,-450,-386.85}},
            {TEXT("F01_last_flight_mid"),{-1655,-450,-473.85}},
            {TEXT("F01_landing_exit"),{-1450,-450,-531.85}},
            {TEXT("F01_atrium_crossing"),{-950,-450,-531.85}},
            {TEXT("F01_east_hall"),{100,-450,-531.85}},
            {TEXT("F01_exit_approach"),{700,-450,-531.85}},
            {TEXT("F01_exit_center"),{700,-220,-531.85}},
            {TEXT("F01_exit_threshold"),{900,-220,-530.35}},
        };
        check(Index>=0 && Index<Count());
        return Points[Index];
    }
};
