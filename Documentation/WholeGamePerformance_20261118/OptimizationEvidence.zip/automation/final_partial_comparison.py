import argparse
import csv
import hashlib
import json
import math
from pathlib import Path
import statistics


here = Path(__file__).resolve().parent
def read_json(path):
    return json.loads(path.read_text(encoding="utf8"))


def read_rows(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def stats(records):
    values = sorted(float(row["ms"]) for row in records)
    assert values
    count = len(values)
    over = sum(value > 1000/60 for value in values)
    worst = max(records, key=lambda row:float(row["ms"]))
    return dict(n=count, mean_ms=statistics.mean(values), fps=1000/statistics.mean(values),
                p99_ms=values[math.ceil(.99*count)-1], max_ms=values[-1], over_count=over,
                over_rate_pct=100*over/count, measured_interval_seconds=sum(values)/1000,
                maximum_interval=worst)


def load(path, mode, baseline):
    run = path.resolve()
    control = run.parent / (run.name + "Control")
    plan = read_json(control / "plan.json")
    validation = read_json(control / "validation.json")
    meta = read_json(run / "metadata.json")
    watch = read_json(run.parent / (run.name + "Window") / "sample_window_audit.json")
    ready = read_json(run.parent / (run.name + "Window") / "ready.json")
    assert validation["complete"] and validation["window_conditions_valid"] and watch["all_rounds_observed_stable"]
    power = validation["power_condition"]
    assert power["valid"] and not validation["invalid"]
    assert power["prelaunch"]["api_ok"] and power["prelaunch"]["ac_power"] == 1
    assert power["game_samples"] > 0 and not power["non_ac_samples"]
    assert power["measurement_windows"] and all(row["game_samples"] > 0 for row in power["measurement_windows"])
    assert plan["mode"] == validation["mode"] == mode and plan["baseline"] == baseline
    assert meta["returncode"] == meta["monitor_returncode"] == 0
    assert plan["conditions"]["expected_slate_sleep"] == 0
    assert plan["conditions"]["supplied_record"]["restored_value"] == 0
    expected_window = plan["conditions"].get("expected_window", "maximized")
    assert expected_window in ("maximized", "normal") and watch["expected"] == expected_window
    initial = ready["initial_window"]
    assert not initial["iconic"]
    assert (initial["zoomed"] and initial["showCmd"] == 3) if expected_window == "maximized" else (not initial["zoomed"] and initial["showCmd"] == 1)
    summary = read_json(run / "summary.json")
    filename = "scene_intervals.csv" if mode == "survey" else "intervals.csv"
    intervals = read_rows(run / filename)
    assert intervals
    for row in intervals:
        assert int(row["q1"]) > int(row["q0"]) and float(row["ms"]) > 0
        computed = (int(row["q1"])-int(row["q0"]))*1000/meta["start"]["frequency"]
        assert abs(computed-float(row["ms"])) < .00001
    intended_gate_changes = {"r.PSOPrecaching.MinPriorityForActivePrecacheRequests", "r.PSOPrecaching.TaskPriorityThreshold"}
    fixed = {key:value for key,value in validation["settings"].items() if key not in intended_gate_changes and (key.startswith(("r.", "sg.", "t.")) or key in ("map", "pawn", "viewport", "max_walk_speed"))}
    groups = {"all": intervals}
    if mode == "survey":
        assert len(summary["per_round"]) == 28 and len(summary["per_scene"]) == 14
        assert {int(row["round"]) for row in intervals} == {1, 2}
        for number in (1, 2):
            groups["round_" + str(number)] = [row for row in intervals if int(row["round"]) == number]
        for scene in summary["per_scene"]:
            selected = [row for row in intervals if row["scene"] == scene]
            groups[scene + "/all"] = selected
            for number in (1, 2):
                groups[scene + "/round_" + str(number)] = [row for row in selected if int(row["round"]) == number]
    else:
        laps, points = (4, 28) if mode == "full-route" else (20, 8)
        assert {row["window"] for row in intervals} == {"lap_" + str(lap) for lap in range(1, laps+1)}
        groups["first_lap"] = [row for row in intervals if row["window"] == "lap_1"]
        groups["warm_laps"] = [row for row in intervals if row["window"] != "lap_1"]
        for lap in range(1, laps+1):
            groups["lap_" + str(lap)] = [row for row in intervals if row["window"] == "lap_" + str(lap)]
        for leg in range(points):
            first, warm = [], []
            for lap in range(1, laps+1):
                name = f"lap_{lap}_leg_{leg:02d}"
                window = summary["windows"][name]
                selected = [row for row in groups["lap_" + str(lap)] if int(window["start"]) <= int(row["q0"]) < int(row["q1"]) <= int(window["end"])]
                assert selected
                groups[name] = selected
                (first if lap == 1 else warm).extend(selected)
            groups[f"leg_{leg:02d}/first_lap"] = first
            groups[f"leg_{leg:02d}/warm_laps"] = warm
            groups[f"leg_{leg:02d}/all"] = first + warm
    snapshot = Path(plan["source"]).parent / "SourceSnapshot"
    helper_names = ["myProject.cpp", "myProject.Build.cs"]
    if mode != "formal-route":
        helper_names += ["Survey.h", "Stress.h", "QualitySweep.h", "LightCandidates.h", "GalleryMaterialCheck.h", "FullRoute.h"]
    hashes = {name:hashlib.sha256((snapshot / name).read_bytes()).hexdigest() for name in helper_names if (snapshot / name).is_file()}
    if mode != "formal-route":
        assert set(hashes) == set(helper_names), "Final diagnostic builds must have complete current helper snapshots"
    return dict(run=str(run), mode=mode, baseline=baseline, groups={key:stats(rows) for key,rows in groups.items()},
                fixed_settings=fixed, plan=plan, validation=validation, window=watch, helper_hashes=hashes,
                expected_window=expected_window, normal_rect=initial["normal_rect"],
                helper_snapshot_available=len(hashes) == len(helper_names),
                monitor_nvidia=str(run / "monitor_nvidia.csv"), monitor_process=str(run / "monitor_process.csv"))


pairs = []
table = []
for order, label, mode, old_name, new_name in (
        ("A", "survey", "survey", "FinalBeforeSurvey", "FinalAfterSurvey"),
        ("B", "survey", "survey", "FinalBeforeSurveyB2", "FinalAfterSurveyB"),
        ("A", "full_route", "full-route", "FinalBeforeRoute", "FinalAfterRoute"),
        ("B", "full_route", "full-route", "FinalBeforeRouteB", "FinalAfterRouteB")):
    before, after = load(here / old_name, mode, True), load(here / new_name, mode, False)
    assert before["fixed_settings"] == after["fixed_settings"]
    assert before["helper_hashes"] == after["helper_hashes"]
    assert set(before["groups"]) == set(after["groups"])
    assert before["expected_window"] == after["expected_window"] == "normal"
    assert before["normal_rect"] == after["normal_rect"] == [236,153,1612,969]
    for side in (before, after):
        gate = side["validation"]["gate"]
        assert gate["exit_cull_enabled"] == "1" and int(gate["exit_cull_permutation"]) >= 0
        assert int(gate["exit_cull_requested_qpc"]) > 0 and int(gate["exit_cull_completed_qpc"]) > 0
    changes = {}
    for group, old in before["groups"].items():
        new = after["groups"][group]
        changes[group] = {key:new[key]-old[key] for key in ("mean_ms", "p99_ms", "max_ms", "over_count", "over_rate_pct")}
        row = dict(order=order, comparison=label, group=group)
        for prefix, values in (("before", old), ("after", new)):
            row.update({prefix+"_"+key:values[key] for key in ("n", "mean_ms", "fps", "p99_ms", "max_ms", "over_count", "over_rate_pct")})
        row.update({"delta_"+key:value for key,value in changes[group].items()})
        table.append(row)
    pairs.append(dict(order=order, comparison=label, before=before, after=after, differences_after_minus_before=changes))
assert len({pair[side]["plan"]["deploy"] for pair in pairs for side in ("before", "after")}) == 8
limits = [
    "Partial acceptance only. The user explicitly deferred further measurements while using Editor; no games or Editor operations are launched by this analysis.",
    "Exactly eight valid diagnostic runs: two order-reversed survey pairs and two order-reversed full-route pairs. A ran Before then After; B ran After then Before (the invalid first BeforeSurveyB is excluded in full and replaced by valid BeforeSurveyB2).",
    "FinalBeforeSurveyB and FinalBeforeFormal are excluded in full for transient Editor foreground/window condition changes. There was only one invalid formal run, FinalBeforeFormal.",
    "FinalAfterFormal and FinalAfterStress10 were not executed. There is no valid final formal comparison and no final Slate0/normal 10-enemy result. The six-input final_comparison_analysis.py remains unexecuted.",
    "P99 is nearest rank ceil(.99*n); over budget is strictly >1000/60ms. Whole-lap intervals crossing waypoint boundaries remain included, while per-leg groups require full containment.",
    "Survey round1 follows startup and120 warm frames per view; it is not entirely cold. Round2 is reported separately. Full-route warm_laps means laps2-4 revisits, not proof that old-gate medium-priority PSO work has finished.",
    "Diagnostic pairs reuse the same old cooked container except intended config, and identical eight helper snapshots. Render settings are compared excluding intended PSO priority settings. This is not a fresh formal-package validation.",
    "Window normal/nonforeground was observed at250ms, AC1 at approximately one-second game observations; shorter changes can be missed. Slate0 is the root supplied MCP record, not an automated CVar query. PIE was read once during BeforeSurveyB2 and between subsequent runs, not continuously.",
    "Fresh deployment path and UserDir per run do not clear OS/driver global caches. Other foreground applications can change workload. Numerical changes are not statistical proof.",
    "CPU process core-equivalent sums parallel threads, not frame critical-path duration. UE counters may refer to the previous frame and must not be added across GPU/CPU or wait/busy lanes.",
    "Prior Slate1/maximized model, light and stress runs are not directly pooled into these before/after improvement values."
]
report = dict(status="partial_measurement_stopped_by_user", method="Validated existing Present interval CSVs; same load/stats functions copied from the prepared final comparison, with eight diagnostic inputs only.", limits=limits, excluded=["FinalBeforeSurveyB","FinalBeforeFormal"], not_executed=["FinalAfterFormal","FinalAfterStress10"], next_run_names=["FinalBeforeFormal2","FinalAfterFormal","FinalAfterStress10"], pairs=pairs)
out=here/"FinalPartialComparison"
out.mkdir(exist_ok=False)
(out/"comparison.json").write_text(json.dumps(report,indent=2),encoding="utf8")
with (out/"comparison.csv").open("w",encoding="utf-8-sig",newline="") as stream:
    writer=csv.DictWriter(stream,fieldnames=list(table[0]));writer.writeheader();writer.writerows(table)
lines=["Final partial diagnostic comparison - eight valid runs only", "", *limits, "", "Order / mode / group / Before mean,P99,max,over/count(rate%) / After mean,P99,max,over/count(rate%)"]
for row in table:
    if row["group"] not in ("all","round_1","round_2","first_lap","warm_laps") and "/all" not in row["group"]:
        continue
    values=[]
    for prefix in ("before","after"):
        values.append(f'{row[prefix+"_mean_ms"]:.5f},{row[prefix+"_p99_ms"]:.4f},{row[prefix+"_max_ms"]:.4f},{row[prefix+"_over_count"]}/{row[prefix+"_n"]}({row[prefix+"_over_rate_pct"]:.3f}%)')
    lines.append(row["order"]+" / "+row["comparison"]+" / "+row["group"]+" / "+" / ".join(values))
lines += ["", "CPU/GPU evidence: ../final_scene_diagnosis.json and ../final_route_telemetry.json. Remaining formal/stress measurements require a new explicit execution slot."]
(out/"comparison.txt").write_text("\n".join(lines)+"\n",encoding="utf8")
print("Wrote",out,"using exactly eight validated diagnostic runs; formal/stress remain pending.")
