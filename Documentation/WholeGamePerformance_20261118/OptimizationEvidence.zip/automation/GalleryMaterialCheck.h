#pragma once
#include "Components/StaticMeshComponent.h"
#include "EngineUtils.h"
#include "Materials/MaterialInterface.h"
#include "Misc/FileHelper.h"
#include "Misc/Paths.h"

inline bool ValidateGalleryMaterials(UWorld* World, const FString& Directory)
{
    FString Rows=TEXT("component,slot,expected,actual,match\n");
    int32 Parts=0, Checked=0, Failures=0;
    for(TActorIterator<AActor> It(World);It;++It)
    {
        TArray<UStaticMeshComponent*> Components;
        It->GetComponents(Components);
        UStaticMeshComponent* Original=nullptr;
        for(UStaticMeshComponent* Component:Components)
            if(Component->GetName()==TEXT("Corridors")) Original=Component;
        for(UStaticMeshComponent* Component:Components)
        {
            if(!Component->GetName().StartsWith(TEXT("Gallery_"))) continue;
            ++Parts;
            if(!Original || Original->GetNumMaterials()!=13 || Component->GetNumMaterials()!=13)
            {
                ++Failures;
                Rows+=FString::Printf(TEXT("%s,-1,13slots,invalid_count,0\n"),*Component->GetName());
                continue;
            }
            for(int32 Slot=0;Slot<13;++Slot)
            {
                UMaterialInterface* Expected=Original->GetMaterial(Slot);
                UMaterialInterface* Actual=Component->GetMaterial(Slot);
                const bool Match=Expected==Actual;
                ++Checked;
                if(!Match) ++Failures;
                Rows+=FString::Printf(TEXT("%s,%d,%s,%s,%d\n"),*Component->GetName(),Slot,
                    *GetPathNameSafe(Expected),*GetPathNameSafe(Actual),Match?1:0);
            }
        }
    }
    if(Parts>0 && Parts!=21) ++Failures;
    const bool Success=Parts==0 || (Parts==21 && Checked==273 && Failures==0);
    FFileHelper::SaveStringToFile(Rows,*FPaths::Combine(Directory,TEXT("gallery_materials.csv")),FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM);
    FFileHelper::SaveStringToFile(FString::Printf(TEXT("parts=%d\nchecked=%d\nfailures=%d\nsuccess=%d\n"),Parts,Checked,Failures,Success?1:0),
        *FPaths::Combine(Directory,TEXT("gallery_material_result.txt")),FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM);
    return Success;
}
