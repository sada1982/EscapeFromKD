import argparse
import csv
import json
import math
from pathlib import Path


here = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description="Offline final A/B figures; run only after all measurements finish.")
parser.add_argument("--pair-a", type=Path, default=here / "FinalComparisonA" / "comparison.json")
parser.add_argument("--pair-b", type=Path, default=here / "FinalComparisonB" / "comparison.json")
parser.add_argument("--output", type=Path, default=here / "FinalReproducibility")
args = parser.parse_args()


def read_pairs(path):
    report = json.loads(path.read_text(encoding="utf-8-sig"))
    pairs = {pair["comparison"]: pair for pair in report["pairs"]}
    if len(pairs) != 3 or set(pairs) != {"survey", "full_route", "formal_route"}:
        raise ValueError("Expected one survey, full_route and formal_route pair: " + str(path))
    for pair in pairs.values():
        if set(pair["before"]["groups"]) != set(pair["after"]["groups"]):
            raise ValueError("Before/After group mismatch: " + str(path))
        for side in ("before", "after"):
            for group, values in pair[side]["groups"].items():
                if values["n"] < 1 or any(not math.isfinite(values[key]) or values[key] <= 0 for key in ("mean_ms", "p99_ms")):
                    raise ValueError("Invalid measured group: " + group)
    return report, pairs


def identity(pair, side):
    return str(Path(pair[side]["run"]).resolve()).casefold()


def direction(delta):
    if delta < -1e-9:
        return "lower"
    if delta > 1e-9:
        return "higher"
    return "equal"


def joint_direction(first, second):
    if first == second == "lower":
        return "lower_in_both"
    if first == second == "higher":
        return "higher_in_both"
    if first == second == "equal":
        return "equal_in_both"
    return "mixed_or_one_equal"


reports, pairs = {}, {}
for label, path in (("A", args.pair_a), ("B", args.pair_b)):
    reports[label], pairs[label] = read_pairs(path)

for mode in ("survey", "full_route"):
    identities = [identity(pairs[label][mode], side) for label in ("A", "B") for side in ("before", "after")]
    if len(set(identities)) != 4:
        raise ValueError(mode + " must contain four distinct runs across A/B")
for side in ("before", "after"):
    if identity(pairs["A"]["formal_route"], side) != identity(pairs["B"]["formal_route"], side):
        raise ValueError("Expected shared formal-route runs; do not silently count another repeat")
    if pairs["A"]["formal_route"][side]["groups"] != pairs["B"]["formal_route"][side]["groups"]:
        raise ValueError("Shared formal-route results differ between input reports")
if identity(pairs["A"]["formal_route"], "before") == identity(pairs["A"]["formal_route"], "after"):
    raise ValueError("Formal Before and After must be distinct runs")

scenes = [group[:-4] for group in pairs["A"]["survey"]["before"]["groups"] if group.endswith("/all")]
if len(scenes) != 14 or len(set(scenes)) != 14:
    raise ValueError("Expected exactly 14 survey scenes")
for label in ("A", "B"):
    actual = {group[:-4] for group in pairs[label]["survey"]["before"]["groups"] if group.endswith("/all")}
    if actual != set(scenes):
        raise ValueError("A/B scene mismatch")
    for scene in scenes:
        for number in (1, 2):
            if scene + "/round_" + str(number) not in pairs[label]["survey"]["before"]["groups"]:
                raise ValueError("Missing scene round: " + scene)

metrics = ("mean_ms", "p99_ms", "over_rate_pct")
directions = []
for mode in ("survey", "full_route"):
    if set(pairs["A"][mode]["before"]["groups"]) != set(pairs["B"][mode]["before"]["groups"]):
        raise ValueError("A/B group mismatch: " + mode)
    for group in pairs["A"][mode]["before"]["groups"]:
        for metric in metrics:
            values = {}
            for label in ("A", "B"):
                pair = pairs[label][mode]
                old = pair["before"]["groups"][group][metric]
                new = pair["after"]["groups"][group][metric]
                values[label] = dict(before=old, after=new, delta_after_minus_before=new-old, direction=direction(new-old))
            directions.append(dict(comparison=mode, group=group, metric=metric, A=values["A"], B=values["B"],
                                   joint_direction=joint_direction(values["A"]["direction"], values["B"]["direction"])))

scene_counts = {}
for number in (1, 2):
    key = "round_" + str(number)
    scene_counts[key] = {}
    for metric in metrics:
        selected = [row for row in directions if row["comparison"] == "survey" and row["group"].endswith("/" + key) and row["metric"] == metric]
        if len(selected) != 14:
            raise ValueError("Incomplete scene direction summary")
        scene_counts[key][metric] = {kind: sum(row["joint_direction"] == kind for row in selected)
                                     for kind in ("lower_in_both", "higher_in_both", "equal_in_both", "mixed_or_one_equal")}

limits = [
    "Pair A is Before then After; pair B is After then Before. Two order-reversed observations are not a statistical causal guarantee.",
    "Round 1 follows the startup gate and 120 warm frames per scene; it is not a completely cold first visit. Round 2 is kept separate.",
    "P99 values are the existing nearest-rank statistics, not averaged percentiles. Scene rounds and route first/warm groups are never pooled here.",
    "Direction is the numerical sign of After minus Before (1e-9 tolerance), not a claim of practical or statistically significant improvement.",
    "Formal route uses the same shared Before and After runs in both inputs: two runs total, not four independent observations. It has no A/B reproducibility score.",
    "Full-route and formal-route use different paths and are not compared against one another. Original input limitations and all source group statistics are retained.",
]
result = dict(inputs={"A": str(args.pair_a.resolve()), "B": str(args.pair_b.resolve())},
              execution_orders={"A": ["before", "after"], "B": ["after", "before"]},
              independent_run_counts={"survey": 4, "full_route": 4, "shared_formal_route": 2},
              scene_order=scenes, scene_direction_counts=scene_counts, directions=directions,
              source_groups={label: {mode: {side: dict(run=pair[side]["run"], groups=pair[side]["groups"])
                                          for side in ("before", "after")}
                                    for mode, pair in pairs[label].items() if mode != "formal_route"}
                             for label in ("A", "B")},
              shared_formal_route={side: dict(run=pairs["A"]["formal_route"][side]["run"], groups=pairs["A"]["formal_route"][side]["groups"])
                                   for side in ("before", "after")},
              source_limits={label: reports[label].get("limits", []) for label in ("A", "B")}, limits=limits)

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

args.output.mkdir(parents=True, exist_ok=False)
budget = 1000 / 60
for number in (1, 2):
    round_name = "round_" + str(number)
    fig, axes = plt.subplots(1, 2, figsize=(16, 9), sharex=True, sharey=True)
    maximum = max(pairs[label]["survey"][side]["groups"][scene + "/" + round_name]["p99_ms"]
                  for label in ("A", "B") for side in ("before", "after") for scene in scenes)
    for axis, label in zip(axes, ("A", "B")):
        for side, shift, color in (("before", -.18, "#657489"), ("after", .18, "#087f8c")):
            values = [pairs[label]["survey"][side]["groups"][scene + "/" + round_name]["p99_ms"] for scene in scenes]
            axis.barh([index + shift for index in range(len(scenes))], values, height=.34, label=side.title(), color=color)
        axis.axvline(budget, color="#b83232", linestyle="--", linewidth=1.2, label="60 FPS budget (16.67 ms)")
        axis.set_title("Pair " + label + (": Before > After execution order" if label == "A" else ": After > Before execution order"))
        axis.set_xlabel("Present interval P99 (ms); lower is better")
        axis.set_xlim(0, max(maximum, budget) * 1.12)
        axis.set_yticks(range(len(scenes)), scenes)
        axis.grid(axis="x", alpha=.18)
        axis.set_axisbelow(True)
        axis.legend(loc="lower right", fontsize=8)
    axes[0].invert_yaxis()
    fig.suptitle("14-scene P99 | Round " + str(number) + (" (after startup and per-view warm frames)" if number == 1 else " (second pass)"), fontsize=14)
    fig.text(.5, .015, "Two independent order-reversed survey pairs. Formal-route shared runs are excluded from these figures.", ha="center", fontsize=9)
    fig.tight_layout(rect=(0, .035, 1, .96))
    fig.savefig(args.output / ("scene_p99_" + round_name + ".png"), dpi=180)
    fig.savefig(args.output / ("scene_p99_" + round_name + ".svg"))
    plt.close(fig)

(args.output / "reproducibility.json").write_text(json.dumps(result, indent=2), encoding="utf8")
with (args.output / "directions.csv").open("w", encoding="utf-8-sig", newline="") as stream:
    writer = csv.writer(stream)
    writer.writerow(["comparison", "group", "metric", "A_before", "A_after", "A_delta", "A_direction", "B_before", "B_after", "B_delta", "B_direction", "joint_direction"])
    for row in directions:
        writer.writerow([row["comparison"], row["group"], row["metric"],
                         *[row[label][key] for label in ("A", "B") for key in ("before", "after", "delta_after_minus_before", "direction")], row["joint_direction"]])
lines = ["Final A/B numerical direction check", "", "Survey: four runs. Full route: four runs. Shared formal route: two runs, counted once.", ""]
for round_name, counts in scene_counts.items():
    for metric, count in counts.items():
        lines.append(round_name + " / " + metric + " / " + ", ".join(key + "=" + str(value) for key, value in count.items()))
lines += ["", "Full-route first/warm summaries (After minus Before):"]
for row in directions:
    if row["comparison"] == "full_route" and row["group"] in ("first_lap", "warm_laps"):
        lines.append(row["group"] + " / " + row["metric"] + " / A=" + format(row["A"]["delta_after_minus_before"], ".6f") + " / B=" + format(row["B"]["delta_after_minus_before"], ".6f") + " / " + row["joint_direction"])
lines += ["", *limits, "", "All original scene rounds, route laps and waypoint first/warm statistics remain in reproducibility.json."]
(args.output / "reproducibility.txt").write_text("\n".join(lines) + "\n", encoding="utf8")
print("Wrote", args.output, "with separate round-1/round-2 figures and shared formal-route runs counted only once.")
