import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile

here = Path(__file__).resolve().parent
source = here / "Variants/GateAll15/Windows"
pak_relative = Path("myProject/Content/Paks/myProject-Windows.pak")
exe_relative = Path("myProject/Binaries/Win64/myProject-Win64-Shipping.exe")
entry = "myProject/Config/Windows/WindowsEngine.ini"
unreal_pak = Path("C:/Program Files/Epic Games/UE_5.8/Engine/Binaries/Win64/UnrealPak.exe")
scratch = Path(tempfile.mkdtemp(prefix="KDWorkerPak_"))

def digest(path):
    result = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(4 * 1024 * 1024), b""):
            result.update(block)
    return result.hexdigest()

def run(*arguments):
    result = subprocess.run([str(unreal_pak), *map(str, arguments)], stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW)
    text = result.stdout.decode(errors="replace")
    with (scratch / "unrealpak.log").open("a", encoding="utf8") as log:
        log.write(text)
    result.check_returncode()
    return text

def entries(path):
    rows = re.findall(r'"([^"\r\n]+)" offset: [^\r\n]+?sha1: ([0-9A-Fa-f]+), compression: (\w+)\.', run(path, "-List"))
    return {name: (sha1, compression) for name, sha1, compression in rows}

original = entries(source / pak_relative)
assert len(original) == 1773 and entry in original
source_pak_hash = digest(source / pak_relative)
source_exe_hash = digest(source / exe_relative)
containers = {str(path.relative_to(source)): digest(path) for path in (source / pak_relative.parent).iterdir()
              if path.suffix in (".ucas", ".utoc")}
raw = scratch / "raw"
run(source / pak_relative, "-Extract", raw)
settings_before = (raw / entry).read_text(encoding="utf-8-sig")
assert "r.PSOPrecaching.MinPriorityForActivePrecacheRequests=0" in settings_before
assert "r.pso.PrecompileThreadPoolSizeMax" not in settings_before
listing = scratch / "files.txt"
listing.write_text("\n".join('"' + (raw / key).as_posix() + '" "../../../' + key + '"' +
                            (" -compress" if compression != "None" else "")
                            for key, (_, compression) in original.items()) + "\n", encoding="utf8")
for workers in (8, 4):
    name = "GateAll" + str(workers)
    output = here / "Variants" / name
    output.mkdir(exist_ok=False)
    windows = output / "Windows"
    linked = []
    for path in source.rglob("*"):
        if not path.is_file():
            continue
        relative = path.relative_to(source)
        if relative == pak_relative or "Saved" in relative.parts:
            continue
        destination = windows / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        os.link(path, destination)
        assert os.path.samefile(path, destination)
        linked.append(str(relative))
    settings = settings_before + "\nr.pso.PrecompileThreadPoolSizeMax=" + str(workers) + "\n"
    (raw / entry).write_text(settings, encoding="utf8")
    run(windows / pak_relative, "-Create=" + str(listing), "-patchpaddingalign=2048", "-compressionformats=Oodle",
        "-compresslevel=4", "-compressmethod=Kraken", "-platform=Windows", "-unattended")
    run(windows / pak_relative, "-Test")
    modified = entries(windows / pak_relative)
    assert set(original) == set(modified)
    changed = [key for key in original if original[key] != modified[key]]
    assert changed == [entry], changed
    run(windows / pak_relative, "-Extract", scratch / name, "-Filter=" + entry)
    assert (scratch / name / entry).read_text(encoding="utf-8-sig") == settings
    proof = dict(name=name, baseline=False, production=False, max_workers=workers,
                 parent="GateAll15", exe=str(windows / exe_relative), exe_sha256=source_exe_hash,
                 pak_sha256=digest(windows / pak_relative), parent_pak_sha256=source_pak_hash,
                 pak_changed_entry=entry, other_pak_entries_unchanged=len(original)-1,
                 settings=settings, iostore_sha256=containers, hardlinked_files=linked,
                 unrealpak_test="passed", scratch=str(scratch))
    (output / "proof.json").write_text(json.dumps(proof, indent=2), encoding="utf8")
    print(name + ": only pool maximum changed; 1772 other entries unchanged; identical executable and IoStore", flush=True)
assert digest(source / pak_relative) == source_pak_hash
assert digest(source / exe_relative) == source_exe_hash
print("GateAll15 original unchanged", flush=True)
