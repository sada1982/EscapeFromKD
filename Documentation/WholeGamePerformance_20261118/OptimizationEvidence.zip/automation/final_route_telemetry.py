import bisect
import csv
import json
import re
import statistics
import sys
from pathlib import Path


here = Path(__file__).resolve().parent
names = sys.argv[1:]
assert names
waypoints = re.findall(r'\{TEXT\("([^"]+)"\)', (here / "FullRoute.h").read_text(encoding="utf8"))


def read(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def stats(rows, field):
    values = [float(row[field]) for row in rows if row[field] not in ("", "[N/A]")]
    return dict(n=len(values), mean=statistics.mean(values), min=min(values), max=max(values)) if values else dict(n=0)


result = []
for name in names:
    run = here / name
    validation = json.loads((here / (name + "Control") / "validation.json").read_text(encoding="utf8"))
    assert validation["complete"] and not validation["invalid"]
    assert validation["mode"] in ("full-route", "formal-route")
    meta = json.loads((run / "metadata.json").read_text(encoding="utf8"))
    summary = json.loads((run / "summary.json").read_text(encoding="utf8"))
    frequency = meta["start"]["frequency"]
    route = Path(meta["route"])
    events = read(route / "events.csv")
    processes = read(run / "monitor_process.csv")
    gpu = read(run / "monitor_nvidia.csv")
    game = [row for row in processes if row["role"] == "game"]
    game_qpcs = [int(row["qpc"]) for row in game]
    intervals = read(run / "intervals.csv")
    presents = {int(row["QPCTime"]): row for row in read(run / "presents_native.csv")}
    windows = []
    for label, window in summary["windows"].items():
        if "_leg_" in label:
            continue
        begin, end = window["start"], window["end"]
        rows = [row for row in game if begin <= int(row["qpc"]) <= end]
        assert len(rows) >= 2
        seconds = (int(rows[-1]["qpc"])-int(rows[0]["qpc"]))/frequency
        cpu_seconds = sum(int(rows[-1][key])-int(rows[0][key]) for key in ("kernel_100ns", "user_100ns"))/1e7
        gpu_rows = [row for row in gpu if begin <= int(row["qpc_delivery"]) <= end]
        windows.append(dict(window=label, q0=begin, q1=end, measured_cpu_seconds=seconds,
                            game_cpu_core_equivalent=cpu_seconds/seconds, present=window,
                            local_usage_B=stats(rows, "local_usage_B"), local_budget_B=stats(rows, "local_budget_B"),
                            local_headroom_min_B=min(int(row["local_budget_B"])-int(row["local_usage_B"]) for row in rows),
                            nonlocal_usage_B=stats(rows, "nonlocal_usage_B"),
                            process_evicted_B_delta=int(rows[-1]["evicted_process_B"])-int(rows[0]["evicted_process_B"]),
                            read_B_delta=int(rows[-1]["read_bytes"])-int(rows[0]["read_bytes"]),
                            gpu={field: stats(gpu_rows, field) for field in ("utilization.gpu [%]", "clocks.current.graphics [MHz]", "temperature.gpu", "power.draw [W]", "memory.used [MiB]")},
                            thermal_active_samples=sum(row["clocks_event_reasons.sw_thermal_slowdown"] == "Active" or row["clocks_event_reasons.hw_thermal_slowdown"] == "Active" for row in gpu_rows),
                            power_cap_samples=sum(row["clocks_event_reasons.sw_power_cap"] == "Active" for row in gpu_rows)))
    peaks = []
    for interval in sorted(intervals, key=lambda row: -float(row["ms"]))[:8]:
        begin, end = int(interval["q0"]), int(interval["q1"])
        lap = int(interval["window"].split("_")[1])
        targets = [row for row in events if row["event"] == "waypoint" and int(row["lap"]) == lap and int(row["qpc"]) >= end]
        target = targets[0] if targets else None
        left = max(0, bisect.bisect_right(game_qpcs, begin)-1)
        right = min(len(game)-1, bisect.bisect_left(game_qpcs, end))
        a, b = game[left], game[right]
        seconds = (int(b["qpc"])-int(a["qpc"]))/frequency
        present = presents.get(end)
        peak = dict(interval=interval, target_waypoint=target,
                    target_name=waypoints[int(target["leg"])] if target and validation["mode"] == "full-route" else None,
                    present_api_ms=float(present["msInPresentAPI"]) if present else None,
                    bracket_seconds=seconds,
                    bracket_cpu_core_equivalent=sum(int(b[key])-int(a[key]) for key in ("kernel_100ns", "user_100ns"))/1e7/seconds,
                    bracket_read_B=int(b["read_bytes"])-int(a["read_bytes"]),
                    bracket_process_evicted_B=int(b["evicted_process_B"])-int(a["evicted_process_B"]))
        peaks.append(peak)
    result.append(dict(name=name, mode=validation["mode"], gate=validation["gate"], windows=windows, longest_intervals=peaks))

report = dict(method="OS CPU cumulative user+kernel deltas between first and last approximately one-second observations fully inside each lap. This excludes boundaries, is aggregate parallel CPU rather than a critical path, and is not a direct PSO attribution. GPU samples are delivery-QPC snapshots. Spike brackets include neighboring frames. Route laps2+ are revisits, not proof of completed PSO warmup.", runs=result)
(here / "final_route_telemetry.json").write_text(json.dumps(report, indent=2), encoding="utf8")
for run in result:
    print(run["name"])
    for row in run["windows"]:
        print(row["window"], "CPU cores", round(row["game_cpu_core_equivalent"], 3), "GPU MHz", round(row["gpu"]["clocks.current.graphics [MHz]"]["mean"], 2), "GPU C", round(row["gpu"]["temperature.gpu"]["mean"], 2), "min headroom MiB", round(row["local_headroom_min_B"]/2**20, 2))
    for peak in run["longest_intervals"][:2]:
        print("peak", peak["interval"], peak["target_name"], "Present", peak["present_api_ms"], "bracket CPU cores", round(peak["bracket_cpu_core_equivalent"], 2))
