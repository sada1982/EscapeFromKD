import csv
import json
import mmap
from pathlib import Path
import struct

base = Path(__file__).resolve().parent
folder = base/'AllWaitCPU2Trace'
trace = Path('C:/Users/motoo/AppData/Local/Temp/KDWholeGame_w8myswcy/game.utrace')
threads = list(csv.DictReader((folder/'threads.csv').open(encoding='utf-8-sig')))
sampled_tids = {int(row['tid']) for row in csv.DictReader((base/'AllWaitCPU2Threads/thread_cpu.csv').open(encoding='utf-8-sig'))}
records = []
with trace.open('rb') as stream, mmap.mmap(stream.fileno(), 0, access=mmap.ACCESS_READ) as data:
    for thread in threads:
        trace_id = int(thread['Id'])
        if trace_id >= 65536:
            continue
        name = thread['Name'].encode('utf8')+b'\0'
        found, offset = [], 0
        while True:
            offset = data.find(name, offset)
            if offset<0:
                break
            if offset>=18:
                internal, native, priority, aux = struct.unpack_from('<IIiI', data, offset-16)
                if internal==trace_id and (aux>>13)==len(name) and ((aux>>8)&31)==3 and (aux&255)==2 and data[offset+len(name)]==6 and native in sampled_tids:
                    found.append(dict(trace_id=internal, os_tid=native, name=thread['Name'], sort_hint=priority, name_byte_offset=offset, fragment_hex=data[offset-18:offset+len(name)+1].hex()))
            offset += len(name)
        identities = {(row['trace_id'],row['os_tid'],row['name']) for row in found}
        if len(identities)>1:
            raise RuntimeError('Conflicting thread fragments '+thread['Name'])
        if found:
            records.append(found[0])
result = dict(trace=str(trace), method='Supplementary raw uncompressed ThreadInfo fragment extraction, not a complete trace packet decoder. Every record matches the standard Insights-exported trace ID/name, UE ThreadInfo field order, Aux field index3/size/name terminator, and a TID actually observed by the concurrent OS sampler. Compressed or split fragments may be omitted. Do not infer unmapped thread names.', sources=['Runtime/TraceLog/Private/Trace/Trace.cpp:20-25,86-92','Runtime/TraceLog/Public/Trace/Detail/Protocols/Protocol5.h:88-92'], records=records)
(folder/'thread_system_map.json').write_text(json.dumps(result,indent=2),encoding='utf8')
print(json.dumps(dict(mapped=len(records),records=[{k:v for k,v in row.items() if k!='fragment_hex'} for row in records]),indent=2))
