import csv
import json
import math
from pathlib import Path
import statistics


here = Path(__file__).resolve().parent
names = ["ModelPerfBaseA", "ModelPerfGallery", "ModelPerfFurniture", "ModelPerfLaptop", "ModelPerfBaseB"]
scenes = ["ClassroomStart", "ClassroomMiddle", "ClassroomExit", "Gallery3F", "Atrium3FDown"]
results = []
for name in names:
    audit = json.loads((here / name / "audit.json").read_text(encoding="utf8"))
    windows = json.loads((here / (name + "Window") / "sample_window_audit.json").read_text(encoding="utf8"))
    assert audit["valid"] and windows["all_rounds_observed_stable"]
    with (here / name / "scene_intervals.csv").open(encoding="utf-8-sig", newline="") as stream:
        values = sorted(float(row["ms"]) for row in csv.DictReader(stream))
    assert len(values) == 5990
    overall = dict(n=len(values), mean_ms=statistics.mean(values), fps=1000/statistics.mean(values),
                   p99_ms=values[math.ceil(.99*len(values))-1], max_ms=values[-1],
                   over=sum(value > 1000/60 for value in values))
    results.append(dict(name=name, overall=overall, audit=audit, window_audit=windows))

baseline_a, baseline_b = results[0], results[-1]
for result in results:
    result["scene_mean_delta_from_base_a_ms"] = {scene: result["audit"]["per_scene"][scene]["mean_ms"]-baseline_a["audit"]["per_scene"][scene]["mean_ms"] for scene in scenes}
    result["scene_mean_delta_from_base_b_ms"] = {scene: result["audit"]["per_scene"][scene]["mean_ms"]-baseline_b["audit"]["per_scene"][scene]["mean_ms"] for scene in scenes}
    result["overall_mean_delta_from_base_a_ms"] = result["overall"]["mean_ms"]-baseline_a["overall"]["mean_ms"]
    result["overall_mean_delta_from_base_b_ms"] = result["overall"]["mean_ms"]-baseline_b["overall"]["mean_ms"]

lines = ["Model runtime performance screen / 2026-11-18", "",
         "No candidate demonstrates a consistent performance improvement over the bracketed baseline runs.",
         "All five runs: normal game/monitor exit0, success1/invalid0, five scenes x two rounds x 600 samples; 5990 Present intervals per run.",
         "Same diagnostic harness and recorded render settings; isolated asset variants. Editor remained open and maximized in all ten sampled windows per run; no Editor foreground observations.",
         "Read-only window watcher at 250ms cannot exclude shorter transitions. Other application focus changes are retained in detailed JSON.", "",
         "Run | Pooled mean ms | FPS | P99 ms | >16.67ms /5990 | GPU MHz | GPU C | GPU-wide VRAM MiB | Game local VRAM MiB"]
for result in results:
    overall, audit = result["overall"], result["audit"]
    gpu, process = audit["gpu"], audit["process"]["game"]
    lines.append(f'{result["name"]} | {overall["mean_ms"]:.5f} | {overall["fps"]:.3f} | {overall["p99_ms"]:.4f} | {overall["over"]} | {gpu["clocks.current.graphics [MHz]"]["mean"]:.2f} | {gpu["temperature.gpu"]["mean"]:.2f} | {gpu["memory.used [MiB]"]["mean"]:.2f} | {process["local_usage_B"]["mean"]/1048576:.2f}')
lines += ["", "Scene order: ClassroomStart / ClassroomMiddle / ClassroomExit / Gallery3F / Atrium3FDown", "Each cell: mean ms, P99 ms, >16.67ms count /1198"]
for result in results:
    lines.append(result["name"] + " / " + " / ".join(f'{result["audit"]["per_scene"][scene]["mean_ms"]:.5f},{result["audit"]["per_scene"][scene]["p99_ms"]:.4f},{result["audit"]["per_scene"][scene]["over"]}' for scene in scenes))
lines += ["", "All observed GPU memory clocks6001MHz, P0, software power capActive; thermal slowdownNot Active. Game evicted-process bytes0 throughout.",
          "GPU-wide VRAM includes Editor and desktop; differences are not solely model memory savings. Per-process game memory and budget retained in JSON.",
          "One ordered run per candidate, reverse scene order on round2. Baseline bracket is a time-drift check, not randomized repeated statistical evidence.",
          "Quality is a separate prerequisite: FurnitureProbe2 is held for wavy chair shading; GalleryFixed2 retains slight Lumen brightness differences; LaptopProbe2 passed conditionally with minor bevel/reflection differences.",
          "No production asset/settings or Editor UI modification performed by this matrix. Candidate adoption requires root review; this performance screen does not justify adoption.",
          "Evidence: each run metadata.json/summary.json/audit.json/scene_intervals.csv and each Window/sample_window_audit.json; runtime proof files are at metadata.route."]
text = "\n".join(lines) + "\n"
(here / "model_perf_comparison.txt").write_text(text, encoding="utf8")
(here / "model_perf_comparison.json").write_text(json.dumps(dict(runs=results, scenes=scenes, interpretation=lines), indent=2), encoding="utf8")
print(text)
