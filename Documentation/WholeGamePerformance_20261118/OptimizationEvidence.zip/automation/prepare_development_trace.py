import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

here = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument("--build", action="store_true")
args = parser.parse_args()
baseline = here / "Variants/OptProbe2"
output = here / "Variants/AllWaitTrace"
snapshot = output / "SourceSnapshot"
snapshot.mkdir(parents=True, exist_ok=True)
for path in (baseline / "SourceSnapshot").iterdir():
    if path.is_file():
        shutil.copyfile(path, snapshot / path.name)
survey = (snapshot / "Survey.h").read_text(encoding="utf-8-sig")

def replace(old, new):
    global survey
    assert survey.count(old) == 1, old
    survey = survey.replace(old, new)

replace("    double LastShot=0;", "    double LastShot=0,SampleSeconds=0;\n    uint64 SampleBeginQpc=0,LastPendingQpc=0;")
replace('        FParse::Value(FCommandLine::Get(),TEXT("KDSurveySampleFrames="),SampleFrames);',
        '        FParse::Value(FCommandLine::Get(),TEXT("KDSurveySampleFrames="),SampleFrames);\n'
        '        FParse::Value(FCommandLine::Get(),TEXT("KDSurveySampleSeconds="),SampleSeconds);\n'
        '        SampleSeconds=FMath::Clamp(SampleSeconds,0.0,120.0);\n'
        '        Write(FPaths::Combine(Dir,TEXT("survey_duration.txt")),FString::Printf(TEXT("sample_seconds=%.3f\\n"),SampleSeconds));')
replace("        const double Progress=Phase==EPhase::Sample?static_cast<double>(Frame)/SampleFrames:0;",
        "        const double Progress=Phase==EPhase::Sample?(SampleSeconds>0?"
        "static_cast<double>(FPlatformTime::Cycles64()-SampleBeginQpc)*FPlatformTime::GetSecondsPerCycle64()/SampleSeconds:"
        "static_cast<double>(Frame)/SampleFrames):0;")
replace("            Phase=EPhase::Sample;", "            Phase=EPhase::Sample;\n            SampleBeginQpc=LastPendingQpc=FPlatformTime::Cycles64();")
replace("            const uint64 Now=FPlatformTime::Cycles64();", "            const uint64 Now=FPlatformTime::Cycles64();\n"
        "            if (SampleSeconds>0 && static_cast<double>(Now-LastPendingQpc)*FPlatformTime::GetSecondsPerCycle64()>=1.0)\n"
        '            { Mark(TEXT("cpu_watch"),Now,Char,Player);LastPendingQpc=Now; }')
replace("            if (Frame<SampleFrames) return;", "            if (SampleSeconds>0?"
        "static_cast<double>(Now-SampleBeginQpc)*FPlatformTime::GetSecondsPerCycle64()<SampleSeconds:Frame<SampleFrames) return;")
(snapshot / "Survey.h").write_text(survey, encoding="utf8")
proof = json.loads((baseline / "proof.json").read_text(encoding="utf8"))
assert "r.PSOPrecaching.MinPriorityForActivePrecacheRequests=0\n" in proof["settings"]
assert "r.PSOPrecaching.TaskPriorityThreshold=0\n" in proof["settings"]
plan = dict(source=str(snapshot), containers_from=str(baseline / "Windows"),
            configuration="Development", purpose="Diagnostic only; not a distribution build",
            extra_args=["-KDSurveyScenes=ClassroomStart", "-KDSurveyRounds=1", "-KDSurveyWarmFrames=120",
                        "-KDSurveySampleSeconds=60", "-KDSurveySampleFrames=2400"],
            known_exit_caveat="Prior Development trace ended with 777003 after data completion. Check result/trace separately; do not call it normal exit 0.",
            baseline_pak_sha256=proof["pak_sha256"],
            source_sha256={p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in snapshot.iterdir() if p.is_file()})
(output / "plan.json").write_text(json.dumps(plan, indent=2), encoding="utf8")
if not args.build:
    print("Prepared only:", snapshot)
    sys.exit(0)

work = Path(os.environ["LOCALAPPDATA"]) / "KDGateTraceDev_20261117"
module = work / "Source/myProject"
assert (work / "myProject.uproject").is_file()
for path in snapshot.iterdir():
    if path.is_file():
        shutil.copyfile(path, module / path.name)
tool = Path("C:/Program Files/Epic Games/UE_5.8/Engine/Build/BatchFiles/Build.bat")
with (output / "build.log").open("wb") as log:
    result = subprocess.run([str(tool), "myProject", "Win64", "Development", "-Project=" + str(work / "myProject.uproject"),
                             "-NoLiveCoding", "-NoHotReload", "-WaitMutex"], stdout=log, stderr=log,
                            creationflags=subprocess.CREATE_NO_WINDOW)
if result.returncode:
    print((output / "build.log").read_text(encoding="utf8", errors="replace")[-6000:])
    sys.exit(result.returncode)
target = output / "Windows"
target.mkdir(exist_ok=False)
template = here.parent / "WholeGame_20261118/Development/Windows"
inner = Path("myProject/Binaries/Win64/myProject.exe")
pak_dir = Path("myProject/Content/Paks")
for path in template.rglob("*"):
    if not path.is_file():
        continue
    rel = path.relative_to(template)
    if rel == inner or rel.is_relative_to(pak_dir) or "Saved" in rel.parts:
        continue
    dest = target / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    os.link(path, dest)
containers = {}
for path in (baseline / "Windows" / pak_dir).iterdir():
    if not path.is_file():
        continue
    dest = target / pak_dir / path.name
    dest.parent.mkdir(parents=True, exist_ok=True)
    os.link(path, dest)
    assert os.path.samefile(path, dest)
    containers[path.name] = dict(source=str(path), samefile=True, bytes=path.stat().st_size)
assert len(containers) == 5
(target / inner).parent.mkdir(parents=True, exist_ok=True)
shutil.copyfile(work / "Binaries/Win64/myProject.exe", target / inner)
plan.update(exe=str(target / inner), containers=containers,
            exe_sha256=hashlib.sha256((target / inner).read_bytes()).hexdigest())
(output / "proof.json").write_text(json.dumps(plan, indent=2), encoding="utf8")
print(target / inner)
