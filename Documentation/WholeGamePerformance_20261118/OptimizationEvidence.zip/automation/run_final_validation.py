import argparse
import csv
import ctypes as c
from ctypes import wintypes as w
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time


here = Path(__file__).resolve().parent
exe_relative = Path("myProject/Binaries/Win64/myProject-Win64-Shipping.exe")
scenes = ["ClassroomStart", "ClassroomMiddle", "ClassroomExit", "Gallery3F", "Atrium3FDown", "Stairs3F", "Gallery2F", "Plaza2F", "Atrium1F", "Atrium1FUp", "Hall1F", "Exit1F", "CombatIdle", "CombatFire"]


def read_values(path):
    return dict(line.split("=", 1) for line in path.read_text(encoding="utf-8-sig").splitlines() if "=" in line)


def read_rows(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def digest(path):
    value = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(4 * 1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()


def hidden(command, log):
    with log.open("wb") as stream:
        return subprocess.Popen(command, stdout=stream, stderr=stream, creationflags=subprocess.CREATE_NO_WINDOW)


def read_power():
    class Power(c.Structure):
        _fields_ = [("ac", w.BYTE), ("battery_flags", w.BYTE), ("battery_percent", w.BYTE),
                    ("saver", w.BYTE), ("life_seconds", w.DWORD), ("full_seconds", w.DWORD)]
    kernel = c.WinDLL("kernel32", use_last_error=True)
    kernel.GetSystemPowerStatus.argtypes = [c.POINTER(Power)]
    kernel.GetSystemPowerStatus.restype = w.BOOL
    power = Power()
    ok = bool(kernel.GetSystemPowerStatus(c.byref(power)))
    return dict(api_ok=ok, ac_power=int(power.ac), battery_percent=int(power.battery_percent), utc_epoch_ns=time.time_ns())


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("exe", type=Path)
    parser.add_argument("name")
    parser.add_argument("--mode", choices=["survey", "full-route", "formal-route", "stress-ten"], default="survey")
    parser.add_argument("--baseline", action="store_true")
    parser.add_argument("--editor", type=int, default=27448)
    parser.add_argument("--state", type=Path, default=here / "editor_minimize_A2.json")
    parser.add_argument("--expected-window", choices=["maximized", "normal"], default="maximized")
    parser.add_argument("--condition-evidence", type=Path, default=here / "editor_session_restored.json")
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args()
    assert args.name.isalnum()
    exe = args.exe.resolve()
    distribution = exe.parents[3]
    assert exe.relative_to(distribution) == exe_relative
    run = here / args.name
    watch = here / (args.name + "Window")
    threads = here / (args.name + "Threads")
    control = here / (args.name + "Control")
    deploy = here / "FreshDeployments" / args.name / "Windows"
    timeout = {"survey": 600, "full-route": 900, "formal-route": 1200, "stress-ten": 600}[args.mode]
    extras = []
    if args.mode == "survey":
        extras = ["-KDSurveyScenes=" + ",".join(scenes), "-KDSurveyRounds=2", "-KDSurveyWarmFrames=120", "-KDSurveySampleFrames=600"]
    elif args.mode == "full-route":
        extras = ["--walk", "-KDFullRoute", "-KDExhibitLaps=4"]
    elif args.mode == "formal-route":
        extras = ["--walk", "-KDExhibitLaps=20"]
    else:
        extras = ["-KDEnemyStress", "-KDStressEnemies=10", "-KDStressSeconds=120", "-KDStressSite=atrium"]
    command = [sys.executable, "-B", str(here / "run_suite.py"), str(deploy / exe_relative), args.name,
               "--editor", str(args.editor), "--timeout", str(timeout), *extras]
    plan = dict(name=args.name, mode=args.mode, source=str(distribution), source_exe=str(exe), deploy=str(deploy),
                run=str(run), watcher=str(watch), threads=str(threads) if args.mode == "stress-ten" else None,
                runner=command, baseline=args.baseline, timeout_seconds=timeout,
                gate_policy="legacy baseline: settled or timeout; never label this as all-wait proof" if args.baseline else "require settled, priority0, ordered hidden views, restored input",
                conditions=dict(editor_pid=args.editor, editor_expected="open, " + args.expected_window + ", nonforeground", expected_window=args.expected_window, expected_slate_sleep=0,
                                evidence=str(args.condition_evidence.resolve()),
                                evidence_method="Root supplied MCP readback record; this wrapper does not query or change Editor CVars. The window watcher reads placement and foreground only."),
                freshness="New executable pathname and UserDir for this mode only. OS/driver global caches not cleared. Never reuse a survey deployment for first-visit route checks.",
                instrumentation="Shipping private-desktop runner, PresentMon and process/GPU monitor, read-only250ms window watcher; thread CPU sampler additionally enabled only for stress-ten.")
    if not args.execute:
        print(json.dumps(plan, indent=2))
        return
    exe = exe.resolve(strict=True)
    for path in (run, watch, threads, control, deploy.parent):
        if path.exists():
            raise FileExistsError(path)
    evidence = json.loads(args.condition_evidence.read_text(encoding="utf8"))
    assert evidence["restored_value"] == 0 and evidence["editor_maximized"] == (args.expected_window == "maximized")
    plan["conditions"]["supplied_record"] = evidence
    plan["exe_sha256"] = digest(exe)
    proof_path = distribution.parent / "proof.json"
    if proof_path.is_file():
        proof = json.loads(proof_path.read_text(encoding="utf8"))
        assert proof["exe_sha256"] == plan["exe_sha256"]
        if "baseline" in proof:
            assert proof["baseline"] == args.baseline, "Gate policy differs from the supplied build proof"
        if args.mode != "formal-route":
            assert not proof.get("production", False), "This mode requires diagnostic helpers"
        plan["source_proof"] = dict(path=str(proof_path), contents=proof)
    control.mkdir()
    linked = []
    for source in distribution.rglob("*"):
        if not source.is_file():
            continue
        relative = source.relative_to(distribution)
        if "Saved" in relative.parts:
            continue
        source.resolve().relative_to(distribution)
        target = deploy / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        os.link(source, target)
        assert os.path.samefile(source, target)
        linked.append(dict(path=str(relative), size=source.stat().st_size))
    plan["hardlink_identity_verified"] = True
    plan["linked_files"] = linked
    (control / "plan.json").write_text(json.dumps(plan, indent=2), encoding="utf8")
    watcher = hidden([sys.executable, "-B", str(here / "watch_editor_window.py"), str(run / "metadata.json"),
                      str(watch), "--state", str(args.state), "--seconds", str(timeout+240)], control / "watcher.log")
    runner = sampler = None
    try:
        deadline = time.monotonic() + 15
        while not (watch / "ready.json").is_file():
            if watcher.poll() is not None or time.monotonic() >= deadline:
                raise RuntimeError("Window watcher not ready; no game launched")
            time.sleep(.1)
        initial = json.loads((watch / "ready.json").read_text(encoding="utf8"))
        window = initial["initial_window"]
        assert not window["iconic"]
        assert (window["zoomed"] and window["showCmd"] == 3) if args.expected_window == "maximized" else (not window["zoomed"] and window["showCmd"] == 1)
        assert window["pid"] == args.editor and initial["initial_foreground"]["pid"] != args.editor
        expected = json.loads(args.state.read_text(encoding="utf8"))["original"]
        assert window["normal_rect"] == expected["normal_rect"] and window["hwnd"] == expected["hwnd"]
        if "normal_rect" in evidence:
            assert window["normal_rect"] == evidence["normal_rect"]
        power_condition = dict(prelaunch=read_power(), valid=None)
        plan["power_condition"] = power_condition
        if not power_condition["prelaunch"]["api_ok"] or power_condition["prelaunch"]["ac_power"] != 1:
            power_condition["valid"] = False
            (control / "validation.json").write_text(json.dumps(dict(complete=False, invalid=True, reason="ac_required_before_launch", power_condition=power_condition), indent=2), encoding="utf8")
            raise RuntimeError("AC power is absent or unknown; game not launched")
        runner = hidden(command, control / "runner.log")
        deadline = time.monotonic() + 20
        while not (run / "metadata.json").is_file():
            if runner.poll() is not None or time.monotonic() >= deadline:
                raise RuntimeError("Runner metadata missing; inspect execution state before another launch")
            time.sleep(.1)
        if args.mode == "stress-ten":
            sampler = hidden([sys.executable, "-B", str(here / "sample_thread_cpu.py"), str(run / "metadata.json"),
                              "--output", str(threads), "--seconds", str(timeout+220)], control / "sampler.log")
        plan["runner_returncode"] = runner.wait(timeout=timeout+200)
        if plan["runner_returncode"]:
            raise RuntimeError("Runner failed; inspect metadata and live game state before another launch")
    finally:
        if watch.exists():
            (watch / "done.flag").write_text("done\n", encoding="ascii")
        for role, process in (("watcher", watcher), ("sampler", sampler)):
            if process is not None:
                try:
                    plan[role + "_returncode"] = process.wait(timeout=15)
                except subprocess.TimeoutExpired:
                    plan[role + "_still_running_pid"] = process.pid
        if runner is not None and runner.poll() is None:
            plan["runner_still_running_pid"] = runner.pid
        if (run / "metadata.json").is_file():
            plan["last_metadata"] = json.loads((run / "metadata.json").read_text(encoding="utf8"))
        (control / "execution.json").write_text(json.dumps(plan, indent=2), encoding="utf8")
    assert plan.get("watcher_returncode") == 0
    if sampler is not None:
        assert plan.get("sampler_returncode") == 0
    meta = json.loads((run / "metadata.json").read_text(encoding="utf8"))
    assert meta["returncode"] == meta["monitor_returncode"] == 0
    route = Path(meta["route"])
    isolation = json.loads((route / "isolation.json").read_text(encoding="utf8"))
    assert isolation["exit_code"] == 0 and isolation["desktop"] != isolation["input_desktop_start"]
    assert isolation["input_desktop_start"] == isolation["input_desktop_end"]
    gate = read_values(route / "startup_result.txt")
    assert gate["input_restored"] == "1" and 0 < int(gate["start_qpc"]) < int(gate["open_qpc"])
    if args.baseline:
        assert gate["reason"] in ("settled", "timeout")
    else:
        assert gate["reason"] == "settled" and gate["pso_min_priority"] == "0"
        assert int(gate["start_qpc"]) < int(gate["entrance_qpc"]) < int(gate["corridor_qpc"]) < int(gate["return_qpc"]) < int(gate["open_qpc"])
    validation = dict(complete=False, mode=args.mode, gate_policy=plan["gate_policy"], gate=gate, settings=read_values(route / "settings.txt"),
                      game_returncode=meta["returncode"], monitor_returncode=meta["monitor_returncode"],
                      baseline_timeout_observed=args.baseline and gate["reason"] == "timeout")
    power_rows = [row for row in read_rows(run / "monitor_process.csv") if row["role"] == "game"]
    bad_power = [dict(qpc=int(row["qpc"]), ac_power=row["ac_power"], battery_percent=row["battery_percent"]) for row in power_rows if row["ac_power"] != "1"]
    power_condition.update(game_samples=len(power_rows), non_ac_samples=bad_power, valid=bool(power_rows) and not bad_power,
                           scope="All recorded game samples, including loading and between measurement windows; approximately one-second observations cannot rule out shorter power changes.")
    validation["power_condition"] = power_condition
    validation["invalid"] = not power_condition["valid"]
    if args.mode == "survey":
        result, survey = read_values(route / "survey_result.txt"), read_values(route / "survey_meta.txt")
        assert result["success"] == "1" and result["invalid_scenes"] == "0" and result["scenes"] == "14" and result["rounds"] == "2"
        assert survey["sample_frames"] == "600"
        analyzer = "analyze_suite.py"
    elif args.mode == "stress-ten":
        result = read_values(route / "stress_result.txt")
        assert result["success"] == "1" and result["enemies"] == "10" and result["site"] == "atrium"
        assert float(result["duration"]) == 120 and int(result["shots"]) > 0 and int(result["hit_updates"]) > 0
        analyzer = "analyze_route_stress.py"
    else:
        laps, points = (4, 28) if args.mode == "full-route" else (20, 8)
        result = read_values(route / "result.txt")
        assert result["success"] == "1" and int(result["lap"]) == laps
        assert result["reason"] == ("exit_1f" if args.mode == "full-route" else "landing")
        events = read_rows(route / "events.csv")
        for lap in range(1, laps+1):
            current = [row for row in events if int(row["lap"]) == lap]
            assert sum(row["event"] == "lap_start" for row in current) == sum(row["event"] == "lap_end" for row in current) == 1
            assert [int(row["leg"]) for row in current if row["event"] == "waypoint"] == list(range(points))
        analyzer = "analyze_route_stress.py"
    validation["completion"] = result
    (control / "validation.json").write_text(json.dumps(validation, indent=2), encoding="utf8")
    subprocess.run([sys.executable, "-B", str(here / analyzer), str(run)], check=True, creationflags=subprocess.CREATE_NO_WINDOW)
    summary = json.loads((run / "summary.json").read_text(encoding="utf8"))
    power_windows = [(row["scene"], row["round"], int(row["q0"]), int(row["q1"])) for row in summary["per_round"]] if "per_round" in summary else [(name, 0, int(row["start"]), int(row["end"])) for name,row in summary["windows"].items() if name == "all" or (name.startswith("lap_") and "_leg_" not in name)]
    power_condition["measurement_windows"] = [dict(name=name, round=number, q0=q0, q1=q1, game_samples=sum(q0 <= int(row["qpc"]) <= q1 for row in power_rows)) for name,number,q0,q1 in power_windows]
    power_condition["valid"] = power_condition["valid"] and bool(power_windows) and all(row["game_samples"] > 0 for row in power_condition["measurement_windows"])
    validation["invalid"] = not power_condition["valid"]
    (control / "validation.json").write_text(json.dumps(validation, indent=2), encoding="utf8")
    if args.mode == "survey":
        assert not summary["invalid"] and set(summary["per_scene"]) == set(scenes) and len(summary["per_round"]) == 28
        assert all(row["end_event"]["frame"] == "600" for row in summary["per_round"])
    subprocess.run([sys.executable, "-B", str(here / "audit_window_samples.py"), str(run), str(watch),
                    "--expected", args.expected_window, "--include-startup"], check=True, creationflags=subprocess.CREATE_NO_WINDOW)
    window_audit = json.loads((watch / "sample_window_audit.json").read_text(encoding="utf8"))
    validation["window_conditions_valid"] = window_audit["all_rounds_observed_stable"]
    validation["invalid"] = not (power_condition["valid"] and window_audit["all_rounds_observed_stable"])
    (control / "validation.json").write_text(json.dumps(validation, indent=2), encoding="utf8")
    assert window_audit["all_rounds_observed_stable"], "Window condition changed; exclude from controlled comparison"
    assert power_condition["valid"], "AC power condition failed or measurement samples are missing; retained results are invalid for comparison"
    if args.mode == "stress-ten":
        state = json.loads((threads / "thread_cpu_state.json").read_text(encoding="utf8"))
        assert state["identity_verified"] and state["rows"] > 0 and state["pid"] == meta["game_pid"]
        subprocess.run([sys.executable, "-B", str(here / "audit_stress_growth.py"), str(run)], check=True, creationflags=subprocess.CREATE_NO_WINDOW)
        subprocess.run([sys.executable, "-B", str(here / "summarize_stress_telemetry.py"), str(run)], check=True, creationflags=subprocess.CREATE_NO_WINDOW)
    validation["complete"] = True
    (control / "validation.json").write_text(json.dumps(validation, indent=2), encoding="utf8")
    print("Completed", args.name, args.mode, "normal exit and conditions validated; gate reason=" + gate["reason"], flush=True)


if __name__ == "__main__":
    main()
