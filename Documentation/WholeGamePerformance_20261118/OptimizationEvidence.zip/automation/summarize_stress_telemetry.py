import argparse
import csv
import json
from pathlib import Path
import statistics


parser = argparse.ArgumentParser()
parser.add_argument("run", type=Path)
args = parser.parse_args()
run = args.run.resolve()
meta = json.loads((run / "metadata.json").read_text(encoding="utf8"))
growth = json.loads((run / "stress_growth_audit.json").read_text(encoding="utf8"))
summary = json.loads((run / "summary.json").read_text(encoding="utf8"))
frequency = meta["start"]["frequency"]
start, end = (summary["windows"]["all"][key] for key in ("start", "end"))


def read(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def stats(values):
    return dict(n=len(values), min=min(values), mean=statistics.mean(values), max=max(values)) if values else None


processes = read(run / "monitor_process.csv")
nvidia = read(run / "monitor_nvidia.csv")
threads = read(run.parent / (run.name + "Threads") / "thread_cpu.csv")
result = dict(name=run.name, returncode=meta["returncode"], monitor_returncode=meta["monitor_returncode"], windows={})
for name, q0, q1 in (("all", start, end), ("first15", start, start+15*frequency), ("last15", end-15*frequency, end)):
    window = dict(q0=q0, q1=q1, seconds=(q1-q0)/frequency, process={})
    for role in ("game", "editor"):
        rows = [row for row in processes if row["role"] == role and q0 <= int(row["qpc"]) <= q1]
        fields = ("cpu_percent_one_core", "local_budget_B", "local_usage_B", "nonlocal_usage_B", "evicted_process_B", "working_set_B", "private_B")
        window["process"][role] = {field:stats([float(row[field]) for row in rows if row[field] not in ("", "[N/A]")]) for field in fields}
    rows = [row for row in nvidia if q0 <= int(row["qpc_delivery"]) <= q1]
    fields = ("clocks.current.graphics [MHz]", "clocks.current.memory [MHz]", "memory.used [MiB]", "temperature.gpu", "utilization.gpu [%]", "power.draw [W]")
    window["gpu"] = {field:stats([float(row[field]) for row in rows if row[field] not in ("", "[N/A]")]) for field in fields}
    window["gpu_flags"] = {field:sorted({row[field] for row in rows}) for field in ("pstate", "clocks_event_reasons.sw_power_cap", "clocks_event_reasons.sw_thermal_slowdown", "clocks_event_reasons.hw_thermal_slowdown")}
    previous, totals = {}, {}
    for row in threads:
        key = (int(row["tid"]), row["thread_creation_filetime"])
        before = previous.get(key)
        previous[key] = row
        if before is None or not (q0 <= int(before["qpc"]) < int(row["qpc"]) <= q1):
            continue
        seconds = sum(int(row[field])-int(before[field]) for field in ("user_cpu_100ns", "kernel_cpu_100ns"))/1e7
        assert seconds >= 0
        item = totals.setdefault(key, dict(tid=key[0], creation=key[1], name=row["description"], cpu_seconds=0, observed_intervals=0))
        item["cpu_seconds"] += seconds
        item["observed_intervals"] += 1
    window["threads"] = sorted(totals.values(), key=lambda item:-item["cpu_seconds"])
    window["observed_thread_cpu_seconds"] = sum(item["cpu_seconds"] for item in totals.values())
    window["observed_thread_cpu_equivalent_cores"] = window["observed_thread_cpu_seconds"]/window["seconds"]
    result["windows"][name] = window
result["limits"] = "GPU/memory are approximately one-second samples. Process CPU snapshots may include a delta beginning just outside the window. Thread CPU includes only same TID/creation intervals fully inside the window, so edge fractions and threads missed by the sampler are omitted. Worker CPU seconds are parallel work, not critical-path frame time."
(run / "stress_telemetry.json").write_text(json.dumps(result, indent=2), encoding="utf8")
print(json.dumps({name:dict(cpu_cores=window["observed_thread_cpu_equivalent_cores"], gpu_clock=window["gpu"]["clocks.current.graphics [MHz]"], gpu_temp=window["gpu"]["temperature.gpu"], game_local=window["process"]["game"]["local_usage_B"]) for name,window in result["windows"].items()}, indent=2))
