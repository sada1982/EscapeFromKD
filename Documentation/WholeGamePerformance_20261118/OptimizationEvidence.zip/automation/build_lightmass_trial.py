import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

out = Path(__file__).resolve().parent
work = Path(os.environ['LOCALAPPDATA']) / 'KDLightmassTrial_20261118'
proof = json.loads((out / 'lightmass_trial_project.json').read_text(encoding='utf8'))
assert Path(proof['project']) == work
command = ['C:/Program Files/Epic Games/UE_5.8/Engine/Build/BatchFiles/Build.bat',
           'myProject', 'Win64', 'Shipping', '-Project=' + str(work / 'myProject.uproject'),
           '-WaitMutex', '-NoHotReload']
with (out / 'lightmass_compile.log').open('wb') as log:
    result = subprocess.run(command, cwd=work, stdout=log, stderr=subprocess.STDOUT,
        creationflags=subprocess.CREATE_NO_WINDOW | subprocess.BELOW_NORMAL_PRIORITY_CLASS)
for entry in proof['original_files']:
    assert hashlib.sha256((Path(proof['source']) / entry['path']).read_bytes()).hexdigest() == entry['sha256']
record = dict(command=command, exit_code=result.returncode, original_content_config_unchanged=True)
exe = work / 'Binaries/Win64/myProject-Win64-Shipping.exe'
if result.returncode == 0:
    assert exe.is_file()
    record['exe'] = str(exe)
    record['exe_sha256'] = hashlib.sha256(exe.read_bytes()).hexdigest()
(out / 'lightmass_compile_result.json').write_text(json.dumps(record, indent=2), encoding='utf8')
print(json.dumps(record))
sys.exit(result.returncode)
