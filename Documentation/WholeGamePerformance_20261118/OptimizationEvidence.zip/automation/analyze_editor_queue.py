import argparse
from bisect import bisect_left, bisect_right
import csv
import json
import math
from pathlib import Path
import re
import statistics
import subprocess


def rows(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def merged(spans, gap=0):
    result = []
    for a, b in sorted(spans):
        if result and a - result[-1][1] <= gap:
            result[-1][1] = max(result[-1][1], b)
        else:
            result.append([a, b])
    return result


def stats(values):
    if not values:
        return dict(n=0)
    v = sorted(values)
    return dict(n=len(v), mean_ms=statistics.mean(v), median_ms=statistics.median(v),
                p99_ms=v[math.ceil(.99*len(v))-1], max_ms=v[-1], over16p67=sum(x>1000/60 for x in v))


parser = argparse.ArgumentParser()
parser.add_argument("run", type=Path)
parser.add_argument("queue", type=Path)
parser.add_argument("editor_pid", type=int)
args = parser.parse_args()
run, queue = args.run.resolve(), args.queue.resolve()
meta = json.loads((run / "metadata.json").read_text())
frequency = meta["start"]["frequency"]
summary = json.loads((run / "summary.json").read_text())
windows = [(int(r["q0"]), int(r["q1"])) for r in summary["per_round"]]
packet_file = queue / "editor_packets.csv"
if not packet_file.exists():
    command = [str(Path(__file__).resolve().parent / "EditorQueueByPid.exe"), str(queue / "dxg.etl"),
               str(packet_file), str(args.editor_pid), *[str(t) for pair in windows for t in pair]]
    result = subprocess.run(command, capture_output=True, text=True, creationflags=subprocess.CREATE_NO_WINDOW)
    (queue / "editor_decode.txt").write_text(result.stdout + result.stderr, encoding="utf8")
    result.check_returncode()
decode = {k:int(v) for k,v in re.findall(r"(\w+)=(-?\d+)", (queue / "editor_decode.txt").read_text())}
state = dict(line.split("=", 1) for line in (queue / "dxg_state.txt").read_text().splitlines() if "=" in line)
assert all(int(v) == 0 for v in state.values()), state
assert decode["status"] == 0 and decode["decode_errors"] == 0, decode
packets = rows(packet_file)
assert all(int(p["pid"]) == args.editor_pid for p in packets)
union = merged([(int(p["begin"]), int(p["end"])) for p in packets])
starts = [a for a,b in union]
ends = [b for a,b in union]
def overlap(a,b):
    return sum(max(0,min(b,y)-max(a,x)) for x,y in union[bisect_right(ends,a):bisect_left(starts,b)])*1000/frequency
intervals = rows(run / "scene_intervals.csv")
output = []
for scene in summary["per_round"]:
    a,b=int(scene["q0"]),int(scene["q1"])
    spans=[(max(a,x),min(b,y)) for x,y in union if x<b and y>a]
    bursts=merged(spans,int(.015*frequency))
    gaps=[(y[0]-x[0])*1000/frequency for x,y in zip(bursts,bursts[1:])]
    substantial=[(x,y) for x,y in bursts if y-x>=.003*frequency]
    substantial_gaps=[(y[0]-x[0])*1000/frequency for x,y in zip(substantial,substantial[1:])]
    selected=[r for r in intervals if int(r["round"])==scene["round"] and r["scene"]==scene["scene"]]
    classified=[]
    for r in selected:
        q0,q1=int(r["q0"]),int(r["q1"])
        classified.append((float(r["ms"]),overlap(q0,q1),overlap(q0,q0+int(.003*frequency))))
    output.append(dict(scene=scene["scene"],round=scene["round"],sample_ms=(b-a)*1000/frequency,
                       editor_queue_union_ms=sum(y-x for x,y in spans)*1000/frequency,
                       burst_count=len(bursts),burst_period_ms=stats(gaps),
                       bursts_at_least3ms=len(substantial),substantial_burst_period_ms=stats(substantial_gaps),
                       burst_outer_span_ms=stats([(y-x)*1000/frequency for x,y in bursts]),
                       present=stats([v[0] for v in classified]),
                       any_overlap={str(flag):stats([v[0] for v in classified if (v[1]>0)==flag]) for flag in (False,True)},
                       fixed_first3ms_overlap={str(flag):stats([v[0] for v in classified if (v[2]>0)==flag]) for flag in (False,True)}))
result=dict(editor_pid=args.editor_pid,frequency=frequency,packet_count=len(packets),etw_state=state,decode=decode,
            note="Queue submitted-to-completed occupancy is not GPU execution or proven stolen time. Bursts use <=15ms gaps only for periodicity; overlap uses actual packet union.",scenes=output)
(queue / "editor_queue_summary.json").write_text(json.dumps(result,indent=2),encoding="utf8")
print(json.dumps(result,indent=2))
