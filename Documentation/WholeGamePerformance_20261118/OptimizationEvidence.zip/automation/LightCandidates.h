#pragma once
#include "CoreMinimal.h"
#include "Components/LocalLightComponent.h"
#include "Components/PointLightComponent.h"
#include "Components/RectLightComponent.h"
#include "Engine/World.h"
#include "EngineUtils.h"
#include "Misc/CommandLine.h"
#include "Misc/FileHelper.h"
#include "Misc/Parse.h"
#include "Misc/Paths.h"

struct FIsolatedLightCandidate
{
    struct FPreset
    {
        const TCHAR* Id;
        const TCHAR* Actor;
        float Radius;
        float CompensationDistance;
        float ExpectedRadius;
        float ExpectedIntensity;
        FVector ExpectedPosition;
        bool ExpectedMega;
        bool ExpectedShadow;
    };
    bool Applied=false;
    TWeakObjectPtr<ULocalLightComponent> Target;
    float OriginalRadius=0;
    float OriginalIntensity=0;

    static double RadiusMask(double Distance,double Radius)
    {
        const double D2=FMath::Square(Distance/Radius);
        return FMath::Square(FMath::Clamp(1.0-FMath::Square(D2),0.0,1.0));
    }
    static void Record(const FString& Dir,const FString& Text)
    {
        FFileHelper::SaveStringToFile(Text,*FPaths::Combine(Dir,TEXT("light_candidate.txt")),FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM);
    }
    bool Restore()
    {
        if (!Applied) return true;
        ULocalLightComponent* C=Target.Get();
        if (!C) return false;
        C->SetAttenuationRadius(OriginalRadius);
        C->SetIntensity(OriginalIntensity);
        const bool Restored=FMath::IsNearlyEqual(C->AttenuationRadius,OriginalRadius,0.01f) && FMath::IsNearlyEqual(C->Intensity,OriginalIntensity,0.1f);
        if (Restored) Applied=false;
        return Restored;
    }
    bool ApplyFromCommandLine(UWorld* World,const FString& EvidenceDir)
    {
        FString Id=TEXT("Baseline");
        FParse::Value(FCommandLine::Get(),TEXT("KDLightCandidate="),Id);
        return Apply(World,Id,EvidenceDir);
    }
    bool Apply(UWorld* World,const FString& Id,const FString& EvidenceDir)
    {
        if (Applied) return false;
        if (!World || !World->IsGameWorld())
        {
            Record(EvidenceDir,TEXT("success=0\nreason=requires_game_world\n"));
            return false;
        }
        const FPreset Presets[]={
            {TEXT("Upper1600Raw"),TEXT("PointLight_0"),1600,0,1800,18000,{-750,-500,450},false,false},
            {TEXT("Upper1600Comp"),TEXT("PointLight_0"),1600,700,1800,18000,{-750,-500,450},false,false},
            {TEXT("Middle1600Raw"),TEXT("PointLight_1"),1600,0,1800,12000,{-750,-500,50},false,false},
            {TEXT("Middle1600Comp"),TEXT("PointLight_1"),1600,700,1800,12000,{-750,-500,50},false,false},
            {TEXT("Lower1600Raw"),TEXT("PointLight_2"),1600,0,1800,8000,{-750,-500,-300},false,false},
            {TEXT("Lower1600Comp"),TEXT("PointLight_2"),1600,700,1800,8000,{-750,-500,-300},false,false},
            {TEXT("AtriumRect1300Raw"),TEXT("RectLight_21"),1300,0,1400,14000,{-750,-500,850},true,true},
            {TEXT("AtriumRect1300Comp"),TEXT("RectLight_21"),1300,850,1400,14000,{-750,-500,850},true,true},
            {TEXT("ClassroomFill780Raw"),TEXT("RectLight_43"),780,0,840,20500,{410,-515,-49},false,false},
            {TEXT("ClassroomFill780Comp"),TEXT("RectLight_43"),780,350,840,20500,{410,-515,-49},false,false},
            {TEXT("NearGalleryFill550Raw"),TEXT("RectLight_47"),550,0,590,4600,{-115,-590,-44},false,false},
            {TEXT("NearGalleryFill550Comp"),TEXT("RectLight_47"),550,300,590,4600,{-115,-590,-44},false,false}
        };
        const FPreset* Preset=nullptr;
        for (const auto& P : Presets) if (Id==P.Id) Preset=&P;
        if (Id!=TEXT("Baseline") && !Preset)
        {
            Record(EvidenceDir,FString::Printf(TEXT("success=0\ncandidate=%s\nreason=unknown_candidate\n"),*Id));
            return false;
        }
        int32 Lights=0,Mega=0,Shadowed=0,Matches=0;
        ULocalLightComponent* Selected=nullptr;
        for (TActorIterator<AActor> It(World);It;++It)
        {
            TInlineComponentArray<ULightComponent*> Components(*It);
            for (ULightComponent* C : Components)
            {
                ++Lights;
                Mega+=C->bAllowMegaLights?1:0;
                Shadowed+=C->CastShadows?1:0;
                if (Preset && It->GetName()==Preset->Actor)
                {
                    ++Matches;
                    Selected=Cast<ULocalLightComponent>(C);
                }
            }
        }
        FString Evidence=FString::Printf(TEXT("candidate=%s\nlights=%d\nmega=%d\nlegacy=%d\nshadowed=%d\n"),*Id,Lights,Mega,Lights-Mega,Shadowed);
        if (Lights!=61 || Mega!=42 || Shadowed!=42)
        {
            Record(EvidenceDir,Evidence+TEXT("success=0\nreason=light_configuration_mismatch\n"));
            return false;
        }
        if (!Preset)
        {
            Record(EvidenceDir,Evidence+TEXT("success=1\napplied=0\n"));
            return true;
        }
        if (Matches!=1 || !Selected || Selected->Mobility!=EComponentMobility::Movable ||
            Selected->IntensityUnits!=ELightUnits::Lumens || Selected->bAllowMegaLights!=Preset->ExpectedMega ||
            Selected->CastShadows!=Preset->ExpectedShadow ||
            !Selected->GetComponentLocation().Equals(Preset->ExpectedPosition,1.0) ||
            !FMath::IsNearlyEqual(Selected->AttenuationRadius,Preset->ExpectedRadius,0.1f) ||
            !FMath::IsNearlyEqual(Selected->Intensity,Preset->ExpectedIntensity,0.1f))
        {
            Record(EvidenceDir,Evidence+TEXT("success=0\nreason=target_baseline_mismatch\n"));
            return false;
        }
        if (UPointLightComponent* Point=Cast<UPointLightComponent>(Selected))
        {
            if (!Point->bUseInverseSquaredFalloff)
            {
                Record(EvidenceDir,Evidence+TEXT("success=0\nreason=requires_inverse_square\n"));
                return false;
            }
        }
        else if (!Cast<URectLightComponent>(Selected))
        {
            Record(EvidenceDir,Evidence+TEXT("success=0\nreason=unsupported_light_type\n"));
            return false;
        }
        Target=Selected;
        OriginalRadius=Selected->AttenuationRadius;
        OriginalIntensity=Selected->Intensity;
        const double Scale=Preset->CompensationDistance>0?
            RadiusMask(Preset->CompensationDistance,OriginalRadius)/RadiusMask(Preset->CompensationDistance,Preset->Radius):1.0;
        Selected->SetAttenuationRadius(Preset->Radius);
        Selected->SetIntensity(static_cast<float>(OriginalIntensity*Scale));
        Applied=true;
        const bool Valid=FMath::IsNearlyEqual(Selected->AttenuationRadius,Preset->Radius,0.01f) &&
            FMath::IsNearlyEqual(Selected->Intensity,static_cast<float>(OriginalIntensity*Scale),0.1f);
        Evidence+=FString::Printf(TEXT("actor=%s\nold_radius=%.4f\nnew_radius=%.4f\nold_intensity=%.4f\nnew_intensity=%.4f\nintensity_scale=%.8f\ncompensation_distance=%.4f\n"),
            Preset->Actor,OriginalRadius,Selected->AttenuationRadius,OriginalIntensity,Selected->Intensity,Scale,Preset->CompensationDistance);
        if (!Valid)
        {
            const bool Restored=Restore();
            Record(EvidenceDir,Evidence+FString::Printf(TEXT("success=0\nreason=setter_validation_failed\nrestored=%d\n"),Restored?1:0));
            return false;
        }
        Record(EvidenceDir,Evidence+TEXT("success=1\napplied=1\n"));
        return true;
    }
};
