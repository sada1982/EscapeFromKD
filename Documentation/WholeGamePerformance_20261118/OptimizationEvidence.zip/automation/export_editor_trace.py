import csv
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile


base = Path(__file__).resolve().parent
output = base / "EditorSleep1Trace"
output.mkdir(exist_ok=True)
scratch = Path(tempfile.mkdtemp(prefix="KDEditorTrace_"))
trace = Path("C:/Users/motoo/AppData/Local/Temp/KDEditorSleep1_20261118.utrace")
insights = Path("C:/Program Files/Epic Games/UE_5.8/Engine/Binaries/Win64/UnrealInsights.exe")
launcher = base.parent / "Exhibit42_20261116/private_launch.py"
columns = " -columns=ThreadId,ThreadName,TimerName,StartTime,EndTime,Duration,Depth"


def export(label, filters):
    target = scratch / (label + ".csv")
    response = scratch / (label + ".rsp")
    response.write_text("TimingInsights.ExportTimingEvents " + target.as_posix() + columns + filters + "\n", encoding="utf8")
    log = scratch / (label + ".log")
    command = [sys.executable, "-B", str(launcher), str(insights), str(scratch / (label + "Desktop")),
               "-OpenTraceFile=" + str(trace), "-ABSLOG=" + str(log), "-AutoQuit", "-NoUI",
               "-ExecOnAnalysisCompleteCmd=@=" + str(response), "-unattended", "-NoSplash"]
    result = subprocess.run(command, capture_output=True,
                            creationflags=subprocess.CREATE_NO_WINDOW | subprocess.BELOW_NORMAL_PRIORITY_CLASS)
    if log.exists():
        shutil.copyfile(log, output / log.name)
    (output / (label + "_launcher.txt")).write_bytes(result.stdout + result.stderr)
    result.check_returncode()
    shutil.copyfile(target, output / target.name)
    with target.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


gpu = export("gpu_all", " -threads=GPU*")
if not gpu:
    raise ValueError("No GPU events in Editor trace")
last = max(float(row["EndTime"]) for row in gpu)
start, end = last - 20.0, last - 10.0
events = export("idle_10s", " -threads=GameThread,RenderThread*,RenderingThread*,RHIThread*,GPU*"
                + f" -startTime={start:.9f} -endTime={end:.9f}")
manifest = dict(trace=str(trace), start=start, end=end, last_gpu_event=last, event_count=len(events),
                note="Central 10 seconds chosen 20 to 10 seconds before the final GPU event; excludes start/stop console interaction. GPU queue lanes are independent, not additive.")
(output / "window.json").write_text(json.dumps(manifest, indent=2), encoding="utf8")
print(json.dumps(manifest))
