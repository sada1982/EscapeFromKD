import argparse
import csv
import json
import math
from pathlib import Path


here = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description="Offline figures for eight completed diagnostic runs; final validation is incomplete.")
parser.add_argument("--input", type=Path, default=here / "FinalPartialComparison" / "comparison.json")
parser.add_argument("--output", type=Path, default=here / "FinalPartialFigures")
args = parser.parse_args()
source = json.loads(args.input.read_text(encoding="utf-8-sig"))
pairs = {(pair["order"], pair["comparison"]): pair for pair in source["pairs"]}
expected = {(order, mode) for order in ("A", "B") for mode in ("survey", "full_route")}
if len(source["pairs"]) != 4 or set(pairs) != expected:
    raise ValueError("Expected exactly A/B survey/full_route pairs; formal input is not supported")
run_paths = [str(Path(pair[side]["run"]).resolve()).casefold() for pair in pairs.values() for side in ("before", "after")]
if len(set(run_paths)) != 8:
    raise ValueError("Expected eight distinct diagnostic runs")
for pair in pairs.values():
    if set(pair["before"]["groups"]) != set(pair["after"]["groups"]):
        raise ValueError("Before/After group mismatch")
    for side in ("before", "after"):
        for group, values in pair[side]["groups"].items():
            if values["n"] < 1 or any(not math.isfinite(values[key]) or values[key] <= 0 for key in ("mean_ms", "p99_ms")):
                raise ValueError("Invalid measured group: " + group)
scenes = [group[:-4] for group in pairs["A", "survey"]["before"]["groups"] if group.endswith("/all")]
if len(scenes) != 14 or len(set(scenes)) != 14:
    raise ValueError("Expected exactly 14 scenes")
for mode in ("survey", "full_route"):
    if set(pairs["A", mode]["before"]["groups"]) != set(pairs["B", mode]["before"]["groups"]):
        raise ValueError("A/B group mismatch: " + mode)
for order in ("A", "B"):
    for scene in scenes:
        for number in (1, 2):
            if scene + "/round_" + str(number) not in pairs[order, "survey"]["before"]["groups"]:
                raise ValueError("Missing scene round: " + scene)


def direction(value):
    return "lower" if value < -1e-9 else "higher" if value > 1e-9 else "equal"


rows = []
for mode in ("survey", "full_route"):
    for group in pairs["A", mode]["before"]["groups"]:
        for metric in ("mean_ms", "p99_ms", "over_rate_pct"):
            row = dict(comparison=mode, group=group, metric=metric)
            for order in ("A", "B"):
                pair = pairs[order, mode]
                old = pair["before"]["groups"][group][metric]
                new = pair["after"]["groups"][group][metric]
                row[order + "_before"] = old
                row[order + "_after"] = new
                row[order + "_delta"] = new - old
                row[order + "_direction"] = direction(new - old)
            row["joint_direction"] = row["A_direction"] + "_in_both" if row["A_direction"] == row["B_direction"] else "mixed_or_one_equal"
            rows.append(row)
counts = {}
for number in (1, 2):
    round_name = "round_" + str(number)
    counts[round_name] = {}
    for metric in ("mean_ms", "p99_ms", "over_rate_pct"):
        selected = [row for row in rows if row["comparison"] == "survey" and row["group"].endswith("/" + round_name) and row["metric"] == metric]
        if len(selected) != 14:
            raise ValueError("Incomplete scene summary")
        counts[round_name][metric] = {kind: sum(row["joint_direction"] == kind for row in selected)
                                     for kind in ("lower_in_both", "higher_in_both", "equal_in_both", "mixed_or_one_equal")}

limits = [
    "Partial validation: only eight valid diagnostic runs are included. Formal Before was invalidated by Editor foreground activity; formal After and final AfterStress10 were not run.",
    "Pair A execution order is Before then After; pair B is After then Before. These two observations do not establish statistical significance or a causal guarantee.",
    "Survey round 1 follows startup and per-view warm frames; it is not a completely cold first visit. Round 2 is kept separate.",
    "P99 is retained from each original group without averaging percentiles. Route first/warm laps and individual legs are kept separately in source_report.",
    "Lower/higher indicates only the numerical sign of After minus Before with 1e-9 tolerance; it does not imply a practically meaningful improvement.",
    "Formal release performance and complete final stress validation remain unverified. No missing or invalid measurements are substituted.",
]

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

args.output.mkdir(parents=True, exist_ok=False)
budget = 1000 / 60
for number in (1, 2):
    round_name = "round_" + str(number)
    fig, axes = plt.subplots(1, 2, figsize=(16, 9), sharex=True, sharey=True)
    maximum = max(pairs[order, "survey"][side]["groups"][scene + "/" + round_name]["p99_ms"]
                  for order in ("A", "B") for side in ("before", "after") for scene in scenes)
    for axis, order in zip(axes, ("A", "B")):
        for side, offset, color in (("before", -.18, "#657489"), ("after", .18, "#087f8c")):
            values = [pairs[order, "survey"][side]["groups"][scene + "/" + round_name]["p99_ms"] for scene in scenes]
            axis.barh([index + offset for index in range(14)], values, height=.34, color=color, label=side.title())
        axis.axvline(budget, color="#b83232", linestyle="--", linewidth=1.2, label="60 FPS budget (16.67 ms)")
        axis.set_title("Pair " + order + (": Before > After execution order" if order == "A" else ": After > Before execution order"))
        axis.set_xlabel("Present interval P99 (ms); lower is better")
        axis.set_xlim(0, max(maximum, budget) * 1.12)
        axis.set_yticks(range(14), scenes)
        axis.grid(axis="x", alpha=.18)
        axis.set_axisbelow(True)
        axis.legend(loc="upper center", bbox_to_anchor=(.5, -.07), ncol=2, fontsize=8)
    axes[0].invert_yaxis()
    fig.suptitle("Partial diagnostic comparison | 14 scenes | Round " + str(number), fontsize=14)
    fig.text(.5, .018, "Formal release validation incomplete: formal Before invalid; formal After / final AfterStress10 not measured.", ha="center", fontsize=9)
    fig.tight_layout(rect=(0, .08, 1, .96))
    fig.savefig(args.output / ("partial_scene_p99_" + round_name + ".png"), dpi=180)
    fig.savefig(args.output / ("partial_scene_p99_" + round_name + ".svg"))
    plt.close(fig)

result = dict(input=str(args.input.resolve()), diagnostic_run_count=8, formal_validation_complete=False,
              scene_order=scenes, scene_direction_counts=counts, directions=rows, limits=limits, source_report=source)
(args.output / "partial_reproducibility.json").write_text(json.dumps(result, indent=2), encoding="utf8")
with (args.output / "partial_directions.csv").open("w", encoding="utf-8-sig", newline="") as stream:
    writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
    writer.writeheader()
    writer.writerows(rows)
lines = ["Partial final comparison: eight valid diagnostic runs only", ""]
for round_name, metrics in counts.items():
    for metric, values in metrics.items():
        lines.append(round_name + " / " + metric + " / " + ", ".join(key + "=" + str(value) for key, value in values.items()))
lines += ["", "Full-route first/warm groups (After minus Before):"]
for row in rows:
    if row["comparison"] == "full_route" and row["group"] in ("first_lap", "warm_laps"):
        lines.append(row["group"] + " / " + row["metric"] + " / A=" + format(row["A_delta"], ".6f") + " / B=" + format(row["B_delta"], ".6f") + " / " + row["joint_direction"])
lines += ["", *limits]
(args.output / "partial_reproducibility.txt").write_text("\n".join(lines) + "\n", encoding="utf8")
print("Wrote", args.output, "without formal-route inputs or a final validation completion claim.")
