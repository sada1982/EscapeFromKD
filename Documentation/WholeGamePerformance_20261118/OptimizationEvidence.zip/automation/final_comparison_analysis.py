import argparse
import csv
import hashlib
import json
import math
from pathlib import Path
import statistics


here = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description="Prepared comparison; run only after all six final validations are complete.")
for key in ("before-survey", "after-survey", "before-route", "after-route", "before-formal", "after-formal"):
    parser.add_argument("--" + key, type=Path, required=True)
parser.add_argument("--output", type=Path, default=here / "FinalComparison")
args = parser.parse_args()


def read_json(path):
    return json.loads(path.read_text(encoding="utf8"))


def read_rows(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def stats(records):
    values = sorted(float(row["ms"]) for row in records)
    assert values
    count = len(values)
    over = sum(value > 1000/60 for value in values)
    worst = max(records, key=lambda row:float(row["ms"]))
    return dict(n=count, mean_ms=statistics.mean(values), fps=1000/statistics.mean(values),
                p99_ms=values[math.ceil(.99*count)-1], max_ms=values[-1], over_count=over,
                over_rate_pct=100*over/count, measured_interval_seconds=sum(values)/1000,
                maximum_interval=worst)


def load(path, mode, baseline):
    run = path.resolve()
    control = run.parent / (run.name + "Control")
    plan = read_json(control / "plan.json")
    validation = read_json(control / "validation.json")
    meta = read_json(run / "metadata.json")
    watch = read_json(run.parent / (run.name + "Window") / "sample_window_audit.json")
    ready = read_json(run.parent / (run.name + "Window") / "ready.json")
    assert validation["complete"] and validation["window_conditions_valid"] and watch["all_rounds_observed_stable"]
    power = validation["power_condition"]
    assert power["valid"] and not validation["invalid"]
    assert power["prelaunch"]["api_ok"] and power["prelaunch"]["ac_power"] == 1
    assert power["game_samples"] > 0 and not power["non_ac_samples"]
    assert power["measurement_windows"] and all(row["game_samples"] > 0 for row in power["measurement_windows"])
    assert plan["mode"] == validation["mode"] == mode and plan["baseline"] == baseline
    assert meta["returncode"] == meta["monitor_returncode"] == 0
    assert plan["conditions"]["expected_slate_sleep"] == 0
    assert plan["conditions"]["supplied_record"]["restored_value"] == 0
    expected_window = plan["conditions"].get("expected_window", "maximized")
    assert expected_window in ("maximized", "normal") and watch["expected"] == expected_window
    initial = ready["initial_window"]
    assert not initial["iconic"]
    assert (initial["zoomed"] and initial["showCmd"] == 3) if expected_window == "maximized" else (not initial["zoomed"] and initial["showCmd"] == 1)
    summary = read_json(run / "summary.json")
    filename = "scene_intervals.csv" if mode == "survey" else "intervals.csv"
    intervals = read_rows(run / filename)
    assert intervals
    for row in intervals:
        assert int(row["q1"]) > int(row["q0"]) and float(row["ms"]) > 0
        computed = (int(row["q1"])-int(row["q0"]))*1000/meta["start"]["frequency"]
        assert abs(computed-float(row["ms"])) < .00001
    intended_gate_changes = {"r.PSOPrecaching.MinPriorityForActivePrecacheRequests", "r.PSOPrecaching.TaskPriorityThreshold"}
    fixed = {key:value for key,value in validation["settings"].items() if key not in intended_gate_changes and (key.startswith(("r.", "sg.", "t.")) or key in ("map", "pawn", "viewport", "max_walk_speed"))}
    groups = {"all": intervals}
    if mode == "survey":
        assert len(summary["per_round"]) == 28 and len(summary["per_scene"]) == 14
        assert {int(row["round"]) for row in intervals} == {1, 2}
        for number in (1, 2):
            groups["round_" + str(number)] = [row for row in intervals if int(row["round"]) == number]
        for scene in summary["per_scene"]:
            selected = [row for row in intervals if row["scene"] == scene]
            groups[scene + "/all"] = selected
            for number in (1, 2):
                groups[scene + "/round_" + str(number)] = [row for row in selected if int(row["round"]) == number]
    else:
        laps, points = (4, 28) if mode == "full-route" else (20, 8)
        assert {row["window"] for row in intervals} == {"lap_" + str(lap) for lap in range(1, laps+1)}
        groups["first_lap"] = [row for row in intervals if row["window"] == "lap_1"]
        groups["warm_laps"] = [row for row in intervals if row["window"] != "lap_1"]
        for lap in range(1, laps+1):
            groups["lap_" + str(lap)] = [row for row in intervals if row["window"] == "lap_" + str(lap)]
        for leg in range(points):
            first, warm = [], []
            for lap in range(1, laps+1):
                name = f"lap_{lap}_leg_{leg:02d}"
                window = summary["windows"][name]
                selected = [row for row in groups["lap_" + str(lap)] if int(window["start"]) <= int(row["q0"]) < int(row["q1"]) <= int(window["end"])]
                assert selected
                groups[name] = selected
                (first if lap == 1 else warm).extend(selected)
            groups[f"leg_{leg:02d}/first_lap"] = first
            groups[f"leg_{leg:02d}/warm_laps"] = warm
            groups[f"leg_{leg:02d}/all"] = first + warm
    snapshot = Path(plan["source"]).parent / "SourceSnapshot"
    helper_names = ["myProject.cpp", "myProject.Build.cs"]
    if mode != "formal-route":
        helper_names += ["Survey.h", "Stress.h", "QualitySweep.h", "LightCandidates.h", "GalleryMaterialCheck.h", "FullRoute.h"]
    hashes = {name:hashlib.sha256((snapshot / name).read_bytes()).hexdigest() for name in helper_names if (snapshot / name).is_file()}
    if mode != "formal-route":
        assert set(hashes) == set(helper_names), "Final diagnostic builds must have complete current helper snapshots"
    return dict(run=str(run), mode=mode, baseline=baseline, groups={key:stats(rows) for key,rows in groups.items()},
                fixed_settings=fixed, plan=plan, validation=validation, window=watch, helper_hashes=hashes,
                expected_window=expected_window, normal_rect=initial["normal_rect"],
                helper_snapshot_available=len(hashes) == len(helper_names),
                monitor_nvidia=str(run / "monitor_nvidia.csv"), monitor_process=str(run / "monitor_process.csv"))


pairs = []
table = []
for label, mode, before_path, after_path in (
        ("survey", "survey", args.before_survey, args.after_survey),
        ("full_route", "full-route", args.before_route, args.after_route),
        ("formal_route", "formal-route", args.before_formal, args.after_formal)):
    before, after = load(before_path, mode, True), load(after_path, mode, False)
    assert before["fixed_settings"] == after["fixed_settings"], "Recorded render settings differ; do not claim a quality-preserving comparison"
    assert set(before["groups"]) == set(after["groups"])
    if before["helper_snapshot_available"] and after["helper_snapshot_available"]:
        assert before["helper_hashes"] == after["helper_hashes"], "Route or diagnostic helper sources differ between paired builds"
    assert before["plan"]["conditions"]["editor_pid"] == after["plan"]["conditions"]["editor_pid"]
    assert before["expected_window"] == after["expected_window"], "Editor window states differ between paired runs"
    assert before["normal_rect"] == after["normal_rect"], "Editor window rectangles differ between paired runs"
    changes = {}
    for group, old in before["groups"].items():
        new = after["groups"][group]
        changes[group] = dict(mean_ms=new["mean_ms"]-old["mean_ms"], p99_ms=new["p99_ms"]-old["p99_ms"],
                              max_ms=new["max_ms"]-old["max_ms"], over_count=new["over_count"]-old["over_count"],
                              over_rate_percentage_points=new["over_rate_pct"]-old["over_rate_pct"])
        row = dict(comparison=label, group=group)
        for prefix, data in (("before", old), ("after", new)):
            for key in ("n", "mean_ms", "fps", "p99_ms", "max_ms", "over_count", "over_rate_pct"):
                row[prefix + "_" + key] = data[key]
        row.update({"delta_"+key:value for key,value in changes[group].items()})
        table.append(row)
    pairs.append(dict(comparison=label, before=before, after=after, differences_after_minus_before=changes))

deployments = [pair[side]["plan"]["deploy"] for pair in pairs for side in ("before", "after")]
assert len(deployments) == len(set(deployments)), "Every mode and side must use its own fresh deployment"
report = dict(method="Present QPC intervals fully inside each measured window; P99 nearest-rank ceil(.99*n); budget strictly greater than1000/60ms. Recomputed from existing interval CSVs with identical arithmetic for all six runs.",
              limits=["Survey round1 follows startup and120 warm frames per view; it is not an entirely cold first visit. Compare round1/round2 separately.",
                      "Route first lap is separate from pooled warm laps; intervals crossing waypoint boundaries are excluded from per-leg summaries but remain in whole-lap summaries.",
                      "No cross-comparison of different routes, survey versus walking, or previous Slate1 stress cases. Stress inputs are not accepted by this script.",
                      "Each side is one run; numerical differences are not randomized statistical causal proof. GPU clock/temperature/memory telemetry and other-application workload still require review.",
                      "Slate0 is from the supplied root record, not a direct CVar query by the wrapper. Window stability is sampled at250ms.",
                      "AC1 is required before launch and in all recorded game samples, with observations inside every measurement window. Approximately one-second sampling cannot rule out shorter power changes.",
                      "Old formal binaries may lack SourceSnapshot; this is explicitly reported, not inferred as source identity.",
                      "Diagnostic Before/After reuse the same old cooked container except the intended configuration entry. Formal After is a fresh recook and has a known KDStage saved/editor-state binary difference from the old formal cook. The367-file proof establishes current source stability and new build-copy identity, not byte identity of the two formal packages. Treat formal results as operational before/after observations with this limitation, not an isolated PSO-only experiment."],
              pairs=pairs)
args.output.mkdir(parents=True, exist_ok=False)
(args.output / "comparison.json").write_text(json.dumps(report, indent=2), encoding="utf8")
with (args.output / "comparison.csv").open("w", encoding="utf-8-sig", newline="") as stream:
    writer = csv.DictWriter(stream, fieldnames=list(table[0]))
    writer.writeheader()
    writer.writerows(table)
lines = ["Final Before/After comparison", "", report["method"], ""]
for pair in pairs:
    lines.append(pair["comparison"] + ": paired Editor=" + pair["before"]["expected_window"] + ", normal_rect=" + str(pair["before"]["normal_rect"]) + ", recorded Slate0, observed AC1")
lines += ["", "comparison / group / Before mean,P99,max,over/count(rate%) / After mean,P99,max,over/count(rate%)"]
for row in table:
    if row["group"] not in ("all", "round_1", "round_2", "first_lap", "warm_laps") and "/all" not in row["group"]:
        continue
    cells = []
    for prefix in ("before", "after"):
        cells.append(f'{row[prefix+"_mean_ms"]:.5f},{row[prefix+"_p99_ms"]:.4f},{row[prefix+"_max_ms"]:.4f},{row[prefix+"_over_count"]}/{row[prefix+"_n"]}({row[prefix+"_over_rate_pct"]:.3f}%)')
    lines.append(row["comparison"] + " / " + row["group"] + " / " + " / ".join(cells))
lines += ["", *report["limits"], "", "Every scene/round, lap and waypoint first/warm split is retained in comparison.csv/json. Raw maximum-frame QPC/position fields are retained in JSON."]
(args.output / "comparison.txt").write_text("\n".join(lines)+"\n", encoding="utf8")
print("Wrote", args.output, "after validating all six final runs; no cross-route or Slate1 stress improvement values were calculated.")
