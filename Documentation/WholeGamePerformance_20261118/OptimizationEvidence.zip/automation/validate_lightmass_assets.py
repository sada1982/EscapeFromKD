import ast
import hashlib
import json
import os
from pathlib import Path
import struct
import unreal

out = Path(os.environ['KD_MODEL_EVIDENCE'])
project = Path(unreal.Paths.convert_relative_path_to_full(unreal.Paths.project_dir())).resolve()
assert project == Path(os.environ['LOCALAPPDATA']) / 'KDLightmassTrial_20261118'
proof = json.loads((out / 'lightmass_room_proof.json').read_text(encoding='utf8'))
api = unreal.GeometryScript_AssetUtils
tree = ast.parse((out / 'make_lightmass_room.py').read_text(encoding='utf8'))
helpers = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name in ('source_mesh', 'uv0_signature')]
assert len(helpers) == 2
exec(compile(ast.Module(body=helpers, type_ignores=[]), '<verified mesh helpers>', 'exec'))
meshes = []
for part in proof['parts']:
    mesh = unreal.load_asset(part['asset'])
    assert mesh and mesh.get_editor_property('light_map_coordinate_index') == 1
    assert mesh.get_editor_property('light_map_resolution') == 1024
    dynamic = source_mesh(mesh)
    assert dynamic.get_num_uv_sets() == 2
    assert dynamic.get_triangle_count() == part['triangles']
    assert uv0_signature(dynamic) == part['uv0_sha256'], part['name']
    meshes.append(part['name'])
for path in (proof['map'], proof['cropped_lumen_control_map']):
    world = unreal.EditorLoadingAndSavingUtils.load_map(path)
    assert world
    actors = {a.get_actor_label(): a for a in unreal.GameplayStatics.get_all_actors_of_class(world, unreal.StaticMeshActor)}
    assert len(actors) == len(proof['parts'])
    for part in proof['parts']:
        component = actors['Bake_' + part['name']].get_component_by_class(unreal.StaticMeshComponent)
        assert component.get_editor_property('static_mesh').get_path_name() == part['asset']
        for prop, value in part['properties'].items():
            assert component.get_editor_property(prop) == value, (path, part['name'], prop)
        assert [component.get_material(i).get_path_name() if component.get_material(i) else None for i in range(component.get_num_materials())] == part['materials']
    lights = unreal.GameplayStatics.get_all_actors_of_class(world, unreal.RectLight)
    assert len(lights) == 12
    expected = unreal.ComponentMobility.STATIONARY if path == proof['map'] else unreal.ComponentMobility.MOVABLE
    assert all(a.get_component_by_class(unreal.RectLightComponent).get_editor_property('mobility') == expected for a in lights)
(out / 'lightmass_assets_validation.json').write_text(json.dumps(dict(valid=True, parts=meshes, maps=[proof['map'], proof['cropped_lumen_control_map']], recovered_from='assets script completed; five empty out-of-crop selections emitted errors; independent saved-asset validation'), indent=2), encoding='utf8')
