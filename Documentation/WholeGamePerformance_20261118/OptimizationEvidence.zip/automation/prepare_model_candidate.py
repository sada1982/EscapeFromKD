import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil

parser = argparse.ArgumentParser()
parser.add_argument('variant', choices=('GalleryParts', 'Furniture', 'LaptopOnly'))
args = parser.parse_args()
out = Path(__file__).resolve().parent
source = out.parents[2]
target = Path(os.environ['LOCALAPPDATA']) / ('KDModel' + args.variant + '_20261118')
assert not target.exists(), target
target.mkdir()
for directory in ('Content', 'Config'):
    shutil.copytree(source / directory, target / directory, copy_function=shutil.copy2)
shutil.copy2(source / 'myProject.uproject', target / 'myProject.uproject')
shutil.copytree(source / 'Build/Exhibit/Source', target / 'Source', copy_function=shutil.copy2)
for relative in ('Config/Windows/WindowsEngine.ini', 'Config/DefaultGameUserSettings.ini'):
    destination = target / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source / 'Build/Exhibit' / relative, destination)
project = json.loads((target / 'myProject.uproject').read_text(encoding='utf8'))
project['Modules'] = [dict(Name='myProject', Type='Runtime', LoadingPhase='Default', TargetAllowList=['Game'])]
(target / 'myProject.uproject').write_text(json.dumps(project, indent=2), encoding='utf8')
files = []
for original in (source / 'Content').rglob('*'):
    if not original.is_file():
        continue
    copied = target / original.relative_to(source)
    assert original.stat().st_ino != copied.stat().st_ino, copied
    source_hash = hashlib.sha256(original.read_bytes()).hexdigest()
    assert hashlib.sha256(copied.read_bytes()).hexdigest() == source_hash
    files.append(dict(path=original.relative_to(source).as_posix(), sha256=source_hash))
record = dict(variant=args.variant, project=str(target), source=str(source), independent_files=True, files=files)
(out / (args.variant + '_isolation.json')).write_text(json.dumps(record, indent=2), encoding='utf8')
if args.variant == 'LaptopOnly':
    relative = Path('Content/Main/Stage/Floor03/OptimizedV03/SM_F03V03_Laptops.uasset')
    imported = Path(os.environ['LOCALAPPDATA']) / 'KDModelFurniture_20261118' / relative
    assert imported.is_file()
    (target / relative).parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(imported, target / relative)
    assert imported.stat().st_ino != (target / relative).stat().st_ino
print('KD_MODEL_COPY_COMPLETE', target, len(files))
