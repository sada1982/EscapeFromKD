import hashlib
import json
import math
import os
from pathlib import Path
import struct
import unreal

out = Path(os.environ['KD_MODEL_EVIDENCE'])
project = Path(unreal.Paths.convert_relative_path_to_full(unreal.Paths.project_dir())).resolve()
assert project == Path(os.environ['LOCALAPPDATA']) / 'KDLightmassTrial_20261118', project
api = unreal.GeometryScript_AssetUtils
assets = unreal.AssetToolsHelpers.get_asset_tools()
world = unreal.EditorLoadingAndSavingUtils.load_map('/Game/Main/Stage/KDStage')
assert world
unreal.SystemLibrary.execute_console_command(world, 'Editor.AsyncAssetCompilationFinishAll')
floor = next(actor for actor in unreal.GameplayStatics.get_all_actors_of_class(world, unreal.Actor) if actor.get_actor_label() == 'BP_Floor03')
directory = '/Game/Diagnostics/LightmassTrial'
map_path = directory + '/KDStage_BakeTrial'
assert not unreal.EditorAssetLibrary.does_asset_exist(map_path)
box = unreal.Box()
box.min = unreal.Vector(-20, -1030, -20)
box.max = unreal.Vector(825, 20, 320)
box.is_valid = True
light_props = ('intensity', 'intensity_units', 'light_color', 'attenuation_radius', 'source_width',
               'source_height', 'use_temperature', 'temperature', 'indirect_lighting_intensity',
               'volumetric_scattering_intensity', 'cast_shadows', 'allow_mega_lights',
               'mega_lights_shadow_method', 'barn_door_angle', 'barn_door_length')
mesh_props = ('cast_shadow', 'cast_static_shadow', 'cast_dynamic_shadow', 'cast_hidden_shadow',
              'hidden_in_game', 'visible', 'render_in_main_pass', 'render_in_depth_pass',
              'receives_decals', 'render_custom_depth', 'affect_distance_field_lighting',
              'affect_dynamic_indirect_lighting', 'affect_indirect_lighting_while_hidden',
              'visible_in_ray_tracing', 'visible_in_reflection_captures', 'visible_in_real_time_sky_captures',
              'use_attach_parent_bound', 'bounds_scale')
lights = []
for actor in unreal.GameplayStatics.get_all_actors_of_class(world, unreal.RectLight):
    if actor.get_actor_label().startswith('F03_GameLab_'):
        light = actor.get_component_by_class(unreal.RectLightComponent)
        lights.append(dict(label=actor.get_actor_label(), transform=actor.get_actor_transform(),
                           props={key: light.get_editor_property(key) for key in light_props}))
assert len(lights) == 12, len(lights)
old_settings = unreal.GameplayStatics.get_all_actors_of_class(world, unreal.WorldSettings)[0]
game_mode = old_settings.get_editor_property('default_game_mode')
post_process = [actor.get_editor_property('settings') for actor in unreal.GameplayStatics.get_all_actors_of_class(world, unreal.PostProcessVolume)]

def source_mesh(mesh):
    dynamic = unreal.DynamicMesh()
    options = unreal.GeometryScriptCopyMeshFromAssetOptions()
    options.request_tangents = True
    options.apply_build_settings = False
    lod = unreal.GeometryScriptMeshReadLOD()
    lod.lod_type = unreal.GeometryScriptLODType.SOURCE_MODEL
    _, result = api.copy_mesh_from_static_mesh(mesh, dynamic, options, lod)
    assert result == unreal.GeometryScriptOutcomePins.SUCCESS
    return dynamic

def uv0_signature(dynamic):
    get_uv = getattr(dynamic, next(name for name in dir(dynamic) if name.replace('_', '') == 'gettriangleuvs'))
    records = []
    for triangle in range(dynamic.get_triangle_count()):
        valid, a, b, c = dynamic.get_triangle_positions(triangle)
        ua, ub, uc, valid_uv = get_uv(0, triangle)
        normals = dynamic.get_triangle_normals(triangle)
        material, valid_material = dynamic.get_triangle_material_id(triangle)
        assert valid and valid_uv and normals[-1] and valid_material
        corners = []
        for point, uv, normal in zip((a, b, c), (ua, ub, uc), normals[-4:-1]):
            values = (point.x, point.y, point.z, uv.x, uv.y, normal.x, normal.y, normal.z)
            corners.append(struct.pack('<8f', *(value if value != 0 else 0 for value in values)))
        a, b, c = corners
        records.append(hashlib.blake2b(struct.pack('<i', material) + min(a+b+c, b+c+a, c+a+b), digest_size=16).digest())
    return hashlib.sha256(b''.join(sorted(records))).hexdigest()

def uv1_stats(dynamic):
    get_uv = getattr(dynamic, next(name for name in dir(dynamic) if name.replace('_', '') == 'gettriangleuvs'))
    area = 0.0
    degenerate = 0
    for triangle in range(dynamic.get_triangle_count()):
        a, b, c, valid = get_uv(1, triangle)
        assert valid
        assert all(math.isfinite(value) and -0.0001 <= value <= 1.0001 for uv in (a, b, c) for value in (uv.x, uv.y))
        triangle_area = abs((b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x)) * 0.5
        area += triangle_area
        degenerate += triangle_area <= 1e-15
    assert area > 0 and area <= 1.0001, area
    return dict(area=area, degenerate_triangles=degenerate, finite_in_unit_square=True,
                overlap_verified=False)

parts = []
packages = []
for component in floor.get_components_by_class(unreal.StaticMeshComponent):
    if not component.get_editor_property('visible') and not component.get_editor_property('cast_hidden_shadow'):
        continue
    original = component.get_editor_property('static_mesh')
    if not original:
        continue
    position = component.get_world_location()
    rotation = component.get_world_rotation()
    scale = component.get_world_scale()
    assert all(abs(value) < 0.0001 for value in (position.x, position.y, position.z, rotation.pitch, rotation.yaw, rotation.roll))
    assert all(abs(value - 1) < 0.0001 for value in (scale.x, scale.y, scale.z))
    dynamic = source_mesh(original)
    _, selection = dynamic.select_mesh_elements_in_box(box)
    selection_method = next(name for name in dir(selection) if name.replace('_', '') == 'getmeshselectioninfo')
    if getattr(selection, selection_method)()[-1] == 0:
        continue
    part = unreal.DynamicMesh()
    dynamic.copy_mesh_selection_to_mesh(part, selection, False, True)
    if part.get_triangle_count() == 0:
        continue
    unreal.log('KDLightmass UV begin ' + component.get_name() + ' triangles=' + str(part.get_triangle_count()))
    before = uv0_signature(part)
    part.set_num_uv_sets(2)
    method = next(name for name in dir(part) if name.replace('_', '') == 'autogeneratexatlasmeshuvs')
    getattr(part, method)(1, unreal.GeometryScriptXAtlasOptions())
    packing = unreal.GeometryScriptRepackUVsOptions()
    packing.target_image_width = 1024
    repack_method = next(name for name in dir(part) if name.replace('_', '') == 'repackmeshuvs')
    getattr(part, repack_method)(1, packing)
    assert part.get_num_uv_sets() == 2 and uv0_signature(part) == before
    uv1 = uv1_stats(part)
    name = 'SM_Bake_' + component.get_name()
    mesh = assets.duplicate_asset(name, directory, original)
    options = unreal.GeometryScriptCopyMeshToAssetOptions()
    options.clean_assigned_materials = False
    options.enable_recompute_normals = False
    options.enable_recompute_tangents = False
    options.enable_remove_degenerates = False
    generate_field = next(name for name in dir(options) if name.replace('_', '') == 'generatelightmapuvs')
    generate_type = type(getattr(options, generate_field))
    disable_generate = next(name for name in dir(generate_type) if name.replace('_', '').lower() == 'donotgeneratelightmapuvs')
    setattr(options, generate_field, getattr(generate_type, disable_generate))
    _, result = api.copy_mesh_to_static_mesh(part, mesh, options, unreal.GeometryScriptMeshWriteLOD(), True)
    assert result == unreal.GeometryScriptOutcomePins.SUCCESS
    mesh.set_editor_property('light_map_coordinate_index', 1)
    mesh.set_editor_property('light_map_resolution', 1024)
    unreal.SystemLibrary.execute_console_command(world, 'Editor.AsyncAssetCompilationFinishAll')
    assert uv0_signature(source_mesh(mesh)) == before
    parts.append(dict(name=component.get_name(), asset=mesh, source=original.get_path_name(),
                      uv0_sha256=before, triangles=part.get_triangle_count(),
                      uv1=uv1,
                      properties={prop: component.get_editor_property(prop) for prop in mesh_props},
                      collision_profile=component.get_collision_profile_name(), collision_enabled=component.get_collision_enabled(),
                      materials=[component.get_material(i) for i in range(component.get_num_materials())]))
    packages.append(mesh.get_outermost())
    unreal.log('KDLightmass UV verified ' + component.get_name())
assert parts
assert {'Chairs_Main_Shadow', 'Desks_Main_Shadow'}.issubset({item['name'] for item in parts})
assert unreal.EditorLoadingAndSavingUtils.save_packages(packages, False)
world = unreal.EditorLoadingAndSavingUtils.new_blank_map(False)
assert world
spawner = unreal.get_default_object(unreal.GameplayStatics)

def spawn(actor_class, transform):
    actor = spawner.call_method('BeginDeferredActorSpawnFromClass',
        (world, actor_class.static_class(), transform, unreal.SpawnActorCollisionHandlingMethod.ALWAYS_SPAWN, None))
    assert actor
    spawner.call_method('FinishSpawningActor', (actor, transform))
    return actor

for item in parts:
    actor = spawn(unreal.StaticMeshActor, unreal.Transform())
    actor.set_actor_label('Bake_' + item['name'])
    component = actor.get_component_by_class(unreal.StaticMeshComponent)
    component.set_static_mesh(item['asset'])
    component.set_mobility(unreal.ComponentMobility.STATIC)
    for prop, value in item['properties'].items():
        if prop == 'visible':
            component.set_visibility(value, False)
        elif prop == 'hidden_in_game':
            component.set_hidden_in_game(value, False)
        else:
            component.set_editor_property(prop, value)
    component.set_collision_profile_name(item['collision_profile'])
    component.set_collision_enabled(item['collision_enabled'])
    for index, material in enumerate(item['materials']):
        component.set_material(index, material)
    assert all(component.get_editor_property(prop) == value for prop, value in item['properties'].items())
    assert [component.get_material(i) for i in range(component.get_num_materials())] == item['materials']
for record in lights:
    actor = spawn(unreal.RectLight, record['transform'])
    actor.set_actor_label(record['label'])
    component = actor.get_component_by_class(unreal.RectLightComponent)
    component.set_mobility(unreal.ComponentMobility.STATIONARY)
    for prop, value in record['props'].items():
        component.set_editor_property(prop, value)
    component.set_editor_property('cast_static_shadows', True)
    component.set_editor_property('cast_dynamic_shadows', True)
for settings in post_process:
    actor = spawn(unreal.PostProcessVolume, unreal.Transform())
    settings.override_dynamic_global_illumination_method = True
    settings.dynamic_global_illumination_method = unreal.DynamicGlobalIlluminationMethod.NONE
    actor.set_editor_property('settings', settings)
    actor.set_editor_property('unbound', True)
start = spawn(unreal.PlayerStart, unreal.Transform(location=unreal.Vector(402, -85, 98.15), rotation=unreal.Rotator(0, -90, 0)))
start.set_actor_label('BakeTrial_PlayerStart')
settings = unreal.GameplayStatics.get_all_actors_of_class(world, unreal.WorldSettings)[0]
settings.set_editor_property('force_no_precomputed_lighting', False)
settings.set_editor_property('default_game_mode', game_mode)
lightmass = settings.get_editor_property('lightmass_settings')
lightmass.volumetric_lightmap_detail_cell_size = 50
settings.set_editor_property('lightmass_settings', lightmass)
assert unreal.EditorLoadingAndSavingUtils.save_map(world, map_path)
proof = dict(project=str(project), map=map_path, stage='uv_prepared_not_baked', lights=12,
             note='Cropped classroom; not a whole-stage quality/performance comparison.',
             omitted='Original 19 auxiliary lights including ClassroomFill; exterior/atrium bounce and occlusion geometry. No original KDStage quality match or whole-game 60 FPS conclusion.',
             parts=[dict(name=item['name'], asset=item['asset'].get_path_name(), source=item['source'],
                         triangles=item['triangles'], uv0_sha256=item['uv0_sha256'], uv1=item['uv1'],
                         properties=item['properties'], materials=[material.get_path_name() if material else None for material in item['materials']]) for item in parts])
baseline_path = directory + '/KDStage_LumenTrial'
assert unreal.EditorAssetLibrary.duplicate_asset(map_path, baseline_path)
world = unreal.EditorLoadingAndSavingUtils.load_map(baseline_path)
assert world
for actor in unreal.GameplayStatics.get_all_actors_of_class(world, unreal.RectLight):
    actor.get_component_by_class(unreal.RectLightComponent).set_mobility(unreal.ComponentMobility.MOVABLE)
for actor in unreal.GameplayStatics.get_all_actors_of_class(world, unreal.PostProcessVolume):
    settings = actor.get_editor_property('settings')
    settings.override_dynamic_global_illumination_method = True
    settings.dynamic_global_illumination_method = unreal.DynamicGlobalIlluminationMethod.LUMEN
    actor.set_editor_property('settings', settings)
assert unreal.EditorLoadingAndSavingUtils.save_map(world, baseline_path)
proof['cropped_lumen_control_map'] = baseline_path
for verify_path in (map_path, baseline_path):
    world = unreal.EditorLoadingAndSavingUtils.load_map(verify_path)
    assert world
    actors = {actor.get_actor_label(): actor for actor in unreal.GameplayStatics.get_all_actors_of_class(world, unreal.StaticMeshActor)}
    for item in parts:
        component = actors['Bake_' + item['name']].get_component_by_class(unreal.StaticMeshComponent)
        assert all(component.get_editor_property(prop) == value for prop, value in item['properties'].items()), (verify_path, item['name'])
        assert [component.get_material(i) for i in range(component.get_num_materials())] == item['materials']
proof['source_flags_and_materials_verified_on_both_saved_maps'] = True
(out / 'lightmass_room_proof.json').write_text(json.dumps(proof, indent=2), encoding='utf8')
