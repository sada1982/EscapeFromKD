import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

parser = argparse.ArgumentParser()
parser.add_argument('--binary-project', required=True)
parser.add_argument('--archive', required=True)
args = parser.parse_args()
out = Path(__file__).resolve().parent
work = Path(os.environ['LOCALAPPDATA']) / 'KDLightmassTrial_20261118'
project_proof = json.loads((out / 'lightmass_trial_project.json').read_text(encoding='utf8'))
bake_proof = json.loads((out / 'lightmass_bake_verify.json').read_text(encoding='utf8'))
assert Path(project_proof['project']) == work and Path(bake_proof['project']) == work
assert bake_proof['registry'] and bake_proof['lights'] and bake_proof['meshes']
binary_project = Path(args.binary_project).resolve()
archive = Path(args.archive).resolve()
assert not archive.exists(), archive
binary = 'myProject-Win64-Shipping.exe'
receipt = binary_project / 'Binaries/Win64/myProject-Win64-Shipping.target'
metadata = json.loads(receipt.read_text(encoding='utf8'))
assert metadata['Configuration'] == 'Shipping' and metadata['TargetName'] == 'myProject'
binary_hash = hashlib.sha256((binary_project / 'Binaries/Win64' / binary).read_bytes()).hexdigest()
for product in metadata['BuildProducts'] + metadata['RuntimeDependencies']:
    path = product['Path']
    if not path.startswith('$(ProjectDir)/') or path.endswith(('.pdb', '.lib', '.exp')):
        continue
    relative = Path(path.removeprefix('$(ProjectDir)/'))
    assert (binary_project / relative).is_file()
    (work / relative).parent.mkdir(parents=True, exist_ok=True)
    if binary_project != work:
        shutil.copy2(binary_project / relative, work / relative)
if binary_project != work:
    shutil.copy2(receipt, work / 'Binaries/Win64' / receipt.name)
engine = Path('C:/Program Files/Epic Games/UE_5.8/Engine')
maps = '/Game/Diagnostics/LightmassTrial/KDStage_BakeTrial+/Game/Diagnostics/LightmassTrial/KDStage_LumenTrial'
command = [str(engine / 'Build/BatchFiles/RunUAT.bat'), 'BuildCookRun', '-project=' + str(work / 'myProject.uproject'),
    '-nop4', '-utf8output', '-platform=Win64', '-clientconfig=Shipping', '-skipbuild', '-cook', '-map=' + maps,
    '-stage', '-pak', '-iostore', '-package', '-archive', '-archivedirectory=' + str(archive), '-nodebuginfo',
    '-nocompileeditor', '-unrealexe=' + str(engine / 'Binaries/Win64/UnrealEditor-Cmd.exe'), '-installed',
    '-unattended', '-AdditionalCookerOptions=-nullrhi']
with (out / 'lightmass_cook.log').open('wb') as log:
    result = subprocess.run(command, cwd=work, stdout=log, stderr=subprocess.STDOUT,
        creationflags=subprocess.CREATE_NO_WINDOW | subprocess.BELOW_NORMAL_PRIORITY_CLASS)
if result.returncode:
    sys.exit(result.returncode)
exe = archive / 'Windows/myProject/Binaries/Win64' / binary
assert hashlib.sha256(exe.read_bytes()).hexdigest() == binary_hash
for entry in project_proof['original_files']:
    assert hashlib.sha256((Path(project_proof['source']) / entry['path']).read_bytes()).hexdigest() == entry['sha256'], entry['path']
record = dict(project=str(work), archive=str(archive), exe=str(exe), exe_sha256=binary_hash,
    bake_map=bake_proof['map'], lumen_map='/Game/Diagnostics/LightmassTrial/KDStage_LumenTrial',
    original_content_config_unchanged=True, runtime_validated=False)
(out / 'lightmass_package_proof.json').write_text(json.dumps(record, indent=2), encoding='utf8')
print(str(exe))
