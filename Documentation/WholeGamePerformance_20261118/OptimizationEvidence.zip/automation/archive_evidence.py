import hashlib
import json
from pathlib import Path
import zipfile

here = Path(__file__).resolve().parent
root = here.parents[2]
destination = root / 'Documentation/WholeGamePerformance_20261118/OptimizationEvidence.zip'
entries = {}

for path in here.iterdir():
    if path.is_file() and path.suffix in ('.py', '.h', '.txt', '.json', '.log'):
        entries['automation/' + path.name] = path

for directory in here.iterdir():
    if not directory.is_dir() or directory.name in ('Variants', 'FreshDeployments'):
        continue
    metadata = directory / 'metadata.json'
    for path in directory.iterdir():
        if path.is_file() and path.suffix in ('.json', '.txt'):
            entries['results/' + directory.name + '/' + path.name] = path
        if path.is_file() and path.suffix == '.csv' and directory.name.endswith(('Window', 'Threads')):
            entries['results/' + directory.name + '/' + path.name] = path
        if path.is_file() and path.suffix in ('.csv', '.png', '.svg') and directory.name.startswith(('FinalPartial', 'FinalComparison')):
            entries['results/' + directory.name + '/' + path.name] = path
    if not metadata.is_file():
        continue
    for name in ('scene_intervals.csv', 'intervals.csv', 'monitor_process.csv', 'monitor_nvidia.csv'):
        path = directory / name
        if path.is_file():
            entries['results/' + directory.name + '/' + name] = path
    record = json.loads(metadata.read_text(encoding='utf8'))
    route = Path(record['route'])
    if route.is_dir():
        for path in route.iterdir():
            if path.is_file() and path.suffix in ('.csv', '.txt', '.json'):
                entries['results/' + directory.name + '/route/' + path.name] = path

for directory in (here / 'Variants').iterdir():
    if directory.is_dir():
        for name in ('proof.json', 'probe_pair.json'):
            path = directory / name
            if path.is_file():
                entries['variants/' + directory.name + '/' + name] = path
        if directory.name.startswith('Final') or directory.name in ('LoadingCapProbe', 'CapValidationProbe'):
            snapshot = directory / 'SourceSnapshot'
            if snapshot.is_dir():
                for path in snapshot.rglob('*'):
                    if path.is_file() and path.suffix in ('.cpp', '.h', '.cs'):
                        entries['variants/' + directory.name + '/source/' + path.relative_to(snapshot).as_posix()] = path

for dirname in ('LoadingCapCandidate',):
    for path in (here / dirname).glob('*'):
        if path.is_file() and path.suffix in ('.cpp', '.h', '.txt'):
            entries['automation/' + dirname + '/' + path.name] = path

for path in (here / 'LightmassEvidence').rglob('*'):
    if path.is_file() and path.suffix in ('.png', '.json', '.txt', '.csv'):
        entries['quality/lightmass/' + path.relative_to(here / 'LightmassEvidence').as_posix()] = path

for dirname in ('Exhibit42_20261116', 'WholeGame_20261118'):
    for path in (here.parent / dirname).glob('*.py'):
        entries['helper_sources/' + dirname + '/' + path.name] = path

manifest = []
with zipfile.ZipFile(destination, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for name, path in sorted(entries.items()):
        data = path.read_bytes()
        archive.writestr(name, data)
        manifest.append(dict(archive_path=name, source=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest()))
    archive.writestr('manifest.json', json.dumps(manifest, ensure_ascii=False, indent=2))
    archive.writestr('README.txt', 'Evidence for Optimization_20261118.txt. Includes rejected and invalid trials; consult the report before using a result.\nRecorded metadata retains original absolute paths. Route data is preserved under results/<run>/route; rebase paths when reproducing analysis on another PC.\nLarge raw ETL/utrace, executable binaries, cooked assets, raw PresentMon CSV, and bulk screenshots remain in Saved/Automation and the recorded temporary paths. Derived interval CSV and summary data are included here.\nThis archive is evidence and diagnostic source, not a runnable distribution.\n')
with zipfile.ZipFile(destination) as archive:
    assert archive.testzip() is None
print(json.dumps(dict(path=str(destination), files=len(manifest), bytes=destination.stat().st_size, sha256=hashlib.sha256(destination.read_bytes()).hexdigest()), indent=2))
