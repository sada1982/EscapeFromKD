import argparse
import ctypes
from ctypes import wintypes
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

from run_observed_probe import digest, hidden


here = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument("variant", type=Path)
parser.add_argument("name")
parser.add_argument("--initial-fps", type=int, choices=[0,20], required=True)
parser.add_argument("--expected-window", choices=["maximized","normal"], default="maximized")
parser.add_argument("--ownership-test", action="store_true")
parser.add_argument("--close-proof", action="store_true")
parser.add_argument("--execute", action="store_true")
args = parser.parse_args()
assert args.name.isalnum()
assert not (args.ownership_test and args.close_proof)
assert not ((args.ownership_test or args.close_proof) and args.initial_fps != 0)
source = args.variant.resolve(strict=True)
proof = json.loads((source / "proof.json").read_text(encoding="utf8"))
gate = (source / "SourceSnapshot/ExhibitStartupGate.cpp").read_text(encoding="utf8")
assert "ResourceReadyQpc" in gate and "LoadingFpsLimit" in gate
assert re.findall(r"^t\.MaxFPS=(.*)$",proof["settings"],flags=re.M) == ["0"]
if args.initial_fps == 20:
    assert proof.get("frame_rate_limit") == 20 and "FrameRateLimit=20.000000" in proof["game_user_settings_after"]
relative_exe = Path("myProject/Binaries/Win64/myProject-Win64-Shipping.exe")
relative_pak = Path("myProject/Content/Paks/myProject-Windows.pak")
run = here / args.name
watch = here / (args.name + "Window")
control = here / (args.name + "Control")
deploy = here / ("Variants" if args.close_proof else "FreshDeployments") / args.name / "Windows"
command = [sys.executable,"-B",str(here / "run_suite.py"),str(deploy / relative_exe),args.name,"--timeout","600",
           "-KDStartupMaxFPS=30","-KDSurveyScenes=ClassroomStart","-KDSurveyRounds=1","-KDSurveyWarmFrames=120","-KDSurveySampleFrames=120"]
if args.ownership_test:
    command.append("-KDLoadingCapOwnershipTest")
if args.close_proof:
    command.append("-KDLoadingCapCloseProof")
plan = dict(source=str(source),run=str(run),watch=str(watch),deploy=str(deploy),initial_fps=args.initial_fps,
            command=command,purpose="loading liveness only; excluded from performance acceptance",
            same_exe_sha256=proof["exe_sha256"],expected_window=args.expected_window,ownership_test=args.ownership_test,close_proof=args.close_proof)
if not args.execute:
    print(json.dumps(plan,indent=2))
    raise SystemExit(0)
for path in (run,watch,control,deploy.parent):
    if path.exists():
        raise FileExistsError(path)
assert digest(source / "Windows" / relative_exe) == proof["exe_sha256"]
assert digest(source / "Windows" / relative_pak) == proof["pak_sha256"]
for path in (source / "Windows").rglob("*"):
    if not path.is_file():
        continue
    relative = path.relative_to(source / "Windows")
    if "Saved" in relative.parts:
        continue
    target = deploy / relative
    target.parent.mkdir(parents=True,exist_ok=True)
    os.link(path,target)
    assert os.path.samefile(path,target)
control.mkdir()
(control / "plan.json").write_text(json.dumps(plan,indent=2),encoding="utf8")
watcher = hidden([sys.executable,"-B",str(here / "watch_editor_window.py"),str(run / "metadata.json"),str(watch),
                  "--state",str(here / "editor_minimize_A2.json"),"--seconds","800"],control / "watcher.log")
runner = None
try:
    deadline = time.monotonic()+15
    while not (watch / "ready.json").exists():
        if watcher.poll() is not None or time.monotonic() > deadline:
            raise RuntimeError("Window watcher not ready; no game launched")
        time.sleep(.1)
    initial = json.loads((watch / "ready.json").read_text(encoding="utf8"))
    window = initial["initial_window"]
    assert not window["iconic"] and window["zoomed"] == (args.expected_window=="maximized") and window["showCmd"] == (3 if args.expected_window=="maximized" else 1)
    assert initial["initial_foreground"]["pid"] != window["pid"]
    class Power(ctypes.Structure):
        _fields_=[("ac",wintypes.BYTE),("battery_flags",wintypes.BYTE),("battery_percent",wintypes.BYTE),("saver",wintypes.BYTE),("remaining_seconds",wintypes.DWORD),("full_seconds",wintypes.DWORD)]
    power=Power()
    if not ctypes.WinDLL("kernel32",use_last_error=True).GetSystemPowerStatus(ctypes.byref(power)):
        raise ctypes.WinError(ctypes.get_last_error())
    plan["launch_power"]={"ac":power.ac,"battery_percent":power.battery_percent,"saver":power.saver}
    runner = hidden(command,control / "runner.log")
    if args.close_proof:
        deadline=time.monotonic()+160
        while True:
            try:
                meta=json.loads((run / "metadata.json").read_text(encoding="utf8"))
                pid=meta["game_pid"]
                break
            except (FileNotFoundError,json.JSONDecodeError,KeyError):
                if runner.poll() is not None or time.monotonic()>deadline:
                    raise RuntimeError("Close proof game did not reach ready")
                time.sleep(.1)
        time.sleep(3)
        subprocess.run([sys.executable,"-B",str(here / "close_private_game.py"),meta["route"],
                        "--expected-pid",str(pid),"--expected-exe",str(deploy / relative_exe),"--send","--wait-seconds","15"],check=True,creationflags=subprocess.CREATE_NO_WINDOW)
    plan["runner_returncode"] = runner.wait(timeout=780)
    assert plan["runner_returncode"] == 0
finally:
    if watch.exists():
        (watch / "done.flag").write_text("done\n",encoding="ascii")
    try:
        plan["watcher_returncode"] = watcher.wait(timeout=15)
    except subprocess.TimeoutExpired:
        plan["watcher_still_running_pid"] = watcher.pid
    if runner is not None and runner.poll() is None:
        plan["runner_still_running_pid"] = runner.pid
    (control / "execution.json").write_text(json.dumps(plan,indent=2),encoding="utf8")
assert plan.get("watcher_returncode") == 0
(run / "exclusion.txt").write_text("Functional low-FPS loading regression validation; not a 60FPS performance acceptance run.\n",encoding="utf8")
if args.close_proof:
    subprocess.run([sys.executable,"-B",str(here / "audit_cap_close.py"),str(run)],check=True,creationflags=subprocess.CREATE_NO_WINDOW)
    print("Early close validation passed:",args.name,flush=True)
    raise SystemExit(0)
gate_audit = [sys.executable,"-B",str(here / "audit_cap_ownership.py"),str(run)] if args.ownership_test else [sys.executable,"-B",str(here / "audit_lowfps_gate.py"),str(run),"--initial-fps",str(args.initial_fps)]
for command in (gate_audit,
                [sys.executable,"-B",str(here / "analyze_suite.py"),str(run)],
                [sys.executable,"-B",str(here / "audit_window_samples.py"),str(run),str(watch),"--expected",args.expected_window,"--include-startup"]):
    subprocess.run(command,check=True,creationflags=subprocess.CREATE_NO_WINDOW)
assert json.loads((watch / "sample_window_audit.json").read_text(encoding="utf8"))["all_rounds_observed_stable"]
print("Functional gate validation passed:",args.name,flush=True)
