import argparse
import hashlib
import json
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('variant', choices=('GalleryParts', 'Furniture', 'LaptopOnly'))
parser.add_argument('--fixed-materials', action='store_true')
args = parser.parse_args()
out = Path(__file__).resolve().parent
isolation = json.loads((out / (args.variant + '_isolation.json')).read_text(encoding='utf8'))
work = Path(isolation['project'])
source = Path(isolation['source'])
baseline = {value['path']: value['sha256'] for value in isolation['files']}
changes = {}
for relative, expected in baseline.items():
    original = source / relative
    assert hashlib.sha256(original.read_bytes()).hexdigest() == expected, ('original_content_changed', relative)
    copied = work / relative
    assert copied.is_file() and original.stat().st_ino != copied.stat().st_ino, relative
for copied in (work / 'Content').rglob('*'):
    if not copied.is_file():
        continue
    relative = copied.relative_to(work).as_posix()
    digest = hashlib.sha256(copied.read_bytes()).hexdigest()
    if baseline.get(relative) != digest:
        changes[relative] = dict(change='changed' if relative in baseline else 'added', sha256=digest)
if args.variant == 'GalleryParts':
    geometry = json.loads((out / 'gallery_geometry_proof.json').read_text(encoding='utf8'))
    allowed = {'Content/Main/Stage/BP_Floor03.uasset', 'Content/Main/Stage/KDStage.umap'}
    allowed.update(item['path'].split('.')[0].replace('/Game/', 'Content/') + '.uasset' for item in geometry['parts'])
elif args.variant == 'LaptopOnly':
    geometry = json.loads((out / 'laptop_only_proof.json').read_text(encoding='utf8'))
    allowed = {'Content/Main/Stage/BP_Floor03.uasset', 'Content/Main/Stage/KDStage.umap',
               'Content/Main/Stage/Floor03/OptimizedV03/SM_F03V03_Laptops.uasset'}
else:
    geometry = json.loads((out / 'furniture_geometry_proof.json').read_text(encoding='utf8'))
    allowed = {'Content/Main/Stage/BP_Floor03.uasset', 'Content/Main/Stage/KDStage.umap'}
    for group in geometry['groups'].values():
        allowed.add(group['path'].split('.')[0].replace('/Game/', 'Content/') + '.uasset')
        allowed.update(item['path'].split('.')[0].replace('/Game/', 'Content/') + '.uasset' for item in group['shadows'])
assert set(changes) == allowed, (sorted(changes), sorted(allowed))
record = dict(variant=args.variant, project=str(work), original_content_unchanged=True,
              independent_content=True, changes=changes)
baseline_world = json.loads((out / 'world_furniture_before.json').read_text(encoding='utf8'))
after_name = 'world_gallery_parts.json' if args.variant == 'GalleryParts' else 'world_furniture_after.json'
if args.variant == 'LaptopOnly':
    after_name = 'world_laptop_only.json'
if args.fixed_materials:
    assert args.variant == 'GalleryParts'
    after_name = 'world_gallery_parts_materialfix.json'
    material_proof = json.loads((out / 'gallery_material_fix_proof.json').read_text(encoding='utf8'))
    assert material_proof['all_match'] and material_proof['checked_slots_per_component'] == 13
    record['effective_material_proof'] = material_proof
candidate_world = json.loads((out / after_name).read_text(encoding='utf8'))
assert baseline_world['tested'] == candidate_world['tested']
assert baseline_world['sha256_trace'] == candidate_world['sha256_trace']
record['collision_rays'] = candidate_world['tested']
record['collision_sha256'] = candidate_world['sha256_trace']
(out / (args.variant + '_content_proof.json')).write_text(json.dumps(record, indent=2), encoding='utf8')
print(args.variant, 'verified changes:', len(changes))
