主性能値はSurveyA/summary.json。DiagnosticAはDevelopment＋トレースの内訳用で、性能絶対値を混合しない。
全28測定区間を取得。DiagnosticAは終了コード777003、具体的原因未確定。exit_777003_audit.txt参照。
コードと小容量の再解析資料を収録。巨大な生utrace・scene_*.csvはローカルのみ。パスはAudit/trace_findings.txt。
正式Content・Config・Build/Exhibit・配布版には変更を加えていない。
