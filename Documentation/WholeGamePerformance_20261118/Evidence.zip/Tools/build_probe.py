import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

here = Path(__file__).resolve().parent
project = here.parents[2]
parser = argparse.ArgumentParser()
parser.add_argument("configuration", choices=["Shipping", "Development"])
args = parser.parse_args()
work = Path(os.environ["LOCALAPPDATA"]) / "KDGateTraceDev_20261117"
subprocess.run([sys.executable, "-B", str(here / "prepare_survey.py")], check=True)
tool = Path("C:/Program Files/Epic Games/UE_5.8/Engine/Build/BatchFiles/Build.bat")
with (here / ("build_" + args.configuration + ".log")).open("wb") as log:
    result = subprocess.run([str(tool), "myProject", "Win64", args.configuration,
                             "-Project=" + str(work / "myProject.uproject"),
                             "-NoLiveCoding", "-NoHotReload", "-WaitMutex"],
                            stdout=log, stderr=log,
                            creationflags=subprocess.CREATE_NO_WINDOW)
if result.returncode:
    print((here / ("build_" + args.configuration + ".log")).read_text(encoding="utf8", errors="replace")[-5000:])
    sys.exit(result.returncode)
target = here / args.configuration / "Windows"
shipping = project / "Saved/ExhibitBuild_20261117_ExitCull/Windows"
binary_name = "myProject-Win64-Shipping.exe" if args.configuration == "Shipping" else "myProject.exe"
template = shipping if args.configuration == "Shipping" else here.parent / "GalleryThreadTrace_20261117/Development/Windows"
inner = Path("myProject/Binaries/Win64") / binary_name
pak_dir = Path("myProject/Content/Paks")
target.mkdir(parents=True, exist_ok=True)
for source in template.rglob("*"):
    if not source.is_file():
        continue
    rel = source.relative_to(template)
    if rel == inner or rel.is_relative_to(pak_dir) or "Saved" in rel.parts:
        continue
    dest = target / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    if not dest.exists():
        os.link(source, dest)
containers = {}
for source in (shipping / pak_dir).iterdir():
    if not source.is_file():
        continue
    dest = target / pak_dir / source.name
    dest.parent.mkdir(parents=True, exist_ok=True)
    if not dest.exists():
        os.link(source, dest)
    assert os.path.samefile(source, dest)
    containers[source.name] = hashlib.sha256(source.read_bytes()).hexdigest()
(target / inner).parent.mkdir(parents=True, exist_ok=True)
shutil.copyfile(work / "Binaries/Win64" / binary_name, target / inner)
proof = dict(configuration=args.configuration, exe=str(target / inner),
             content_containers=containers, source="current Build/Exhibit with Survey.h added",
             original_shipping_exe_sha256=hashlib.sha256((shipping / "myProject/Binaries/Win64/myProject-Win64-Shipping.exe").read_bytes()).hexdigest())
(here / (args.configuration + "_proof.json")).write_text(json.dumps(proof, indent=2), encoding="utf8")
print(target / inner)
