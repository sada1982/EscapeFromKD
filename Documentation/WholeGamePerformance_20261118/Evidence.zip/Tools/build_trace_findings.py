import csv
import json
from collections import defaultdict
from pathlib import Path

from summarize_scene_trace import Timeline, deepest_segments, stats


root = Path(__file__).resolve().parent
scene_root = root / "DiagnosticA/SceneTrace"
scene_data = json.loads((scene_root / "scene_scopes.json").read_text())
worker_data = json.loads((root / "DiagnosticA/WorkerTrace/scene_scopes.json").read_text())
passes = ["Frame", "MegaLights", "LumenReflections", "TemporalSuperResolution",
          "ShadowDepths", "RenderVirtualShadowMaps", "Nanite::DrawGeometry",
          "LumenScreenProbeGather", "LumenSceneLighting%s", "BuildCardUpdateContext",
          "UpdateWorldRadianceCaches", "ContrastAdaptiveShading"]
wait_names = {"Game thread idle time", "WaitForTasks", "WaitForFrameEventCompletion",
              "RHIThreadStall", "FTaskBase::WaitImpl_StateChangeEvent_WaitFor"}
scenes = []
for scene in scene_data["scenes"]:
    row = {key: scene[key] for key in ("scene", "tour", "start", "end", "events_csv")}
    row["gpu"] = {}
    row["cpu"] = {}
    for name, lane in scene["lanes"].items():
        if name.startswith("GPU"):
            row["gpu"][name] = {p: lane["complete_frame_scopes"][p] for p in passes
                                 if p in lane["complete_frame_scopes"]}
        else:
            waiting = sum(v for k, v in lane["exclusive_deepest_ms"].items()
                          if k in wait_names or k.startswith(("CPU Stall - ", "FPlatformProcess::Sleep")))
            row["cpu"][name] = dict(window_ms=lane["window_ms"], named_leaf_wait_ms=waiting,
                                     unscoped_ms=lane["unscoped_ms"],
                                     recorded_wall_excluding_named_wait_ms=lane["window_ms"]-waiting-lane["unscoped_ms"],
                                     top_deepest_scopes=list(lane["exclusive_deepest_ms"].items())[:10])
    if scene["tour"] == 2 and scene["scene"] in ("ClassroomStart", "ClassroomExit", "Atrium3FDown"):
        with (scene_root / scene["events_csv"]).open(encoding="utf-8-sig", newline="") as stream:
            scopes = [(float(r["StartTime"]), float(r["EndTime"]), int(r["Depth"]), r["TimerName"])
                      for r in csv.DictReader(stream) if r["ThreadName"] == "GameThread"]
        leaves = deepest_segments(scopes, scene["start"], scene["end"])
        waits = Timeline([span for name, spans in leaves.items() for span in spans
                          if name in wait_names or name.startswith(("CPU Stall - ", "FPlatformProcess::Sleep"))])
        uncovered = Timeline(leaves.get("[unscoped]", []))
        groups = defaultdict(list)
        for a, b, depth, timer in scopes:
            if timer == "FEngineLoop::Tick" and scene["start"] <= a < b <= scene["end"]:
                duration = 1000 * (b-a)
                wait = waits.overlap_ms(a, b)
                groups["over16p67" if duration > 1000/60 else "within16p67"].append(
                    dict(frame_ms=duration, wait_ms=wait,
                         recorded_other_wall_ms=duration-wait-uncovered.overlap_ms(a, b)))
        row["gt_conditional"] = {key: {metric: stats([x[metric] for x in values])
                                        for metric in ("frame_ms", "wait_ms", "recorded_other_wall_ms")}
                                 for key, values in groups.items()}
    scenes.append(row)

workers = []
for scene in worker_data["scenes"]:
    pool = {name: lane for name, lane in scene["lanes"].items() if name.startswith("PSOPrecompilePool")}
    shader_ms = defaultdict(float)
    for lane in pool.values():
        for name, duration in lane["inclusive_ms"].items():
            if name.startswith("F") and name.endswith("CS"):
                shader_ms[name] += duration
    workers.append(dict(scene=scene["scene"], tour=scene["tour"], window_ms=1000*(scene["end"]-scene["start"]),
                        pool_threads_with_recorded_events=len(pool),
                        create_time_thread_ms=sum(l["exclusive_deepest_ms"].get("Create time", 0) for l in pool.values()),
                        medium_priority_thread_ms=sum(l["inclusive_ms"].get("Priority: Medium", 0) for l in pool.values()),
                        compute_create_thread_ms=sum(l["inclusive_ms"].get("FD3D12DynamicRHI::RHICreateComputePipelineState", 0) for l in pool.values()),
                        shader_inclusive_thread_ms=dict(sorted(shader_ms.items(), key=lambda kv: -kv[1])),
                        per_pool_thread={name: dict(thread_id=l["thread_id"], create_ms=l["exclusive_deepest_ms"].get("Create time", 0)) for name,l in pool.items()}))

result = dict(
    build="Independent Development diagnostic, not the Shipping performance baseline",
    trace="C:/Users/motoo/AppData/Local/Temp/KDWholeGame_se8vnisg/game.utrace",
    anchor_count=56, anchor_spread_ms=scene_data["anchor_spread_ms"],
    method=["Every scene uses a centered 3-second sample; 12 scene/round windows, 2 all-worker windows.",
            "GPU values are timestamp elapsed time per complete Frame on that same lane. Parent/child inclusive scopes overlap. Graphics and Compute execute concurrently; do not sum lanes.",
            "CPU deepest scope time is elapsed wall time, not OS on-CPU time. Named waits exclude nested recorded work; remaining wall time may contain unscheduled time or driver waits.",
            "PSO thread-ms is resource occupancy across concurrent threads, not frame time or a proven achievable frame-time saving.",
            "All 28 begin/end pairs (56 markers) were found. Last CombatFire round 2 contains 243 complete GPU Frames on each lane. Process exit 777003 was reported by the launcher; parent investigation identifies CrashReporterCrashed after measured work. Trace data does not establish crash cause."],
    workers=workers, scenes=scenes,
    conclusions=[
        "Confirmed: 15 PSOPrecompilePool workers are creating Medium-priority compute PSOs during the first ClassroomStart sample. In round 2 those pool threads emit no sampled events. This explains an important startup CPU workload, not all steady-state slow frames.",
        "Priority: include Medium PSO work in loading readiness and/or explicitly control its compile concurrency; validate startup time and first-play hitches in fresh Shipping deployment. Merely seeing active priority >=2 count zero is insufficient.",
        "Steady GPU sample hotspots: MegaLights on Graphics; LumenScreenProbeGather and LumenSceneLighting on Compute; LumenReflections and TSR also material. Retain lane overlap caveat.",
        "Atrium ShadowDepths is lower than classroom samples, so global contact-shadow reduction is not supported as first priority. Classroom VSM should be considered separately.",
        "Reducing excess light influence and investigating Lumen/reflection-visible geometry are targeted candidates. Current Surface Cache update scopes do not establish a uniquely large atrium update cost, so SharedGallery mesh splitting is not a demonstrated speedup.",
        "Warm GT slow frames show substantial named waits. Remaining wall scheduling/submission waits require focused correlation or OS scheduling evidence; the GPU pass ranking does not prove the cause of every Present outlier.",
        "CombatIdle/CombatFire represents the current single enemy setup only. It cannot predict many-enemy scalability or maximum decal/effect accumulation."])
(root / "trace_findings.json").write_text(json.dumps(result, indent=2), encoding="utf-8")

lines = ["Whole-game diagnostic trace findings (2026-11-18)",
         "Development diagnostic only. Shipping SurveyA remains the absolute performance baseline.", "",
         "1. Startup CPU",]
for w in workers:
    lines.append(f"ClassroomStart round {w['tour']}, 3000 ms: {w['pool_threads_with_recorded_events']} PSO pool threads recorded, Create time={w['create_time_thread_ms']:.3f} thread-ms, Medium={w['medium_priority_thread_ms']:.3f} thread-ms.")
lines += ["15 simultaneous Medium-priority compute PSO compiles are confirmed in round 1; no pool scope events in round 2.",
          "CPU scope elapsed is not OS CPU execution; parallel thread-ms must not be added to a frame budget.", "",
          "2. Warm GPU scope elapsed means, ms (same-lane inclusive scopes; Graphics/Compute overlap)",
          "scene | Graphics Frame | MegaLights | Reflections | TSR | ShadowDepths | VSM | Compute Gather | LumenSceneLighting | CardUpdate | RadianceCache"]
for s in scenes:
    if s["tour"] != 2:
        continue
    g = s["gpu"]["GPU0-Graphics0"]
    c = s["gpu"]["GPU0-Compute0"]
    vals = [g.get(k, {}).get("mean_ms", 0) for k in ("Frame", "MegaLights", "LumenReflections", "TemporalSuperResolution", "ShadowDepths", "RenderVirtualShadowMaps")]
    vals += [c.get(k, {}).get("mean_ms", 0) for k in ("LumenScreenProbeGather", "LumenSceneLighting%s", "BuildCardUpdateContext", "UpdateWorldRadianceCaches")]
    lines.append(s["scene"] + " | " + " | ".join(f"{v:.3f}" for v in vals))
lines += ["", "3. Warm GT slow-frame split: mean elapsed / named wait / remaining recorded wall (ms)"]
for s in scenes:
    for group, values in s.get("gt_conditional", {}).items():
        lines.append(f"{s['scene']} {group} n={values['frame_ms']['n']}: " + " / ".join(f"{values[k]['mean_ms']:.3f}" for k in ("frame_ms", "wait_ms", "recorded_other_wall_ms")))
lines += ["", "4. Findings and limits"] + result["conclusions"]
lines += ["", "5. Evidence and integrity"] + result["method"] + [result["trace"],
           str(scene_root / "scene_scopes.json"), str(root / "DiagnosticA/WorkerTrace/scene_scopes.json"),
           "Raw CSV and utrace are local evidence, intentionally not copied into the compact report bundle."]
(root / "trace_findings.txt").write_text("\n".join(lines)+"\n", encoding="utf-8")
print("Wrote trace_findings.json and trace_findings.txt")
