import argparse
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import time

here = Path(__file__).resolve().parent
helpers = here.parent / "Exhibit42_20261116"
sys.path.insert(0, str(helpers))
from exhibit_telemetry import PM, clock_snapshot, hidden

parser = argparse.ArgumentParser()
parser.add_argument("exe", type=Path)
parser.add_argument("name")
parser.add_argument("--trace", action="store_true")
parser.add_argument("--editor", type=int, default=27448)
parser.add_argument("--timeout", type=int, default=1200)
parser.add_argument("extra", nargs="*")
args = parser.parse_args()
assert args.name.isalnum()
exe = args.exe.resolve(strict=True)
out = here / args.name
out.mkdir(exist_ok=False)
scratch = Path(tempfile.mkdtemp(prefix="KDWholeGame_"))
route = scratch / "route"
profile = scratch / "profile"
route.mkdir()
profile.mkdir()
session = "KDWholeGame_" + args.name
meta = dict(exe=str(exe), route=str(route), profile=str(profile),
            trace=str(scratch / "game.utrace"), start=clock_snapshot(),
            instrumentation="Development trace" if args.trace else "Shipping scene control")
def save():
    (out / "metadata.json").write_text(json.dumps(meta, indent=2), encoding="utf8")
save()
pm = hidden([str(PM), "-session_name", session, "-process_name", exe.name, "-qpc_time",
             "-output_file", str(out / "presents_native.csv"), "-no_top"],
            out / "pm.stdout", out / "pm.stderr")
monitor = None
game = None
try:
    if (here / "monitor.py").is_file():
        monitor = hidden([sys.executable, "-B", str(here / "monitor.py"), str(route), str(out),
                          "--editor", str(args.editor)], out / "monitor.stdout", out / "monitor.stderr")
    launch = [sys.executable, "-B", str(helpers / "private_launch.py"), str(exe), str(route),
              "-windowed", "-ResX=1920", "-ResY=1080", "-ForceRes", "-D3D12", "-NoVSync",
              "-NoSplash", "-NoScreenMessages", "-unattended", "-WinX=0", "-WinY=0",
              "-UserDir=" + str(profile), "-KDExhibitRoute", "-KDExhibitRouteWaitForGo",
              "-KDExhibitRouteDir=" + str(route), "-KDWholeGameSurvey",
              "-abslog=" + str(scratch / "engine.log"), *args.extra]
    if args.trace:
        launch += ["-trace=cpu,gpu,frame,bookmark", "-tracefile=" + meta["trace"], "-statnamedevents"]
    meta["args"] = launch[5:]
    save()
    with (out / "launcher.log").open("wb") as log:
        game = subprocess.Popen(launch, stdout=log, stderr=log, creationflags=subprocess.CREATE_NO_WINDOW)
        deadline = time.monotonic() + 160
        while not (route / "ready.txt").is_file():
            if game.poll() is not None or time.monotonic() > deadline:
                raise RuntimeError("Game failed before route ready")
            time.sleep(.1)
        isolation = json.loads((route / "isolation.json").read_text(encoding="utf8"))
        assert isolation["desktop"] != isolation["input_desktop_start"]
        meta["game_pid"] = isolation["pid"]
        meta["ready"] = clock_snapshot()
        save()
        (route / "go.flag").write_text("go\n", encoding="ascii")
        print("Started", args.name, isolation["pid"], route, flush=True)
        code = game.wait(timeout=args.timeout)
        meta["returncode"] = code
        if code:
            raise RuntimeError(f"Game exit {code}")
finally:
    (out / "done.flag").write_text("done\n", encoding="ascii")
    subprocess.run([str(PM), "-terminate_existing", "-session_name", session],
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                   creationflags=subprocess.CREATE_NO_WINDOW)
    if monitor:
        meta["monitor_returncode"] = monitor.wait(timeout=15)
    meta["end"] = clock_snapshot()
    save()
print("Completed", args.name, flush=True)
