import bisect
import csv
import json
import statistics
import sys
from pathlib import Path


folder = Path(sys.argv[1]).resolve()
meta = json.loads((folder / "metadata.json").read_text(encoding="utf8"))
monitor = json.loads((folder / "monitor_state.json").read_text(encoding="utf8"))
route = Path(meta["route"])
frequency = monitor["qpc_frequency"]


def read(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


events = read(route / "survey_events.csv")
game = [row for row in read(folder / "monitor_process.csv") if row["role"] == "game"]
editor = [row for row in read(folder / "monitor_process.csv") if row["role"] == "editor"]
nvidia = read(folder / "monitor_nvidia.csv")
intervals = read(folder / "scene_intervals.csv")
frames = read(route / "survey_frames.csv")
process_fields = ("threads", "cpu_percent_one_core", "working_set_B", "private_B", "local_budget_B",
                  "local_usage_B", "nonlocal_usage_B", "evicted_process_B", "adapter_evicted_B")
gpu_fields = ("memory.used [MiB]", "utilization.gpu [%]", "utilization.memory [%]", "temperature.gpu",
              "clocks.current.graphics [MHz]", "clocks.current.memory [MHz]", "power.draw [W]")
status_fields = ("mem_ret", "local_status", "nonlocal_status", "proc_stat_status", "adapter_stat_status")


def stats(values):
    return dict(n=len(values), min=min(values), median=round(statistics.median(values), 4),
                mean=round(statistics.mean(values), 4), max=max(values)) if values else dict(n=0)


def values(rows, field):
    return [float(row[field]) for row in rows if row[field] not in ("", "[N/A]")]


def process_group(rows, begin, end):
    selected = [row for row in rows if begin <= int(row["qpc"]) <= end]
    result = {field: stats(values(selected, field)) for field in process_fields if field != "cpu_percent_one_core"}
    result["invalid_memory_samples"] = sum(any(int(row[k]) != 0 for k in status_fields) for row in selected)
    valid = [row for row in selected if all(int(row[k]) == 0 for k in status_fields)]
    result["local_headroom_MiB"] = stats([(int(row["local_budget_B"]) - int(row["local_usage_B"])) / 2**20 for row in valid])
    cpu = []
    read_delta = write_delta = eviction_delta = 0
    for previous, current in zip(rows, rows[1:]):
        if int(previous["qpc"]) < begin or int(current["qpc"]) > end:
            continue
        seconds = (int(current["qpc"]) - int(previous["qpc"])) / frequency
        core_seconds = sum(int(current[k]) - int(previous[k]) for k in ("kernel_100ns", "user_100ns")) / 1e7
        computed = core_seconds / seconds * 100
        assert abs(computed - float(current["cpu_percent_one_core"])) < .000051
        cpu.append(computed)
        read_delta += int(current["read_bytes"]) - int(previous["read_bytes"])
        write_delta += int(current["write_bytes"]) - int(previous["write_bytes"])
        if all(int(row[k]) == 0 for row in (previous, current) for k in status_fields):
            eviction_delta += int(current["evicted_process_B"]) - int(previous["evicted_process_B"])
    result["cpu_percent_one_core"] = stats(cpu)
    result["cpu_percent_all_logical"] = stats([x / monitor["logical_processors"] for x in cpu])
    result["in_window_io_read_bytes"] = read_delta
    result["in_window_io_write_bytes"] = write_delta
    result["in_window_evicted_process_bytes"] = eviction_delta
    return result


def gpu_group(begin, end):
    selected = [row for row in nvidia if begin <= int(row["qpc_delivery"]) <= end]
    result = {field: stats(values(selected, field)) for field in gpu_fields}
    result["thermal_active_samples"] = sum(row["clocks_event_reasons.sw_thermal_slowdown"] == "Active" or
                                           row["clocks_event_reasons.hw_thermal_slowdown"] == "Active" for row in selected)
    result["power_limit_active_samples"] = sum(row["clocks_event_reasons.sw_power_cap"] == "Active" for row in selected)
    return result


windows = []
table = []
for stop in events:
    if stop["event"] != "sample_end":
        continue
    start = next(row for row in events if row["event"] == "sample_begin" and row["round"] == stop["round"]
                 and row["index"] == stop["index"])
    begin, end = int(start["qpc"]), int(stop["qpc"])
    record = dict(round=int(stop["round"]), scene=stop["scene"], q0=begin, q1=end,
                  seconds_from_launch=round((begin - meta["start"]["qpc"]) / frequency, 3),
                  game=process_group(game, begin, end), editor=process_group(editor, begin, end),
                  gpu=gpu_group(begin, end))
    windows.append(record)
    def median(group, field):
        return record[group][field].get("median")
    table.append(dict(round=record["round"], scene=record["scene"], seconds_from_launch=record["seconds_from_launch"],
                      game_cpu_pct_one_core=median("game", "cpu_percent_one_core"),
                      game_cpu_pct_all_20_logical=median("game", "cpu_percent_all_logical"),
                      editor_cpu_pct_one_core=median("editor", "cpu_percent_one_core"),
                      gpu_pct=median("gpu", "utilization.gpu [%]"), gpu_MHz=median("gpu", "clocks.current.graphics [MHz]"),
                      gpu_W=median("gpu", "power.draw [W]"), gpu_C=median("gpu", "temperature.gpu"),
                      adapter_memory_MiB=median("gpu", "memory.used [MiB]"),
                      game_local_MiB=round(median("game", "local_usage_B") / 2**20, 3),
                      game_local_budget_MiB=round(median("game", "local_budget_B") / 2**20, 3),
                      min_game_local_headroom_MiB=record["game"]["local_headroom_MiB"].get("min"),
                      game_nonlocal_MiB=round(median("game", "nonlocal_usage_B") / 2**20, 3),
                      game_evicted_B=record["game"]["in_window_evicted_process_bytes"],
                      read_bytes=record["game"]["in_window_io_read_bytes"],
                      thermal_active=record["gpu"]["thermal_active_samples"],
                      power_limit_active=record["gpu"]["power_limit_active_samples"]))
game_qpcs = [int(row["qpc"]) for row in game]
peaks = []
for interval in sorted(intervals, key=lambda row: -float(row["ms"]))[:8]:
    begin, end = int(interval["q0"]), int(interval["q1"])
    before = bisect.bisect_right(game_qpcs, begin) - 1
    after = bisect.bisect_left(game_qpcs, end)
    if before < 0 or after >= len(game):
        continue
    left, right = game[before], game[after]
    bracket_s = (int(right["qpc"]) - int(left["qpc"])) / frequency
    peaks.append(dict(interval=interval, bracket_seconds=bracket_s,
                      bracket_process_cpu_pct_one_core=100 * sum(int(right[k]) - int(left[k]) for k in ("user_100ns", "kernel_100ns")) / 1e7 / bracket_s,
                      bracket_io_read_bytes=int(right["read_bytes"]) - int(left["read_bytes"]),
                      bracket_io_write_bytes=int(right["write_bytes"]) - int(left["write_bytes"]),
                      bracket_process_evicted_bytes=int(right["evicted_process_B"]) - int(left["evicted_process_B"]),
                      bracket_adapter_evicted_bytes=int(right["adapter_evicted_B"]) - int(left["adapter_evicted_B"]),
                      before=left, after=right,
                      nvidia_nearby=[row for row in nvidia if begin-frequency <= int(row["qpc_delivery"]) <= end+frequency],
                      ue_nearby=[row for row in frames if begin-frequency//10 <= int(row["qpc"]) <= end+frequency//10]))
rounds = {}
for number in sorted({window["round"] for window in windows}):
    selected = [window for window in windows if window["round"] == number]
    begin, end = selected[0]["q0"], selected[-1]["q1"]
    rounds[str(number)] = dict(q0=begin, q1=end, includes_transition_windows=True,
                              game=process_group(game, begin, end), editor=process_group(editor, begin, end), gpu=gpu_group(begin, end))
report = dict(method="1-second external sampling; CPU deltas are included only when both endpoints are within the scene. Memory snapshots and NVIDIA delivery QPC are sampled within the scene. Spike brackets include neighboring work and are not exact per-frame time attribution.",
              qpc_frequency=frequency, logical_processors=monitor["logical_processors"],
              scenes=windows, rounds=rounds, longest_frames=peaks,
              continuous_ac=all(row["ac_power"] == "1" for row in game),
              memory_valid_samples=sum(all(int(row[k]) == 0 for k in status_fields) for row in game),
              memory_total_samples=len(game))
(folder / "telemetry_audit.json").write_text(json.dumps(report, indent=2), encoding="utf8")
with (folder / "telemetry_by_scene.csv").open("w", encoding="utf-8-sig", newline="") as stream:
    writer = csv.DictWriter(stream, fieldnames=list(table[0]))
    writer.writeheader()
    writer.writerows(table)
print(json.dumps(dict(scenes=len(windows), ac=report["continuous_ac"], memory_valid=report["memory_valid_samples"], memory_total=len(game))))
for row in table:
    print(row["round"], row["scene"], row["game_cpu_pct_one_core"], row["gpu_pct"], row["gpu_MHz"], row["gpu_W"], row["gpu_C"], row["min_game_local_headroom_MiB"], row["game_evicted_B"])
