#pragma once
#include "Camera/PlayerCameraManager.h"
#include "Components/LightComponent.h"
#include "DynamicRHI.h"
#include "EngineUtils.h"
#include "GameFramework/Character.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "GameFramework/PlayerController.h"
#include "HAL/IConsoleManager.h"
#include "HAL/PlatformTime.h"
#include "Misc/CommandLine.h"
#include "Misc/FileHelper.h"
#include "Misc/Paths.h"
#include "ProfilingDebugging/CpuProfilerTrace.h"
#include "RenderTimer.h"
#include "PipelineStateCache.h"
#include "ShaderPipelineCache.h"
#include "UObject/UnrealType.h"
#include "UnrealClient.h"

struct FWholeGameSurvey
{
    struct FPose
    {
        const TCHAR* Name;
        FVector Position;
        FRotator Rotation;
        double Sweep;
        bool Fire;
    };
    enum class EPhase { Move, Warm, Sample, Photo };
    bool Enabled=false;
    bool Initialized=false;
    int32 Index=0, Round=1, Frame=0, Rounds=2, WarmFrames=120, SampleFrames=600;
    int32 HitSamples=0, ShotChanges=0, InvalidScenes=0;
    double LastShot=0;
    EPhase Phase=EPhase::Move;
    TArray<FPose> Poses;
    TArray<TWeakObjectPtr<AActor>> Enemies;
    UFunction* FireStart=nullptr;
    UFunction* FireStop=nullptr;
    FNumericProperty* ShotProperty=nullptr;
    FString Events=TEXT("event,round,index,scene,qpc,frame,x,y,z,pitch,yaw,fire,hit_samples,shot_changes\n");
    FString Frames=TEXT("qpc,round,index,scene,frame,world_delta,app_delta,x,y,z,pitch,yaw,cam_x,cam_y,cam_z,cam_pitch,cam_yaw,fov,next_shot,hit_count,gt_busy_ms,rt_busy_ms,rhi_busy_ms,gpu_ms,gt_wait_ms,rt_wait_ms\n");
    FString Floors=TEXT("round,scene,hit,x,y,z,actor,component\n");
    FString Pending=TEXT("event,round,scene,qpc,pso_pending,active_precache\n");

    const FPose& CurrentPose() const
    {
        const bool HasCombatPair=Poses.Num()>=2 && FCString::Strcmp(Poses.Last().Name,TEXT("CombatFire"))==0 &&
            FCString::Strcmp(Poses[Poses.Num()-2].Name,TEXT("CombatIdle"))==0;
        const int32 Count=HasCombatPair?Poses.Num()-2:Poses.Num();
        return Poses[Round%2==0 && Index<Count?Count-Index-1:Index];
    }

    static void Write(const FString& Path,const FString& Text)
    {
        FFileHelper::SaveStringToFile(Text,*Path,FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM);
    }
    void Mark(const TCHAR* Event,uint64 Now,ACharacter* Char,APlayerController* Player)
    {
        const FVector P=Char->GetActorLocation();
        const FRotator R=Player->GetControlRotation();
        Pending+=FString::Printf(TEXT("%s,%d,%s,%llu,%u,%u\n"),Event,Round,CurrentPose().Name,Now,FShaderPipelineCache::NumPrecompilesRemaining(),PipelineStateCache::NumActivePrecacheRequests());
        Events+=FString::Printf(TEXT("%s,%d,%d,%s,%llu,%d,%.4f,%.4f,%.4f,%.4f,%.4f,%d,%d,%d\n"),
            Event,Round,Index,CurrentPose().Name,Now,Frame,P.X,P.Y,P.Z,R.Pitch,R.Yaw,CurrentPose().Fire?1:0,HitSamples,ShotChanges);
    }
    void Save(const FString& Dir)
    {
        Write(FPaths::Combine(Dir,TEXT("survey_events.csv")),Events);
        Write(FPaths::Combine(Dir,TEXT("survey_frames.csv")),Frames);
        Write(FPaths::Combine(Dir,TEXT("survey_floors.csv")),Floors);
        Write(FPaths::Combine(Dir,TEXT("survey_pending.csv")),Pending);
    }
    double ShotTime(ACharacter* Char) const
    {
        return ShotProperty?ShotProperty->GetFloatingPointPropertyValue(ShotProperty->ContainerPtrToValuePtr<void>(Char)):0.0;
    }
    int32 Hits() const
    {
        int32 N=0;
        for (const auto& Weak : Enemies)
            if (AActor* Actor=Weak.Get())
                if (FBoolProperty* P=FindFProperty<FBoolProperty>(Actor->GetClass(),TEXT("IsHitReacting")))
                    N+=P->GetPropertyValue_InContainer(Actor)?1:0;
        return N;
    }
    void Init(const FString& Dir,ACharacter* Char)
    {
        Initialized=true;
        const FPose All[]={
            {TEXT("ClassroomStart"),{402,-73,98.15},{0,-90,0},10,false},
            {TEXT("ClassroomMiddle"),{402,-665,98.15},{0,-90,0},10,false},
            {TEXT("ClassroomExit"),{252,-890,98.15},{0,-168,0},10,false},
            {TEXT("Gallery3F"),{-117,-420,98.15},{0,90,0},12,false},
            {TEXT("Atrium3FDown"),{-117,-550,98.15},{-25,-155,0},12,false},
            {TEXT("Stairs3F"),{-1635,190,98.15},{-12,180,0},8,false},
            {TEXT("Gallery2F"),{-105,-850,-216.85},{-3,90,0},12,false},
            {TEXT("Plaza2F"),{-1150,100,-216.85},{0,180,0},12,false},
            {TEXT("Atrium1F"),{-950,-700,-530},{20,35,0},12,false},
            {TEXT("Atrium1FUp"),{-950,-700,-530},{55,35,0},12,false},
            {TEXT("Hall1F"),{100,-650,-530},{0,-90,0},15,false},
            {TEXT("Exit1F"),{700,-220,-530},{0,0,0},12,false},
            {TEXT("CombatIdle"),{-1100,350,98.15},{-8,180,0},0,false},
            {TEXT("CombatFire"),{-1100,350,98.15},{-8,180,0},0,true}
        };
        FString Filter;
        TArray<FString> Chosen;
        FParse::Value(FCommandLine::Get(),TEXT("KDSurveyScenes="),Filter);
        Filter.ParseIntoArray(Chosen,TEXT(","),true);
        for (const auto& P : All)
            if (Chosen.IsEmpty() || Chosen.Contains(P.Name)) Poses.Add(P);
        FParse::Value(FCommandLine::Get(),TEXT("KDSurveyRounds="),Rounds);
        FParse::Value(FCommandLine::Get(),TEXT("KDSurveyWarmFrames="),WarmFrames);
        FParse::Value(FCommandLine::Get(),TEXT("KDSurveySampleFrames="),SampleFrames);
        Rounds=FMath::Clamp(Rounds,1,4);
        WarmFrames=FMath::Clamp(WarmFrames,120,1200);
        SampleFrames=FMath::Clamp(SampleFrames,120,2400);
        Frames.Reserve(Rounds*Poses.Num()*SampleFrames*240);
        FireStart=Char->FindFunction(TEXT("StartFiring"));
        FireStop=Char->FindFunction(TEXT("StopFiring"));
        ShotProperty=FindFProperty<FNumericProperty>(Char->GetClass(),TEXT("NextShotTime"));
        FString Actors=TEXT("path,class,x,y,z\n");
        FString Lights=TEXT("actor,component,class,x,y,z,intensity,cast_shadow,mobility\n");
        int32 LightCount=0;
        for (TActorIterator<AActor> It(Char->GetWorld());It;++It)
        {
            const FVector P=It->GetActorLocation();
            Actors+=FString::Printf(TEXT("%s,%s,%.4f,%.4f,%.4f\n"),*It->GetPathName(),*It->GetClass()->GetPathName(),P.X,P.Y,P.Z);
            if (It->GetClass()->GetName().StartsWith(TEXT("BP_AdmissionRobot"))) Enemies.Add(*It);
            TInlineComponentArray<ULightComponent*> Components(*It);
            for (ULightComponent* C : Components)
            {
                ++LightCount;
                const FVector L=C->GetComponentLocation();
                Lights+=FString::Printf(TEXT("%s,%s,%s,%.4f,%.4f,%.4f,%.4f,%d,%d\n"),*It->GetName(),*C->GetName(),*C->GetClass()->GetName(),L.X,L.Y,L.Z,C->Intensity,C->CastShadows?1:0,(int32)C->Mobility.GetValue());
            }
        }
        Write(FPaths::Combine(Dir,TEXT("survey_actors.csv")),Actors);
        Write(FPaths::Combine(Dir,TEXT("survey_lights.csv")),Lights);
        Write(FPaths::Combine(Dir,TEXT("survey_meta.txt")),FString::Printf(TEXT("qpc_frequency=%lld\nrounds=%d\nscenes=%d\nwarm_frames=%d\nsample_frames=%d\nenemies=%d\nlights=%d\nstart_fire=%d\nstop_fire=%d\nnext_shot=%d\n"),
            FMath::RoundToInt64(1.0/FPlatformTime::GetSecondsPerCycle64()),Rounds,Poses.Num(),WarmFrames,SampleFrames,Enemies.Num(),LightCount,FireStart?1:0,FireStop?1:0,ShotProperty?1:0));
    }
    void Next(const FString& Dir,ACharacter* Char)
    {
        if (FireStop) Char->ProcessEvent(FireStop,nullptr);
        Save(Dir);
        ++Index;
        if (Index==Poses.Num()) { Index=0; ++Round; }
        Frame=0;
        Phase=EPhase::Move;
        if (Round>Rounds)
        {
            Write(FPaths::Combine(Dir,TEXT("survey_result.txt")),FString::Printf(TEXT("success=%d\nrounds=%d\nscenes=%d\ninvalid_scenes=%d\n"),InvalidScenes==0?1:0,Rounds,Poses.Num(),InvalidScenes));
            FPlatformMisc::RequestExit(false,TEXT("KDWholeGameSurveyComplete"));
        }
    }
    void Update(const FString& Dir,APlayerController* Player,ACharacter* Char,float Delta)
    {
        if (!Initialized) Init(Dir,Char);
        if (Round>Rounds) return;
        if (Poses.IsEmpty())
        {
            Write(FPaths::Combine(Dir,TEXT("survey_result.txt")),TEXT("success=0\nreason=no_scenes\n"));
            FPlatformMisc::RequestExit(false,TEXT("KDWholeGameSurveyEmpty"));
            return;
        }
        const auto& Pose=CurrentPose();
        if (Phase==EPhase::Move)
        {
            if (FireStop) Char->ProcessEvent(FireStop,nullptr);
            Char->GetCharacterMovement()->StopMovementImmediately();
            Char->SetActorLocation(Pose.Position,false,nullptr,ETeleportType::TeleportPhysics);
            Player->SetControlRotation(Pose.Rotation);
            Frame=0;HitSamples=0;ShotChanges=0;LastShot=ShotTime(Char);
            Mark(TEXT("arrive"),FPlatformTime::Cycles64(),Char,Player);
            Phase=EPhase::Warm;
        }
        const double Progress=Phase==EPhase::Sample?static_cast<double>(Frame)/SampleFrames:0;
        FRotator Angle=Pose.Rotation;
        Angle.Yaw+=Pose.Sweep*FMath::Sin(2*PI*Progress);
        Player->SetControlRotation(Angle);
        if (Phase==EPhase::Warm)
        {
            ++Frame;
            if (Frame==30 && Pose.Fire && FireStart) Char->ProcessEvent(FireStart,nullptr);
            if (Frame<WarmFrames) return;
            const FVector Actual=Char->GetActorLocation();
            FHitResult Floor;
            FCollisionQueryParams Params(SCENE_QUERY_STAT(KDSurveyFloor),false,Char);
            for (const auto& Enemy : Enemies) if (Enemy.IsValid()) Params.AddIgnoredActor(Enemy.Get());
            const bool HasFloor=Char->GetWorld()->LineTraceSingleByChannel(Floor,Actual,Actual-FVector(0,0,300),ECC_Visibility,Params);
            Floors+=FString::Printf(TEXT("%d,%s,%d,%.4f,%.4f,%.4f,%s,%s\n"),Round,Pose.Name,HasFloor?1:0,Floor.ImpactPoint.X,Floor.ImpactPoint.Y,Floor.ImpactPoint.Z,*GetNameSafe(Floor.GetActor()),*GetNameSafe(Floor.GetComponent()));
            if (FVector::Dist2D(Actual,Pose.Position)>50 || FMath::Abs(Actual.Z-Pose.Position.Z)>45 ||
                (Pose.Fire && (!FireStart || !FireStop || Enemies.IsEmpty() || !ShotProperty)))
            {
                ++InvalidScenes;
                Mark(TEXT("invalid_pose_or_combat"),FPlatformTime::Cycles64(),Char,Player);
                Next(Dir,Char);
                return;
            }
            Frame=0;HitSamples=0;ShotChanges=0;LastShot=ShotTime(Char);
            Phase=EPhase::Sample;
            TRACE_CPUPROFILER_EVENT_SCOPE(KD_SurveyMeasureStart);
            Mark(TEXT("sample_begin"),FPlatformTime::Cycles64(),Char,Player);
            return;
        }
        if (Phase==EPhase::Sample)
        {
            ++Frame;
            const uint64 Now=FPlatformTime::Cycles64();
            const FVector P=Char->GetActorLocation();
            const FRotator R=Player->GetControlRotation();
            APlayerCameraManager* Camera=Player->PlayerCameraManager.Get();
            const FVector C=Camera->GetCameraLocation();
            const FRotator CR=Camera->GetCameraRotation();
            const double Shot=ShotTime(Char);
            const int32 Hit=Hits();
            HitSamples+=Hit>0?1:0;
            ShotChanges+=Shot>LastShot?1:0;
            LastShot=Shot;
            Frames+=FString::Printf(TEXT("%llu,%d,%d,%s,%d,%.8f,%.8f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.8f,%d,%.5f,%.5f,%.5f,%.5f,%.5f,%.5f\n"),
                Now,Round,Index,Pose.Name,Frame,Delta,FApp::GetDeltaTime(),P.X,P.Y,P.Z,R.Pitch,R.Yaw,C.X,C.Y,C.Z,CR.Pitch,CR.Yaw,Camera->GetFOVAngle(),Shot,Hit,
                FPlatformTime::ToMilliseconds(GGameThreadTime),FPlatformTime::ToMilliseconds(GRenderThreadTime),FPlatformTime::ToMilliseconds(GRHIThreadTime),
                FPlatformTime::ToMilliseconds(RHIGetGPUFrameCycles()),FPlatformTime::ToMilliseconds(GGameThreadWaitTime),FPlatformTime::ToMilliseconds(GRenderThreadWaitTime));
            if (Frame<SampleFrames) return;
            {
                TRACE_CPUPROFILER_EVENT_SCOPE(KD_SurveyMeasureEnd);
                Mark(TEXT("sample_end"),FPlatformTime::Cycles64(),Char,Player);
            }
            Save(Dir);
            const FString File=FString::Printf(TEXT("%02d_%s_R%d.png"),Index,Pose.Name,Round);
            FScreenshotRequest::RequestScreenshot(FPaths::Combine(Dir,File),false,false);
            Frame=0; Phase=EPhase::Photo;
            return;
        }
        if (Phase==EPhase::Photo && ++Frame>30 && !FScreenshotRequest::IsScreenshotRequested()) Next(Dir,Char);
    }
};
