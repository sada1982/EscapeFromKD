import bisect
import collections
import csv
import json
import math
from pathlib import Path
import statistics
import sys

run = Path(sys.argv[1]).resolve()
meta = json.loads((run / "metadata.json").read_text(encoding="utf8"))
route = Path(meta["route"])
frequency = meta["start"]["frequency"]
pid = int(json.loads((route / "isolation.json").read_text(encoding="utf8"))["pid"])

def read(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))

events = read(route / "survey_events.csv")
samples = read(route / "survey_frames.csv")
times = [int(r["qpc"]) for r in samples]
presents = [r for r in read(run / "presents_native.csv")
            if int(r["ProcessID"]) == pid and r["Runtime"] == "DXGI" and int(r["SwapChainAddress"], 16)]
chain = collections.Counter(r["SwapChainAddress"] for r in presents).most_common(1)[0][0]
presents = sorted((r for r in presents if r["SwapChainAddress"] == chain), key=lambda r: int(r["QPCTime"]))
intervals = []
for a, b in zip(presents, presents[1:]):
    q0, q1 = int(a["QPCTime"]), int(b["QPCTime"])
    intervals.append((q0, q1, (q1 - q0) * 1000 / frequency, float(a["msInPresentAPI"])))
windows = {}
for e in events:
    if e["event"] in ("sample_begin", "sample_end"):
        windows.setdefault((int(e["round"]), e["scene"]), {})[e["event"]] = e

def stats(values):
    values = sorted(values)
    if not values:
        return None
    n = len(values)
    return dict(n=n, mean_ms=round(statistics.mean(values), 5),
                fps=round(1000 / statistics.mean(values), 3) if sum(values) else None,
                median_ms=round(statistics.median(values), 5),
                p99_ms=values[math.ceil(.99 * n) - 1], max_ms=values[-1],
                over=sum(v > 1000 / 60 for v in values),
                over_pct=round(sum(v > 1000 / 60 for v in values) * 100 / n, 4),
                over33=sum(v > 1000 / 30 for v in values))

per_scene = collections.defaultdict(list)
per_round = []
records = []
for (round_number, scene), window in windows.items():
    if len(window) != 2:
        continue
    begin, end = (int(window[key]["qpc"]) for key in ("sample_begin", "sample_end"))
    segment = [row for row in intervals if begin <= row[0] < row[1] <= end]
    local = [r for r in samples if r["scene"] == scene and int(r["round"]) == round_number]
    if not segment:
        continue
    for q0, q1, duration, api in segment:
        nearest = min(len(times) - 1, bisect.bisect_left(times, (q0 + q1) // 2))
        pose = samples[nearest]
        records.append(dict(round=round_number, scene=scene, q0=q0, q1=q1, ms=duration,
                            lead_present_api_ms=api, x=pose["x"], y=pose["y"], z=pose["z"],
                            yaw=pose["cam_yaw"], pitch=pose["cam_pitch"]))
    per_scene[scene].extend(r[2] for r in segment)
    counters = {key: stats([float(r[key]) for r in local])
                for key in ("gt_busy_ms", "rt_busy_ms", "rhi_busy_ms", "gpu_ms", "gt_wait_ms", "rt_wait_ms")}
    per_round.append(dict(round=round_number, scene=scene, q0=begin, q1=end,
                          present=stats([r[2] for r in segment]), counters=counters,
                          end_event=window["sample_end"]))
result = dict(source=str(run), per_scene={k: stats(v) for k, v in per_scene.items()},
              per_round=per_round, invalid=[e for e in events if e["event"].startswith("invalid")])
(run / "summary.json").write_text(json.dumps(result, indent=2), encoding="utf8")
with (run / "scene_intervals.csv").open("w", encoding="utf-8-sig", newline="") as stream:
    writer = csv.DictWriter(stream, fieldnames=list(records[0]))
    writer.writeheader()
    writer.writerows(records)
for scene, result in sorted(result["per_scene"].items(), key=lambda pair: -pair[1]["mean_ms"]):
    print(scene, result)
