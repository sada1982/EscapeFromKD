import argparse
import csv
import json
import shutil
import statistics
import subprocess
import sys
import tempfile
from pathlib import Path


parser = argparse.ArgumentParser()
parser.add_argument("trace", type=Path)
parser.add_argument("events", type=Path)
parser.add_argument("output", type=Path)
parser.add_argument("--frequency", type=int, required=True)
parser.add_argument("--scene", action="append", default=[])
parser.add_argument("--seconds", type=float, default=0)
parser.add_argument("--all-threads", action="store_true")
parser.add_argument("--engine", type=Path, default=Path("C:/Program Files/Epic Games/UE_5.8"))
args = parser.parse_args()
trace = args.trace.resolve(strict=True)
events_file = args.events.resolve(strict=True)
output = args.output.resolve()
output.mkdir(parents=True, exist_ok=False)
scratch = Path(tempfile.mkdtemp(prefix="KDWholeExport_"))
insights = args.engine / "Engine/Binaries/Win64/UnrealInsights.exe"
launcher = Path(__file__).resolve().parents[1] / "Exhibit42_20261116/private_launch.py"
columns = " -columns=ThreadId,ThreadName,TimerName,StartTime,EndTime,Duration,Depth"


def export(label, commands):
    response = scratch / (label + ".rsp")
    response.write_text("\n".join(commands) + "\n", encoding="utf8")
    log = scratch / (label + ".log")
    command = [sys.executable, "-B", str(launcher), str(insights), str(scratch / (label + "Desktop")),
               "-OpenTraceFile=" + str(trace), "-ABSLOG=" + str(log), "-AutoQuit", "-NoUI",
               "-ExecOnAnalysisCompleteCmd=@=" + str(response), "-unattended", "-NoSplash"]
    result = subprocess.run(command, capture_output=True,
                            creationflags=subprocess.CREATE_NO_WINDOW | subprocess.BELOW_NORMAL_PRIORITY_CLASS)
    if log.exists():
        shutil.copyfile(log, output / log.name)
    if result.returncode:
        raise RuntimeError(f"Insights {label} returned {result.returncode}; see {log}")


def read(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


marks_file = scratch / "anchors.csv"
export("anchors", ["TimingInsights.ExportTimingEvents " + marks_file.as_posix() + columns
                   + " -threads=GameThread -timers=KD_SurveyMeasureStart,KD_SurveyMeasureEnd"])
shutil.copyfile(marks_file, output / "anchors.csv")
marks = read(marks_file)
events = read(events_file)
offsets = []
for event, timer in (("sample_begin", "KD_SurveyMeasureStart"), ("sample_end", "KD_SurveyMeasureEnd")):
    clock_rows = [row for row in events if row["event"] == event]
    clock_rows.sort(key=lambda row: int(row["qpc"]))
    trace_rows = [row for row in marks if row["TimerName"] == timer]
    trace_rows.sort(key=lambda row: float(row["StartTime"]))
    if len(clock_rows) != len(trace_rows) or not clock_rows:
        raise ValueError(f"Unmatched {event}: {len(clock_rows)} QPC markers, {len(trace_rows)} trace markers")
    offsets.extend(float(mark["StartTime"]) - int(row["qpc"]) / args.frequency
                   for row, mark in zip(clock_rows, trace_rows))
offset = statistics.median(offsets)
spread_ms = 1000 * (max(offsets) - min(offsets))
if spread_ms > 5:
    raise ValueError(f"Clock anchor spread {spread_ms:.3f} ms")
windows = []
commands = []
for row in events:
    if row["event"] != "sample_begin" or (args.scene and row["scene"] not in args.scene):
        continue
    ends = [end for end in events if end["event"] == "sample_end"
            and end["scene"] == row["scene"] and end["round"] == row["round"]]
    if len(ends) != 1:
        raise ValueError(f"Expected one end marker for {row}")
    end = ends[0]
    start_time = int(row["qpc"]) / args.frequency + offset
    end_time = int(end["qpc"]) / args.frequency + offset
    if args.seconds > 0 and end_time - start_time > args.seconds:
        start_time = (start_time + end_time - args.seconds) / 2
        end_time = start_time + args.seconds
    assert end_time > start_time
    label = f"scene_{len(windows):03d}"
    file = scratch / (label + ".csv")
    thread_filter = "*" if args.all_threads else "GameThread,RenderThread*,RenderingThread*,RHIThread*,GPU*"
    commands.append("TimingInsights.ExportTimingEvents " + file.as_posix() + columns
                    + " -threads=" + thread_filter
                    + f" -startTime={start_time:.9f} -endTime={end_time:.9f}")
    windows.append(dict(scene=row["scene"], tour=int(row["round"]), start=start_time, end=end_time,
                        source_start_qpc=int(row["qpc"]), source_end_qpc=int(end["qpc"]),
                        events_csv=label + ".csv"))
if not windows:
    raise ValueError("No scene windows selected")
export("scenes", commands)
for window in windows:
    shutil.copyfile(scratch / window["events_csv"], output / window["events_csv"])
manifest = dict(trace=str(trace), source_events=str(events_file), qpc_frequency=args.frequency,
                clock_offset_s=offset, anchor_spread_ms=spread_ms, anchor_count=len(offsets),
                full_scene_windows=args.seconds == 0, all_threads=args.all_threads, windows=windows)
(output / "windows.json").write_text(json.dumps(manifest, indent=2), encoding="utf8")
print(json.dumps(dict(scenes=len(windows), anchor_spread_ms=spread_ms, output=str(output))))
