import argparse
import bisect
import csv
import heapq
import json
import math
import statistics
from collections import defaultdict
from pathlib import Path


def merged(spans):
    result = []
    for start, end in sorted(spans):
        if end <= start:
            continue
        if result and start <= result[-1][1]:
            result[-1][1] = max(end, result[-1][1])
        else:
            result.append([start, end])
    return result


class Timeline:
    def __init__(self, spans):
        self.spans = merged(spans)
        self.starts = [span[0] for span in self.spans]
        self.ends = [span[1] for span in self.spans]
        self.prefix = [0.0]
        for start, end in self.spans:
            self.prefix.append(self.prefix[-1] + end - start)

    def integral(self, point):
        index = bisect.bisect_right(self.ends, point)
        length = self.prefix[index]
        if index < len(self.spans):
            length += max(0, point - self.starts[index])
        return length

    def overlap_ms(self, start, end):
        return 1000 * (self.integral(end) - self.integral(start))


def stats(values):
    if not values:
        return dict(n=0)
    ordered = sorted(values)
    return dict(n=len(values), mean_ms=statistics.mean(values), median_ms=statistics.median(values),
                p99_ms=ordered[math.ceil(len(values) * 0.99) - 1], max_ms=ordered[-1],
                over16p67=sum(value > 1000 / 60 for value in values))


def deepest_segments(scopes, start, end):
    edges = defaultdict(lambda: [[], []])
    for index, (a, b, depth, name) in enumerate(scopes):
        a, b = max(start, a), min(end, b)
        if b > a:
            edges[a][0].append(index)
            edges[b][1].append(index)
    edges[start]
    edges[end]
    active = set()
    by_depth = []
    previous = start
    segments = defaultdict(list)
    for point, (starts, ends) in sorted(edges.items()):
        while by_depth and by_depth[0][1] not in active:
            heapq.heappop(by_depth)
        name = scopes[by_depth[0][1]][3] if by_depth else "[unscoped]"
        if point > previous:
            segments[name].append((previous, point))
        for index in ends:
            active.discard(index)
        for index in starts:
            active.add(index)
            heapq.heappush(by_depth, (-scopes[index][2], index))
        previous = point
    return segments


def analyze_lane(rows, start, end):
    scopes = []
    by_name = defaultdict(list)
    for row in rows:
        a, b = float(row["StartTime"]), float(row["EndTime"])
        name = row["TimerName"]
        if name.startswith("TemporalSuperResolution("):
            name = "TemporalSuperResolution"
        scopes.append((a, b, int(row["Depth"]), name))
        by_name[name].append((a, b))
    lane_name = rows[0]["ThreadName"]
    gpu = lane_name.startswith("GPU")
    frame_name = "Frame" if gpu else "FEngineLoop::Tick"
    frames = sorted((a, b) for a, b in by_name.get(frame_name, []) if start <= a < b <= end)
    inclusive = {}
    per_frame = {}
    for name, spans in by_name.items():
        timeline = Timeline(spans)
        inclusive[name] = timeline.overlap_ms(start, end)
        if frames:
            per_frame[name] = stats([timeline.overlap_ms(a, b) for a, b in frames])
    leaves = deepest_segments(scopes, start, end)
    leaf_ms = {name: Timeline(spans).overlap_ms(start, end) for name, spans in leaves.items()}
    measured_ms = 1000 * (end - start)
    assert abs(sum(leaf_ms.values()) - measured_ms) < 0.001
    waiting_names = [name for name in leaves if name in (
        "Game thread idle time", "WaitForTasks", "WaitForFrameEventCompletion", "RHIThreadStall")
        or name.startswith(("CPU Stall - ", "FPlatformProcess::Sleep"))]
    wait_timeline = Timeline([span for name in waiting_names for span in leaves[name]])
    waiting = wait_timeline.overlap_ms(start, end)
    return dict(scope_events=len(rows), window_ms=measured_ms, frame_timer=frame_name,
                complete_frames=stats([1000 * (b - a) for a, b in frames]),
                inclusive_ms=dict(sorted(inclusive.items(), key=lambda item: -item[1])),
                exclusive_deepest_ms=dict(sorted(leaf_ms.items(), key=lambda item: -item[1])),
                named_leaf_wait_ms=waiting, named_leaf_wait_names=waiting_names,
                unscoped_ms=leaf_ms.get("[unscoped]", 0),
                scoped_wall_excluding_named_wait_ms=measured_ms - waiting - leaf_ms.get("[unscoped]", 0),
                complete_frame_scopes=per_frame)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("exports", type=Path)
    args = parser.parse_args()
    root = args.exports.resolve(strict=True)
    manifest = json.loads((root / "windows.json").read_text(encoding="utf8"))
    output = []
    flat = []
    for window in manifest["windows"]:
        lanes = defaultdict(list)
        with (root / window["events_csv"]).open(encoding="utf-8-sig", newline="") as stream:
            for row in csv.DictReader(stream):
                lanes[(row["ThreadName"], row["ThreadId"])].append(row)
        name_counts = defaultdict(int)
        for name, thread_id in lanes:
            name_counts[name] += 1
        analysis = {}
        for (name, thread_id), rows in lanes.items():
            lane = name if name_counts[name] == 1 else f"{name} [tid={thread_id}]"
            analysis[lane] = dict(analyze_lane(rows, window["start"], window["end"]), thread_id=thread_id)
        output.append(dict(**window, lanes=analysis))
        for lane, data in analysis.items():
            for name, duration in data["inclusive_ms"].items():
                frame = data["complete_frame_scopes"].get(name, {})
                flat.append(dict(scene=window["scene"], tour=window["tour"], lane=lane, timer=name,
                                 inclusive_ms=duration, deepest_exclusive_ms=data["exclusive_deepest_ms"].get(name, 0),
                                 window_ms=data["window_ms"], complete_frames=frame.get("n", 0),
                                 per_frame_mean_ms=frame.get("mean_ms", ""), per_frame_p99_ms=frame.get("p99_ms", "")))
        print(window["scene"], window["tour"], {name: value["complete_frames"] for name, value in analysis.items() if name.startswith("GPU")})
    result = dict(method={
        "cpu_times": "Elapsed profiled wall time. Named leaf waits exclude deeper recorded work. Unscheduled OS time cannot be identified from CPU scope traces.",
        "gpu_times": "Elapsed GPU timestamp intervals per lane. Inclusive parent and child scopes overlap. Graphics and compute lanes may run concurrently.",
        "per_frame": "Scopes intersected with every complete Frame on the same GPU lane; CPU frame timer FEngineLoop::Tick when available.",
        "exclusive": "Deepest active recorded scope at each time; scoped coverage and unscoped time sum to the window length."},
        anchor_spread_ms=manifest["anchor_spread_ms"], scenes=output)
    (root / "scene_scopes.json").write_text(json.dumps(result, indent=2), encoding="utf8")
    with (root / "scene_scopes.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(flat[0]))
        writer.writeheader()
        writer.writerows(flat)


if __name__ == "__main__":
    main()
