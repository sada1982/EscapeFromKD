import json
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties

here = Path(__file__).resolve().parent
out = here.parents[2] / "Documentation/WholeGamePerformance_20261118"
out.mkdir(parents=True, exist_ok=True)
data = json.loads((here / "SurveyA/summary.json").read_text(encoding="utf8"))
names = {
    "Atrium3FDown": "3F 吹抜けを見下ろす", "ClassroomExit": "3F 教室出口",
    "ClassroomStart": "3F 実習室・開始地点", "Gallery3F": "3F 廊下",
    "ClassroomMiddle": "3F 実習室中央", "Gallery2F": "2F 廊下",
    "Atrium1F": "1F 吹抜け", "Atrium1FUp": "1F 吹抜けを見上げる",
    "CombatFire": "敵1体への連続射撃", "Stairs3F": "3F 下り階段前",
    "CombatIdle": "戦闘地点・待機", "Plaza2F": "2F 階段前ロビー",
    "Hall1F": "1F ホール", "Exit1F": "1F 出口",
}
font = FontProperties(fname="C:/Windows/Fonts/meiryo.ttc")
plt.rcParams.update({"font.size": 10, "axes.spines.top": False,
                     "axes.spines.right": False, "axes.spines.left": False})
rows = sorted(data["per_scene"].items(), key=lambda row: -row[1]["mean_ms"])
fig, ax = plt.subplots(figsize=(11, 8))
fig.set_facecolor("#f9fbfe")
ax.set_facecolor("#f9fbfe")
ys = list(range(len(rows)))
ax.barh(ys, [r["mean_ms"] for _, r in rows], color="#345b80", height=.55, label="Mean")
ax.scatter([r["p99_ms"] for _, r in rows], ys, color="#e07824", s=36, zorder=4, label="P99")
for y, (_, r) in zip(ys, rows):
    ax.text(r["p99_ms"] + .23, y, f'{r["p99_ms"]:.2f}', va="center", fontsize=9, color="#8b480e")
ax.set_yticks(ys, [names[k] for k, _ in rows], fontproperties=font)
ax.invert_yaxis()
ax.axvline(1000 / 60, color="#ba3434", linestyle="--", linewidth=1.3, label="60 FPS = 16.67 ms")
ax.set_xlim(0, 21)
ax.set_xlabel("Frame submission interval (ms)")
ax.grid(axis="x", alpha=.15)
ax.set_axisbelow(True)
ax.tick_params(axis="y", length=0)
ax.legend(loc="lower right", frameon=False)
fig.suptitle("Escape From KD｜全階・戦闘の代表14場面", fontproperties=font, fontsize=18, x=.08, ha="left")
fig.text(.08, .91, "職場RTX 3050 Laptop・Editor起動中・1080p / 内部54%・各場面2巡", fontproperties=font, fontsize=10)
fig.text(.08, .035, "同一配布コンテンツの計測用Shipping。各場面1,198提出間隔。最大値はP99より大きい場合がある。", fontproperties=font, fontsize=9)
fig.subplots_adjust(left=.25, right=.96, top=.86, bottom=.12)
fig.savefig(out / "SceneFrameTimes.png", dpi=150)
print(out / "SceneFrameTimes.png")
