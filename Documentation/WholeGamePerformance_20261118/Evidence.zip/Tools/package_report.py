import hashlib
import json
from pathlib import Path
import shutil
import zipfile

here = Path(__file__).resolve().parent
project = here.parents[2]
out = project / "Documentation/WholeGamePerformance_20261118"
out.mkdir(parents=True, exist_ok=True)
manifest = []

with zipfile.ZipFile(out / "Evidence.zip", "w", zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    def add(path, name):
        raw = path.read_bytes()
        archive.writestr(name, raw)
        manifest.append(dict(file=name, bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest()))

    for path in sorted(here.iterdir()):
        if path.is_file() and path.suffix in (".py", ".h", ".json", ".txt", ".log"):
            add(path, "Tools/" + path.name if path.suffix in (".py", ".h") else "Audit/" + path.name)
    for name in ("SurveyA", "DiagnosticA"):
        run = here / name
        meta = json.loads((run / "metadata.json").read_text(encoding="utf8"))
        route = Path(meta["route"])
        for path in sorted(run.iterdir()):
            if path.is_file() and path.suffix in (".csv", ".json", ".txt", ".log", ".stderr", ".stdout"):
                add(path, name + "/" + path.name)
        for path in sorted(route.iterdir()):
            if path.is_file() and path.suffix in (".csv", ".json", ".txt"):
                add(path, name + "/Route/" + path.name)
        log = route.parent / "engine.log"
        if log.exists():
            add(log, name + "/engine.log")
        for sub in ("SceneTrace", "WorkerTrace"):
            for filename in ("windows.json", "scene_scopes.json", "scene_scopes.csv", "anchors.csv"):
                path = run / sub / filename
                if path.exists():
                    add(path, name + "/" + sub + "/" + filename)
    ship_meta = json.loads((here / "SurveyA/metadata.json").read_text(encoding="utf8"))
    photo = Path(ship_meta["route"]) / "04_Atrium3FDown_R1.png"
    shutil.copyfile(photo, out / "HeaviestScene.png")
    add(Path(ship_meta["route"]) / "13_CombatFire_R1.png", "Views/CombatFire.png")
    archive.writestr("manifest.json", json.dumps(manifest, ensure_ascii=False, indent=2))
    archive.writestr("README.txt", "主性能値はSurveyA/summary.json。DiagnosticAはDevelopment＋トレースの内訳用で、性能絶対値を混合しない。\n"
                     "全28測定区間を取得。DiagnosticAは終了コード777003、具体的原因未確定。exit_777003_audit.txt参照。\n"
                     "コードと小容量の再解析資料を収録。巨大な生utrace・scene_*.csvはローカルのみ。パスはAudit/trace_findings.txt。\n"
                     "正式Content・Config・Build/Exhibit・配布版には変更を加えていない。\n")

with zipfile.ZipFile(out / "Evidence.zip") as archive:
    assert archive.testzip() is None
    for row in manifest:
        assert hashlib.sha256(archive.read(row["file"])).hexdigest() == row["sha256"]
print(json.dumps(dict(entries=len(manifest), zip_bytes=(out / "Evidence.zip").stat().st_size), indent=2))
