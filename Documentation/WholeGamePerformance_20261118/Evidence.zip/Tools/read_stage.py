import bpy
import json
import sys
from pathlib import Path
from mathutils import Vector

project = Path(__file__).resolve().parents[3]
rows = []
for name in ('Floor01/EntranceGallery.blend', 'Floor02/Floor02_Plaza.blend'):
    bpy.ops.wm.open_mainfile(filepath=str(project / 'SourceAssets/Stages' / name))
    for obj in bpy.data.objects:
        if obj.type != 'MESH':
            continue
        points = [obj.matrix_world @ Vector(corner) for corner in obj.bound_box]
        rows.append(dict(source=name, name=obj.name, lo=[min(p[i] for p in points) for i in range(3)],
                         hi=[max(p[i] for p in points) for i in range(3)]))
(Path(__file__).resolve().parent / 'source_bounds.json').write_text(json.dumps(rows, indent=2), encoding='utf8')
print('READ_STAGE',len(rows))
