import os
from pathlib import Path
import shutil

here = Path(__file__).resolve().parent
project = here.parents[2]
original = project / 'Build/Exhibit/Source/myProject'
work = Path(os.environ['LOCALAPPDATA']) / 'KDGateTraceDev_20261117'
module = work / 'Source/myProject'
assert (work / 'myProject.uproject').is_file()
source = (original / 'myProject.cpp').read_text(encoding='utf-8-sig')

def insert(old, new):
    global source
    assert source.count(old) == 1, old
    source = source.replace(old, new)

insert('#include "Engine/World.h"', '#include "Engine/World.h"\n#include "Survey.h"')
insert('    FExhibitStartupGate Startup;', '    FExhibitStartupGate Startup;\n    FWholeGameSurvey Survey;')
insert('            GoQpc=Now;', '            if (Survey.Enabled)\n            {\n                if (!Survey.Initialized) Startup.WriteReport(Dir);\n                Survey.Update(Dir,Player,Char,Delta);\n                if (Survey.Round>Survey.Rounds) WriteSettings(World,Player,Char,TEXT("final"));\n                return;\n            }\n            GoQpc=Now;')
insert('        bPhoto=FParse::Param', '        Survey.Enabled=FParse::Param(Cmd,TEXT("KDWholeGameSurvey"));\n        bPhoto=FParse::Param')
for filename in ('ExhibitStartupGate.cpp', 'ExhibitStartupGate.h', 'myProject.Build.cs'):
    shutil.copyfile(original / filename, module / filename)
(module / 'myProject.cpp').write_text(source, encoding='utf8')
shutil.copyfile(here / 'Survey.h', module / 'Survey.h')
print(work)
