import argparse
import csv
import ctypes as c
from ctypes import wintypes as w
import json
import os
from pathlib import Path
import shutil
import subprocess
import threading
import time
import uuid


class ProcessEntry(c.Structure):
    _fields_ = [("size", w.DWORD), ("usage", w.DWORD), ("pid", w.DWORD),
                ("heap", c.c_size_t), ("module", w.DWORD), ("threads", w.DWORD),
                ("parent", w.DWORD), ("priority", w.LONG), ("flags", w.DWORD),
                ("name", w.WCHAR * 260)]


class Memory(c.Structure):
    _fields_ = [("size", w.DWORD), ("page_faults", w.DWORD),
                ("peak_working_set", c.c_size_t), ("working_set", c.c_size_t),
                ("peak_paged_pool", c.c_size_t), ("paged_pool", c.c_size_t),
                ("peak_nonpaged_pool", c.c_size_t), ("nonpaged_pool", c.c_size_t),
                ("pagefile", c.c_size_t), ("peak_pagefile", c.c_size_t),
                ("private_bytes", c.c_size_t)]


class IO(c.Structure):
    _fields_ = [(name, c.c_ulonglong) for name in ("read_ops", "write_ops", "other_ops",
                                                 "read_bytes", "write_bytes", "other_bytes")]


class Power(c.Structure):
    _fields_ = [("ac", w.BYTE), ("battery_flags", w.BYTE), ("battery_percent", w.BYTE),
                ("saver", w.BYTE), ("life_seconds", w.DWORD), ("full_seconds", w.DWORD)]


class Luid(c.Structure):
    _fields_ = [("low", w.DWORD), ("high", w.LONG)]


class AdapterDesc(c.Structure):
    _fields_ = [("description", w.WCHAR * 128), ("vendor", w.UINT), ("device", w.UINT),
                ("subsystem", w.UINT), ("revision", w.UINT), ("dedicated_video", c.c_size_t),
                ("dedicated_system", c.c_size_t), ("shared_system", c.c_size_t),
                ("luid", Luid), ("flags", w.UINT)]


kernel = c.WinDLL("kernel32", use_last_error=True)
psapi = c.WinDLL("psapi", use_last_error=True)
kernel.OpenProcess.argtypes = [w.DWORD, w.BOOL, w.DWORD]
kernel.OpenProcess.restype = w.HANDLE
kernel.CloseHandle.argtypes = [w.HANDLE]
kernel.WaitForSingleObject.argtypes = [w.HANDLE, w.DWORD]
kernel.QueryFullProcessImageNameW.argtypes = [w.HANDLE, w.DWORD, w.LPWSTR, c.POINTER(w.DWORD)]
kernel.GetProcessTimes.argtypes = [w.HANDLE] + [c.POINTER(w.FILETIME)] * 4
kernel.GetProcessIoCounters.argtypes = [w.HANDLE, c.POINTER(IO)]
kernel.CreateToolhelp32Snapshot.argtypes = [w.DWORD, w.DWORD]
kernel.CreateToolhelp32Snapshot.restype = w.HANDLE
kernel.Process32FirstW.argtypes = [w.HANDLE, c.POINTER(ProcessEntry)]
kernel.Process32NextW.argtypes = [w.HANDLE, c.POINTER(ProcessEntry)]
kernel.GetSystemPowerStatus.argtypes = [c.POINTER(Power)]
psapi.GetProcessMemoryInfo.argtypes = [w.HANDLE, c.POINTER(Memory), w.DWORD]


def qpc():
    value = c.c_longlong()
    kernel.QueryPerformanceCounter(c.byref(value))
    return value.value


def filetime(value):
    return (value.dwHighDateTime << 32) | value.dwLowDateTime


def method(obj, index, result, *arguments):
    table = c.cast(obj, c.POINTER(c.POINTER(c.c_void_p))).contents
    return c.WINFUNCTYPE(result, c.c_void_p, *arguments)(table[index])


def nvidia_adapter():
    dxgi = c.WinDLL("dxgi")
    factory = c.c_void_p()
    iid = c.create_string_buffer(uuid.UUID("770aae78-f26f-4dba-a829-253c83d1b387").bytes_le)
    create = dxgi.CreateDXGIFactory1
    create.argtypes = [c.c_void_p, c.POINTER(c.c_void_p)]
    create.restype = c.c_long
    if create(iid, c.byref(factory)) != 0:
        raise RuntimeError("DXGI factory unavailable")
    try:
        enum = method(factory, 12, c.c_long, w.UINT, c.POINTER(c.c_void_p))
        for index in range(16):
            adapter = c.c_void_p()
            if enum(factory, index, c.byref(adapter)) != 0:
                break
            try:
                desc = AdapterDesc()
                status = method(adapter, 10, c.c_long, c.POINTER(AdapterDesc))(adapter, c.byref(desc))
                if status == 0 and desc.vendor == 0x10DE:
                    return dict(name=desc.description, low=desc.luid.low, high=desc.luid.high,
                                dedicated_video_bytes=desc.dedicated_video)
            finally:
                method(adapter, 2, w.ULONG)(adapter)
    finally:
        method(factory, 2, w.ULONG)(factory)
    raise RuntimeError("NVIDIA DXGI adapter unavailable")


def thread_counts(pids):
    snapshot = kernel.CreateToolhelp32Snapshot(2, 0)
    if snapshot == c.c_void_p(-1).value:
        return {}
    result = {}
    try:
        item = ProcessEntry()
        item.size = c.sizeof(item)
        valid = kernel.Process32FirstW(snapshot, c.byref(item))
        while valid:
            if item.pid in pids:
                result[item.pid] = item.threads
            valid = kernel.Process32NextW(snapshot, c.byref(item))
    finally:
        kernel.CloseHandle(snapshot)
    return result


def image_path(handle):
    buffer = c.create_unicode_buffer(32768)
    size = w.DWORD(len(buffer))
    if not kernel.QueryFullProcessImageNameW(handle, 0, buffer, c.byref(size)):
        raise c.WinError(c.get_last_error())
    return buffer.value


def nvidia_reader(process, path):
    with path.open("x", encoding="utf8", newline="", buffering=1) as output:
        writer = csv.writer(output)
        fields = None
        for line in process.stdout:
            row = next(csv.reader([line]))
            if fields is None:
                fields = [value.strip() for value in row]
                writer.writerow(["qpc_delivery", "utc_epoch_ns"] + fields)
            else:
                writer.writerow([qpc(), time.time_ns()] + [value.strip() for value in row])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("route", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--editor", type=int)
    parser.add_argument("--pid", type=int)
    parser.add_argument("--seconds", type=float, default=1800)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    state_file = args.output / "monitor_state.json"
    if state_file.exists():
        raise FileExistsError(state_file)
    frequency = c.c_longlong()
    kernel.QueryPerformanceFrequency(c.byref(frequency))
    adapter = nvidia_adapter()
    dll_path = Path(__file__).resolve().parents[1] / "Route54_20261116/Telemetry/vidmm_sample.dll"
    dll = c.CDLL(str(dll_path))
    query = dll.query_memory
    query.argtypes = [w.UINT, w.UINT, w.LONG, c.POINTER(c.c_ulonglong), c.POINTER(c.c_long)]
    query.restype = c.c_long
    target_pid = args.pid
    deadline = time.monotonic() + 180
    while not target_pid and time.monotonic() < deadline:
        try:
            target_pid = int(json.loads((args.route / "isolation.json").read_text(encoding="utf8"))["pid"])
        except (FileNotFoundError, ValueError, KeyError):
            time.sleep(.05)
    if not target_pid:
        raise TimeoutError("Route isolation.json did not supply a PID")
    processes = {target_pid: "game"}
    if args.editor:
        processes[args.editor] = "editor"
    handles = {}
    state = dict(qpc_frequency=frequency.value, start_qpc=qpc(), adapter=adapter,
                 logical_processors=os.cpu_count(), processes={}, samples=0,
                 memory_helper=str(dll_path), cpu_units="one logical core = 100 percent")
    smi = None
    reader = None
    stderr = None
    try:
        for pid, role in processes.items():
            handle = kernel.OpenProcess(0x100000 | 0x400 | 0x10, False, pid)
            if not handle:
                raise c.WinError(c.get_last_error())
            handles[pid] = handle
            state["processes"][str(pid)] = dict(role=role, image=image_path(handle))
        state_file.write_text(json.dumps(state, indent=2), encoding="utf8")
        smi_path = shutil.which("nvidia-smi.exe")
        if not smi_path:
            raise FileNotFoundError("nvidia-smi.exe")
        fields = "timestamp,name,driver_version,pstate,memory.total,memory.used,temperature.gpu,utilization.gpu,utilization.memory,power.draw,power.limit,clocks.current.graphics,clocks.current.memory,clocks_event_reasons.sw_power_cap,clocks_event_reasons.sw_thermal_slowdown,clocks_event_reasons.hw_thermal_slowdown"
        stderr = (args.output / "monitor_nvidia.stderr").open("xb")
        smi = subprocess.Popen([smi_path, "--query-gpu=" + fields, "--format=csv,nounits", "-l", "1"],
                               stdout=subprocess.PIPE, stderr=stderr, text=True, errors="replace",
                               creationflags=subprocess.CREATE_NO_WINDOW)
        reader = threading.Thread(target=nvidia_reader,
                                  args=(smi, args.output / "monitor_nvidia.csv"), daemon=True)
        reader.start()
        columns = ["qpc", "qpc_after", "utc_epoch_ns", "role", "pid", "threads", "ac_power", "battery_percent",
                   "cpu_status", "io_status", "ram_status", "user_100ns", "kernel_100ns", "cpu_percent_one_core",
                   "read_bytes", "write_bytes", "working_set_B", "private_B", "page_faults", "mem_ret",
                   "local_status", "nonlocal_status", "proc_stat_status", "adapter_stat_status",
                   "local_budget_B", "local_usage_B", "local_reservation_B", "nonlocal_budget_B", "nonlocal_usage_B",
                   "nonlocal_reservation_B", "evicted_process_B", "adapter_faults", "adapter_faults_evicted",
                   "adapter_evictions", "adapter_evicted_B", "transfer_mdl_to_mem_B", "transfer_mem_to_mdl_B",
                   "transfer_aperture_to_mem_B", "transfer_mem_to_aperture_B"]
        previous = {}
        started = time.monotonic()
        next_tick = started
        with (args.output / "monitor_process.csv").open("x", encoding="utf8", newline="", buffering=1) as output:
            writer = csv.writer(output)
            writer.writerow(columns)
            while time.monotonic() - started < args.seconds:
                if (args.output / "done.flag").exists() or (args.output / "monitor.stop").exists():
                    state["stop_reason"] = "flag"
                    break
                if kernel.WaitForSingleObject(handles[target_pid], 0) != 258:
                    state["stop_reason"] = "game_exit"
                    break
                counts = thread_counts(processes)
                power = Power()
                kernel.GetSystemPowerStatus(c.byref(power))
                for pid, handle in handles.items():
                    begin = qpc()
                    created, closed, user, kern = w.FILETIME(), w.FILETIME(), w.FILETIME(), w.FILETIME()
                    cpu_ok = kernel.GetProcessTimes(handle, c.byref(created), c.byref(closed), c.byref(kern), c.byref(user))
                    io = IO()
                    io_ok = kernel.GetProcessIoCounters(handle, c.byref(io))
                    ram = Memory()
                    ram.size = c.sizeof(ram)
                    ram_ok = psapi.GetProcessMemoryInfo(handle, c.byref(ram), c.sizeof(ram))
                    values = (c.c_ulonglong * 15)()
                    statuses = (c.c_long * 4)(-1, -1, -1, -1)
                    mem_ok = query(pid, adapter["low"], adapter["high"], values, statuses)
                    cpu_time = filetime(user) + filetime(kern)
                    cpu_pct = ""
                    if cpu_ok:
                        if pid in previous:
                            old_qpc, old_cpu = previous[pid]
                            cpu_pct = round((cpu_time - old_cpu) / 1e7 / ((begin - old_qpc) / frequency.value) * 100, 4)
                        previous[pid] = (begin, cpu_time)
                    writer.writerow([begin, qpc(), time.time_ns(), processes[pid], pid, counts.get(pid, ""), power.ac,
                                     power.battery_percent, int(bool(cpu_ok)), int(bool(io_ok)), int(bool(ram_ok)),
                                     filetime(user), filetime(kern), cpu_pct, io.read_bytes, io.write_bytes,
                                     ram.working_set, ram.private_bytes, ram.page_faults, mem_ok] + list(statuses) + list(values))
                state["samples"] += 1
                next_tick += 1
                time.sleep(max(0, next_tick - time.monotonic()))
            else:
                state["stop_reason"] = "timeout"
        if smi.poll() is not None:
            raise RuntimeError("nvidia-smi exited early")
    finally:
        if smi:
            if smi.poll() is None:
                smi.terminate()
            smi.wait(timeout=10)
        if reader:
            reader.join(timeout=5)
        if stderr:
            stderr.close()
        for handle in handles.values():
            kernel.CloseHandle(handle)
        state["end_qpc"] = qpc()
        state_file.write_text(json.dumps(state, indent=2), encoding="utf8")
    print(json.dumps(dict(samples=state["samples"], reason=state["stop_reason"], adapter=adapter["name"])))


if __name__ == "__main__":
    main()
