"""Summarize equal spatial segments with both Present and game-thread frame intervals."""
import csv,json,math,statistics,sys
from bisect import bisect_left
from pathlib import Path
r=Path(sys.argv[1]);o=Path(sys.argv[2]) if len(sys.argv)>2 else r;o.mkdir(parents=True,exist_ok=True)
def rows(s):return list(csv.DictReader((r/s).open(encoding='utf-8-sig',newline='')))
mon=json.loads((r/'telemetry.json').read_text('utf8'));freq=mon['start']['frequency'];pid=json.loads((r/'route/isolation.json').read_text('utf8'))['pid']
events=rows('route/events.csv');f=rows('route/frames.csv');times=[int(i['qpc']) for i in f]
rec={}
regions=('classroom_aisle','classroom_exit','gallery','connector','lobby_turn','stair_approach','stair_turn','downstairs')
def sample(lap,leg,y,v,kind):
 phase='First' if lap==1 else 'Warm'; groups=['all',regions[leg]]
 if leg==2 and -340<=y<-240:groups.append('gallery_550_650cm')
 for s in groups:rec.setdefault((phase,s,kind),[]).append(v)
def summary(ds):
 ds=sorted(ds);n=len(ds);return {'n':n,'mean_ms':round(statistics.mean(ds),4),'fps':round(1000/statistics.mean(ds),3),'p99_ms':round(ds[math.ceil(.99*n)-1],4),'max_ms':round(ds[-1],4),'over':sum(i>1000/60 for i in ds),'rate_pct':round(sum(i>1000/60 for i in ds)*100/n,3),'excess_ms':round(sum(max(0,i-1000/60) for i in ds),3)}
pm=rows('presents_native.csv')
for ev in events:
 if ev['event']!='lap_start':continue
 k=int(ev['lap']);begin=int(ev['qpc']);end=int(next(row['qpc'] for row in events if row['event']=='lap_end' and int(row['lap'])==k))
 subset=[i for i in f if i['lap']==str(k) and begin<=int(i['qpc'])<=end]
 for a,b in zip(subset,subset[1:]):
  leg=int(b['leg']);y=(float(a['y'])+float(b['y']))*.5
  sample(k,leg,y,(int(b['qpc'])-int(a['qpc']))*1000/freq,'Tick')
 for row in pm:
  if int(row['ProcessID'])!=pid or row['Runtime']!='DXGI' or not int(row['SwapChainAddress'],16):continue
  b=int(row['QPCTime']);v=float(row['msBetweenPresents']);a=b-v*freq/1000
  if v<=0 or a<begin or b>end:continue
  q=(a+b)/2;i=min(len(f)-1,bisect_left(times,q))
  if i and abs(times[i-1]-q)<abs(times[i]-q):i-=1
  pose=f[i];sample(k,int(pose['leg']),float(pose['y']),v,'Present')
file=o/'spatial_metrics.csv'
with file.open('w',newline='',encoding='utf-8-sig') as handle:
 fields=['run','phase','region','kind','n','mean_ms','fps','p99_ms','max_ms','over','rate_pct','excess_ms'];w=csv.DictWriter(handle,fieldnames=fields);w.writeheader()
 for (phase,loc,kind),ds in rec.items():w.writerow(dict(run=r.name,phase=phase,region=loc,kind=kind,**summary(ds)))
