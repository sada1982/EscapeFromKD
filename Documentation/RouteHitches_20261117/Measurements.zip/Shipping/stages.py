"""Measure per-stage time and driver/streaming work in the same QPC domain as the playable route."""
import csv,json,sys
from pathlib import Path
from collections import defaultdict
from bisect import bisect_left,bisect_right
r=Path(sys.argv[1]);get=lambda f:list(csv.DictReader((r/f).open(encoding='utf-8-sig',newline='')))
s=dict(line.split('=',1) for line in (r/'route/startup_result.txt').read_text(encoding='utf-8-sig').splitlines() if '=' in line)
f=get('route/startup.csv');q0=int(s['start_qpc']);q1=int(s['open_qpc']);f=[x for x in f if q0<=int(x['qpc'])<=q1]
freq=json.loads((r/'telemetry.json').read_text('utf8'))['start']['frequency']
def ms(t):return round(t/freq*1000,4)
spans=[];stack=defaultdict(list)
if (r/'pso.csv').exists():
 for v in get('pso.csv'):
  tid,id,q=(int(v[k]) for k in ('tid','event_id','qpc'))
  if id==155:stack[tid].append(q)
  elif id==156 and stack[tid]:spans.append((stack[tid].pop(),q,tid))
m=[];mqs=[]
if (r/'process.csv').exists():
 m=[x for x in get('process.csv') if all(int(x[k])==0 for k in ['mem_ret','local_status','nonlocal_status','eviction_status'])]
 mqs=[int(x['qpc']) for x in m]
stages=[('initial_room',q0)];corr=int(s.get('corridor_qpc','0'));ret=int(s.get('return_qpc','0'))
entrance=int(s.get('entrance_qpc','0'))
if entrance:stages.append(('entrance',entrance))
if corr:stages.append(('corridor',corr))
if ret:stages.append(('returned_room',ret))
stages.append(('playable',q1));stages.sort(key=lambda v:v[1]);out={}
for (label,a),(next_,b) in zip(stages,stages[1:]):
 clip=[i for i in f if a<=int(i['qpc'])<=b]
 ps=[(x,y,t) for x,y,t in spans if x<b and y>a];dur=[ms(min(y,b)-max(x,a)) for x,y,t in ps]
 result={'duration_ms':ms(b-a),'samples':len(clip),'max_tick_wall_ms':max((float(i['wall_ms']) for i in clip),default=0),'input_guard_all':all(i['input_guard']=='1' for i in clip),'pso_overlapping':len(ps),'pso_longest_ms':max(dur,default=0),'pso_over_20ms':sum(v>20 for v in dur),'pso_over_50ms':sum(v>50 for v in dur)}
 if m:
  i=max(0,bisect_right(mqs,a)-1);j=min(len(m)-1,bisect_left(mqs,b));result['process_io_read_MiB_bracket']=round((int(m[j]['read_bytes'])-int(m[i]['read_bytes']))/2**20,3);result['evicted_bytes_bracket']=int(m[j]['evicted_process'])-int(m[i]['evicted_process'])
 out[label]=result
(r/'startup_stages.json').write_text(json.dumps({'engine':s,'stages':out},indent=2))
print(json.dumps(out))
