"""Correlate DXGI Present intervals, pawn Tick, location, and optional per-process PSO, I/O and VidMm."""
from collections import Counter,defaultdict
from bisect import bisect_left,bisect_right
import argparse,csv,json,math,statistics
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('run',type=Path);p.add_argument('output',type=Path);p.add_argument('--lap',type=int,default=1);u=p.parse_args()
r=u.run;out=u.output;out.mkdir(parents=True,exist_ok=True)
def rows(f):return list(csv.DictReader((r/f).open(encoding='utf-8-sig',newline='')))
meta=json.loads((r/'telemetry.json').read_text('utf8'))['start'];freq=meta['frequency']
pid=json.loads((r/'route/isolation.json').read_text('utf8'))['pid']
ev=rows('route/events.csv');start=int(next(i['qpc'] for i in ev if i['event']=='lap_start' and i['lap']==str(u.lap)))
end=int(next(i['qpc'] for i in ev if i['event']=='lap_end' and i['lap']==str(u.lap)))
pose=[i for i in rows('route/frames.csv') if i['lap']==str(u.lap)];qpose=[int(i['qpc']) for i in pose]
present=[(int(i['QPCTime']),float(i['msBetweenPresents']),int(i['SwapChainAddress'],16)) for i in rows('presents_native.csv') if i['Runtime']=='DXGI' and int(i['ProcessID'])==pid and int(i['SwapChainAddress'],16) and float(i['msBetweenPresents'])>0]
swap=Counter(s for q,ms,s in present if start<=q<=end).most_common(1)[0][0]
slices=[(round(q-ms*freq/1000),q,ms) for q,ms,s in present if s==swap and q-ms*freq/1000>=start and q<=end]
slots=['classroom_aisle','classroom_exit','gallery','connector','lobby_turn','stair_approach','stair_turn','downstairs']
def near(q):
 j=min(len(qpose)-1,bisect_left(qpose,q))
 if j and abs(qpose[j-1]-q)<abs(qpose[j]-q):j-=1
 return pose[j]
def tick_max(a,b):
 i=max(0,bisect_right(qpose,a)-1);j=min(len(qpose)-1,bisect_left(qpose,b))
 if i>=j:return 0
 return max((y-x)*1000/freq for x,y in zip(qpose[i:j],qpose[i+1:j+1]))
mem=[];spans=[]
if (r/'process.csv').exists() and (r/'pso.csv').exists():
 mem=[x for x in rows('process.csv') if all(int(x[k])==0 for k in ('mem_ret','local_status','nonlocal_status','eviction_status'))];mq=[int(x['qpc']) for x in mem]
 stack=defaultdict(list)
 for e in rows('pso.csv'):
  id,t,q=(int(e[s]) for s in ['event_id','tid','qpc'])
  if id==155:stack[t].append(q)
  if id==156 and stack[t]:spans.append((stack[t].pop(),q,t))
def diagnostic(a,b):
 if not mem:return {}
 match=[(max(x,a),min(y,b),tid) for x,y,tid in spans if x<b and y>a]
 cov=0;old=a
 for x,y,_ in sorted(match):cov+=max(0,y-max(old,x));old=max(old,y)
 i=max(0,bisect_right(mq,a)-1);j=min(len(mq)-1,bisect_left(mq,b));group=mem[i:j+1]
 def delta(k):return int(mem[j][k])-int(mem[i][k])
 return dict(pso=len(match),pso_threads=len({t for _,_,t in match}),pso_wall_ms=round(cov*1000/freq,3),io_MiB=round(delta('read_bytes')/2**20,3),evicted_bytes=delta('evicted_process'),budget_headroom_MiB=round(min((int(v['local_budget'])-int(v['local_usage']))/2**20 for v in group),1),cpu_core_ms=round((delta('user_100ns')+delta('kernel_100ns'))/1e4,2))
points=[(402,-73),(402,-890),(-117,-890),(-117,109),(-876,109),(-876,308),(-1635,308),(-1635,189),(-2154,189)]
records=[]
for a,b,ms in slices:
 pt=near((a+b)/2);p0=near(a);p1=near(b);leg=int(pt['leg']);ox,oy=points[leg];ex,ey=points[leg+1];length=math.hypot(ex-ox,ey-oy)
 offset=((float(pt['x'])-ox)*(ex-ox)+(float(pt['y'])-oy)*(ey-oy))/length
 records.append(dict(leg=leg,region=slots[leg],cm=round(offset,1),bin_m=int(min(length-1,max(0,offset))//100),
 q0=a,q1=b,s_since_start=round((a-start)/freq,4),present_ms=ms,gt_tick_bracket_ms=round(tick_max(a,b),3),
 x=float(pt['x']),y=float(pt['y']),z=float(pt['z']),yaw=float(pt['yaw']),start_xyyaw=[p0[k] for k in ('x','y','yaw')],end_xyyaw=[p1[k] for k in ('x','y','yaw')]))
def met(samples):
 v=sorted(i['present_ms'] for i in samples);n=len(v)
 return dict(n=n,over=sum(x>1000/60 for x in v),fps=round(1000/statistics.mean(v),3),p99=round(v[math.ceil(n*.99)-1],3),maximum=round(v[-1],4))
def details(i):return dict(i,**diagnostic(i['q0'],i['q1']))
byregion={k:met([i for i in records if i['region']==k]) for k in slots if any(i['region']==k for i in records)}
gallery=[i for i in records if i['leg']==2]
bins=sorted(set(i['bin_m'] for i in gallery))
result={'regions':byregion,'gallery_bins':{str(i):met([x for x in gallery if x['bin_m']==i]) for i in bins},'top_gallery':[details(i) for i in sorted(gallery,key=lambda i:-i['present_ms'])[:5]],'top_full':[details(i) for i in sorted(records,key=lambda i:-i['present_ms'])[:3]]}
groups={'exit_x_50': [i for i in records if i['leg']==1 and -50<=i['x']<=50],
        'aisle_0_140cm':[i for i in records if i['leg']==0 and 0<=i['cm']<=140],
        'aisle_300_400cm':[i for i in records if i['leg']==0 and 300<=i['cm']<400],
        'gallery_550_650cm':[i for i in records if i['leg']==2 and 550<=i['cm']<=650]}
result['target_regions']={}
for name,subset in groups.items():
 if subset:
  worst=max(subset,key=lambda i:i['present_ms'])
  minq=min(i['q0'] for i in subset);maxq=max(i['q1'] for i in subset)
  result['target_regions'][name]={'metrics':met(subset),'worst':details(worst),'whole_zone_counters':diagnostic(minq,maxq)}
file=out/('first_location.json' if u.lap==1 else ('lap'+str(u.lap)+'_location.json'));file.write_text(json.dumps(result,indent=2,ensure_ascii=False),encoding='utf8')
print(json.dumps({'gallery':byregion['gallery'],'top_gallery':result['top_gallery'][0],'top_full':result['top_full'][0]},ensure_ascii=False))
