import csv,json,sys
from collections import defaultdict
from pathlib import Path
for name in sys.argv[1:]:
 r=Path(name);f=json.loads((r/'first_location.json').read_text())['top_gallery'][0];w0,w1=f['q0'],f['q1'];t0=10000
 pending=defaultdict(list);spans=[]
 for row in csv.DictReader((r/'pso.csv').open()):
  t,i,q=(int(row[n]) for n in ('tid','event_id','qpc'))
  if i==155:pending[t].append(q)
  elif i==156 and pending[t]:
   a=pending[t].pop()
   if a<w1 and q>w0:spans.append({'tid':t,'start_ms_offset':round((a-w0)/t0,4),'end_ms_offset':round((q-w0)/t0,4),'duration_ms':round((q-a)/t0,4)})
 spans.sort(key=lambda x:x['start_ms_offset'])
 (r/'gallery_pso.json').write_text(json.dumps({'present_ms':f['present_ms'],'calls':spans},indent=2))
 print(r.name,spans)
