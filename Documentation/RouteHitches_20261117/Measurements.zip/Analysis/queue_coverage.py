import csv,os,math,statistics,collections,sys,bisect
from pathlib import Path
p=Path(os.environ['LOCALAPPDATA'])/'KDRouteHitch_F01';h=Path('Saved/Automation/RouteHitch_20261117')
def read(n):
 with (p/(n+'.csv')).open(encoding='utf-8-sig') as f:yield from csv.DictReader(f)
ev=list(read('events'));o=next(r for r in read('pso') if r['TimerName']=='KD_DiagnosticLapStart')
e=next(r for r in ev if r['event']=='lap_start')
q0=int(e['qpc']);t0=float(o['StartTime'])
def trace(q):return (int(q)-q0)*1e-7+t0
lo=trace(next(r['qpc'] for r in ev if r['event']=='lap_start' and r['lap']=='2'));hi=trace(next(r['qpc'] for r in ev if r['event']=='waypoint' and r['leg']=='0' and r['lap']=='2'))
gr=collections.defaultdict(list)
for r in read('gpu'):
 a=float(r['StartTime']);b=float(r['EndTime'])
 if b<lo or a>hi:continue
 gr[(r['ThreadName'],r['TimerName'])].append((a,b))
def union(spans,a,b):
 tail=a;sum_ms=0
 for s,e in sorted(spans):
  s=max(a,s);e=min(b,e)
  if s>=e:continue
  sum_ms+=max(0,e-max(s,tail))*1000;tail=max(e,tail)
 return sum_ms
f0=[(s,e) for s,e in gr['GPU0-Graphics0','Frame'] if s>=lo and e<=hi]
data=[]
for (queue,name),cuts in gr.items():
 within=[];over=[]
 for s,e in f0:
  (over if (e-s)*1000>1000/60 else within).append(union(cuts,s,e))
 data.append(dict(queue=queue,scope=name,within=round(statistics.mean(within),4),over=round(statistics.mean(over),4),delta=round(statistics.mean(over)-statistics.mean(within),4)))
data.sort(key=lambda r:-r['delta'])
with (h/'QueueCoverage.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=data[0].keys());w.writeheader();w.writerows(data)
for r in data[:25]:print(r['queue'], r['scope'],r['within'],r['over'],r['delta'])
