from pathlib import Path
import sys,json,csv,statistics,math
h=Path(__file__).resolve().parent
if len(sys.argv)<3:quit()
a,b=[json.loads((h/('Middle_'+v+'.json')).read_text(encoding='utf8')) for v in sys.argv[1:3]]
keys=sorted(k for k in a['metrics'] if k.startswith('warm/40cm_') and k in b['metrics'] and a['metrics'][k]['n']>=5 and b['metrics'][k]['n']>=5)
def delta(k,field):return b['metrics'][k][field]-a['metrics'][k][field]
out={'before':sys.argv[1],'after':sys.argv[2],'common_40cm_bins':len(keys),
     'equal_bin_mean_frame_ms_delta':round(statistics.mean(delta(k,'mean_ms') for k in keys),4),
     'equal_bin_tail_pct_point_delta':round(statistics.mean(delta(k,'over_pct') for k in keys),4),
     'faster_mean_bin_count':sum(delta(k,'mean_ms')<0 for k in keys)}
for obj,name in [(a,'before'),(b,'after')]:
 vals=[r['over_pct'] for r in obj['per_lap'] if r['region']=='warm/aisle']
 out[name+'_lap_over_pct_range']=[min(vals),max(vals)]
print(out)
(h/('MatchedAisle_'+sys.argv[2]+'.json')).write_text(json.dumps(out,indent=2),encoding='utf8')
