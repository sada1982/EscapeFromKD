import os,csv,statistics,collections,bisect,sys
from pathlib import Path
h=Path(__file__).resolve().parent;p=Path(os.environ['LOCALAPPDATA'])/'KDRouteHitch_F01'
def rows(f):
 with (p/f).open(encoding='utf-8-sig') as fi:yield from csv.DictReader(fi)
a=next(r for r in rows('pso.csv') if r['TimerName']=='KD_DiagnosticLapStart')
q=next(r for r in rows('events.csv') if r['event']=='lap_start')
def t(x):return float(a['StartTime'])+(int(x)-int(q['qpc']))/1e7
legs=list(rows('events.csv')); lo=t(next(r['qpc'] for r in legs if r['event']=='lap_start' and r['lap']=='2'));hi=t(next(r['qpc'] for r in legs if r['event']=='waypoint' and r['lap']=='2' and r['leg']=='0'))
events=[]
for r in rows('gpu.csv'):
 if r['ThreadName']!='GPU0-Graphics0':continue
 a0,b=float(r['StartTime']),float(r['EndTime'])
 if a0>=lo and b<=hi:events.append((a0,b,r['TimerName'],int(r['Depth'])))
events.sort(key=lambda x:(x[0],-x[1],x[3]))
frames=[(a,b) for a,b,n,d in events if n=='Frame']
out=[]
for i,(s,e) in enumerate(frames):
 stack=[]; seen=collections.defaultdict(list)
 for a,b,n,d in events:
  if a<s or b>e:continue
  while stack and (stack[-1][1]<b-1e-8 or stack[-1][3]>=d):stack.pop()
  stack.append((a,b,n,d))
  gp='ShadowDepths' if any(z[2]=='ShadowDepths' for z in stack) else ('MegaLights' if any(z[2]=='MegaLights' for z in stack) else '')
  if gp:seen[gp+'/'+n].append((a,b))
 times={}
 for key,spans in seen.items():
  prev=s;ms=0
  for a,b in spans:ms+=max(0,b-max(prev,a))*1000;prev=max(prev,b)
  times[key]=ms
 out.append(((e-s)*1000,times))
keys=sorted(set().union(*(set(x[1]) for x in out)))
compare=[]
for label in keys:
 fast=[tm.get(label,0) for dt,tm in out if dt<=1000/60];slow=[tm.get(label,0) for dt,tm in out if dt>1000/60]
 compare.append(dict(scope=label,within_frames=len(fast),within_ms=round(statistics.mean(fast),4),over_frames=len(slow),over_ms=round(statistics.mean(slow),4),delta=round(statistics.mean(slow)-statistics.mean(fast),4)))
with (h/'CenterSubpasses.csv').open('w',newline='') as f:
 wr=csv.DictWriter(f,fieldnames=compare[0].keys());wr.writeheader();wr.writerows(compare)
for z in sorted(compare,key=lambda x:-x['delta'])[:15]:print(z['scope'],z['within_ms'],z['over_ms'],z['delta'])
