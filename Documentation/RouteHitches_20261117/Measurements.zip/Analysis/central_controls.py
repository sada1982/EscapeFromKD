from pathlib import Path
import csv,collections,statistics,json,math
import numpy as np
p=Path('Saved/Profiling/CSV')
tags=['C02Control','C11Control','D02Ref','E02Ref','E10Ref','E12Restore','F02Ref','F10Ref']
rows=[]
for tag in tags:
 f=p/('Cent17_'+tag+'.csv')
 if not f.is_file(): continue
 with f.open(encoding='utf-8-sig') as src:
  for r in csv.DictReader(src):
   try: x=float(r['View/PosX']);y=float(r['View/PosY']);gt=float(r['GPUTime'])
   except (TypeError,ValueError,KeyError):continue
   if x>350 and -780<y<-420 and gt>0:rows.append((tag,gt,r))
keys=['GPUTime','GPU/ShadowDepths','GPU/MegaLights','VSM/ALLOCATED_NEW','VSM/DYNAMIC_INVALIDATED_PAGES','VSM/STATIC_INVALIDATED_PAGES','VSM/WPO_CONSIDERED_PAGES','GPU/TemporalSuperResolution','GPU/LumenScreenProbeGather']
out={}
for name,group in [('over',[r for t,ms,r in rows if ms>1000/60]),('within',[r for t,ms,r in rows if ms<=1000/60])]:
 result={'n':len(group)}
 for k in keys:
  v=[float(r[k]) for r in group if r.get(k)]
  if v:result[k]=round(statistics.mean(v),4)
 out[name]=result
out['controls']=dict(collections.Counter(t for t,_,_ in rows));print(out)
Path('Saved/Automation/RouteHitch_20261117/CentralControlPasses.json').write_text(json.dumps(out,indent=2),encoding='utf8')
