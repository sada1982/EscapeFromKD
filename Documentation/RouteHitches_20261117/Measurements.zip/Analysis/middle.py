"""Position-aligned DXGI intervals for the central aisle; complete intervals only, using the midpoint pawn sample."""
from pathlib import Path
import csv,json,math,sys,bisect,statistics
root=Path.cwd()
here=Path(__file__).resolve().parent
origin=here.parent/'RouteHitchVerify_20261117'
def rows(p):
 with p.open('r',encoding='utf-8-sig',newline='') as f: return list(csv.DictReader(f))
def calc(values):
 ordered=sorted(values)
 if not values:return {}
 return {'n':len(values),'over':sum(t>1000/60 for t in values),'over_pct':round(100*sum(t>1000/60 for t in values)/len(values),3),'p95_ms':round(ordered[math.ceil(.95*len(values))-1],4),'p99_ms':round(ordered[math.ceil(.99*len(values))-1],4),'max_ms':round(ordered[-1],4),'mean_ms':round(statistics.mean(values),4)}
def analyze(run):
 p=origin/run
 frames=rows(p/'route/frames.csv'); qposes=[int(r['qpc']) for r in frames]
 m=json.loads((p/'telemetry.json').read_text(encoding='utf-8-sig'))['start'];freq=m['frequency']
 iso=json.loads((p/'route/isolation.json').read_text(encoding='utf-8-sig'));pid=iso['pid']
 spans={}
 for r in rows(p/'route/events.csv'):
  if r['event']=='lap_start':start=int(r['qpc'])
  elif r['event']=='waypoint' and int(r['leg'])==0:spans[int(r['lap'])]=(start,int(r['qpc']))
 ends=[end for _,end in spans.values()];laps=list(spans); buckets={};bylap={}
 for r in rows(p/'presents_native.csv'):
  if r['Runtime']!='DXGI' or int(r['ProcessID'])!=pid:continue
  dt=float(r['msBetweenPresents']);b=int(r['QPCTime']);a=b-dt/1000*freq
  if dt<=0:continue
  i=bisect.bisect_left(ends,b)
  if i>=len(laps) or a<spans[laps[i]][0]:continue
  lap=laps[i]; q=(a+b)/2
  k=bisect.bisect_left(qposes,q)
  if k==len(qposes) or (k and q-qposes[k-1]<qposes[k]-q):k-=1
  x,y=float(frames[k]['x']),float(frames[k]['y'])
  stage='first' if lap==1 else 'warm'
  keys=[stage+'/aisle',stage+'/40cm_bin_'+str(math.floor((-y-73)/40))]
  if x>350 and -780<y<-420:keys.append(stage+'/middle_360cm')
  for key in keys:
   buckets.setdefault(key,[]).append(dt)
   bylap.setdefault((lap,key),[]).append(dt)
 (here/('CoreValues_'+run+'.json')).write_text(json.dumps(buckets.get('warm/middle_360cm',[])),encoding='utf8')
 return {key:calc(v) for key,v in buckets.items()},[dict(lap=l,region=k,**calc(v)) for (l,k),v in bylap.items()]
out=[]
for run in sys.argv[1:]:
 summary,perlap=analyze(run)
 (here/('Middle_'+run+'.json')).write_text(json.dumps(dict(run=run,metrics=summary,per_lap=perlap),indent=2),encoding='utf8')
 mid=summary.get('warm/middle_360cm',{})
 print(run,mid)
 for region,val in summary.items():out.append(dict(run=run,region=region,**val))
if out:
 with (here/'AislePositions.csv').open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=out[0].keys());w.writeheader();w.writerows(out)


