import bisect,csv,os,collections,json,sys,statistics
from pathlib import Path
h=Path(__file__).resolve().parent
p=Path(os.environ['LOCALAPPDATA'])/('KDRouteHitch_'+sys.argv[1])
def rows(f):
    with (p/f).open(encoding='utf-8-sig',newline='') as rd:yield from csv.DictReader(rd)
psos=list(rows('pso.csv'));f=list(rows('frames.csv'));ev=list(rows('events.csv'))
la=[r for r in psos if r['TimerName']=='KD_DiagnosticLapStart']; e=[r for r in ev if r['event']=='lap_start']
t0=float(la[0]['StartTime']);q0=int(e[0]['qpc'])
def clock(q):return t0+(int(q)-q0)/1e7
print('anchor_error_ms',[(float(a['StartTime'])-clock(b['qpc']))*1000 for a,b in zip(la,e)])
spans={}
for n in ('1','2'):
 for name,leg,a,b in [('target','2',-350,-210),('gallery','2',-1000,150),('cell','0',-780,-420),('aisle','0',-1000,100)]:
  subset=[r for r in f if r['lap']==n and r['leg']==leg and a<=float(r['y'])<=b]
  if subset:spans[n,name]=(clock(subset[0]['qpc']),clock(subset[-1]['qpc']),subset)
raw=collections.defaultdict(list)
for r in rows('gpu.csv'):
 name=r['TimerName'];key=(r['ThreadName'],name);raw[key].append((float(r['StartTime']),float(r['EndTime']),int(r['Depth'])))
def area(iv,lo,hi):
 elapsed=0;tail=lo
 for a,b,d in sorted(iv):
  a=max(a,lo);b=min(b,hi)
  if a>=b:continue
  elapsed+=max(0,b-max(tail,a));tail=max(tail,b)
 return elapsed*1000
core=['Frame','MegaLights','ShadowDepths','RenderVirtualShadowMaps','BasePass','LumenScreenProbeGather','LumenReflections','PostProcessing','Nanite::DrawGeometry','Translucency','UpdateWorldRadianceCaches','RenderDeferredLighting']
frames_gpu={thread:[(a,b) for a,b,d in seq] for (thread,k),seq in raw.items() if k=='Frame'}
detailed=[]
for (n,name),(s,end,sub) in spans.items():
 for thread,intervals in frames_gpu.items():
  for label in core:
   sig=raw.get((thread,label)); 
   if not sig: continue
   startkeys=[a for a,b,d in sig]
   series=[]
   for a,b in intervals:
    if a<s or b>end:continue
    l=bisect.bisect_left(startkeys,a);r=bisect.bisect_left(startkeys,b)
    series.append(((b-a)*1000,area(sig[max(0,l-2):r],a,b)))
   for subset_name,part in [('all',series),('over',[v for v in series if v[0]>1000/60]),('within',[v for v in series if v[0]<=1000/60])]:
    if not part:continue
    detailed.append(dict(lap=n,region=name,queue=thread,scope=label,subset=subset_name,n=len(part),ms_mean=round(statistics.mean(x[1] for x in part),4),frame_mean=round(statistics.mean(x[0] for x in part),4)))
 result=[]
 for r in psos:
  a=float(r['StartTime']);b=float(r['EndTime'])
  if a>=end or b<s:continue
  label=r['TimerName']
  if not any(z in label for z in ('RHICreate','PSOPrecache:','FCompilePipelineStateTask')):continue
  result.append((label,round((min(end,b)-max(s,a))*1000,4)))
 grp=collections.Counter(label for label,t in result)
 if name=='target':print('target',n,s,end,'app_max',max(float(r['app_dt'])*1000 for r in sub),'pso',dict(grp))
print('warm_graphics')
for name in ('aisle','cell','gallery'):
 for group in ('within','over'):
  print(name,group,[(r['scope'],r['ms_mean'],r['n']) for r in detailed if r['lap']=='2' and r['region']==name and r['queue']=='GPU0-Graphics0' and r['subset']==group and r['scope'] in ('Frame','ShadowDepths','MegaLights','BasePass')])
with (h/('Trace_'+sys.argv[1]+'.csv')).open('w',newline='') as fp:
 w=csv.DictWriter(fp,fieldnames=detailed[0].keys());w.writeheader();w.writerows(detailed)
