from pathlib import Path
import json,sys,csv
base=Path('Saved/Automation/RouteHitchVerify_20261117');here=Path('Saved/Automation/RouteHitch_20261117')
def read(f):
 with f.open(encoding='utf-8-sig',newline='') as r:return list(csv.DictReader(r))
out=[]
for run in sorted(base.iterdir()):
 f=run/'spatial_metrics.csv';loc=run/'first_location.json'
 if not f.is_file() or not loc.is_file():continue
 l=json.loads(loc.read_text(encoding='utf8'))
 rows=read(f)
 def metric(phase,region):
  return next((r for r in rows if r['phase']==phase and r['kind']=='Present' and r['region']==region),{})
 def key(r,k):
  return r.get(k,'')
 c,g,e=(metric('First',r) for r in ('classroom_aisle','gallery','gallery_550_650cm'))
 a,m=(metric('Warm',r) for r in ('classroom_aisle','all'))
 first=metric('First','all')
 proof=run/'route/startup_result.txt';gate={}
 if proof.is_file():
  gate=dict(row.split('=',1) for row in proof.read_text(encoding='utf-8-sig').splitlines() if '=' in row)
 wait=round((int(gate['open_qpc'])-int(gate['start_qpc']))/1e7,4) if gate.get('open_qpc') else None
 sw=run/'power_state.json'
 out.append(dict(run=run.name,startup_s=wait,release=gate.get('reason'),gallery0_max=l['gallery_bins'].get('0',{}).get('maximum'),
   gallery6_max=key(e,'max_ms'),gallery6_over=key(e,'over'),gallery6_n=key(e,'n'),gallery_full_max=key(g,'max_ms'),first_all_max=key(first,'max_ms'),
   first_all_fps=key(first,'fps'),warm_all_n=key(m,'n'),warm_all_fps=key(m,'fps'),warm_all_p99=key(m,'p99_ms'),warm_all_max=key(m,'max_ms'),warm_all_over=key(m,'over'),
   warm_aisle_n=key(a,'n'),warm_aisle_p99=key(a,'p99_ms'),warm_aisle_max=key(a,'max_ms'),warm_aisle_over=key(a,'over'),warm_aisle_over_pct=key(a,'rate_pct')))
if out:
 with (here/'RunIndex.csv').open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=out[0].keys());w.writeheader();w.writerows(out)
 print(len(out))
