import json
import unreal
world=unreal.get_editor_subsystem(unreal.UnrealEditorSubsystem).get_editor_world()
cmd=lambda command:unreal.SystemLibrary.execute_console_command(world,command)
assetpath='/Game/Main/Stage/Floor03/ShadowCasters'
bp=unreal.load_asset('/Game/Main/Stage/BP_Floor03')
sub=unreal.get_engine_subsystem(unreal.SubobjectDataSubsystem);lib=unreal.SubobjectDataBlueprintFunctionLibrary
def tree():
    items={}
    for h in sub.k2_gather_subobject_data_for_blueprint(bp):
        data=lib.get_data(h)
        items[str(lib.get_variable_name(data))]=(h,lib.get_object_for_blueprint(data,bp))
    return items
items=tree()
results={};assets_to_save=[]
for category in ('Chairs','Desks'):
    base_path='/Game/Main/Stage/Floor03/SurveyV02/SM_F03V02_'+category
    source=unreal.load_asset(base_path)
    work=unreal.DynamicMesh()
    read=unreal.GeometryScriptCopyMeshFromAssetOptions()
    read.request_tangents=True
    read.apply_build_settings=False
    lod=unreal.GeometryScriptMeshReadLOD()
    lod.lod_type=unreal.GeometryScriptLODType.SOURCE_MODEL
    api=unreal.GeometryScript_AssetUtils
    _,result=api.copy_mesh_from_static_mesh(source,work,read,lod)
    assert result==unreal.GeometryScriptOutcomePins.SUCCESS
    expected=work.get_triangle_count();added=0
    for label,lo,hi in [('Main',(-5,-1017,-10),(815,5,200)),
                        ('Adjacent',(-225,-2033,-10),(815,-1017,200)),
                        ('Remainder',None,None)]:
        if lo is None:
            part=work
        else:
            box=unreal.Box()
            box.min=unreal.Vector(*lo);box.max=unreal.Vector(*hi);box.is_valid=True
            _,selection=work.select_mesh_elements_in_box(box)
            part=unreal.DynamicMesh()
            work.copy_mesh_selection_to_mesh(part,selection,False,True)
            work.delete_selected_triangles_from_mesh(selection)
        count=part.get_triangle_count()
        assert count>0
        added+=count
        name='SM_'+category+'_'+label+'_Shadow'
        dest=assetpath+'/'+name
        mesh=unreal.load_asset(dest) if unreal.EditorAssetLibrary.does_asset_exist(dest) else unreal.AssetToolsHelpers.get_asset_tools().duplicate_asset(name,assetpath,source)
        options=unreal.GeometryScriptCopyMeshToAssetOptions()
        options.clean_assigned_materials=False
        options.enable_recompute_normals=False
        options.enable_recompute_tangents=False
        options.enable_remove_degenerates=False
        _,result=api.copy_mesh_to_static_mesh(part,mesh,options,unreal.GeometryScriptMeshWriteLOD(),True)
        assert result==unreal.GeometryScriptOutcomePins.SUCCESS
        cmd('Editor.AsyncAssetCompilationFinishAll')
        child=name.removeprefix('SM_')
        items=tree();old_handle,old=items[category]
        if child not in items:
            params=unreal.AddNewSubobjectParams(parent_handle=old_handle,new_class=unreal.StaticMeshComponent,blueprint_context=bp)
            handle,why=sub.add_new_subobject(params)
            if str(why):raise RuntimeError(str(why))
            if not sub.rename_subobject(handle,unreal.Text(child)):raise RuntimeError('rename '+child)
            items=tree()
        shadow=items[child][1]
        shadow.set_static_mesh(mesh);shadow.set_mobility(unreal.ComponentMobility.STATIC)
        shadow.set_collision_profile_name('NoCollision');shadow.set_collision_enabled(unreal.CollisionEnabled.NO_COLLISION)
        shadow.set_cast_shadow(True);shadow.set_editor_property('cast_hidden_shadow',True)
        for prop in ('can_ever_affect_navigation','visible_in_reflection_captures','visible_in_real_time_sky_captures','affect_indirect_lighting_while_hidden','render_custom_depth'):
            shadow.set_editor_property(prop,False)
        shadow.set_editor_property('affect_distance_field_lighting',False);shadow.set_editor_property('affect_dynamic_indirect_lighting',False)
        shadow.set_editor_property('visible_in_ray_tracing',True);shadow.set_hidden_in_game(True,False)
        results[child]={'category':category,'path':mesh.get_path_name(),'triangles':mesh.get_num_nanite_triangles()}
        assets_to_save.append(mesh.get_outermost())
    assert added==expected
    items=tree();items[category][1].set_editor_property('cast_dynamic_shadow',False)
unreal.BlueprintEditorLibrary.compile_blueprint(bp)
cmd('Editor.AsyncAssetCompilationFinishAll')
if not unreal.EditorLoadingAndSavingUtils.save_packages(assets_to_save+[bp.get_outermost()],False):raise RuntimeError('save')
items=tree();base={}
for k in ['Chairs','Desks']:
    a=items[k][1];base[k]={'path':a.get_editor_property('static_mesh').get_path_name(),'cast_shadow':a.get_editor_property('cast_shadow'),'dynamic':a.get_editor_property('cast_dynamic_shadow'),'visible':a.get_editor_property('visible'),'collision':str(a.get_collision_enabled())}
    assert base[k]['cast_shadow'] and not base[k]['dynamic'] and base[k]['visible'] and 'NO_COLLISION' not in base[k]['collision']
for k,v in results.items():
    b=items[k][1];v.update(mesh=b.get_editor_property('static_mesh').get_path_name(),shadow=b.get_editor_property('cast_shadow'),dynamic=b.get_editor_property('cast_dynamic_shadow'),hidden=b.get_editor_property('hidden_in_game'),cast_hidden=b.get_editor_property('cast_hidden_shadow'),collision=str(b.get_collision_enabled()),relative_location=str(b.get_editor_property('relative_location')))
    v['auxiliary']={p:bool(b.get_editor_property(p)) for p in ('can_ever_affect_navigation','visible_in_reflection_captures','visible_in_real_time_sky_captures','affect_indirect_lighting_while_hidden','render_custom_depth','affect_distance_field_lighting','affect_dynamic_indirect_lighting')}
    assert not any(v['auxiliary'].values())
    assert v['mesh']==v['path'] and v['shadow'] and v['dynamic'] and v['hidden'] and v['cast_hidden'] and 'NO_COLLISION' in v['collision']
unreal.log('Floor03 shadow casters rebuilt: '+json.dumps({'base':base,'proxies':results}))

