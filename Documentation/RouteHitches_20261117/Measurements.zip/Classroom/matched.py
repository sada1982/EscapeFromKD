import csv,json,statistics,sys
from pathlib import Path
import numpy as np
r=Path(__file__).resolve().parent
fields=['GPUTime','GPU/ShadowDepths','GPU/MegaLights','FrameTime']
def bins(label):
    p=r.parents[2]/'Saved/Profiling/CSV'/('Cent17_'+label+'.csv')
    if not p.is_file():return {}
    result={}
    with p.open(encoding='utf-8-sig') as file:
        for row in csv.DictReader(file):
            try:x=float(row['View/PosX']);y=float(row['View/PosY'])
            except (TypeError,ValueError):continue
            if not(x>350 and -780<y<-420) or float(row['GPUTime'])<=0:continue
            b=int((-420-y)//40);result.setdefault(b,[]).append([float(row[k]) for k in fields])
    return {i:np.mean(a,axis=0) for i,a in result.items() if a}
refs=sys.argv[1].split(',');ref_bins=[bins(n) for n in refs]
out={}
for target in sys.argv[2:]:
    v=bins(target)
    if not v:continue
    ids=sorted(set(v).intersection(*(set(m) for m in ref_bins)))
    if not ids:continue
    err=np.array([v[i]-np.mean([u[i] for u in ref_bins],axis=0) for i in ids])
    out[target]={'matched_bins':ids,'refs':refs,'fields':fields,'mean_ms_delta':np.mean(err,axis=0).round(4).tolist(),'per_bin_delta_ms':err.round(4).tolist()}
    print(target,np.mean(err,axis=0).round(3).tolist())
(r/('matched_'+refs[0]+'.json')).write_text(json.dumps(out,indent=2),encoding='utf8')
