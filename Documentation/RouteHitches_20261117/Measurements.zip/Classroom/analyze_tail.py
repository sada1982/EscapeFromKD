from pathlib import Path
import csv,json,sys
import numpy as np
r=Path(__file__).resolve().parent
source=r.parents[2]/'Saved/Profiling/CSV'
cols=['FrameTime','GPUTime','GPU/ShadowDepths','GPU/MegaLights','GPU/TemporalSuperResolution','GPU/LumenScreenProbeGather','VSM/ALLOCATED_NEW','VSM/STATIC_INVALIDATED_PAGES','VSM/DYNAMIC_INVALIDATED_PAGES','VSM/NON_NANITE_INSTANCES_DRAWN','VSM/NANITE_TRIANGLES','VSM/NUM_PAGES_TO_CLEAR','VSM/FreePages','VSM/WPO_CONSIDERED_PAGES']
out={}
for p in sorted(source.glob('Cent17_*.csv')):
 try:
  raw=[]
  for v in csv.DictReader(p.open(encoding='utf-8-sig')):
   try:x=float(v['View/PosX']);y=float(v['View/PosY'])
   except (TypeError,KeyError,ValueError):continue
   if x>350 and -780<y<-420:raw.append(v)
  if not raw:continue
  d={k:np.array([float(v.get(k) or 'nan') for v in raw]) for k in cols}
  masks={'all':d['GPUTime']>0,'gpu_under':(d['GPUTime']>0)&(d['GPUTime']<=1000/60),'gpu_over':d['GPUTime']>1000/60,'frame_over':(d['GPUTime']>0)&(d['FrameTime']>1000/60)}
  stats={n:dict(frames=int(z.sum()),averages={k:round(float(np.nanmean(v[z])),4) for k,v in d.items() if z.any() and np.isfinite(v[z]).any()}) for n,z in masks.items()}
  vals=d['GPUTime'][d['GPUTime']>0]
  stats['gpu_p95']=round(float(np.percentile(vals,95)),4)
  stats['raw_frames']=len(raw)
  out[p.stem[7:]]=stats
 except PermissionError:continue
(r/'central_tails.json').write_text(json.dumps(out,indent=1),encoding='utf8')
for k in sys.argv[1:]:
 if k not in out:continue
 a=out[k];print(k, a['gpu_over']['frames'],a['all']['frames'],a['all']['averages']['GPUTime'],a['gpu_p95'],[(label,[a[label]['averages'].get(z) for z in ('GPU/ShadowDepths','VSM/ALLOCATED_NEW','VSM/DYNAMIC_INVALIDATED_PAGES')]) for label in ('gpu_under','gpu_over')])
