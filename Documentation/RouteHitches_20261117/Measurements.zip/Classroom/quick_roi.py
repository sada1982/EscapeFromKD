from pathlib import Path
import numpy as np,sys
from PIL import Image
r=Path(__file__).resolve().parent
rois={'feet':[(84,134,140,167),(150,224,216,265),(167,149,218,181)],'wheels':[(66,95,122,122),(145,240,228,267),(15,124,55,161)]}
def score(b,a):
 v=[]
 for view,boxes in rois.items():
  with Image.open(r/f'shot_{a}_{view}.png') as ia,Image.open(r/f'shot_{b}_{view}.png') as ib:
   for x,y,X,Y in boxes:
    box=[4*t for t in [x,y,X,Y]];a1=np.array(ia.crop(box).convert('RGB'),np.float32);b1=np.array(ib.crop(box).convert('RGB'),np.float32)
    h,w=a1.shape[:2];d=(a1-b1)[:h//8*8,:w//8*8].reshape(h//8,8,w//8,8,3).mean(axis=(1,3));v.append(np.mean(abs(d)))
 return round(float(np.mean(v)),3),[round(float(i),1) for i in v]
for a in sys.argv[2:]:
 try:print(a,score(sys.argv[1],a))
 except FileNotFoundError:pass
