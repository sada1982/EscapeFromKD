import argparse
import csv
import json
import math
import os
from pathlib import Path

os.environ["OPENBLAS_NUM_THREADS"] = "1"
import numpy as np


BUDGET = 1000 / 60
THREADS = [
    "GPUTime", "GameThreadTime", "GameThreadTime_CriticalPath", "RenderThreadTime",
    "RenderThreadTime_CriticalPath", "RHIThreadTime", "DrawSceneCommand_StartDelay",
    "Exclusive/GameThread/EventWait", "RenderThreadIdle/Total", "RenderThreadIdle/CriticalPath",
    "RenderThreadIdle/SwapBuffer", "RenderThreadIdle/GPUQuery", "InputLatencyTime",
    "FileIO/GameThread/AsyncLoadingTime", "Exclusive/GameThread/AsyncLoading",
    "Exclusive/RenderThread/RDG_Execute", "Exclusive/GameThread/CharacterMovement",
    "Exclusive/GameThread/PlayerControllerTick", "Exclusive/GameThread/CsvProfiler"
]
COUNTERS = [
    "RHI/DrawCalls", "RHI/PrimitivesDrawn", "GPUMem/LocalUsedMB", "GPUMem/LocalBudgetMB",
    "GPUMem/SystemUsedMB", "GPUMem/DeltaMiB", "VSM/FreePages", "VSM/OVERFLOW_FLAGS",
    "VSM/ALLOCATED_NEW", "VSM/DYNAMIC_INVALIDATED_PAGES", "VSM/STATIC_INVALIDATED_PAGES",
    "VSM/NON_NANITE_INSTANCES_DRAWN", "VSM/NUM_PAGES_TO_CLEAR", "VSM/NON_NANITE_INSTANCES_TOTAL",
    "LightCount/All", "LightCount/Batched", "LightCount/Unbatched", "RDGCount/Passes",
    "LightCount/UpdatedShadowMaps", "TextureStreaming/PendingStreamInData",
    "TextureStreaming/DesiredDataLoadedPercent", "IoDispatcher/PendingIoRequests",
    "StreamableManager/StreamablesInFlight", "FileIO/QueuedPackagesQueueDepth",
    "LevelStreaming/NumLevelsLoading", "NaniteStreamingDetail/NewStreamingDataSizeMB",
    "NaniteStreamingDetail/VisibleStreamingDataSizeMB", "PSO/PSOMisses", "PSO/PSOMissesOnHitch",
    "PSO/PSOPrevFrameMissesOnHitch", "PSO/PSOComputeMisses", "PSO/PSOComputeMissesOnHitch",
    "PSO/PSOComputePrevFrameMissesOnHitch", "Shaders/NumShadersCreated"
]
POSITION = ["View/PosX", "View/PosY", "View/PosZ"]


def number(cell):
    try:
        return float(cell)
    except (TypeError, ValueError):
        return math.nan


def read_capture(path):
    with path.open(encoding="utf-8-sig", newline="") as f:
        rows = list(csv.reader(f))
    if not rows or not rows[-1][0].startswith("["):
        raise ValueError(f"Incomplete UE CSV: {path}")
    header = next(row for row in reversed(rows) if "FrameTime" in row)
    fields = [key for key in header if key in THREADS + COUNTERS + POSITION + ["FrameTime"]
              or key.startswith("GPU/")]
    indices = [header.index(key) for key in fields]
    frame_index = header.index("FrameTime")
    matrix = []
    for row in rows:
        if not row or row[0].startswith("[") or len(row) <= frame_index or not number(row[frame_index]) > 0:
            continue
        matrix.append([number(row[i]) if len(row) > i else math.nan for i in indices])
    values = dict(zip(fields, np.asarray(matrix, dtype=float).T))
    if "GPUMem/LocalUsedMB" in values and "GPUMem/LocalBudgetMB" in values:
        used, budget = values["GPUMem/LocalUsedMB"], values["GPUMem/LocalBudgetMB"]
        values["GPUMem/DeltaMiB"] = np.where((used > 0) & (budget > 0), used - budget, np.nan)
    for key in ("GPUTime", "GPUMem/LocalUsedMB", "GPUMem/LocalBudgetMB", "GPUMem/SystemUsedMB"):
        if key in values:
            values[key] = np.where(values[key] > 0, values[key], np.nan)
    return values


def rounded(value):
    return round(float(value), 4) if np.isfinite(value) else None


def correlation(a, b):
    valid = np.isfinite(a) & np.isfinite(b)
    a, b = a[valid], b[valid]
    if len(a) < 3 or np.ptp(a) < 1e-8 or np.ptp(b) < 1e-8:
        return None
    return rounded(np.corrcoef(a, b)[0, 1])


def distribution(values, mask):
    x = values[mask & np.isfinite(values)]
    if not len(x):
        return None
    return {"n": len(x), "mean": rounded(np.mean(x)), "p95": rounded(np.percentile(x, 95)),
            "max": rounded(np.max(x))}


def analyze(data, rows):
    data = {k: v[rows] for k, v in data.items()}
    ft = data["FrameTime"]
    if not len(ft):
        raise ValueError("Empty frame range")
    slow = ft > BUDGET
    all_rows = np.ones(len(ft), dtype=bool)
    slowest = np.argsort(ft)[::-1]
    adjacent = np.diff(rows) == 1
    result = {"frame_start_0": int(rows[0]), "frame_end_exclusive": int(rows[-1]+1),
              "continuous_spans": 1+int(sum(~adjacent)), "n": len(ft),
              "duration_seconds": rounded(ft.sum()/1000), "fps": rounded(1000/ft.mean()),
              "low1_fps": rounded(1000/ft[slowest[:math.ceil(len(ft)*.01)]].mean()),
              "exceed": int(slow.sum()), "exceed_pct": rounded(np.mean(slow)*100),
              "above_25ms": int(sum(ft > 25)), "above_33_33ms": int(sum(ft > 1000/30)),
              "p95_ms": rounded(np.percentile(ft,95)), "p99_ms": rounded(np.percentile(ft,99)),
              "worst_ms": rounded(ft[slowest[0]])}
    if all(k in data for k in POSITION):
        locations = np.column_stack([data[k] for k in POSITION])
        result["start_camera_cm"] = [rounded(v) for v in locations[0]]
        result["end_camera_cm"] = [rounded(v) for v in locations[-1]]
        result["maxima_frames"] = [
            {"row0": int(rows[j]), "frame_ms": rounded(ft[j]),
             "camera_cm": [rounded(v) for v in locations[j]],
             "gpu_ms_reported": rounded(data["GPUTime"][j]) if "GPUTime" in data else None}
            for j in slowest[:5]
        ]
    for group, keys in (("threads", THREADS), ("gpu", [k for k in data if k.startswith("GPU/")]),
                        ("counters", COUNTERS)):
        diagnostics = {}
        for key in keys:
            if key not in data:
                continue
            values = data[key]
            overall = distribution(values, all_rows)
            if overall is None:
                continue
            slow_stats, fast_stats = distribution(values, slow), distribution(values, ~slow)
            stats = dict(overall, mean_on_over=slow_stats and slow_stats["mean"],
                         mean_on_within=fast_stats and fast_stats["mean"])
            if group in ("threads", "gpu"):
                stats["corr_same_row"] = correlation(ft, values)
                stats["corr_prev_row"] = correlation(ft[1:][adjacent], values[:-1][adjacent])
                stats["over_budget_rows"] = int(np.count_nonzero(values > BUDGET))
                stats["overlap_with_slow_same_row"] = int(np.count_nonzero((values > BUDGET) & slow))
                if key in THREADS:
                    prev = distribution(values[:-1], slow[1:] & adjacent)
                    stats["prev_mean_on_over"] = prev and prev["mean"]
            else:
                stats["positive_rows"] = int(np.count_nonzero(values > 0))
                stats["positive_over_rows"] = int(np.count_nonzero((values > 0) & slow))
                stats["min"] = rounded(np.nanmin(values))
            diagnostics[key] = stats
        result[group] = diagnostics
    if "GPUTime" in data:
        gpu = data["GPUTime"]
        gpu_valid = np.isfinite(gpu)
        residual = slow & gpu_valid & (gpu <= BUDGET)
        result["gpu_budget_decomposition"] = {
            "slow_valid_gpu": int(sum(slow & gpu_valid)),
            "slow_with_gpu_over_same_row": int(sum(slow & (gpu > BUDGET))),
            "slow_without_gpu_over_same_row": int(sum(residual)),
            "slow_without_valid_gpu": int(sum(slow & ~gpu_valid)),
            "gpu_over_without_slow_same_row": int(sum((~slow) & (gpu > BUDGET))),
            "same_row_on_residual": {},
            "previous_row_on_residual": {}
        }
        for key in THREADS:
            if key in data:
                result["gpu_budget_decomposition"]["same_row_on_residual"][key] = distribution(data[key], residual)
                result["gpu_budget_decomposition"]["previous_row_on_residual"][key] = distribution(data[key][:-1], residual[1:] & adjacent)
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("captures", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("frame_attribution.json"))
    parser.add_argument("--ranges", type=Path, help="JSON mapping CSV stem to {name: [first, end_exclusive]}; 0-based CSV data rows")
    args = parser.parse_args()
    ranges = json.loads(args.ranges.read_text(encoding="utf-8-sig")) if args.ranges else {}
    result = {"budget_ms": BUDGET, "captures": {}, "notes": [
        "Gameplay, rendering, RHI and GPU overlap. Sums of their times do not yield frame time.",
        "Previous-row and same-row correlations are descriptive. GPU timings are reported asynchronously.",
        "Render-thread stats may include dependent waits. InputLatencyTime covers engine stages, not display.",
        "Zero in sparsely updated memory budget/usage or GPUTime is missing, not an actual zero sample.",
        "GPU/Unaccounted covers time without a named exclusive stat. Async GPU queues and idle time vary.",
        "Counter overlap is evidence of coincidence. Zero PSO misses cannot rule out every form of IO or compilation."
    ]}
    for path in args.captures:
        data = read_capture(path)
        n = len(data["FrameTime"])
        groups = {"all": [0,n], **ranges.get(path.stem,{})}
        for label, (first, end) in groups.items():
            if first < 0 or end > n or first >= end:
                raise ValueError(f"Invalid range {path.stem}/{label}: [{first}, {end}) of {n}")
        groups = {name: np.arange(first, end) for name,(first,end) in groups.items()}
        if "View/PosX" in data and "View/PosY" in data:
            x, y = data["View/PosX"], data["View/PosY"]
            valid = np.isfinite(x) & np.isfinite(y)
            classroom = valid & (x >= 0)
            for name, mask in {
                "classroom": classroom,
                "gallery": valid & (~classroom) & (x > -860),
                "lobby": valid & (x <= -860) & (x > -1650),
                "downstairs": valid & (x <= -1650),
                "no_camera": ~valid
            }.items():
                if np.any(mask):
                    groups[name] = np.flatnonzero(mask)
        result["captures"][path.stem] = {name: analyze(data, indices) for name, indices in groups.items()}
        entry = result["captures"][path.stem]["all"]
        print(path.stem, entry["n"], entry["fps"], entry["exceed"], entry["low1_fps"])
    args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False),encoding="utf-8")
