import json
import sys
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageStat, ImageChops

base, candidate, out = (Path(p) for p in sys.argv[1:])
out.mkdir(parents=True, exist_ok=True)
images = [Image.open(path).convert('RGB') for path in (base, candidate)]
assert all(im.size == (1920, 1080) for im in images)
boxes = {'left_table_legs': (101, 938, 372, 1033), 'near_chair_base': (576, 950, 766, 1055),
         'middle_aisle_table_foot': (735, 837, 849, 970)}


def block_mae(crops):
    w, h = crops[0].size
    crops = [im.crop((0, 0, w-w%8, h-h%8)).resize((w//8, h//8), Image.Resampling.BOX) for im in crops]
    return sum(ImageStat.Stat(ImageChops.difference(*crops)).mean)/3


result = {'both_sizes': [im.size for im in images], 'block_8px_MAE_RGB255': {'image': block_mae(images)}}
for label, roi in boxes.items():
    result['block_8px_MAE_RGB255'][label] = block_mae([im.crop(roi) for im in images])
result['ROIs'] = boxes
(out/'visual_check.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
sheet = Image.new('RGB', (1104, 477), 'white')
draw = ImageDraw.Draw(sheet)
font = ImageFont.truetype('C:/Windows/Fonts/meiryo.ttc', 18)
for col, (im, title) in enumerate(zip(images, ('従来版', '単一PSOの事前生成あり'))):
    x = 8 + 552 * col
    draw.text((x, 3), title, fill='black', font=font)
    thumb = im.resize((536, 302), Image.Resampling.LANCZOS)
    sheet.paste(thumb, (x, 35))
    for n, box in enumerate(boxes.values()):
        draw.rectangle((x+box[0]*536/1920, 35+box[1]*302/1080,
                        x+box[2]*536/1920, 35+box[3]*302/1080), outline='#f3bf46', width=1)
        crop = im.crop(box)
        crop.thumbnail((174, 126), Image.Resampling.LANCZOS)
        sheet.paste(crop, (x+n*180, 344))
sheet.save(out/'ContactShadows.jpg', quality=91)
print(result['block_8px_MAE_RGB255'])
