import csv
import json
import sys
from pathlib import Path

here = Path(__file__).resolve().parent
runs = here.parent / 'ExitFirst_20261117'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def read_pairs(path):
    return dict(line.split('=', 1) for line in path.read_text(encoding='utf-8-sig').splitlines() if '=' in line)


def collect(run):
    d = runs / run
    first = read(d / 'first_location.json')
    warm = read(d / 'lap2_location.json') if (d / 'lap2_location.json').is_file() else None
    route = read_pairs(d / 'route/result.txt')
    assert route['success'] == '1' and route['reason'] == 'landing'
    isolation = read(d / 'route/isolation.json')
    assert isolation['desktop'] != isolation['input_desktop_start']
    manifest = read(d / 'launch_native.json')
    assert not manifest['profile_files_before_launch']
    startup = read_pairs(d / 'route/startup_result.txt')
    assert startup['input_restored'] == '1' and startup['pawn_start'] == startup['pawn_released']
    assert startup['room_view_start'] == startup['room_view_return']
    assert startup['room_fov_start'] == startup['room_fov_return']
    freq = read(d / 'telemetry.json')['start']['frequency']
    with (d / 'condition_summary.csv').open(encoding='utf-8-sig', newline='') as f:
        cond = {r['condition']: r for r in csv.DictReader(f)}
    peak = first['top_full'][0]
    base = {'run': run, 'exit_max_ms': first['regions']['classroom_exit']['maximum'],
            'gallery_max_ms': first['regions']['gallery']['maximum'], 'route_max_ms': peak['present_ms'],
            'peak_region': peak['region'], 'peak_x': peak['x'], 'peak_y': peak['y'],
            'route_p99_ms': cond['First']['present_p99_ms'], 'route_fps': cond['First']['present_fps'],
            'over_16_67': cond['First']['present_over16p67'], 'frames': cond['First']['present_n'],
            'prep_s': round((int(startup['open_qpc']) - int(startup['start_qpc']))/freq, 3),
            'warm_exit_max_ms': warm['regions']['classroom_exit']['maximum'] if warm else '',
            'warm_route_max_ms': warm['top_full'][0]['present_ms'] if warm else ''}
    return base


if __name__ == '__main__':
    data = [collect(name) for name in sys.argv[1:]]
    with (here / 'route_runs.csv').open('w', encoding='utf-8-sig', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=data[0].keys())
        writer.writeheader()
        writer.writerows(data)
    for row in data:
        print(row['run'], row['exit_max_ms'], row['route_max_ms'], row['prep_s'])
