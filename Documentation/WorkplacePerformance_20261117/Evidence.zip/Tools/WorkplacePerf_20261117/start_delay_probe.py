import argparse
import ctypes as c
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time

import os
sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'Exhibit42_20261116'))
from exhibit_telemetry import ROOT, start, stop, clock_snapshot


def launch(exe,folder,laps):
    folder.mkdir(exist_ok=True)
    scratch=Path(tempfile.mkdtemp(prefix="KD42Walk_20261116_"))
    profile=scratch/"profile"
    route=scratch/"route"
    profile.mkdir()
    route.mkdir()
    if not str(scratch).isascii():raise ValueError("Instrumentation path must be ASCII")
    args=[sys.executable,str(ROOT/"private_launch.py"),str(exe),str(route),
          "-windowed","-ResX=1920","-ResY=1080","-ForceRes","-D3D12","-NoVSync","-NoSplash","-unattended",
          "-WinX=0","-WinY=0","-UserDir="+str(profile),"-KDExhibitRoute","-KDExhibitRouteDir="+str(route),
          "-KDExhibitLaps="+str(laps),"-KDExhibitRouteWaitForGo","-KDExhibitRouteScreenshot"]
    manifest={"profile":str(profile),"route":str(route),"profile_files_before_launch":list(profile.iterdir()),
              "exe":str(exe),"args":args[2:],"os_and_vendor_caches":"preserved",
              "focus_and_input":"private non-input desktop; no global input, desktop switch or capture",
              "launcher_begin":clock_snapshot()}
    def save():
        (folder/"launch_native.json").write_text(json.dumps(manifest,indent=2),encoding="utf8")
    save()
    start(folder)
    p=None
    try:
        with (folder/"private.stdout").open("wb") as o,(folder/"private.stderr").open("wb") as e:
            p=subprocess.Popen(args,stdout=o,stderr=e,creationflags=subprocess.CREATE_NO_WINDOW)
        manifest["private_launcher_pid"]=p.pid
        save()
        target=time.monotonic()+175
        while not (route/"ready.txt").exists():
            if p.poll() is not None:raise RuntimeError("Game exited before route ready")
            if time.monotonic()>target:raise TimeoutError("Game did not reach route ready")
            time.sleep(.08)
        isolated=json.loads((route/"isolation.json").read_text("utf8"))
        if isolated["desktop"]==isolated["input_desktop_start"]:raise RuntimeError("Private desktop not isolated")
        manifest["ready"]=clock_snapshot()
        manifest["game_pid"]=isolated["pid"]
        if not (folder/"pm.stdout").exists():raise RuntimeError("Missing PresentMon trace")
        delay=float(os.environ["KD_PREWALK_HOLD_SECONDS"])
        manifest["requested_hold_seconds"]=delay
        time.sleep(delay)
        (route/"go.flag").write_text("go\n",encoding="ascii")
        manifest["go"]=clock_snapshot()
        save()
        print("Route started",isolated["pid"],str(route),flush=True)
        result=p.wait(timeout=450)
        manifest["returncode"]=result
        if result:raise RuntimeError(f"Game exited with {result}")
    finally:
        manifest["launcher_end"]=clock_snapshot()
        manifest["profile_files_after"]=[str(v.relative_to(profile)) for v in profile.rglob("*") if v.is_file()]
        save()
        stop(folder)
        shutil.copytree(route,folder/"route",dirs_exist_ok=True)
    print("Route ended",folder,flush=True)


if __name__=="__main__":
    cli=argparse.ArgumentParser()
    cli.add_argument("executable",type=Path)
    cli.add_argument("output")
    cli.add_argument("--laps",type=int,default=11)
    u=cli.parse_args()
    exe=u.executable.resolve(strict=True)
    if exe.name.lower()!="myproject-win64-shipping.exe":raise ValueError("Expected the packaged game executable")
    launch(exe,ROOT/u.output,u.laps)
