import collections
import re

def prop(obj,key,default=None):
    try: return obj.get_editor_property(key)
    except Exception: return default

def xyz(v): return [round(v.x,2),round(v.y,2),round(v.z,2)]

actors=unreal.GameplayStatics.get_all_actors_of_class(world,unreal.Actor)
registry={}; objects={}; changes=[]
for a in actors:
    label_a=a.get_actor_label() or a.get_name()
    for typ,klass in [('light',unreal.LightComponent),('caster',unreal.PrimitiveComponent)]:
        for c in a.get_components_by_class(klass):
            mesh=prop(c,'static_mesh') or prop(c,'skeletal_mesh_asset')
            if typ=='caster' and not mesh: continue
            key=typ+'|'+label_a+'|'+c.get_name()
            if key in registry:key+='|'+a.get_name()
            row={'type':typ,'label':label_a,'actor':a.get_name(),'component':c.get_name(),'class':c.get_class().get_name(),'pos':xyz(c.get_world_location()),'cast':bool(prop(c,'cast_shadows' if typ=='light' else 'cast_shadow',False)),'mobility':str(prop(c,'mobility')),'visible':bool(prop(c,'visible',True))}
            if typ=='light':row.update(radius=prop(c,'attenuation_radius'),intensity=prop(c,'intensity'),color=str(prop(c,'light_color')))
            if mesh:
                try: center,ext,_=unreal.SystemLibrary.get_component_bounds(c);row['bounds']=[xyz(center),xyz(ext)]
                except Exception: pass
                row.update(mesh=mesh.get_path_name(),nanite=bool(prop(prop(mesh,'nanite_settings'),'enabled',False)),hiddenInGame=bool(prop(c,'hidden_in_game')),cast_hidden_shadow=bool(prop(c,'cast_hidden_shadow')))
            registry[key]=row; objects[key]=c
if session!='light1':
    for key,row in registry.items():
        if row['type']=='caster':
            mesh=prop(objects[key],'static_mesh'); row['nanite_triangle_count']=mesh.get_num_nanite_triangles() if mesh and hasattr(mesh,'get_num_nanite_triangles') else None
            row.pop('nanite',None)
((root/'runtime_inventory.json') if session=='light1' else (root/('runtime_inventory_'+session+'.json'))).write_text(json.dumps(registry,ensure_ascii=False,indent=1),encoding='utf-8')
previous_swaps=[]
channel_restore=[]
mega_restore=[]
def restrict_mega(job):
    def set_flag(c,val):
        c.set_editor_property('allow_mega_lights',val)
        if prop(c,'visible',False):c.set_visibility(False,False);c.set_visibility(True,False)
        if prop(c,'allow_mega_lights')!=val:raise RuntimeError('MegaLights flag mismatch')
    for c,value in reversed(mega_restore):set_flag(c,value)
    mega_restore.clear()
    if 'mega_only' not in job:return
    kept=[];disabled=[]
    for k,r in registry.items():
        if r['type']!='light':continue
        c=objects[k];old=prop(c,'allow_mega_lights')
        if old is None:raise ValueError('Missing allow_mega_lights')
        if re.search(job['mega_only'],r['label']):kept.append(k);continue
        if old:set_flag(c,False);mega_restore.append((c,old));disabled.append(k)
    event('mega_filter',label=job['label'],kept=kept,disabled=disabled)
def channel_bits(c):
    v=prop(c,'lighting_channels')
    return tuple(bool(getattr(v,'channel'+str(n))) for n in range(3))
def channels(job):
    for c,old in reversed(channel_restore):
        c.set_lighting_channels(*old);assert channel_bits(c)==old
    channel_restore.clear()
    if not job.get('channels'):return
    changed=[];skipped=[]
    def lower(r):return r['label']=='F02_Plaza' or bool(re.match(r'^F02_Copy_(Chairs|Desks|Laptops|Mice|ClassroomFixtures)$',r['label']))
    occupied=[(k,channel_bits(objects[k])) for k,r in registry.items() if (r['type']=='light' and not r['label'].startswith('F03_GameLab_')) or (r['type']=='caster' and (lower(r) or not channel_bits(objects[k])[0]))]
    bits=[i for i in (2,1) if not any(v[i] for k,v in occupied)]
    if not bits:
        event('channels_unavailable',label=job['label'],occupied=occupied);return False
    free=bits[0]
    for k,r in registry.items():
        c=objects[k]
        if r['type']=='light' and not r['label'].startswith('F03_GameLab_'):continue
        if r['type']=='caster' and lower(r):
            skipped.append(k);continue
        old=channel_bits(c)
        if not old[0]:continue
        new=list(old);new[free]=True
        if r['type']=='light':new[0]=False
        new=tuple(new);c.set_lighting_channels(*new);assert channel_bits(c)==new
        channel_restore.append((c,old));changed.append(k)
    event('channels',label=job['label'],channel=free,changed=changed,lower_excluded=skipped)
gate_active=False
gate_trace=[]
gated=[k for k,r in registry.items() if r['type']=='caster' and re.match(r'^F02_Copy_(Chairs|Desks|Laptops|Mice|ClassroomFixtures)$',r['label']) and r['cast']]
def inner_gate(x,z,enabled):
    global gate_active
    wanted=bool(enabled and z>35 and (x>12 if gate_active else x>48))
    if wanted==gate_active:return
    for key in gated:
        if setvalue(key,'shadow',not wanted)!=(not wanted):raise RuntimeError(key)
    gate_active=wanted;gate_trace.append([round(clock(),5),wanted,x,z])
def apply_meshes(job):
    for component,original in reversed(previous_swaps):swap_trial_mesh(component,original)
    previous_swaps.clear()
    if not job.get('swap'):return
    applied=[]
    for key,row in registry.items():
        if row['type']!='caster' or row['label'] not in job['swap']:continue
        c=objects[key]; old=prop(c,'static_mesh'); asset=job['swap'][row['label']];replacement=variants[asset]
        before=old.get_num_nanite_triangles();after=replacement.get_num_nanite_triangles();assert after>0 and before==0
        swap_trial_mesh(c,replacement);previous_swaps.append((c,old));applied.append([row['label'],old.get_name(),replacement.get_name(),before,after,str(prop(c,'mobility'))])
    assert len(applied)==len(job['swap']),applied
    event('mesh_swap',label=job['label'],applied=applied)

def setvalue(key,action,value):
    c=objects[key];row=registry[key]
    if action=='shadow':
        if row['type']=='light':c.set_cast_shadows(bool(value));return bool(prop(c,'cast_shadows'))
        c.set_cast_shadow(bool(value));return bool(prop(c,'cast_shadow'))
    if action=='radius':c.set_attenuation_radius(float(value));return float(prop(c,'attenuation_radius'))
    if action=='visible':c.set_visibility(bool(value),False);return bool(prop(c,'visible'))
    raise ValueError(action)

def intervene(job):
    inner_gate(0,0,False);gate_trace.clear()
    restrict_mega(job)
    channels(job)
    apply_meshes(job)
    for key,action,old in reversed(changes):
        if setvalue(key,action,old)!=old:raise RuntimeError('restore failed '+key)
    changes.clear()
    for rule in job.get('rules',[]):
        n=0
        for key,row in registry.items():
            if row['type']!=rule['type']:continue
            ref='|'.join([row['label'],row['component'],row.get('mesh','')]);pos=row['pos']
            if 'match' in rule and not re.search(rule['match'],ref,re.I):continue
            if 'exclude' in rule and re.search(rule['exclude'],ref,re.I):continue
            if 'keys' in rule and key not in rule['keys']:continue
            if 'original_cast' in rule and row['cast']!=rule['original_cast']:continue
            if 'nanite' in rule and row.get('nanite')!=rule['nanite']:continue
            if 'radius_min' in rule and (row.get('radius') or 0)<rule['radius_min']:continue
            if 'box' in rule and not all(lo<=num<=hi for lo,num,hi in zip(rule['box'][:3],pos,rule['box'][3:])):continue
            action=rule['action']; old=row[{'shadow':'cast','radius':'radius','visible':'visible'}[action]];v=rule['value']
            if old==v:continue
            if setvalue(key,action,v)!=v:raise RuntimeError('change failed '+key)
            changes.append((key,action,old));n+=1
        if n==0:raise RuntimeError('no changes matched '+str(rule))
    event('intervention',label=job['label'],changes=changes,rules=job.get('rules',[]))

views={'aisle':(402,-73,98.15,-90,0),'desk':(402,-580,98.15,-142,-6),'gallery':(-117,-465,98.15,3,0),'lobby':(-852,108,98.15,163,0),'plaza2':(-875,108,-216.85,149,0),'gallery2':(-117,-465,-216.85,-91,0)}
def take_views(dt):
    global photo_index,photo_step,next_poll,phase
    v=job['views'][photo_index]; spec=views[v]
    if photo_step==0:
        movement.stop_movement_immediately();pawn.set_actor_location(unreal.Vector(*spec[:3]),False,True);pc.set_control_rotation(unreal.Rotator(pitch=spec[4],yaw=spec[3],roll=0));next_poll=clock()+1.6;photo_step=1
    else:
        rot=camera.get_camera_rotation();event('photo',label=label,view=v,xyz=position(),camera=xyz(camera.get_camera_location()),angles=[rot.pitch,rot.yaw,rot.roll])
        cmd('Shot -nosuffix filename="'+(root/('shot_'+label+'_'+v+'.png')).as_posix()+'"');photo_index+=1;photo_step=0;next_poll=clock()+.4
        if photo_index==len(job['views']):phase='photo_done'

profile_seen=set()
def profile_move(leg,x,y,z):
    if not job.get('profile'):return
    name=next((name for name,passed in [('early',leg==0 and y<-270),('mid',leg==0 and y<-665),('exit',leg==1 and x<155),('gallery',leg==2 and y>-580)] if passed and name not in profile_seen),None)
    if name:
        profile_seen.add(name);unreal.log('KD54_PROFILE '+name+' '+str(job['profile']));event('profile_trigger',label=label,view=name,index=job['profile'],xyz=[x,y,z]);cmd('profilegpu')
