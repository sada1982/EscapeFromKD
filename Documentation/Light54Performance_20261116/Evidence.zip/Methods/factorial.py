import argparse
import csv
import itertools
import json

from aggregate_light import root, project, np, read_capture, labeled_masks
from match_positions import waypoints, unit, length, offset, baseline_job

metrics={'gpu_ms':'GPUTime','shadow_instances_non_nanite':'VSM/NON_NANITE_INSTANCES_DRAWN','shadow_ms':'GPU/ShadowDepths','lights_ms':'GPU/Lights'}

def route_profile(label):
    d=read_capture(project/'Saved/Profiling/CSV'/f'Light54_{label}.csv');x,y=d['View/PosX'],d['View/PosY'];xy=np.stack((x,y),axis=1)
    rel=xy[:,None,:]-waypoints[:-1][None,:,:];proj=np.clip((rel*unit[None,:,:]).sum(axis=2),0,length)
    leg=np.argmin(np.sum((rel-proj[:,:,None]*unit[None,:,:])**2,axis=2),axis=1); along=offset[leg]+proj[np.arange(len(x)),leg];bins=np.floor(along/80).astype(int)
    out={}
    for zone,mask in labeled_masks(d).items():
        out[zone]={}
        for name,key in metrics.items():
            if key not in d:continue
            vals=d[key];good=mask&np.isfinite(vals);out[zone][name]={int(i):float(np.mean(vals[good&(bins==i)])) for i in np.unique(bins[good]) if np.count_nonzero(good&(bins==i))>=2}
    return out

def analyze(treatments):
    jobs={j['label']:j for p in sorted(root.glob('*_jobs.json')) for j in json.loads(p.read_text(encoding='utf-8-sig')) if 'label' in j}
    ev=[json.loads(s) for s in (root/'events.jsonl').read_text(encoding='utf-8').splitlines() if s]
    starts={e['label']:e for e in ev if e['event']=='capture_start'}
    ends={e['label'] for e in ev if e['event']=='capture_end' and e.get('success')}
    controls=[lab for lab in ends if baseline_job(jobs[lab])]
    by_treat={}
    for lab in treatments:
        e=starts[lab]; same=sorted([k for k in controls if e['pid']==starts[k]['pid']],key=lambda k:starts[k]['time'])
        by_treat[lab]=[k for k in same if starts[k]['time']<e['time']][-1:]+[k for k in same if starts[k]['time']>e['time']][:1]
        if not by_treat[lab]: raise ValueError('No same-process control: '+lab)
    chosen=set(treatments)|{k for v in by_treat.values() for k in v};profiles={lab:route_profile(lab) for lab in chosen};rows=[]
    for zone in ['all','classroom','gallery','lobby','downstairs']:
        for metric,key in metrics.items():
            values={k:z[zone][metric] for k,z in profiles.items()};bins=sorted(set.intersection(*(set(v) for v in values.values())))
            if not bins:continue
            means={k:np.array([v[b] for b in bins]) for k,v in values.items()}
            savings={k:np.mean([means[control] for control in by_treat[k]],axis=0)-means[k] for k in treatments}
            l,c,j=treatments; i=savings[l]+savings[c]-savings[j]
            # Sensitivity to the nearest pre/post baseline, not a confidence interval.
            drift=[np.mean((means[a]-means[l])+(means[b]-means[c])-(means[k]-means[j])) for a,b,k in itertools.product(by_treat[l],by_treat[c],by_treat[j])]
            row={'zone':zone,'metric':metric,'matched_80cm_bins':len(bins),'controls_light':'|'.join(by_treat[l]),'controls_caster':'|'.join(by_treat[c]),'controls_both':'|'.join(by_treat[j]),
                 'light_saving':float(np.mean(savings[l])),'caster_saving':float(np.mean(savings[c])),'both_saving':float(np.mean(savings[j])),
                 'interaction':float(np.mean(i)),'interaction_median_bin':float(np.median(i)),'positive_bins':int((i>0).sum()),
                 'baseline_sensitivity_low':float(min(drift)),'baseline_sensitivity_high':float(max(drift))}
            rows.append({k:round(v,4) if isinstance(v,float) else v for k,v in row.items()})
    with (root/'Factorial.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    local={r['metric']:r for r in rows if r['zone']=='classroom'}; gpu=local['gpu_ms'];sh=local['shadow_ms'];num=local['shadow_instances_non_nanite']
    note=(f"教室内の経路を80 cmごとに分け、4条件すべてで2フレーム以上入った{gpu['matched_80cm_bins']}区間を等しい重みで比較。各処置は同じ実行プロセスで直前・直後に測った基準2走の平均と照合した。教室12灯の影を止めるとGPU {gpu['light_saving']:.2f} ms、2F広場の投影を止めると{gpu['caster_saving']:.2f} ms、両方で{gpu['both_saving']:.2f} ms短縮。重なりはGPU {gpu['interaction']:.2f} ms、うち指標ShadowDepthsの交互作用は{sh['interaction']:.2f} ms。GPU全体と各描画パスは別の時間系列なので加算しない。\n"
          f"非Naniteの影描画は重複する延べ{num['interaction']:.1f}件/フレームを確認（{num['positive_bins']}/{num['matched_80cm_bins']}区間で交互作用が正）。基準を直前・直後で選び分けると、GPUの交互作用は{gpu['baseline_sensitivity_low']:.2f}～{gpu['baseline_sensitivity_high']:.2f} ms、件数は{num['baseline_sensitivity_low']:.0f}～{num['baseline_sensitivity_high']:.0f}件。これは基準走の選択に対する感度で、統計的な信頼区間ではない。延べ件数は複数の影ビュー・ライトで再計上され、固有オブジェクト数を表さない。元の全区間フレーム平均と本段落の位置合わせ平均では重みが異なる。")
    (root/'interact_note.txt').write_text(note+'\n',encoding='utf-8')
    return rows

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('light');ap.add_argument('caster');ap.add_argument('both');a=ap.parse_args()
    for r in analyze([a.light,a.caster,a.both]):
        if r['zone']=='classroom':print(r)
