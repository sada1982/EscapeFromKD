import argparse
import csv
import json
import math
import sys
from pathlib import Path

root = Path(__file__).resolve().parent
project = root.parents[2]
previous = root.parent / 'Route54_20261116'
sys.path.insert(0, str(previous))
from analyze_frames import BUDGET, read_capture, rounded
import numpy as np

metric_keys = {
    'gpu_ms': 'GPUTime', 'shadow_ms': 'GPU/ShadowDepths', 'lights_ms': 'GPU/Lights',
    'megalights_ms':'GPU/MegaLights', 'megalights_light_power_delta_ms':'GPU/MegaLightsLightPowerDelta',
    'tsr_ms': 'GPU/TemporalSuperResolution', 'deferred_ms': 'GPU/RenderDeferredLighting',
    'gi_ms': 'GPU/LumenScreenProbeGather', 'reflections_ms': 'GPU/LumenReflections',
    'game_ms': 'GameThreadTime', 'render_ms': 'RenderThreadTime', 'rhi_ms': 'RHIThreadTime',
    'draw_calls': 'RHI/DrawCalls', 'primitives': 'RHI/PrimitivesDrawn',
    'lights_all': 'LightCount/All', 'lights_batched': 'LightCount/Batched',
    'lights_unbatched': 'LightCount/Unbatched', 'updated_shadows': 'LightCount/UpdatedShadowMaps',
    'shadow_instances_non_nanite': 'VSM/NON_NANITE_INSTANCES_DRAWN',
    'new_shadow_pages': 'VSM/ALLOCATED_NEW', 'shadow_pages_cleared': 'VSM/NUM_PAGES_TO_CLEAR',
    'dynamic_invalidations': 'VSM/DYNAMIC_INVALIDATED_PAGES', 'static_invalidations': 'VSM/STATIC_INVALIDATED_PAGES',
    'free_vsm_pages': 'VSM/FreePages', 'vram_delta_mib': 'GPUMem/DeltaMiB',
}

def labeled_masks(d):
    x=d['View/PosX']; all_valid=np.isfinite(x)
    masks={'all':all_valid,'classroom':x>=0,'gallery':(x<0)&(x>-860),'lobby':(x<=-860)&(x>-1650),'downstairs':x<=-1650}
    if not all_valid.all() or sum(int(v.sum()) for k,v in masks.items() if k!='all')!=len(x):
        raise ValueError('Missing or multiply assigned view position')
    return masks

def sample(d, mask):
    f=d['FrameTime'][mask]
    h=d['GPUTime'][mask] if 'GPUTime' in d else np.full_like(f,np.nan)
    slow=(f>BUDGET)
    n=len(f)
    row={'frames':n,'duration_s':rounded(f.sum()/1000),'fps':rounded(1000/f.mean()),'mean_ms':rounded(f.mean()),
         'low1':rounded(1000/np.sort(f)[-math.ceil(.01*n):].mean()),'p95_ms':rounded(np.percentile(f,95)),
         'worst_ms':rounded(f.max()),'over':int(slow.sum()),'over_pct':rounded(slow.mean()*100),
         'valid_gpu_frames':int(np.isfinite(h).sum()),'over_and_gpu_over':int((slow & (h>BUDGET)).sum())}
    for key,src in metric_keys.items():
        vals=d[src][mask] if src in d else np.array([])
        vals=vals[np.isfinite(vals)]
        row[key]=rounded(vals.mean()) if len(vals) else None
    for key in ('PSO/PSOMisses','PSO/PSOComputeMisses','VSM/OVERFLOW_FLAGS'):
        row[key+'_positive_frames']=int((d[key][mask]>0).sum()) if key in d else None
    return row

def analyze_all(allow_active=False):
    captures={}
    for path in sorted((project/'Saved/Profiling/CSV').glob('Light54_*.csv')):
        try:
            d=read_capture(path)
        except (PermissionError,ValueError,IndexError):
            if allow_active: continue
            raise
        captures[path.stem.removeprefix('Light54_')]={name:sample(d,mask) for name,mask in labeled_masks(d).items() if mask.any()}
    return captures

def save(captures):
    if not captures: return
    dest=root/'metrics.json'; temp=root/'metrics.tmp';temp.write_text(json.dumps(captures,indent=2,allow_nan=False),encoding='utf-8');temp.replace(dest)
    rows=[dict(label=label,region=name,**s) for label,zones in captures.items() for name,s in zones.items()]
    dest=root/'Metrics.csv'; temp=root/'Metrics.tmp'
    with temp.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader();w.writerows(rows)
    temp.replace(dest)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--active',action='store_true');args=ap.parse_args()
    results=analyze_all(args.active); save(results)
    for label,zones in results.items():
        c=zones['classroom'];a=zones['all'];print(f"{label:26} all {a['fps']:6.2f}/{a['over']:3}/{a['frames']}  room {c['fps']:6.2f} {c['over']:3}/{c['frames']} GPU {c['gpu_ms']} shadow {c['shadow_ms']} lights {c['lights_ms']} nonNanite {c['shadow_instances_non_nanite']}")
