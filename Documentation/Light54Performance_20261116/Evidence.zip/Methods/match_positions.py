import csv
import json
import math
from pathlib import Path

from aggregate_light import root, project, np, read_capture, labeled_masks

waypoints=np.array([(402,-73),(402,-890),(-117,-890),(-117,109),(-876,109),(-876,308),(-1635,308),(-1635,189),(-2154,189)])
unit=np.diff(waypoints,axis=0);length=np.linalg.norm(unit,axis=1); unit=unit/length[:,None]
offset=np.concatenate(([0],np.cumsum(length)[:-1]))

def baseline_job(job):
    return not any(v for k,v in job.items() if k not in ('label','warm','views','shot'))

def bins_for_path(path):
    d=read_capture(path);mask=labeled_masks(d)['classroom']; xy=np.stack([d['View/PosX'][mask],d['View/PosY'][mask]],axis=-1)
    rel=xy[:,None,:]-waypoints[:-1][None,:,:];proj=np.clip((rel*unit[None,:,:]).sum(axis=2),0,length)
    d2=np.sum((rel-proj[:,:,None]*unit[None,:,:])**2,axis=2);leg=np.argmin(d2,axis=1)
    along=offset[leg]+proj[np.arange(len(xy)),leg]; bins=np.floor(along/80).astype(int); gpu=d['GPUTime'][mask]
    return {int(i):float(np.mean(gpu[(bins==i)&np.isfinite(gpu)])) for i in np.unique(bins) if np.sum((bins==i)&np.isfinite(gpu))>=2}

def run():
    events=[json.loads(line) for line in (root/'events.jsonl').read_text(encoding='utf-8').splitlines() if line]
    actions={e['label']:e for e in events if e['event']=='intervention'}
    starts={e['label']:e for e in events if e['event']=='capture_start'}
    finished={e['label'] for e in events if e['event']=='capture_end' and e.get('success')}
    profiles={}
    for label in sorted(finished):
        path=project/'Saved/Profiling/CSV'/f'Light54_{label}.csv'
        try:profiles[label]=bins_for_path(path)
        except (FileNotFoundError,PermissionError,ValueError):continue
    jobs={j['label']:j for p in sorted(root.glob('*_jobs.json')) for j in json.loads(p.read_text(encoding='utf-8-sig')) if 'label' in j}
    controls=[k for k in profiles if not actions[k]['rules'] and baseline_job(jobs[k])]
    rows=[]
    for label,measured in profiles.items():
        e=starts[label];same=sorted([k for k in controls if starts[k]['pid']==e['pid'] and k!=label],key=lambda k:starts[k]['time'])
        earlier=[k for k in same if starts[k]['time']<e['time']];later=[k for k in same if starts[k]['time']>e['time']]
        refs=earlier[-1:]+later[:1]
        if not refs:continue
        common=sorted(set.intersection(set(measured),*(set(profiles[k]) for k in refs)))
        deltas=np.array([np.mean([profiles[k][i] for k in refs])-measured[i] for i in common]);n=len(common)
        if not n:continue
        rows.append({'label':label,'same_process_controls':'+'.join(refs),'matched_80cm_bins':n,'mean_paired_gpu_ms_saved':round(float(np.mean(deltas)),4),
                     'median_paired_gpu_ms_saved':round(float(np.median(deltas)),4),'bins_positive':int(np.sum(deltas>0)),
                     'bin_ms_saved_p10':round(float(np.percentile(deltas,10)),4),'bin_ms_saved_p90':round(float(np.percentile(deltas,90)),4)})
    if rows:
        with (root/'MatchedRoomGPU.csv').open('w',encoding='utf-8-sig',newline='') as f:
            w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    return rows

if __name__=='__main__':
    for row in run():print(*row.values())
