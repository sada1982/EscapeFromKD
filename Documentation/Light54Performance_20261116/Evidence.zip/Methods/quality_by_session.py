import csv
import json
from pathlib import Path

from compare_light_views import root, boxes, views, get, delta, shot_stamps
from match_positions import baseline_job


def summarize():
    jobs={j['label']:j for p in sorted(root.glob('*_jobs.json')) for j in json.loads(p.read_text(encoding='utf-8-sig')) if 'label' in j}
    ev=[json.loads(s) for s in (root/'events.jsonl').read_text(encoding='utf-8').splitlines() if s]
    starts={s['label']:s for s in ev if s['event']=='capture_start'}; ends={s['label'] for s in ev if s['event']=='capture_end' and s.get('success')}
    photos={(s['label'],s['view']):s for s in ev if s['event']=='photo'}
    controls=sorted(lab for lab in ends if baseline_job(jobs[lab]))
    dest=root/'quality_matched.json'; old=json.loads(dest.read_text(encoding='utf-8')) if dest.exists() else {}; stamps=shot_stamps();rows=[]; pairs={}
    for lab in sorted(ends):
        t=starts[lab]; bases=sorted([c for c in controls if c!=lab and starts[c]['pid']==t['pid']],key=lambda c:starts[c]['time'])
        prev=[k for k in bases if starts[k]['time']<t['time']]; later=[k for k in bases if starts[k]['time']>t['time']]
        refs=prev[-1:]+later[:1]
        for v in views:
            p=f'shot_{lab}_{v}.png'
            if p not in stamps:continue
            a=None
            for ref in refs:
                q=f'shot_{ref}_{v}.png';key='|'.join([lab,ref,v]);rev='|'.join([ref,lab,v])
                if q not in stamps:continue
                sig=[stamps[p],stamps[q]];saved=old.get('pairs',{}).get(key)
                if saved and saved.get('stamps')==sig:
                    dat=saved['regions']
                else:
                    if a is None:a=get(lab,v)
                    b=get(ref,v);dat=delta(a,b)
                ca=photos.get((lab,v),{}).get('camera');cb=photos.get((ref,v),{}).get('camera')
                ra=photos.get((lab,v),{}).get('angles');rb=photos.get((ref,v),{}).get('angles')
                distance=(sum((x-y)**2 for x,y in zip(ca,cb))**.5) if ca and cb else None
                angle=max(abs((x-y+180)%360-180) for x,y in zip(ra,rb)) if ra and rb else None
                pairs[key]={'stamps':sig,'regions':dat,'camera_displacement_cm':distance,'max_abs_angle_change_deg':angle}
                for roi,fields in dat.items():
                    rows.append({'label':lab,'control':ref,'view':v,'roi':roi,'camera_displacement_cm':distance,'max_abs_angle_change_deg':angle,**fields})
    info={'metric':'8-bit RGB absolute difference. 16px cell channel averages are compared before absolute difference. Position and camera-angle checks where the runtime supplied photo events. Compare controls to controls in same run to gauge normal differences. Camera offsets must agree before claiming visual equivalence.','boxes':boxes,'pairs':pairs}
    temp=dest.with_suffix('.tmp');temp.write_text(json.dumps(info,indent=2,allow_nan=False),encoding='utf-8');temp.replace(dest)
    if rows:
        p=root/'VisualComparison.csv'
        with p.open('w',encoding='utf-8-sig',newline='') as f:
            w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    print('Verified region pairs',len(rows),'source pairs',len(pairs))

if __name__=='__main__':summarize()
