import argparse
import json
import re
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFont

root=Path(__file__).resolve().parent
views=('aisle','desk','gallery','lobby','gallery2','plaza2')
boxes={
    'upper_environment':(20,40,1900,680),
    'lower_left_environment':(20,680,745,1040),
    'center_desks':(590,475,1240,670),
}

def get(label,view):
    p=root/f'shot_{label}_{view}.png'
    if not p.is_file():return None
    with Image.open(p) as im:
        if im.size!=(1920,1080):raise ValueError((p,im.size))
        return np.asarray(im.convert('RGB'),dtype=np.float32)

def delta(a,b):
    result={}
    for key,(x1,y1,x2,y2) in boxes.items():
        a1=a[y1:y2,x1:x2]; b1=b[y1:y2,x1:x2]; diff=a1-b1
        # 16px tiles suppress fine temporal noise and still retain localized shadow changes.
        h,w,_=diff.shape; h-=h%16; w-=w%16
        tiles=diff[:h,:w].reshape(h//16,16,w//16,16,3).mean(axis=(1,3))
        tile_abs=np.abs(tiles).mean(axis=2)
        result[key]={'rgb_mae':round(float(np.abs(diff).mean()),3),'tile_mae':round(float(tile_abs.mean()),3),
                     'tile_p95':round(float(np.percentile(tile_abs,95)),3), 'tile_p99':round(float(np.percentile(tile_abs,99)),3),
                     'tile_above_8_pct':round(float((tile_abs>8).mean()*100),3),
                     'signed_luma_change':round(float((diff.mean(axis=(0,1))*[.2126,.7152,.0722]).sum()),3)}
    return result

def compare(labels,bases,cache=None):
    cache=cache or {}
    results={}
    prior_views=cache.get('views',{})
    old_stamps=cache.get('screenshot_stamp',{})
    stamps=shot_stamps()
    for v in views:
        controls={b:get(b,v) for b in bases};controls={b:a for b,a in controls.items() if a is not None}
        if not controls:continue
        results[v]={}
        for lab in labels:
            name=f'shot_{lab}_{v}.png'
            if name not in stamps: continue
            a=None;differences={}
            for b,base in controls.items():
                if b==lab:continue
                control_name=f'shot_{b}_{v}.png'
                cached=prior_views.get(v,{}).get(lab,{}).get(b)
                if cached and old_stamps.get(name)==stamps[name] and old_stamps.get(control_name)==stamps[control_name]:
                    differences[b]=cached
                else:
                    if a is None:a=get(lab,v)
                    differences[b]=delta(a,base)
            results[v][lab]=differences
    return results

def shot_stamps():
    return {p.name:[p.stat().st_size,p.stat().st_mtime_ns] for p in root.glob('shot_*.png')}

def draw_comparison(base,candidate,views_to_show,dest):
    tiles_w,tiles_h=458,257; gap=13; left=65; y0=82
    im=Image.new('RGB',(left+3*(tiles_w+gap),y0+len(views_to_show)*(tiles_h+gap)),(247,248,249));draw=ImageDraw.Draw(im)
    font=ImageFont.truetype('C:/Windows/Fonts/YuGothM.ttc',20);bold=ImageFont.truetype('C:/Windows/Fonts/YuGothB.ttc',22)
    title={'AP_Shadowed42Repeat':'影あり42灯にMegaLightsを適用','S_MegaLightsWarm':'全灯にMegaLightsを適用','AC_PlazaNaniteRepeat':'2F広場にNaniteを適用','C_RoomShadow12':'実習室12灯の影を停止'}.get(candidate,candidate)
    draw.text((left,10),'同一視点の比較　'+title,font=bold,fill=(25,40,52))
    for j,txt in enumerate(('現行の照明　'+base,'候補の描画','RGB絶対差 ×4（変化の位置）')):
        draw.text((left+j*(tiles_w+gap),49),txt,font=font,fill=(36,58,72))
    tags={'aisle':'教室','desk':'机列','gallery':'廊下','lobby':'ロビー','gallery2':'2F廊下','plaza2':'2F広場'}
    for i,v in enumerate(views_to_show):
        a=get(base,v);b=get(candidate,v)
        if a is None or b is None:raise ValueError(f'Missing comparison shot at {v}')
        y=y0+i*(tiles_h+gap);draw.text((4,y+tiles_h//2-14),tags[v],fill=(36,58,72),font=font)
        for j,t in enumerate([a,b,np.clip(np.abs(a-b)*4,0,255)]):
            image=Image.fromarray(t.astype('uint8')).resize((tiles_w,tiles_h),Image.Resampling.LANCZOS)
            im.paste(image,(left+j*(tiles_w+gap),y))
    im.save(dest)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--baseline',nargs='+',default=['A_Start','B_Warm']);ap.add_argument('--panel',nargs=2);ap.add_argument('--output',default='QualityComparison.png');ap.add_argument('--json-out',default='quality.json');ap.add_argument('--label-regex',default='.*');args=ap.parse_args()
    labels=sorted({p.stem[5:].rsplit('_',1)[0] for p in root.glob('shot_*.png') if p.stem.rsplit('_',1)[-1] in views})
    labels=[k for k in labels if re.search(args.label_regex,k)]
    if args.panel:
        a,b=args.panel; valid=[v for v in views if (root/f'shot_{a}_{v}.png').exists() and (root/f'shot_{b}_{v}.png').exists()];draw_comparison(a,b,valid,root/args.output)
    p=root/args.json_out;cache=json.loads(p.read_text(encoding='utf-8')) if p.exists() else {}
    result=compare(labels,args.baseline,cache)
    descriptor={'boxes_xyxy':boxes,'comparison':'mean absolute difference per 8-bit RGB channel. Tile statistics average each channel within matched 16px cells before evaluating differences. Deltas = candidate minus baseline. Missing view is not evidence of visual equivalence.','views':result,'screenshot_stamp':shot_stamps()}
    temp=p.with_suffix('.tmp');temp.write_text(json.dumps(descriptor,indent=2,allow_nan=False),encoding='utf-8');temp.replace(p)
    for v,ls in result.items():
        print(v,'upper_environment mean/99th tile difference')
        for lab,comparisons in ls.items():
            print(lab,' '.join(f"{b}:{r['upper_environment']['rgb_mae']:.2f}/{r['upper_environment']['tile_p99']:.2f}" for b,r in comparisons.items()))
