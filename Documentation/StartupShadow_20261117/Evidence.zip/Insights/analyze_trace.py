import os, csv, collections, json, statistics as st, bisect
from pathlib import Path
p = Path(os.environ['LOCALAPPDATA']) / 'KDTrace_Base_20261117'
dest = Path(__file__).resolve().parent
def rows(name):
    with (p / (name + '.csv')).open(encoding='utf-8-sig', newline='') as f:
        yield from csv.DictReader(f)
route = list(rows('events'))
anchors = [r for r in rows('pso_events') if r['TimerName']=='KD_DiagnosticLapStart']
anchor = float(anchors[0]['StartTime'])
q0 = int(next(r['qpc'] for r in route if r['event']=='lap_start'))
def t(q):
    return anchor + (int(q)-q0)/10000000
spans = {}
for r in route:
    if r['event']=='lap_start': start=t(r['qpc'])
    if r['event']=='waypoint':
        end=t(r['qpc'])
        spans[int(r['lap']), int(r['leg'])] = (start,end)
        start=end
names={'Frame','ShadowDepths','RenderVirtualShadowMaps','MegaLights','LumenScreenProbeGather','LumenReflections','PostProcessing','BasePass','Nanite::VisBuffer'}
gpu = collections.defaultdict(list)
for r in rows('gpu'):
    if r['TimerName'] in names: gpu[r['ThreadName'],r['TimerName']].append((float(r['StartTime']),float(r['EndTime'])))
print([(k,len(v)) for k,v in gpu.items() if k[1]=='Frame'])
def dur_in(intervals,lo,hi):
    sections=sorted((max(s,lo),min(e,hi)) for s,e in intervals if s<hi and e>lo)
    total=0
    last=lo
    for s,e in sections:
        total+=max(0,e-max(last,s))
        last=max(e,last)
    return total
out=[]
for (lap,leg),(s,e) in spans.items():
    if lap!=2: continue
    for key,times in gpu.items():
        thread,label=key
        frames=[(a,b) for a,b in gpu.get((thread,'Frame'),[]) if a>=s and b<=e]
        if frames:
            lo,hi=frames[0][0],frames[-1][1]
            # GPU queues are separate. Report only complete frames and union any nested same-label intervals.
            out.append(dict(lap=lap,leg=leg,queue=thread,pass_name=label,frames=len(frames),ms_per_frame=round(dur_in(times,lo,hi)*1000/len(frames),3)))
with (dest/'TraceGpuWarm.csv').open('w',encoding='utf-8',newline='') as f:
    w=csv.DictWriter(f,fieldnames=out[0].keys());w.writeheader();w.writerows(out)
for leg in (0,1,7): print(leg,[(r['queue'],r['pass_name'],r['ms_per_frame']) for r in out if r['leg']==leg and r['pass_name'] in ('Frame','ShadowDepths','MegaLights','LumenScreenProbeGather')])
pso=list(rows('pso_events'))
stalls=sorted((float(r['app_dt']),t(r['qpc']),int(r['lap']),int(r['leg'])) for r in rows('frames') if int(r['lap'])==1 and int(r['leg'])==0)[-6:][::-1]
evidence=[]
for dt,hi,lap,leg in stalls:
    lo=hi-dt
    hit=[r for r in pso if float(r['StartTime'])<hi and float(r['EndTime'])>lo]
    labels=['PSOPrecache: Too Late','PSOPrecache: Missed','FD3D12DynamicRHI::RHICreateComputePipelineState','FD3D12DynamicRHI::RHICreateGraphicsPipelineState','GameThreadWaitForTask','WaitUntilTasksComplete','WaitOnPSOPrecacheTasks']
    vals={}
    for label in labels:
        selection=[r for r in hit if r['TimerName']==label and (label!='GameThreadWaitForTask' or r['ThreadName']=='GameThread')]
        if not selection: continue
        active=dur_in([(float(r['StartTime']),float(r['EndTime'])) for r in selection],lo,hi)
        vals[label]={'overlapping_events':len(selection),'wall_active_ms':round(active*1000,2)}
    evidence.append(dict(start=round(lo,5),end=round(hi,5),app_ms=round(1000*dt,2),events=vals))
print(json.dumps(evidence[:2],ensure_ascii=False))
(dest/'TraceCpuStartup.json').write_text(json.dumps(evidence,indent=2),encoding='utf-8')

# Per-frame pass coverage for tails in the warm aisle and exit.
from bisect import bisect_left
from math import ceil
out=[]
for label in ('ShadowDepths','RenderVirtualShadowMaps','MegaLights','BasePass','PostProcessing','LumenReflections'):
    intervals=sorted(gpu['GPU0-Graphics0',label])
    starts=[a for a,b in intervals]
    for leg in (0,1,2,7):
        s,e=spans[2,leg]
        pairs=[]
        for lo,hi in gpu['GPU0-Graphics0','Frame']:
            if lo<s or hi>e: continue
            i=bisect_left(starts,lo);j=bisect_left(starts,hi)
            pairs.append(((hi-lo)*1000,dur_in(intervals[max(0,i-2):j],lo,hi)*1000))
        if not pairs:continue
        pairs.sort()
        def mean(seq):return round(st.mean(seq),3) if seq else None
        over=[x for f,x in pairs if f>1000/60]
        under=[x for f,x in pairs if f<=1000/60]
        out.append(dict(leg=leg,pass_name=label,frames=len(pairs),over=len(over),pass_ms_within=mean(under),pass_ms_over=mean(over),frame_p95_ms=round(pairs[ceil(.95*len(pairs))-1][0],3)))
with (dest/'TraceGpuSlowFrames.csv').open('w',encoding='utf-8',newline='') as f:
    w=csv.DictWriter(f,fieldnames=out[0].keys());w.writeheader();w.writerows(out)
