"""Align process-specific Direct3D12 pipeline creation and memory counters to the route clock."""
from bisect import bisect_left, bisect_right
from collections import defaultdict
import csv,json,sys
from pathlib import Path

p=Path(sys.argv[1])
def rows(f):return list(csv.DictReader((p/f).open(encoding='utf-8-sig',newline='')))
events=rows('route/events.csv')
freq=json.loads((p/'telemetry.json').read_text('utf8'))['start']['frequency']
def seconds(q):return q/freq
ready=int(next(i.split('=')[1] for i in (p/'route/ready.txt').read_text().splitlines() if i.startswith('qpc')))
begin=int(next(e['qpc'] for e in events if e['event']=='lap_start'));end=int(next(e['qpc'] for e in events if e['event']=='lap_end'))
pso=rows('pso.csv');stack=defaultdict(list);spans=[]
for row in pso:
 id,t,q=int(row['event_id']),int(row['tid']),int(row['qpc'])
 if id==155:stack[t].append(q)
 if id==156 and stack[t]:
  a=stack[t].pop();spans.append((a,q,t))
spans.sort()
mem=[r for r in rows('process.csv') if all(int(r[k])==0 for k in ['mem_ret','local_status','nonlocal_status','eviction_status'])]
mqs=[int(r['qpc']) for r in mem]
pm=[r for r in rows('presents_native.csv') if r['Runtime']=='DXGI' and int(r['SwapChainAddress'],16)]
ps=[]
for r in pm:
 ms=float(r['msBetweenPresents']);b=int(r['QPCTime']);a=round(b-ms*freq/1000)
 if ms>0 and a>=begin and b<=end:ps.append((a,b,ms))
ps.sort(key=lambda s:-s[2])
def during(a,b):
 matched=[(s,e,t) for s,e,t in spans if s<b and e>a]
 cuts=sorted((max(a,s),min(e,b)) for s,e,t in matched)
 elapsed=0;old=a
 for s,e in cuts:
  elapsed+=max(0,e-max(s,old));old=max(old,e)
 x=mem[max(0,bisect_right(mqs,a)-1)];y=mem[min(len(mem)-1,bisect_left(mqs,b))]
 incl=mem[max(0,bisect_right(mqs,a)-1):min(len(mem),bisect_left(mqs,b)+1)]
 def d(k):return int(y[k])-int(x[k])
 return {'start_relative_s':round(seconds(a-begin),5),'end_relative_s':round(seconds(b-begin),5),'duration_ms':round(1000*seconds(b-a),5),'pso_overlapping':len(matched),'pso_wall_covered_ms':round(1000*seconds(elapsed),3),'pso_longest_overlap_ms':round(max((1000*seconds(e-s) for s,e in cuts),default=0.),3),'pso_threads':len(set(t for _,_,t in matched)),'pso_max_full_ms':round(max((1000*seconds(e-s) for s,e,t in matched),default=0),3),'proc_io_read_MiB_bracket':round(d('read_bytes')/2**20,3),'proc_cpu_corems_bracket':round((d('user_100ns')+d('kernel_100ns'))/10000,3),'proc_evictions_MiB_bracket':round(d('evicted_process')/2**20,3),'local_budget_min_MiB_bracket':round(min(int(i['local_budget']) for i in incl)/2**20,2),'local_usage_max_MiB_bracket':round(max(int(i['local_usage']) for i in incl)/2**20,2),'local_over_budget_max_MiB_bracket':round(max(int(i['local_usage'])-int(i['local_budget']) for i in incl)/2**20,2)}
q={'psos_paired':len(spans),'psos_unclosed':sum(map(len,stack.values())),'ready_to_walk_s':seconds(begin-ready),'walk':during(begin,end),'largest_first_present_intervals':[during(a,b) for a,b,ms in ps[:8]]}
if begin>ready:q['ready_to_walk']=during(ready,begin)
(p/'diagnostic.json').write_text(json.dumps(q,indent=2),encoding='utf8')
print(json.dumps([q['psos_paired'],q['walk'],q['largest_first_present_intervals'][:3]],indent=1))
