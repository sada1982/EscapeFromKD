"""Summarize isolated packaged runs using aligned full Present intervals, stage positions and startup times."""
import argparse
from bisect import bisect_left
import csv,json,math
from pathlib import Path
from statistics import mean,median

THRESHOLD=1000/60
def rows(p):return list(csv.DictReader(p.open(encoding='utf-8-sig',newline='')))
def metrics(ds):
 a=sorted(ds)
 if not a:return {'n':0}
 return {'n':len(a),'fps':round(1000/mean(a),3),'p95':round(a[math.ceil(.95*len(a))-1],3),'p99':round(a[math.ceil(.99*len(a))-1],3),'max':round(a[-1],3),'over':sum(i>THRESHOLD for i in a),'excess_ms':round(sum(max(0,i-THRESHOLD) for i in a),3)}
def analyze(p,output=None):
 if output is None:output=p
 output.mkdir(parents=True,exist_ok=True)
 raw=rows(p/'route/frames.csv');ev=rows(p/'route/events.csv')
 iso=json.loads((p/'route/isolation.json').read_text(encoding='utf8'))
 meta=json.loads((p/'launch_native.json').read_text(encoding='utf8'))
 mon=json.loads((p/'telemetry.json').read_text(encoding='utf8'))
 freq=mon['start']['frequency']
 ready=int(next(i.split('=')[1] for i in (p/'route/ready.txt').read_text().splitlines() if i.startswith('qpc')))
 names=('classroom_aisle','classroom_exit','gallery','connector','lobby_turn','stair_approach','stair_turn','downstairs')
 starts={int(i['lap']):int(i['qpc']) for i in ev if i['event']=='lap_start'}
 ends={int(i['lap']):int(i['qpc']) for i in ev if i['event']=='lap_end'}
 assert set(starts)==set(ends)
 endpose=[i for i in ev if i['event']=='lap_end']
 assert all(float(i['z']) < -58 for i in endpose)
 points=[(402,-73),(402,-890),(-117,-890),(-117,109),(-876,109),(-876,308),(-1635,308),(-1635,189),(-2154,189)]
 t=[int(i['qpc']) for i in raw]
 pm=[(int(i['QPCTime']),float(i['msBetweenPresents'])) for i in rows(p/'presents_native.csv') if int(i['ProcessID'])==int(iso['pid']) and i['Runtime']=='DXGI' and int(i['SwapChainAddress'],16)!=0 and float(i['msBetweenPresents'])>0]
 out={};boxes={};rollup={};all_laps={}
 for lap,begin in starts.items():
  end=ends[lap]
  key='First' if lap==1 else 'Warm'
  intervals=[]
  for right,ms in pm:
   left=right-ms*freq/1000
   if left<begin or right>end:continue
   q=(right+left)/2
   ix=bisect_left(t,q);index=max(0,min(ix,len(t)-1))
   if index and abs(t[index-1]-q)<abs(t[index]-q):index-=1
   r=raw[index];leg=int(r['leg'])
   region=names[leg]
   start=points[leg];goal=points[leg+1];v=(goal[0]-start[0],goal[1]-start[1]);total=math.hypot(*v)
   offset=(float(r['x'])-start[0])*v[0]/total+(float(r['y'])-start[1])*v[1]/total
   box=min(int(total//100),max(0,int(offset//100)))
   boxes.setdefault((key,leg,box),[]).append(ms);rollup.setdefault((key,region),[]).append(ms)
   intervals.append(ms)
  out.setdefault(key,[]).extend(intervals);all_laps[lap]=metrics(intervals)
 first=starts[1]
 pre=[ms for q,ms in pm if q-ms*freq/1000>=ready and q<=first]
 launcher=meta['launcher_begin']['qpc']
 result={'ready_from_launcher_s':round((ready-launcher)/freq,4),'ready_to_walk_s':round((first-ready)/freq,4),'launch_to_walk_s':round((first-launcher)/freq,4),'prewalk':metrics(pre),'by_condition':{k:metrics(v) for k,v in out.items()},'by_region':{'/'.join(k):metrics(v) for k,v in rollup.items()},'by_lap':all_laps}
 target=output/'bin_comparison.csv'
 with target.open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=['condition','leg','bin100cm','n','fps','p95','p99','max','over','excess_ms']);w.writeheader()
  for (phase,leg,box),ds in sorted(boxes.items()):w.writerow(dict(condition=phase,leg=leg,bin100cm=box,**metrics(ds)))
 (output/'comparison.json').write_text(json.dumps(result,indent=2),encoding='utf8')
 return result
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('folder',type=Path);parser.add_argument('--out',type=Path);u=parser.parse_args()
 print(json.dumps(analyze(u.folder,u.out),indent=2))
