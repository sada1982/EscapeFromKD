from datetime import datetime
from pathlib import Path
import collections,csv,json,statistics
t=Path('Saved/Automation/GateVerify_20261117')
def read(f):
    with f.open(encoding='utf-8-sig',newline='') as ptr: return list(csv.DictReader(ptr,skipinitialspace=True))
for p in sorted(t.iterdir()):
    if not (p/'route/events.csv').is_file() or not (p/'gpu_native.csv').is_file(): continue
    a=json.loads((p/'telemetry.json').read_text())['start']
    e=read(p/'route/events.csv')
    spans={}
    for r in e:
        stamp=a['utc_epoch_ns']/1e9+(int(r['qpc'])-a['qpc'])/a['frequency']
        if r['event']=='lap_start':
            start=stamp
        elif r['event']=='lap_end':
            spans[int(r['lap'])]=start,stamp
    env=collections.defaultdict(lambda:collections.defaultdict(list))
    for r in read(p/'gpu_native.csv'):
        try:stamp=datetime.strptime(r['timestamp'],'%Y/%m/%d %H:%M:%S.%f').timestamp()
        except ValueError:continue
        leg=next((n for n,(b,e) in spans.items() if b<=stamp<=e),None)
        if leg is None:continue
        for lookup,key in [('clocks.current.graphics','gpu_mhz'),('temperature.gpu','temp_degC'),('power.draw','board_w'),('memory.used','total_adapter_memory_mib'),('utilization.gpu','total_adapter_gpu_pct')]:
            field=next((k for k in r if k.startswith(lookup)),None)
            if not field:continue
            try:val=float(r[field].split()[0])
            except (ValueError,AttributeError):continue
            env['First' if leg==1 else 'Warm'][key].append(val)
    env={k:{n:dict(samples=len(v),min=min(v),median=statistics.median(v),max=max(v)) for n,v in z.items()} for k,z in env.items()}
    if env: (p/'environment.json').write_text(json.dumps(env,indent=2),encoding='utf8')
    print(p.name,[(k,z.get('gpu_mhz',{}).get('median'),z.get('temp_degC',{}).get('median')) for k,z in env.items()])
