from pathlib import Path
import sys,json
import numpy as np
r=Path(__file__).resolve().parent
sys.path.insert(0,str(r.parent/'Light54_20261116'))
from aggregate_light import sample,read_capture,labeled_masks
from PIL import Image
out={}
for p in sorted((r.parents[2]/'Saved/Profiling/CSV').glob('Shade17_*.csv')):
 try:
  d=read_capture(p); masks=labeled_masks(d);masks.update(center=(d['View/PosX']>350)&(d['View/PosY']<-420)&(d['View/PosY']>-780),exit=(d['View/PosX']>0)&(d['View/PosX']<350))
  values={k:sample(d,m) for k,m in masks.items() if m.any()}
  name=p.stem[8:];out[name]=values
  print(name,[(k,values['classroom'][k]) for k in ['gpu_ms','shadow_ms','shadow_instances_non_nanite','p95_ms','over_pct']], 'center,exit',[(v,values[v]['shadow_ms']) for v in ['center','exit']])
 except Exception as e:print(p.name,type(e),e)
(r/'measured.json').write_text(json.dumps(out,indent=2),encoding='utf8')
for p in r.glob('shot_W2PlazaN1*'):
 q=p.with_name(p.name.replace('W2PlazaN1','W2RefA'))
 if q.exists():
  a=np.asarray(Image.open(q).convert('RGB'),dtype=np.float32);b=np.asarray(Image.open(p).convert('RGB'),dtype=np.float32); print(p.name,'MAE',abs(a-b).mean())
