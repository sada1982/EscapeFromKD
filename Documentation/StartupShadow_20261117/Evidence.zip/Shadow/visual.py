from pathlib import Path
import numpy as np
from PIL import Image
import json,sys,itertools
r=Path(__file__).resolve().parent
rois={'feet':{'desk_left':(84,134,140,167),'chair_front':(150,224,216,265),'chair_mid':(167,149,218,181)},'wheels':{'desk_left':(66,95,122,122),'desk_front':(145,240,228,267),'chair_left':(15,124,55,161)}}
def stats(a,b):
 d=b-a; h,w=d.shape[:2]; m=d[:h//8*8,:w//8*8].reshape(h//8,8,w//8,8,3).mean(axis=(1,3));err=abs(m).mean(axis=2)
 return [float(np.mean(err)),float(np.percentile(err,95)),float(np.mean(m@[.2126,.7152,.0722]))]
def read(p):return np.asarray(Image.open(p).convert('RGB'),dtype=np.float32)
allstats={}
for ref,variant in itertools.combinations(sorted(p.name[5:-9] for p in r.glob('shot_*_feet.png')),2):
 result={};delta=[]
 for view in ('feet','wheels','gallery','plaza2'):
  paths=[r/f'shot_{tag}_{view}.png' for tag in (ref,variant)]
  if not all(p.is_file() for p in paths):continue
  a,b=map(read,paths); result[view]={'whole':stats(a,b)}
  for name,(x,y,X,Y) in rois.get(view,{}).items():
   measure=stats(a[4*y:4*Y,4*x:4*X],b[4*y:4*Y,4*x:4*X]); result[view][name]=measure;delta.append(measure[0])
 key=ref+' vs '+variant;allstats[key]={'roi_mae':np.mean(delta),'results':result}
 print(key,round(np.mean(delta),3),'whole-8px',[round(v['whole'][0],3) for v in result.values()])
(r/'contacts_all.json').write_text(json.dumps(allstats,indent=2),encoding='utf8')
