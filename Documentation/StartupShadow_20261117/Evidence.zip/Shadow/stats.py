import json,csv,sys,statistics
from pathlib import Path
r=Path(__file__).resolve().parent
keys=['GPUTime','GPU/ShadowDepths','GPU/MegaLights','VSM/ALLOCATED_NEW','VSM/STATIC_CACHED_PAGES','VSM/DYNAMIC_CACHED_PAGES','VSM/STATIC_INVALIDATED_PAGES','VSM/DYNAMIC_INVALIDATED_PAGES','VSM/WPO_CONSIDERED_PAGES','VSM/NON_NANITE_INSTANCES_DRAWN','VSM/REQUESTED_THIS_FRAME_PAGES']
out={}
for tag in sys.argv[1:]:
 p=r.parents[2]/'Saved/Profiling/CSV'/('Shade17_'+tag+'.csv')
 if not p.is_file():continue
 groups={'classroom':[], 'center':[], 'exit':[],'gallery':[],'lobby':[],'downstairs':[]}
 for row in csv.DictReader(p.open(encoding='utf-8-sig')):
  try:x=float(row['View/PosX']);y=float(row['View/PosY'])
  except (KeyError,ValueError,TypeError):continue
  if x>=0:groups['classroom'].append(row)
  if x>350 and -780<y<-420:groups['center'].append(row)
  if 0<x<350:groups['exit'].append(row)
  if -860<x<0:groups['gallery'].append(row)
  elif -1650<x<=-860:groups['lobby'].append(row)
  elif x<=-1650:groups['downstairs'].append(row)
 regions={}
 for name,g in groups.items():
  if not g:continue
  regions[name]={'count':len(g)}
  for key in keys:
   vec=[float(row[key]) for row in g if row.get(key) and (float(row[key])>0 or key not in ['GPUTime','GPU/ShadowDepths','GPU/MegaLights'])]
   if vec:regions[name][key]=round(statistics.mean(vec),4)
 out[tag]=regions
 print(tag,[(name,regions[name]['GPUTime'],regions[name]['GPU/ShadowDepths']) for name in ('classroom','center','exit') if name in regions])
(r/'shadow_stats.json').write_text(json.dumps(out,indent=2),encoding='utf8')
