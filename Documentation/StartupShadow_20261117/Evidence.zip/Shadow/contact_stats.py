from pathlib import Path
import json,sys
import numpy as np
from PIL import Image
r=Path(__file__).resolve().parent
rois={'feet':{'desk_left':(84,134,140,167),'chair_front':(150,224,216,265),'chair_mid':(167,149,218,181)},'wheels':{'desk_left':(66,95,122,122),'desk_front':(145,240,228,267),'chair_left':(15,124,55,161)}}
out={}
for tag in ['W4Ref2','W4PlazaNanite','W4PlazaSplit','W4RoomsSplit','W4SplitBoth','W4NaniteRooms','W4Proxy']:
 result={}
 for view in ['feet','wheels','gallery','plaza2']:
  if not (r/f'shot_{tag}_{view}.png').is_file():continue
  with Image.open(r/f'shot_W4Ref1_{view}.png') as a,Image.open(r/f'shot_{tag}_{view}.png') as b:
   if a.size!=b.size or a.size!=(1920,1080):raise RuntimeError((a.size,b.size))
   aa=np.asarray(a.convert('RGB'),dtype=np.int16);bb=np.asarray(b.convert('RGB'),dtype=np.int16)
   dif=(bb-aa)
   def measure(v):
    h,w=v.shape[:2]; cells=v[:h//8*8,:w//8*8].reshape(h//8,8,w//8,8,3).mean(axis=(1,3))
    return {'mae':round(float(abs(cells).mean()),4),'p95':round(float(np.percentile(abs(cells).mean(axis=2),95)),4),'luma_signed':round(float(cells.mean(axis=(0,1))@[0.2126,.7152,.0722]),4)}
   result[view]={'whole':measure(dif)}
   for label,(x,y,X,Y) in rois.get(view,{}).items():result[view][label]=measure(dif[4*y:4*Y,4*x:4*X])
 out[tag]={'mean_roi_mae_255':round(float(np.mean([result[k][label]['mae'] for k in rois for label in rois[k]])),4),'views':result}
 print(tag,out[tag]['mean_roi_mae_255'],[result[v]['whole']['mae'] for v in result])
(r/'shadow_contact_stats.json').write_text(json.dumps({'reference':'W4Ref1','rois_480x270':rois,'pixel_channel_range':[0,255],'input_size':[1920,1080],'cell_edge_pixels':8,'measures':out},indent=2),encoding='utf8')
