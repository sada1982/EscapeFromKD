import csv
import json
import statistics
import sys
from bisect import bisect_left, bisect_right
from collections import Counter
from datetime import datetime
from pathlib import Path

here = Path(__file__).resolve().parent
prior = here.parent/'ExitFirst_20261117'
current = here.parent/'StairWarm_20261117'
selected = sys.argv[1:]

def records(path):
    with path.open(encoding='utf-8-sig', newline='') as file:
        return list(csv.DictReader(file, skipinitialspace=True))

def inspect(path):
    anchor = json.loads((path/'telemetry.json').read_text())['start']
    freq = anchor['frequency']
    clock = lambda q: anchor['utc_epoch_ns'] / 1e9 + (q-anchor['qpc'])/freq
    raw = records(path/'gpu_native.csv')
    sensor = []
    for sample in raw:
        try:
            utc = datetime.strptime(sample['timestamp'], '%Y/%m/%d %H:%M:%S.%f').timestamp()
            sensor.append((utc, int(sample['memory.used [MiB]'].split()[0])))
        except (KeyError, ValueError, AttributeError):
            continue
    steps = [(a[0],b[0],b[1]-a[1]) for a,b in zip(sensor,sensor[1:]) if b[1] - a[1] <= -128]
    gtimes = [a[0] for a in sensor]
    metadata = json.loads((path/'route/isolation.json').read_text(encoding='utf-8-sig'))
    pid=metadata['pid']
    launched=datetime.fromisoformat(metadata['utc_start']).timestamp()
    poses=records(path/'route/frames.csv')
    poses_q=[int(a['qpc']) for a in poses]
    events=records(path/'route/events.csv')
    first={int(e['lap']):int(e['qpc']) for e in events if e['event']=='lap_start'}
    last={int(e['lap']):int(e['qpc']) for e in events if e['event']=='lap_end'}
    dx = [r for r in records(path/'presents_native.csv') if r['Runtime']=='DXGI' and int(r['ProcessID'])==pid and int(r['SwapChainAddress'],16)]
    primary = Counter(r['SwapChainAddress'] for r in dx if first[1]<=int(r['QPCTime'])<=last[max(last)]).most_common(1)[0][0]
    dx = [r for r in dx if r['SwapChainAddress']==primary]
    totals=Counter()
    peaks=[]
    max_delta=0
    target_peaks={}
    for previous,next_row in zip(dx,dx[1:]):
        start,end=int(previous['QPCTime']),int(next_row['QPCTime'])
        ms=(end-start)*1000/freq
        if ms<=0: continue
        mid=(start+end)/2
        k=min(len(poses)-1,bisect_left(poses_q,mid))
        if k and mid-poses_q[k-1]<=poses_q[k]-mid:k-=1
        p=poses[k]; lap=int(p['lap']); leg=int(p['leg'])
        if lap<2 or start<first[lap] or end>last[lap]:continue
        max_delta=max(max_delta,abs(ms-float(next_row['msBetweenPresents'])))
        utc=clock(mid)
        overlap=[(a,b,d) for a,b,d in steps if a<=utc<=b+0.50]
        api=float(previous['msInPresentAPI'])
        ratio=min(api,ms)/ms
        near=0<=(-876-float(p['x']))<=50 and leg==5
        info={'run':path.name,'lap':lap,'leg':leg,'x':p['x'],'y':p['y'],'yaw':p['yaw'],
              'q0':start,'q1':end,'ms':round(ms,4),'start_api_ms':round(api,4),'api_fraction':round(ratio,4),
              'process_age_s':round(utc-launched,3),'lap_age_s':round((mid-first[lap])/freq,3),
              'sensor_memory_drop_mib_in_nearby_sample':min([x[2] for x in overlap],default=0),
              'nearest_sensor_poll_s':round(min([abs(t-utc) for t in gtimes],default=10000),3),
              'entry_0_50cm':near}
        if near and (lap not in target_peaks or target_peaks[lap]['ms']<ms):target_peaks[lap]=info
        totals['frames']+=1
        totals['all_near_mem_drop']+=bool(overlap)
        totals['all_at_sensor_poll_50ms']+=info['nearest_sensor_poll_s']<=.050
        totals['target_frames']+=near
        if ms>33.3333:
            peaks.append(info)
            totals['long_33ms']+=1
            totals['long_near_mem_drop']+=bool(overlap)
            totals['long_at_sensor_poll_50ms']+=info['nearest_sensor_poll_s']<=.050
            totals['long_with_most_time_in_api']+=ratio>=.5
            totals['long_50ms']+=ms>=50
            totals['long_in_entry']+=near
    assert max_delta < .05, (path.name,max_delta)
    return dict(name=path.name,swapchain=primary,warm_laps=len(last)-1,counts=dict(totals),
                nearby_adapter_drop_windows=[[round(a-launched,3),round(b-launched,3),d] for a,b,d in steps if a<=clock(last[max(last)]) and b>=clock(first[2])],
                peak_by_target_lap=list(target_peaks.values()),warm_above_33ms=peaks)

groups=[]
for name in selected:
    folder=current/name if (current/name).is_dir() else prior/name
    groups.append(inspect(folder))
(here/'timing_context.json').write_text(json.dumps(groups,indent=2),encoding='utf-8')
for g in groups:print(g['name'],g['warm_laps'],g['counts'],[(i['lap'],i['leg'],i['ms'],i['start_api_ms']) for i in g['warm_above_33ms']][:15])
