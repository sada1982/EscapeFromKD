import bisect
import csv
import json
import math
import statistics
import sys
from collections import Counter, defaultdict
from pathlib import Path

run = Path(sys.argv[1]).resolve()
out = Path(sys.argv[2]).resolve() if len(sys.argv) > 2 else run
out.mkdir(exist_ok=True, parents=True)
names = ["classroom_aisle", "classroom_exit", "gallery", "connector", "lobby_turn",
         "stair_approach", "stair_turn", "downstairs"]
frequency = json.loads((run/"telemetry.json").read_text(encoding="utf8"))["start"]["frequency"]
pid = json.loads((run/"route/isolation.json").read_text(encoding="utf8"))["pid"]
def rows(path):
    with (run/path).open(encoding="utf-8-sig", newline="") as input_file:
        return list(csv.DictReader(input_file))

events = rows("route/events.csv")
poses = rows("route/frames.csv")
qs = [int(row["qpc"]) for row in poses]
records = [row for row in rows("presents_native.csv") if int(row["ProcessID"]) == pid
           and row["Runtime"] == "DXGI" and int(row["SwapChainAddress"], 16)]
chain = Counter(row["SwapChainAddress"] for row in records).most_common(1)[0][0]
pm = sorted((row for row in records if row["SwapChainAddress"] == chain), key=lambda row: int(row["QPCTime"]))
spans = {}
for row in events:
    if row["event"] in ("lap_start", "lap_end"):
        spans.setdefault(int(row["lap"]), {})[row["event"]] = int(row["qpc"])
target = (-893.732, 320.632)
def nearest(q):
    i = min(len(qs)-1, bisect.bisect_left(qs, q))
    if i and abs(qs[i-1]-q) < abs(qs[i]-q):
        i -= 1
    return i

def metrics(items):
    vals = sorted(f["present_ms"] for f in items)
    n = len(vals)
    if not n:
        return dict(n=0)
    peak = max(items, key=lambda f: f["present_ms"])
    return dict(n=n, fps=round(1000/statistics.mean(vals), 3), p99=round(vals[math.ceil(n*.99)-1], 4),
          max=round(vals[-1], 4), over16p67=sum(x>1000/60 for x in vals), over33=sum(x>1000/30 for x in vals),
          over50=sum(x>50 for x in vals), peak_lap=peak["lap"], peak_region=peak["region"], peak_prev_api=peak["lead_api_ms"],
          peak_gt=peak["gt_bracket_ms"], peak_x=peak["x"], peak_y=peak["y"], peak_q0=peak["q0"])

all_frames = []
for prev, current in zip(pm, pm[1:]):
    a, b = int(prev["QPCTime"]), int(current["QPCTime"])
    mid = (a+b)/2
    j = nearest(mid)
    pose = poses[j]
    lap = int(pose["lap"])
    window = spans.get(lap, {})
    if a < window.get("lap_start", b+1) or b > window.get("lap_end", a-1):
        continue
    leg = int(pose["leg"])
    x, y = float(pose["x"]), float(pose["y"])
    elapsed = (b-a)*1000/frequency
    pm_elapsed = float(current["msBetweenPresents"])
    assert abs(elapsed-pm_elapsed)<.05
    lo = max(0, bisect.bisect_right(qs, a)-1)
    hi = min(len(qs)-1,bisect.bisect_left(qs,b))
    gt = max(((qs[k+1]-qs[k])*1000/frequency for k in range(lo,hi)), default=0)
    lead_api = float(prev["msInPresentAPI"])
    all_frames.append(dict(lap=lap, region=names[leg], leg=leg, q0=a, q1=b, elapsed_s=round((a-window["lap_start"])/frequency, 5),
                    x=x, y=y, z=float(pose["z"]), yaw=float(pose["yaw"]),
                    distance_cm=round(math.hypot(x-target[0],y-target[1]),2), present_ms=round(elapsed, 4),
                    gt_bracket_ms=round(gt, 4), lead_api_ms=round(lead_api, 4),
                    interval_outside_api_ms=round(elapsed-lead_api, 4), next_api_ms=round(float(current["msInPresentAPI"]),4),
                    mode=prev["PresentMode"]))
def subsets(fs):
    yield "all",fs
    for r in names:
        yield r, [f for f in fs if f["region"] == r]
    yield "original_50cm", [f for f in fs if f["distance_cm"]<=50]
    yield "original_100cm", [f for f in fs if f["distance_cm"]<=100]
    yield "original_leg5_50cm", [f for f in fs if f["leg"]==5 and f["distance_cm"]<=50 and abs(f["z"]-98.15)<=10]
    yield "other", [f for f in fs if f["distance_cm"]>100]
summary = {}
for label, frames in [("first",[f for f in all_frames if f["lap"]==1]),
                      ("warm",[f for f in all_frames if f["lap"]>=2])]:
    summary[label] = {scope:metrics(fs) for scope,fs in subsets(frames)}
by_lap = []
for lap in sorted(spans):
    frames = [f for f in all_frames if f["lap"]==lap]
    for scope, contents in subsets(frames):
        by_lap.append(dict(lap=lap, region=scope, **metrics(contents)))
with (out/"stair_by_lap.csv").open("w", encoding="utf-8-sig", newline="") as stream:
    writer = csv.DictWriter(stream,fieldnames=list(dict.fromkeys(k for row in by_lap for k in row)))
    writer.writeheader()
    writer.writerows(by_lap)
with (out/"all_intervals.csv").open("w", encoding="utf-8-sig", newline="") as stream:
    writer = csv.DictWriter(stream,fieldnames=all_frames[0].keys())
    writer.writeheader()
    writer.writerows(all_frames)
long = sorted((f for f in all_frames if f["lap"]>1 and f["present_ms"]>1000/30),key=lambda f:-f["present_ms"])
summary["warm_over_33"] = long
summary["warm_lead_api_over_40"] = sorted((f for f in all_frames if f["lap"]>1 and f["lead_api_ms"]>=40),
                                          key=lambda f:-f["lead_api_ms"])
(out/"stair_summary.json").write_text(json.dumps(summary,indent=2), encoding="utf8")
print(json.dumps({"run":run.name,"warm_all":summary["warm"]["all"],"warm_50cm":summary["warm"]["original_50cm"],
                  "warm_approach":summary["warm"]["stair_approach"],"warm_spikes":len(long)}))
