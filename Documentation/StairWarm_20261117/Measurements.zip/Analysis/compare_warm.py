import csv
import json
import math
import statistics
import sys
from pathlib import Path
from collections import defaultdict

here=Path(__file__).resolve().parent
directory=here.parent/'StairWarm_20261117'
names=sys.argv[1:]
rows_by_group=defaultdict(list)
individual=[]
checks=[]

def read_rows(path):
    with path.open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))

def metric(scope, selection):
    ms=sorted(float(r['present_ms']) for r in selection)
    return dict(scope=scope, passes=len({(r['run'],r['lap']) for r in selection}), n=len(ms),
                p99_ms=ms[math.ceil(len(ms)*.99)-1], max_ms=ms[-1], over_16ms67=sum(v>1000/60 for v in ms),
                over_33ms33=sum(v>1000/30 for v in ms), at_least_50ms=sum(v>=50 for v in ms),
                lead_present_at_least_40ms=sum(float(r['lead_api_ms'])>=40 for r in selection),
                worst_lead_api_ms=max(float(r['lead_api_ms']) for r in selection))

def scope_rows(rows):
    yield 'target_leg5_radius50cm', [r for r in rows if r['leg']=='5' and float(r['distance_cm'])<=50 and abs(float(r['z'])-98.15)<=10]
    yield 'approach_leg5', [r for r in rows if r['leg']=='5']
    yield 'approach_turn_descent_legs5to7', [r for r in rows if int(r['leg'])>=5]
    yield 'whole_route', rows

for name in names:
    d=directory/name
    rows=[dict(r,run=name) for r in read_rows(d/'all_intervals.csv') if int(r['lap'])>=2]
    check=dict(line.split('=',1) for line in (d/'route/result.txt').read_text().splitlines() if '=' in line)
    assert check['success']=='1' and check['reason']=='landing'
    power=json.loads((d/'power_state.json').read_text(encoding='utf-8-sig'))
    assert power['continuous_ac']
    s=json.loads((d/'route/isolation.json').read_text(encoding='utf-8-sig'))
    assert s['desktop']!=s['input_desktop_start']
    code=dict(line.split('=',1) for line in (d/'route/startup_result.txt').read_text().splitlines() if '=' in line)
    assert code['input_restored']=='1' and int(code['exit_cull_requested_qpc'])>0
    checks.append(dict(run=name,pid=s['pid'],ac=power['continuous_ac'],landed=check['reason'],laps=int(check['lap']),dedicated_desktop=True))
    group='diagnostic' if name.startswith('Diag') else 'long_standard' if name.startswith('Baseline') else 'fresh_standard'
    rows_by_group[group].extend(rows)
    if group!='diagnostic':rows_by_group['standard_total'].extend(rows)
    for scope, chosen in scope_rows(rows):
        individual.append({'run':name,**metric(scope,chosen)})
combined=[]
for group, rows in rows_by_group.items():
    for scope, chosen in scope_rows(rows):
        combined.append({'group':group,**metric(scope,chosen)})

for name, group in [('per_run.csv',individual),('combined.csv',combined),('tested.csv',checks)]:
    with (here/name).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(group[0]));w.writeheader();w.writerows(group)
print(*[r for r in combined if r['scope']=='target_leg5_radius50cm'],sep='\n')
