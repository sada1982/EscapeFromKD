"""Offline check of waypoint 4→5 from all specified historical captures."""
import bisect
import argparse
import collections
import csv
import json
import math
import statistics
from pathlib import Path

root=Path(__file__).resolve().parent
old=root.parent/'RouteHitchVerify_20261117'
recent=root.parent/'ExitFirst_20261117'
spot=(-893.732,320.632,98.15,-247.295)
groups={
    'H_long':[old/'H11',old/'H11rev'], 'J_long':[old/'J11',old/'J11rev'],
    'J_short':[recent/'J_Formal1',recent/'J_Formal2'],
    'Direct_on':[recent/('Direct_On'+str(n)) for n in (1,2,3)],
    'Direct_off':[recent/('Direct_Off'+str(n)) for n in (1,2,3)],
    'Release_on':[recent/n for n in ('Clean_On1','Clean_On2','Clean_On3','Copied_On1','Copied_On2')],
    'Release_off':[recent/n for n in ('Clean_Off1','Clean_Off2','Clean_Off3','Copied_Off1','Copied_Off2')]}


def rows(file):
    with file.open(encoding='utf-8-sig',newline='') as src:
        return list(csv.DictReader(src))


def maximum(data,k):
    return round(max(x[k] for x in data),4) if data else None


def metrics(data):
    if not data:return dict(n=0)
    s=sorted(d['ms'] for d in data)
    return dict(n=len(s),p99=round(s[math.ceil(.99*len(s))-1],4),max_ms=round(s[-1],4),
                over16=sum(v>1000/60 for v in s),over33=sum(v>100/3 for v in s),over50=sum(v>50 for v in s),
                max_start_api=maximum(data,'api'),max_gt_tick=maximum(data,'gt_ms'))


def save_csv(p,data):
    names=list(dict.fromkeys(k for row in data for k in row))
    with p.open('w',newline='',encoding='utf8') as fp:
        writer=csv.DictWriter(fp,fieldnames=names);writer.writeheader();writer.writerows(data)


def selected(d):
    leg=d['leg']; x,y,z,yaw=(d[k] for k in ('x','y','z','yaw'))
    dist=math.hypot(x-spot[0],y-spot[1]); view=abs((yaw-spot[3]+180)%360-180)
    scopes=['route']
    if leg>=5:scopes.append('stair_legs5to7')
    if leg==5:
        scopes.append('stair_approach')
        if 0<=-876.0-x<100:scopes.append('entry_0to100cm')
        if dist<=50 and abs(z-spot[2])<=10:
            scopes.append('within50cm')
            if view<=20:scopes.append('within50cm_yaw20')
            if dist<=25:scopes.append('within25cm')
    return scopes


def examine(path):
    frequency=json.loads((path/'telemetry.json').read_text())['start']['frequency']
    pid=json.loads((path/'route/isolation.json').read_text(encoding='utf8'))['pid']
    frames=rows(path/'route/frames.csv')
    bylap=collections.defaultdict(list)
    for z in frames:bylap[int(z['lap'])].append(z)
    events=rows(path/'route/events.csv')
    presents=rows(path/'presents_native.csv')
    # Main DXGI swap chain. Rows with address zero describe the composed display stream.
    presents=[p for p in presents if int(p['ProcessID'])==pid and p['Runtime']=='DXGI' and int(p['SwapChainAddress'],16)]
    primary=collections.Counter(p['SwapChainAddress'] for p in presents).most_common(1)[0][0]
    ch=sorted((p for p in presents if p['SwapChainAddress']==primary),key=lambda p:int(p['QPCTime']))
    observed=[]
    for lap,fr in bylap.items():
        qr=[int(w['qpc']) for w in fr]
        a=int(next(w['qpc'] for w in events if int(w['lap'])==lap and w['event']=='lap_start'))
        b=int(next(w['qpc'] for w in events if int(w['lap'])==lap and w['event']=='lap_end'))
        for p,e in zip(ch,ch[1:]):
            q0,q1=int(p['QPCTime']),int(e['QPCTime'])
            if q0<a or q1>b:continue
            delta=(q1-q0)*1000/frequency
            if abs(delta-float(e['msBetweenPresents']))>0.002:continue
            middle=(q0+q1)/2
            t=min(len(fr)-1,bisect.bisect_left(qr,middle))
            if t and middle-qr[t-1] < qr[t]-middle:t-=1
            start=max(0,bisect.bisect_right(qr,q0)-1);end=min(len(qr)-1,bisect.bisect_left(qr,q1))
            gt=max(((qr[i+1]-qr[i])*1000/frequency for i in range(start,end)),default=0)
            w=fr[t]
            info=dict(lap=lap,leg=int(w['leg']),qpc0=q0,qpc1=q1,ms=delta,api=float(p['msInPresentAPI']),end_api=float(e['msInPresentAPI']),gt_ms=gt)
            info.update({k:float(w[k]) for k in ('x','y','z','yaw')})
            observed.append(info)
    return observed


def run(conditions,output):
    framegroups=collections.defaultdict(list);perlap=[];long=[];idset=set()
    for label,dirs in conditions.items():
        for path in dirs:
            frames=examine(path)
            assert frames and frames[0]['qpc0'] not in idset
            idset.add(frames[0]['qpc0'])
            laps=collections.defaultdict(list)
            for fr in frames:
                for scope in selected(fr):
                    framegroups[label,fr['lap']==1,scope].append(fr)
                    laps[fr['lap'],scope].append(fr)
                if fr['ms']>100/3:long.append(dict(group=label,run=path.name,**fr))
            for (lap,scope),data in laps.items():
                worst=max(data,key=lambda w:w['ms'])
                perlap.append(dict(group=label,run=path.name,lap=lap,phase='First' if lap==1 else 'Warm',
                                   scope=scope,**metrics(data),max_at_x=worst['x'],max_at_y=worst['y'],
                                   max_at_leg=worst['leg'],api_at_max=worst['api'],gt_at_max=round(worst['gt_ms'],4)))
    aggregate=[]
    for (group,first,scope),frames in framegroups.items():
        subset=[w for w in perlap if w['group']==group and (w['lap']==1)==first and w['scope']==scope]
        aggregate.append(dict(group=group,phase='First' if first else 'Warm',scope=scope,passes=len(subset),
                              passes_over33=sum(w['over33']>0 for w in subset),passes_over50=sum(w['over50']>0 for w in subset),**metrics(frames)))
    output.mkdir(parents=True,exist_ok=True)
    save_csv(output/'historical_crossings.csv',perlap);save_csv(output/'historical_summary.csv',aggregate);save_csv(output/'over33.csv',long)
    for v in aggregate:
        if v['phase']=='Warm' and v['scope'] in ('within50cm','entry_0to100cm','stair_approach','stair_legs5to7'):
            print(v['group'],v['scope'],v['passes'],v['n'],v['p99'],v['max_ms'],v['over33'],v['over50'])


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--group',action='append',nargs='+',metavar='LABEL_OR_PATH',help='Label followed by one or more completed capture directories. Repeat for additional groups.')
    parser.add_argument('--out',type=Path,help='Output directory for the three summary CSVs.')
    args=parser.parse_args()
    conditions=groups
    if args.group:
        conditions={}
        for label,*paths in args.group:
            if not paths or label in conditions:parser.error('Each group needs a unique label and at least one path.')
            conditions[label]=[Path(path).resolve() for path in paths]
    run(conditions,args.out or (root/'selected_runs' if args.group else root))
