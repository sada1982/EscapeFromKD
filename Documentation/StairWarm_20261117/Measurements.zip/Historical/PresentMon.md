# Clean_On2 の Present 計測

`ExitFirst_20261117/Clean_On2/presents_native.csv` の PID 10952 を、同梱された PresentMon 1.8.0 の列定義と照合した。CSV の行番号にはヘッダーを含む。

|行|Runtime|SwapChainAddress|PresentMode|Dropped|QPCTime|msBetweenPresents|msInPresentAPI|msBetweenDisplayChange|
|---:|---|---|---|---:|---:|---:|---:|---:|
|2618|DXGI|0x000001E0549B2DC0|Other|1|1030899124932|11.3649|46.9853|0|
|2619|DXGI|0x000001E0549B2DC0|Other|1|1030899698053|57.3121|0.9036|0|
|2620|Other|0x0000000000000000|Composed: Flip|0|1030899596725|57.0312|0|50.0340|

主アドレスの 57.3121 ms は連続したアプリの Present 開始時刻の差で、最初の呼び出しに 46.9853 ms を費やした。2件とも `Dropped=1` で、1.8.0 が `Presented` と分類できたイベントではない。`msUntilDisplayed=0` は、このフレームを即時に表示したという意味を持たない。[CSV 出力の時刻・状態判定](https://github.com/GameTechDev/PresentMon/blob/v1.8.0/PresentMon/CsvOutput.cpp#L95-L124) [Dropped の変換](https://github.com/GameTechDev/PresentMon/blob/v1.8.0/PresentMon/CsvOutput.cpp#L37-L42)

副記録の 50.0340 ms は PID 10952・アドレス 0 のグループ内で、PresentMon が `Presented` と判定した2件の `ScreenTime` の差。PresentMon は PID と SwapChainAddress で履歴を分ける。アドレス 0 は DXGI スワップチェーンを識別しない。主行と一対一で対応付ける情報はなく、行順も QPC 順とは限らない。[履歴のキー](https://github.com/GameTechDev/PresentMon/blob/v1.8.0/PresentMon/OutputThread.cpp#L250-L275) [カーネル側で初めて観測された Present](https://github.com/GameTechDev/PresentMon/blob/v1.8.0/README.md#L185-L195)

`route/isolation.json` と `route/desktop_windows.json` ではゲームは専用デスクトップ `KDExhibit_38edb21e2a` にあり、入力デスクトップは `Default`。この記録からユーザーが実際のモニターで見た表示停止時間は分からない。GT の Tick 間隔 56.9261 ms の計算と時刻関係は同じフォルダーの `original57.json` に掲載した。
