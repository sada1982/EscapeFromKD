import argparse
import bisect
import collections
import csv
import json
import struct
from pathlib import Path


def rows(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        yield from csv.DictReader(stream)


def layout(schema_path):
    all_fields = collections.defaultdict(list)
    for r in rows(schema_path):
        all_fields[int(r["id"]), int(r["version"])].append((r["name"], int(r["intype"]), int(r["flags"]), int(r["count"])))
    return all_fields


def decoder(fields, pointer):
    formats = {3:"b", 4:"B", 5:"h", 6:"H", 7:"i", 8:"I", 9:"q", 10:"Q",
               11:"f", 12:"d", 13:"I", 15:"16s", 16:"Q" if pointer == 8 else "I", 17:"Q", 18:"16s", 20:"I", 21:"Q"}
    names = []
    fmt = "<"
    for name, kind, flags, count in fields:
        if flags & 7 or count != 1 or kind not in formats:
            break
        names.append(name)
        fmt += formats[kind]
    return names, struct.Struct(fmt)


def read_gpu(folder):
    descriptions = layout(folder / "dxg_schema.csv")
    parse = {}
    header = struct.Struct("<QIIHBBH")
    with (folder / "dxg.raw").open("rb") as stream:
        while data := stream.read(header.size):
            q, pid, tid, event, ver, ptr, length = header.unpack(data)
            body = stream.read(length)
            if len(body) != length:
                raise ValueError("Truncated record")
            key = event, ver, ptr
            if key not in parse:
                parse[key] = decoder(descriptions.get((event, ver), ()), ptr)
            names, fmt = parse[key]
            if fmt.size <= length:
                yield q, pid, event, dict(zip(names, fmt.unpack_from(body)))


def coverage(spans, start, end):
    result = 0
    cursor = start
    for a,b in sorted(spans):
        if b > cursor:
            result += max(0, min(end,b) - max(a,cursor))
            cursor = min(end,b)
    return result


def analyze(folder, run, output):
    player = json.loads((run / "launch_native.json").read_text(encoding="utf-8-sig"))["game_pid"]
    freq = int(next(line.split("=")[1] for line in (run/"route/settings.txt").read_text().splitlines() if line.startswith("qpc_frequency=")))
    cpu = list(rows(folder / "threads.csv"))
    owner = {int(r["pid"]):r["role"] for r in rows(folder / "owners.csv")}
    owner[player] = "game"
    warm = [r for r in rows(run/"all_intervals.csv") if int(r["lap"])>1]
    if not warm:
        raise ValueError("No complete warm lap")
    long = [r for r in warm if float(r["present_ms"])>=30]
    stair = [r for r in warm if int(r["leg"])==5]
    long.extend([max(stair,key=lambda r:float(r["present_ms"])),max(warm,key=lambda r:float(r["lead_api_ms"])),max(warm,key=lambda r:float(r["present_ms"]))])
    near_original = [r for r in stair if float(r["distance_cm"])<=50]
    if near_original:
        high_near = max(near_original,key=lambda r:float(r["present_ms"]))
        long.append(high_near)
        controls = [r for r in near_original if r["lap"]!=high_near["lap"] and
                    (float(r["x"])-float(high_near["x"]))**2+(float(r["y"])-float(high_near["y"]))**2<=20**2]
        if controls: long.append(sorted(controls,key=lambda r:float(r["present_ms"]))[len(controls)//2])
    worst = max(warm,key=lambda r:float(r["present_ms"]))
    matched = [r for r in warm if r["leg"]==worst["leg"] and r["lap"]!=worst["lap"] and
               (float(r["x"])-float(worst["x"]))**2+(float(r["y"])-float(worst["y"]))**2<=25**2]
    if matched: long.append(sorted(matched,key=lambda r:float(r["present_ms"]))[len(matched)//2])
    focus = {int(r["q0"]):r for r in long}
    windows = [(a,int(focus[a]["q1"])) for a in sorted(focus)]
    expanded = [(a-freq//20,b+freq//20) for a,b in windows]
    starts = [a for a,_ in expanded]
    counts = collections.Counter()
    device = {}; contexts = {}; hw = {}; active = {}; spans = []; residency = []; node_types={}
    def keep(a,b):
        n = bisect.bisect_right(starts,b)
        return n>0 and any(e>=a for _,e in expanded[max(0,n-3):n])
    def metadata(ctx, pid):
        dev,node = contexts.get(ctx,(None,None))
        proc,adap = device.get(dev,(None,None))
        return proc or pid,adap,node
    for q,pid,e,d in read_gpu(folder):
        counts[e]+=1
        if e==250 and "EngineType" in d:
            node_types[d["pDxgAdapter"],d["NodeOrdinal"]]=d["EngineType"]
        elif e in (27,29) and "hDevice" in d:
            device[d["hDevice"]] = d["hProcessId"], d["pDxgAdapter"]
        elif e==28:
            device.pop(d.get("hDevice"),None)
        elif e in (30,32) and "hContext" in d:
            contexts[d["hContext"]] = d["hDevice"],d["NodeOrdinal"]
        elif e==31:
            contexts.pop(d.get("hContext"),None)
        elif e in (422,424) and "hHwQueue" in d:
            for name in ("hHwQueue", "ParentDxgHwQueue"):
                if d.get(name): hw[d[name]] = d["hContext"]
        elif e==423:
            hw.pop(d.get("hHwQueue"),None)
            hw.pop(d.get("ParentDxgHwQueue"),None)
        elif e in (178,244,245,175,450):
            typ = "queue" if e in (178,244,245) else "dma" if e==175 else "hardware"
            ctx = d.get("hContext") if e!=450 else hw.get(d.get("hHwQueue"))
            sequence = d.get("SubmitSequence") if typ=="queue" else d.get("uliSubmissionId") if typ=="dma" else d.get("ProgressFenceValue")
            if sequence is None: continue
            src, adapter, node = metadata(ctx,pid if typ=="queue" and pid not in (0,4) else None)
            key=typ, (d.get("hHwQueue") if typ=="hardware" else ctx),sequence
            active[key]=(q,src,adapter,node,e)
        elif e in (180,176,451):
            typ="queue" if e==180 else "dma" if e==176 else "hardware"
            key=(typ,d.get("hHwQueue") if e==451 else d.get("hContext"),
                 d.get("SubmitSequence") if e==180 else d.get("uliCompletionId") if e==176 else d.get("ProgressFenceValue"))
            pending=active.pop(key,None)
            if pending and keep(pending[0],q):
                a,src,adapter,node,kind=pending
                spans.append((a,q,owner.get(src,"other" if src else "unknown"),src,adapter,node,typ,kind))
        elif e in (74,320,321,322,323,324,325,338,339) and keep(q,q):
            residency.append((q,e,pid))
    result=[]
    for a,b in windows:
        groups=collections.defaultdict(list)
        for start,end,role,src,adapter,node,typ,kind in spans:
            if start<b and end>a:
                groups[(role,src,adapter,node,typ,kind)].append((start,end))
        packets=[]
        for (role,pid,adapter,node,typ,kind),intervals in groups.items():
            packets.append(dict(owner=role,pid=pid,adapter=adapter,node=node,engine_type=node_types.get((adapter,node)),source=typ,submit_event=kind,
                n=len(intervals),start_in_window=sum(a<=s<b for s,e in intervals),end_in_window=sum(a<e<=b for s,e in intervals),
                outstanding_wall_ms=round(coverage(intervals,a,b)*1000/freq,3),
                longest_lifecycle_ms=round(max(e-s for s,e in intervals)*1000/freq,3)))
        near=[r for r in cpu if a-freq//50 <= int(r["qpc_end"]) <= b+freq//50]
        mem=collections.Counter((e,pid) for q,e,pid in residency if a<=q<=b)
        result.append(dict(frame=focus[a],packets=packets,thread_samples=near,residency_events=[dict(event_id=e,header_pid=pid,n=n) for (e,pid),n in mem.items()]))
    state=(folder/"dxg_state.txt").read_text().splitlines()
    if (run/"process.csv").exists():
        processes=list(rows(run/"process.csv"))
        moments=[int(r["qpc"]) for r in processes]
        pending_pso={}
        creations=[]
        for entry in rows(run/"pso.csv"):
            t,tid=int(entry["qpc"]),entry["tid"]
            if entry["event_id"]=="155": pending_pso[tid]=t
            if entry["event_id"]=="156" and tid in pending_pso: creations.append((pending_pso.pop(tid),t))
        for entry in result:
            a,b=int(entry["frame"]["q0"]),int(entry["frame"]["q1"])
            index_a=bisect.bisect_right(moments,a)-1
            index_b=bisect.bisect_left(moments,b)
            entry["pso_overlap_count"]=sum(begin<b and end>a for begin,end in creations)
            if index_a<0 or index_b>=len(processes): continue
            before,after=processes[index_a],processes[index_b]
            valid_evict=before["eviction_status"]=="0" and after["eviction_status"]=="0"
            valid_budget=before["local_status"]=="0" and after["local_status"]=="0"
            entry["process_sample_bracket"]={
                "span_ms":round((moments[index_b]-moments[index_a])*1000/freq,3),
                "read_bytes":int(after["read_bytes"])-int(before["read_bytes"]),
                "evicted_process_delta":int(after["evicted_process"])-int(before["evicted_process"]) if valid_evict else None,
                "local_headroom_after_bytes":int(after["local_budget"])-int(after["local_usage"]) if valid_budget else None}
    output.write_text(json.dumps(dict(trace_state=state,event_counts=counts,frequency=freq,windows=result),indent=2),encoding="utf-8")


if __name__ == "__main__":
    cli=argparse.ArgumentParser()
    cli.add_argument("queue",type=Path)
    cli.add_argument("run",type=Path)
    cli.add_argument("output",type=Path)
    args=cli.parse_args()
    analyze(args.queue,args.run,args.output)
