#include <windows.h>
#include <evntrace.h>
#include <evntcons.h>
#include <tdh.h>
#include <winternl.h>
#include <set>
#include <map>
#include <algorithm>
#include <cstdio>
#include <filesystem>
#include <string>
#include <vector>
#include <cstring>
namespace fs = std::filesystem;
const GUID Dxg = {0x802ec45a,0x1e99,0x4b83,{0x99,0x20,0x87,0xc9,0x82,0x77,0xba,0x9d}};
const USHORT Ids[] = {24,25,26,27,28,29,30,31,32,74,175,176,177,178,179,180,185,244,245,250,320,321,322,323,324,325,338,339,422,423,424,450,451,469,470};
FILE* raw = nullptr;
FILE* schema = nullptr;
std::set<unsigned> versions;
unsigned long long records = 0;
#pragma pack(push,1)
struct Header { ULONGLONG qpc; ULONG pid,tid; USHORT id; UCHAR version,pointerBytes; USHORT length; };
#pragma pack(pop)
void WINAPI OnEvent(EVENT_RECORD* record)
{
    const auto& h = record->EventHeader;
    if (!IsEqualGUID(h.ProviderId,Dxg)) return;
    bool selected = false;
    for (auto id : Ids) if (id == h.EventDescriptor.Id) { selected = true; break; }
    if (!selected) return;
    const unsigned key = (unsigned(h.EventDescriptor.Id)<<8) | h.EventDescriptor.Version;
    if (versions.insert(key).second)
    {
        ULONG size = 0;
        if (TdhGetEventInformation(record,0,nullptr,nullptr,&size) == ERROR_INSUFFICIENT_BUFFER)
        {
            std::vector<unsigned char> data(size);
            auto* info = reinterpret_cast<TRACE_EVENT_INFO*>(data.data());
            if (TdhGetEventInformation(record,0,nullptr,info,&size) == ERROR_SUCCESS)
                for (unsigned i=0; i<info->TopLevelPropertyCount; ++i)
                {
                    const auto& p = info->EventPropertyInfoArray[i];
                    fprintf(schema,"%u,%u,%u,%lu,%u,%u,%u,%ls\n",h.EventDescriptor.Id,h.EventDescriptor.Version,
                        i,(unsigned long)p.Flags,p.nonStructType.InType,p.count,p.length,(wchar_t*)(data.data()+p.NameOffset));
                }
        }
    }
    Header item{(ULONGLONG)h.TimeStamp.QuadPart,h.ProcessId,h.ThreadId,h.EventDescriptor.Id,h.EventDescriptor.Version,
        (UCHAR)((h.Flags & EVENT_HEADER_FLAG_32_BIT_HEADER) ? 4 : 8),record->UserDataLength};
    fwrite(&item,sizeof(item),1,raw);
    fwrite(record->UserData,1,item.length,raw);
    ++records;
}
int Extract(const fs::path& dir)
{
    std::wstring path = (dir/L"dxg.etl").wstring();
    EVENT_TRACE_LOGFILEW source{};
    source.LogFileName = path.data();
    source.ProcessTraceMode = PROCESS_TRACE_MODE_EVENT_RECORD | PROCESS_TRACE_MODE_RAW_TIMESTAMP;
    source.EventRecordCallback = OnEvent;
    TRACEHANDLE input = OpenTraceW(&source);
    if (input == INVALID_PROCESSTRACE_HANDLE) return 2;
    raw = _wfopen((dir/L"dxg.raw").c_str(),L"wb");
    if (!raw) { CloseTrace(input); return 3; }
    schema = _wfopen((dir/L"dxg_schema.csv").c_str(),L"wb");
    if (!schema) { fclose(raw); CloseTrace(input); return 3; }
    fprintf(schema,"id,version,index,flags,intype,count,length,name\n");
    ULONG status = ProcessTrace(&input,1,nullptr,nullptr);
    fclose(raw);
    fclose(schema);
    CloseTrace(input);
    printf("parsed=%lu selected=%llu frequency=%lld\n",status,records,source.LogfileHeader.PerfFreq.QuadPart);
    return status ? 4 : 0;
}
static unsigned long long Qpc()
{
    LARGE_INTEGER time{}; QueryPerformanceCounter(&time); return time.QuadPart;
}
struct Thread { HANDLE handle=nullptr; std::wstring label; };
static void SampleThreads(HANDLE game,DWORD pid,const fs::path& dir)
{
    using Query = NTSTATUS (NTAPI*)(SYSTEM_INFORMATION_CLASS,PVOID,ULONG,PULONG);
    auto query = reinterpret_cast<Query>(GetProcAddress(GetModuleHandleW(L"ntdll.dll"),"NtQuerySystemInformation"));
    FILE* f = _wfopen((dir/L"threads.csv").c_str(),L"wb");
    FILE* names = _wfopen((dir/L"owners.csv").c_str(),L"wb");
    if (!query || !f || !names) return;
    fprintf(f,"qpc_begin,qpc_end,tid,thread,state,wait_reason,cycle_count,user_100ns,kernel_100ns\n");
    fprintf(names,"pid,role\n");
    std::map<DWORD,Thread> known; std::set<DWORD> owners;
    std::vector<unsigned char> buf(4*1024*1024);
    for(unsigned i=0; i<24000 && WaitForSingleObject(game,12)==WAIT_TIMEOUT; ++i)
    {
        const auto a=Qpc();
        ULONG needed=0;
        NTSTATUS status=query(SystemProcessInformation,buf.data(),(ULONG)buf.size(),&needed);
        const auto b=Qpc();
        if(status<0){ if(needed>buf.size())buf.resize(needed+65536); continue; }
        size_t offset=0;
        do {
            auto* pr=reinterpret_cast<SYSTEM_PROCESS_INFORMATION*>(buf.data()+offset);
            const DWORD owner=(DWORD)(ULONG_PTR)pr->UniqueProcessId;
            if(i%100==0 && owners.find(owner)==owners.end() && pr->ImageName.Buffer)
            {
                std::wstring name(pr->ImageName.Buffer,pr->ImageName.Length/2);
                const char* role = owner==pid?"game":_wcsicmp(name.c_str(),L"dwm.exe")==0?"dwm":
                    _wcsicmp(name.c_str(),L"UnrealEditor.exe")==0?"editor":"other";
                fprintf(names,"%lu,%s\n",owner,role); owners.insert(owner);
            }
            if(owner==pid && pr->NumberOfThreads && offset+sizeof(*pr)+pr->NumberOfThreads*sizeof(SYSTEM_THREAD_INFORMATION)<=buf.size())
            {
                auto* t=reinterpret_cast<SYSTEM_THREAD_INFORMATION*>(pr+1);
                auto* mainThread=std::min_element(t,t+pr->NumberOfThreads,[](auto& x,auto& y){return x.Reserved1[2].QuadPart<y.Reserved1[2].QuadPart;});
                for(unsigned j=0;j<pr->NumberOfThreads;++j)
                {
                    DWORD tid=(DWORD)(ULONG_PTR)t[j].ClientId.UniqueThread;
                    auto it=known.find(tid);
                    if(it==known.end() || (it->second.label.empty() && i%100==0))
                    {
                        auto& slot=known[tid];
                        if(!slot.handle)slot.handle=OpenThread(THREAD_QUERY_LIMITED_INFORMATION,FALSE,tid);
                        PWSTR desc=nullptr;
                        if(slot.handle && SUCCEEDED(GetThreadDescription(slot.handle,&desc)) && desc){slot.label=desc;LocalFree(desc);}
                        it=known.find(tid);
                    }
                    auto& th=it->second;
                    const char* label = (&t[j]==mainThread || th.label==L"GameThread")?"game":
                        th.label.find(L"RenderThread")!=std::wstring::npos?"render":
                        th.label.find(L"RHIThread")!=std::wstring::npos?"rhi":nullptr;
                    if(!label || !th.handle) continue;
                    ULONG64 cycles=0;
                    FILETIME c{},x{},u{},k{};
                    QueryThreadCycleTime(th.handle,&cycles);
                    GetThreadTimes(th.handle,&c,&x,&k,&u);
                    auto ft=[](const FILETIME& z){return (ULONGLONG(z.dwHighDateTime)<<32)|z.dwLowDateTime;};
                    fprintf(f,"%llu,%llu,%lu,%s,%lu,%lu,%llu,%llu,%llu\n",a,b,tid,label,t[j].ThreadState,t[j].WaitReason,cycles,ft(u),ft(k));
                }
            }
            if(!pr->NextEntryOffset)break;
            offset+=pr->NextEntryOffset;
        } while(offset+sizeof(SYSTEM_PROCESS_INFORMATION)<buf.size());
    }
    for(auto& entry:known)if(entry.second.handle)CloseHandle(entry.second.handle);
    fclose(f);fclose(names);
}
int Capture(DWORD pid,const fs::path& dir)
{
    fs::create_directories(dir);
    const std::wstring name = L"KD_StairDxg_" + std::to_wstring(GetCurrentProcessId());
    const std::wstring file = fs::absolute(dir/L"dxg.etl").wstring();
    if (fs::exists(file)) return 5;
    HANDLE game = OpenProcess(SYNCHRONIZE,FALSE,pid);
    if (!game) return 6;
    size_t size = sizeof(EVENT_TRACE_PROPERTIES)+(name.size()+file.size()+2)*sizeof(wchar_t);
    std::vector<unsigned char> storage(size,0);
    auto* prop = reinterpret_cast<EVENT_TRACE_PROPERTIES*>(storage.data());
    prop->Wnode.BufferSize = (ULONG)size;
    prop->Wnode.Flags = WNODE_FLAG_TRACED_GUID;
    prop->Wnode.ClientContext = 1;
    prop->LogFileMode = EVENT_TRACE_FILE_MODE_SEQUENTIAL;
    prop->BufferSize = 128;
    prop->MinimumBuffers = 8;
    prop->MaximumBuffers = 80;
    prop->LoggerNameOffset = sizeof(*prop);
    prop->LogFileNameOffset = sizeof(*prop)+(ULONG)(name.size()+1)*sizeof(wchar_t);
    wcscpy_s((wchar_t*)(storage.data()+prop->LogFileNameOffset),file.size()+1,file.c_str());
    TRACEHANDLE session = 0;
    ULONG start = StartTraceW(&session,name.c_str(),prop);
    struct { BOOLEAN included; UCHAR reserved; USHORT count; USHORT ids[_countof(Ids)]; } selected{1,0,_countof(Ids),{}};
    memcpy(selected.ids,Ids,sizeof(Ids));
    EVENT_FILTER_DESCRIPTOR filter{(ULONGLONG)&selected,sizeof(selected),EVENT_FILTER_TYPE_EVENT_ID};
    ENABLE_TRACE_PARAMETERS params{};
    params.Version = ENABLE_TRACE_PARAMETERS_VERSION_2;
    params.EnableFilterDesc = &filter;
    params.FilterDescCount = 1;
    const ULONGLONG keywords = 0x800000 | 0x8000 | 0x400 | 0x80 | 0x40 | 0x04 | 0x01;
    ULONG enabled = start ? start : EnableTraceEx2(session,&Dxg,EVENT_CONTROL_CODE_ENABLE_PROVIDER,TRACE_LEVEL_INFORMATION,keywords,0,1500,&params);
    ULONG rundown = enabled ? enabled : EnableTraceEx2(session,&Dxg,EVENT_CONTROL_CODE_CAPTURE_STATE,TRACE_LEVEL_INFORMATION,keywords,0,1500,&params);
    if (!enabled) SampleThreads(game,pid,dir);
    CloseHandle(game);
    ULONG stopped = start ? start : ControlTraceW(session,nullptr,prop,EVENT_TRACE_CONTROL_STOP);
    FILE* state = _wfopen((dir/L"dxg_state.txt").c_str(),L"wb");
    if (state) { fprintf(state,"start=%lu\nenable=%lu\nrundown=%lu\nstop=%lu\nevents_lost=%lu\nbuffers_lost=%lu\n",start,enabled,rundown,stopped,prop->EventsLost,prop->LogBuffersLost); fclose(state); }
    return enabled || stopped ? 7 : 0;
}
int wmain(int argc,wchar_t** args)
{
    if (argc==4 && !wcscmp(args[1],L"capture")) return Capture(wcstoul(args[2],nullptr,10),args[3]);
    if (argc==3 && !wcscmp(args[1],L"unpack")) return Extract(args[2]);
    return 1;
}
